const mongoose = require("mongoose");

const tripSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  name: { type: String, required: true },
  destination: String,
  // Trip origin (validated location — never free text). Canonical name plus
  // the verified location object (record id, kind, coordinates) for maps,
  // directions, distance and transport planning.
  origin: String,
  originDetails: { type: mongoose.Schema.Types.Mixed },
  startDate: Date,
  endDate: Date,
  notes: String,
  durationDays: { type: Number, min: 1, max: 14 },
  adults: { type: Number, min: 1, max: 12 },
  children: { type: Number, min: 0, max: 12, default: 0 },
  budget: { type: mongoose.Schema.Types.Mixed },
  travelStyle: String,
  interests: [String],
  transportPreference: String,
  accommodationPreference: String,
  foodPreferences: [String],
  itinerary: [mongoose.Schema.Types.Mixed],
  recommendations: { type: mongoose.Schema.Types.Mixed },
  dataAvailability: [String],
  warnings: [String],
  hotelId: { type: mongoose.Schema.Types.ObjectId, ref: "Hotel" },
  hotelName: String,
  hotelLocation: String,
  hotelLatitude: Number,
  hotelLongitude: Number,
  plannedItems: [{
    itemId: { type: String, required: true },
    category: { type: String, required: true },
    name: { type: String, required: true },
    location: String,
    latitude: Number,
    longitude: Number
  }],
  // Snapshot of the services the traveller selected in Plan a Complete Trip
  // (hotel, transport legs, activities, restaurant, party, priced totals).
  // Stored at submit time so admin review, My Bookings, and the trip PDF
  // always show what was actually chosen — never reconstructed estimates.
  selections: { type: mongoose.Schema.Types.Mixed },
  // Bookings created for this trip plan (unified trip summary / My Trips).
  bookingIds: [{ type: mongoose.Schema.Types.ObjectId, ref: "Booking" }],
  // Complete-trip one-payment checkout (Plan a Complete Trip). Standalone
  // trips/bookings leave these unset.
  checkoutPaymentId: { type: mongoose.Schema.Types.ObjectId, ref: "TripPayment" },
  paymentStatus: { type: String, enum: ["unpaid", "paid", "failed"], default: "unpaid" },
  totalAmount: { type: Number, min: 0, max: 10000000 },
  status: { type: String, default: "planned" }
}, { timestamps: true });

module.exports = mongoose.model("Trip", tripSchema);
