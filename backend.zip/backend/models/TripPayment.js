const mongoose = require("mongoose");
const crypto = require("node:crypto");

// Parent checkout record for ONE complete-trip payment (Plan a Complete Trip).
// The traveller selects hotel + transport + activities (+ other services)
// first; this record holds the single grand total. Individual service
// bookings reference it via Booking.paymentId. Demo/sandbox payments are
// recorded with demo: true and NEVER represent real money movement.
const tripPaymentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  tripId: { type: mongoose.Schema.Types.ObjectId, ref: "Trip", required: true, index: true },
  // Human trip reference shown on review / QR / confirmation (SUV-XXXXXX).
  checkoutCode: { type: String, unique: true, required: true, trim: true, maxlength: 20 },
  // Human payment reference (PAY-XXXXXX); every linked booking points here.
  paymentId: { type: String, unique: true, required: true, trim: true, maxlength: 20 },
  paymentMethod: {
    type: String,
    enum: ["esewa", "khalti", "imepay", "fonepay", "connectips", "prabhupay", "namastepay"],
    required: true,
  },
  totalAmount: { type: Number, required: true, min: 0, max: 10000000 },
  currency: { type: String, default: "NPR" },
  // Category totals actually charged (Hotel / Transportation / Activities / Other).
  breakdown: [{
    _id: false,
    category: { type: String, trim: true, maxlength: 40 },
    label: { type: String, trim: true, maxlength: 160 },
    amount: { type: Number, min: 0, max: 10000000 },
  }],
  bookingIds: [{ type: mongoose.Schema.Types.ObjectId, ref: "Booking" }],
  paymentStatus: {
    type: String,
    enum: ["PENDING", "PAID", "FAILED"],
    default: "PENDING",
    required: true,
    index: true,
  },
  // Admin approval mirrors the linked bookings: payment success never
  // auto-approves the trip. Admin accept/reject flips this + every booking.
  approvalStatus: {
    type: String,
    enum: ["pending", "approved", "rejected"],
    default: "pending",
    required: true,
    index: true,
  },
  submittedForApprovalAt: Date,
  approvalDeadline: Date,
  approvedAt: Date,
  approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  rejectedAt: Date,
  rejectedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  rejectionReason: { type: String, trim: true, maxlength: 500 },
  qrPayload: { type: String, trim: true, maxlength: 500 },
  // Provider/demo reference recorded at confirm time.
  referenceId: { type: String, trim: true, maxlength: 100 },
  failureReason: { type: String, trim: true, maxlength: 300 },
  completedAt: Date,
  demo: { type: Boolean, default: true },
}, { timestamps: true });

function randomCode(prefix) {
  return `${prefix}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

tripPaymentSchema.pre("validate", function () {
  if (!this.checkoutCode) {
    this.checkoutCode = randomCode("SUV");
  }
  if (!this.paymentId) {
    this.paymentId = randomCode("PAY");
  }
});

module.exports = mongoose.model("TripPayment", tripPaymentSchema);
