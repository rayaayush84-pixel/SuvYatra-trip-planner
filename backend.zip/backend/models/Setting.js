const mongoose = require("mongoose");

const settingSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", unique: true },
  pushNotifications: { type: Boolean, default: true },
  emailNotifications: { type: Boolean, default: true },
  smsNotifications: { type: Boolean, default: false },
  language: { type: String, default: "English" },
  currency: { type: String, default: "NPR" },
  compactView: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model("Setting", settingSchema);
