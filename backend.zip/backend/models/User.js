const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const NAME_PATTERN = /^[\p{L}\p{M}]+(?:[ '\u2019-][\p{L}\p{M}]+)*$/u;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isStrongPassword(value) {
  return (
    typeof value === "string" &&
    value.length >= 8 &&
    /[A-Z]/.test(value) &&
    /[a-z]/.test(value) &&
    /\d/.test(value) &&
    /[^A-Za-z0-9]/.test(value)
  );
}

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100,
    validate: {
      validator: (value) => NAME_PATTERN.test(value),
      message: "Please enter a valid name.",
    },
  },
  email: {
    type: String,
    unique: true,
    sparse: true,
    lowercase: true,
    trim: true,
    maxlength: 254,
    match: [EMAIL_PATTERN, "Please enter a valid email address."],
  },
  password: {
    type: String,
    required: function () {
      // Google-only accounts are created without a user-chosen password.
      // Email accounts must always have one.
      return this.provider !== "Google";
    },
    minlength: 8,
    select: false,
    validate: {
      validator: isStrongPassword,
      message: "Password must be at least 8 characters and contain at least one uppercase letter, one lowercase letter, one number, and one special character.",
    },
  },
  googleId: { type: String, unique: true, sparse: true, trim: true },
  emailVerified: { type: Boolean, default: false },
  emailVerificationOtpHash: { type: String, select: false },
  emailVerificationExpiresAt: { type: Date, select: false },
  emailVerificationAttempts: { type: Number, default: 0, select: false },
  emailVerificationRequestedAt: { type: Date, select: false },
  passwordResetOtpHash: { type: String, select: false },
  passwordResetExpiresAt: { type: Date, select: false },
  passwordResetAttempts: { type: Number, default: 0, select: false },
  phone: { type: String, unique: true, sparse: true, trim: true },
  appleId: { type: String, unique: true, sparse: true, lowercase: true, trim: true },
  location: String,
  bio: String,
  avatar: String,
  provider: {
    type: String,
    enum: ["Email", "Google", "Facebook", "Apple", "Demo"],
    default: "Email",
  },
  role: {
    type: String,
    enum: ["user", "admin"],
    default: "user",
  },
  status: {
    type: String,
    enum: ["active", "disabled"],
    default: "active",
    index: true,
  },
  memberSince: { type: Date, default: Date.now }
}, { timestamps: true });

userSchema.pre("save", async function(next) {
  if (!this.isModified("password") || !this.password) return next();

  // Google auto-provisioned random secrets are already hashed (see googleLogin).
  if (this.password.startsWith("$2a$") || this.password.startsWith("$2b$")) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function(candidatePassword) {
  if (!this.password) return false;
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model("User", userSchema);
