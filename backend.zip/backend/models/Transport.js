const mongoose = require("mongoose");

const transportSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  type: { type: String, trim: true },
  provider: { type: String, trim: true },
  route: { type: String, trim: true },
  origin: { type: String, trim: true },
  destination: { type: String, trim: true },
  description: String,
  image: String,
  images: [String],
  imageSource: String,
  imageSourcePage: String,
  imageLicense: String,
  imageCredit: String,
  imageDescription: String,
  imageRelevance: { type: String, enum: ["entity", "category"] },
  catalogKey: { type: String, unique: true, sparse: true },
  dataSource: String,
  dataSourceUrl: String,
  departureTime: String,
  arrivalTime: String,
  durationMinutes: { type: Number, min: 0 },
  price: { type: Number, min: 0 },
  currency: { type: String, default: "NPR" },
  capacity: { type: Number, min: 1 },
  serviceMode: { type: String, enum: ["private", "shared", "scheduled", "rental"] },
  // Optional seat map for per-seat booking (destination-agnostic).
  // Seat numbers are generated as `${row}${letter}` (e.g. 1A, 1B) unless explicit seatLabels are set.
  seatMap: {
    rows: { type: Number, min: 1, max: 100 },
    seatsPerRow: { type: Number, min: 1, max: 20 },
    aisleAfter: { type: Number, min: 0, max: 20 },
  },
  seatLabels: [{ type: String, trim: true, maxlength: 10 }],
  amenities: [String],
  cancellationPolicy: String,
  bookingUrl: String,
  contact: { phone: String, website: String },
  latitude: { type: Number, min: -90, max: 90 },
  longitude: { type: Number, min: -180, max: 180 },
  isDemoData: { type: Boolean, default: true, index: true }
}, { timestamps: true });

module.exports = mongoose.model("Transport", transportSchema);
