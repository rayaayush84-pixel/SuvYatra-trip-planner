import React, { useState } from "react";
import { Platform, StyleSheet, View } from "react-native";
import {
  NavigationContainer,
  createNavigationContainerRef,
  NavigatorScreenParams,
} from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";

import * as WebBrowser from "expo-web-browser";

import { AuthProvider } from "./src/auth/AuthContext";
import { AdminAuthProvider } from "./src/auth/AdminAuthContext";
import SplashScreen from "./src/screens/SplashScreen";
import TermsAndConditionsScreen from "./src/screens/TermsAndConditionsScreen";
import MainTabs from "./src/navigation/MainTabs";
import SearchScreen from "./src/screens/SearchScreen";
import HotelListScreen from "./src/screens/HotelListScreen";
import RestaurantListScreen from "./src/screens/RestaurantListScreen";
import TransportScreen from "./src/screens/TransportScreen";
import ChatScreen from "./src/screens/ChatScreen";
import DestinationScreen from "./src/screens/DestinationScreen";
import MapScreen from "./src/screens/MapScreen";
import WeatherScreen from "./src/screens/WeatherScreen";
import RatingScreen from "./src/screens/RatingandreviewScreen";
import LoginScreen from "./src/screens/LoginScreen";
import ForgotPasswordScreen from "./src/screens/ForgotPasswordScreen";
import ResetPasswordScreen from "./src/screens/ResetPasswordScreen";
import VerifyEmailScreen from "./src/screens/VerifyEmailScreen";
import EditProfileScreen from "./src/screens/EditProfileScreen";
import SettingsScreen from "./src/screens/SettingsScreen";
import HelpSupportScreen from "./src/screens/HelpSupportScreen";
import BookingsListScreen from "./src/screens/BookingsListScreen";
import NotificationsScreen from "./src/screens/NotificationsScreen";
import BookingScreen from "./src/screens/BookingScreen";
import AdminLoginActivityScreen from "./src/screens/AdminLoginActivityScreen";
import AdminRegisteredUsersScreen from "./src/screens/AdminRegisteredUsersScreen";
import AdminLoginScreen from "./src/screens/AdminLoginScreen";
import AdminWorkspaceScreen from "./src/screens/AdminWorkspaceScreen";
import HiddenGemsScreen from "./src/screens/HiddenGemsScreen";
import HiddenGemDetailScreen from "./src/screens/HiddenGemDetailScreen";
import { MainTabParamList } from "./src/navigation/MainTabs";
import HotelDetailsScreen from "./src/screens/HotelDetailsScreen";
import PlaceDirectoryScreen from "./src/screens/PlaceDirectoryScreen";
import PlanMyTripScreen from "./src/screens/PlanMyTripScreen";
import DestinationTripScreen from "./src/screens/DestinationTripScreen";


export type HiddenGemDetails = {
  id?: string;
  category?: string;
  name: string;
  location?: string;
  description?: string;
  bookingOptions?: string[];
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  bestTime?: string;
  estimatedCost?: string;
  thingsToDo?: string[];
  accommodation?: string;
  transportation?: string;
  safety?: string;
  nearbyServices?: string[];
  latitude?: number;
  longitude?: number;
  province?: string;
  tags?: string[];
  whyHiddenGem?: string;
  whyVisit?: string;
  howToReach?: string;
  travelTime?: string;
  budgetFriendly?: boolean;
  nearKathmandu?: boolean;
  budgetBreakdown?: {
    transportation?: string;
    accommodation?: string;
    food?: string;
    activities?: string;
    entryFees?: string;
    total?: string;
  };
  food?: string;
  recommendedDuration?: string;
  nearbyAttractions?: string[];
  accommodationDetails?: string;
  transportationOptions?: string[];
};

export type DestinationDetails = {
  id?: number | string;
  name: string;
  location: string;
  rating: string;
  reviews: string;
  description: string;
  bestTime: string;
  price: string;
  image: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  hiddenGems?: (string | HiddenGemDetails)[];
  categories?: string[];
  thingsToDo?: string[];
  estimatedCost?: string;
  accommodation?: string;
  transportation?: string;
  safety?: string;
  nearbyServices?: string[];
  latitude?: number;
  longitude?: number;
};

export type RootStackParamList = {
  Splash: undefined;
  TermsAndConditions: undefined;
  MainTabs: NavigatorScreenParams<MainTabParamList> | undefined;
  Search: undefined;
  Hotels: { location?: string } | undefined;
  HotelDetails: {
    hotelId: string;
    availabilitySearch?: {
      checkIn: string;
      checkOut: string;
      adults: number;
      children: number;
      rooms: number;
    };
  };
  Restaurants: { restaurantId?: string; location?: string } | undefined;
  Transport: { transportId?: string; origin?: string; destination?: string; location?: string } | undefined;
  PlaceDirectory: {
    module: "activity" | "shopping" | "petrol" | "hospital" | "atm";
    placeId?: string;
    search?: string;
  };
  Destination: { destination?: DestinationDetails } | undefined;
  HiddenGems: { destination?: DestinationDetails } | undefined;
  HiddenGemDetail: { gem: HiddenGemDetails };
  Chat: { prompt?: string } | undefined;
  Map: {
    category?: string;
    query?: string;
    latitude?: number;
    longitude?: number;
  } | undefined;
  Weather: undefined;
  PlanMyTrip: { prompt?: string; tripId?: string } | undefined;
  Rating: undefined;
  Login: {
    provider?: "Apple" | "Email" | "Google";
    identifier?: string;
    notice?: string;
  } | undefined;
  AdminLogin: undefined;
  AdminDashboard: undefined;
  ForgotPassword: { email?: string; admin?: boolean } | undefined;
  ResetPassword: { email: string; otp: string; admin?: boolean };
  VerifyEmail: { email: string };
  EditProfile: undefined;
  Settings: undefined;
  Help: undefined;
  Booking: {
    trip?: {
      name: string;
      location: string;
      price: string;
      image?: string;
      itemType?: "trip" | "transport";
      imageSource?: string;
      imageSourcePage?: string;
      imageLicense?: string;
      imageCredit?: string;
      imageDescription?: string;
      imageRelevance?: "entity" | "category";
    };
    hotel?: {
      id?: string;
      name: string;
      location?: string;
      price?: string;
      pricePerNight?: number;
      rating?: string;
      image?: string;
      images?: string[];
      imageSource?: string;
      imageSourcePage?: string;
      imageLicense?: string;
      imageCredit?: string;
      imageDescription?: string;
      imageRelevance?: "entity" | "category";
      description?: string;
      propertyTypes?: string[];
      amenities?: string[];
      latitude?: number;
      longitude?: number;
      isDemoData?: boolean;
      roomTypes?: {
        _id: string;
        name: string;
        capacityAdults: number;
        capacityChildren: number;
        totalRooms: number;
        nightlyRate?: number;
        availableRooms?: number;
        matchesOccupancy?: boolean;
      }[];
    };
    checkIn?: string;
    checkOut?: string;
    adults?: number;
    children?: number;
    rooms?: number;
    activity?: {
      id?: string;
      name: string;
      location?: string;
      price?: number;
      currency?: string;
      durationMinutes?: number;
      capacityPerSlot?: number;
      minAge?: number;
      image?: string;
      images?: string[];
      imageSource?: string;
      imageSourcePage?: string;
      imageLicense?: string;
      imageCredit?: string;
      imageDescription?: string;
      imageRelevance?: "entity" | "category";
    };
    vehicle?: {
      name: string;
      type: string;
      price: string;
      time: string;
      image?: string;
      location?: string;
      imageSource?: string;
      imageSourcePage?: string;
      imageLicense?: string;
      imageCredit?: string;
      imageDescription?: string;
      imageRelevance?: "entity" | "category";
      /** Standalone transport booking handoff (all optional, additive only). */
      id?: string;
      origin?: string;
      destination?: string;
      departureTime?: string;
      arrivalTime?: string;
      durationMinutes?: number;
      unitPrice?: number;
      currency?: string;
      capacity?: number;
      serviceMode?: string;
    };
  } | undefined;
  Bookings: undefined;
  DestinationTrip: {
    destination?: string;
    origin?: string;
    preselect?: { itemType: "hotel" | "transport" | "restaurant" | "activity"; itemId: string };
  } | undefined;
  AdminLoginActivity: undefined;
  AdminRegisteredUsers: undefined;
  Notifications: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

WebBrowser.maybeCompleteAuthSession();

export const navigationRef = createNavigationContainerRef<RootStackParamList>();

export function navigateToScreen(
  name: keyof RootStackParamList,
  params?: Record<string, unknown>
) {
  if (navigationRef.isReady()) {
    (navigationRef as any).navigate(name, params);
  }
}

export default function App() {
  const [adminDashboard, setAdminDashboard] = useState(false);
  const syncAdminLayout = () => {
    setAdminDashboard(navigationRef.getCurrentRoute()?.name === "AdminDashboard");
  };
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <AdminAuthProvider>
          <View style={Platform.OS === "web" ? styles.webViewport : styles.nativeViewport}>
            <View style={Platform.OS === "web" ? (adminDashboard ? styles.adminWebApp : styles.webApp) : styles.nativeApp}>
              <NavigationContainer
                ref={navigationRef}
                onReady={syncAdminLayout}
                onStateChange={syncAdminLayout}
              >
              <StatusBar style="light" />
              <Stack.Navigator
                initialRouteName="Splash"
                screenOptions={{ headerShown: false }}
              >
          <Stack.Screen name="Splash" component={SplashScreen} />
          <Stack.Screen name="TermsAndConditions" component={TermsAndConditionsScreen} />
          <Stack.Screen name="MainTabs" component={MainTabs} />
          <Stack.Screen name="Search" component={SearchScreen} />
          <Stack.Screen name="Hotels" component={HotelListScreen} />
          <Stack.Screen name="HotelDetails" component={HotelDetailsScreen} />
          <Stack.Screen name="Restaurants" component={RestaurantListScreen} />
          <Stack.Screen name="Transport" component={TransportScreen} />
          <Stack.Screen name="PlaceDirectory" component={PlaceDirectoryScreen} />
          <Stack.Screen name="Destination" component={DestinationScreen} />
          <Stack.Screen name="HiddenGems" component={HiddenGemsScreen} />
          <Stack.Screen name="HiddenGemDetail" component={HiddenGemDetailScreen} />
          <Stack.Screen name="Chat" component={ChatScreen} />
          <Stack.Screen name="Map" component={MapScreen} />
          <Stack.Screen name="Weather" component={WeatherScreen} />
          <Stack.Screen name="PlanMyTrip" component={PlanMyTripScreen} />
          <Stack.Screen name="Rating" component={RatingScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="AdminLogin" component={AdminLoginScreen} />
          <Stack.Screen name="AdminDashboard" component={AdminWorkspaceScreen} />
          <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
          <Stack.Screen name="ResetPassword" component={ResetPasswordScreen} />
          <Stack.Screen name="VerifyEmail" component={VerifyEmailScreen} />
          <Stack.Screen name="EditProfile" component={EditProfileScreen} />
          <Stack.Screen name="Settings" component={SettingsScreen} />
          <Stack.Screen name="Help" component={HelpSupportScreen} />
          <Stack.Screen name="Booking" component={BookingScreen} />
          <Stack.Screen name="Bookings" component={BookingsListScreen} />
          <Stack.Screen name="DestinationTrip" component={DestinationTripScreen} />
          <Stack.Screen name="Notifications" component={NotificationsScreen} />
          <Stack.Screen name="AdminLoginActivity" component={AdminLoginActivityScreen} />
          <Stack.Screen name="AdminRegisteredUsers" component={AdminRegisteredUsersScreen} />
              </Stack.Navigator>
              </NavigationContainer>
            </View>
          </View>
        </AdminAuthProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  webViewport: {
    flex: 1,
    width: "100%",
    alignItems: "center",
    backgroundColor: "#e8edeb",
  },
  webApp: {
    flex: 1,
    width: "100%",
    maxWidth: 430,
    overflow: "hidden",
    backgroundColor: "#ffffff",
  },
  adminWebApp: {
    flex: 1,
    width: "100%",
    // Same mobile-sized container as the normal user dashboard (webApp).
    maxWidth: 430,
    overflow: "hidden",
    backgroundColor: "#ffffff",
  },
  nativeViewport: {
    flex: 1,
  },
  nativeApp: {
    flex: 1,
  },
});