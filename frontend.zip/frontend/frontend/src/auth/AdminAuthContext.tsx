import React, {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";
import { BACKEND_BASE_URL } from "../services/backendApi";

export type AdminIdentity = {
  email: string;
  role: "admin";
};

type AdminAuthContextValue = {
  admin: AdminIdentity | null;
  ready: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  getAccessToken: () => string | null;
};

type StoredAdminSession = {
  token: string;
  admin: AdminIdentity;
};

const SESSION_KEY = "suvyatra_admin_session_v1";
const AdminAuthContext = createContext<AdminAuthContextValue | undefined>(undefined);

function getWebStorage(): Storage | null {
  try {
    return typeof sessionStorage !== "undefined" ? sessionStorage : null;
  } catch {
    return null;
  }
}

async function readSession(): Promise<StoredAdminSession | null> {
  const raw = Platform.OS === "web"
    ? getWebStorage()?.getItem(SESSION_KEY) ?? null
    : await SecureStore.getItemAsync(SESSION_KEY);
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as StoredAdminSession;
    return typeof value.token === "string" && value.admin?.role === "admin"
      ? value
      : null;
  } catch {
    return null;
  }
}

async function writeSession(session: StoredAdminSession | null): Promise<void> {
  if (Platform.OS === "web") {
    const storage = getWebStorage();
    if (!storage) throw new Error("Secure browser session storage is unavailable.");
    if (session) storage.setItem(SESSION_KEY, JSON.stringify(session));
    else storage.removeItem(SESSION_KEY);
    return;
  }
  if (session) await SecureStore.setItemAsync(SESSION_KEY, JSON.stringify(session));
  else await SecureStore.deleteItemAsync(SESSION_KEY);
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${BACKEND_BASE_URL}${path}`, init);
  const body: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      typeof body === "object" && body !== null && "message" in body &&
      typeof body.message === "string"
        ? body.message
        : `Request failed (${response.status}).`;
    throw new Error(message);
  }
  return body as T;
}

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [admin, setAdmin] = useState<AdminIdentity | null>(null);
  const [ready, setReady] = useState(false);
  const tokenRef = useRef<string | null>(null);

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const session = await readSession();
        if (!session) return;
        const result = await request<{ admin: AdminIdentity }>("/admin/session", {
          headers: { Authorization: `Bearer ${session.token}` },
        });
        if (active) {
          tokenRef.current = session.token;
          setAdmin(result.admin);
        }
      } catch {
        await writeSession(null).catch(() => undefined);
      } finally {
        if (active) setReady(true);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const session = await request<StoredAdminSession>("/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: email.trim(), password }),
    });
    if (!session.token || session.admin?.role !== "admin") {
      throw new Error("The server did not return a valid administrator session.");
    }
    await writeSession(session);
    tokenRef.current = session.token;
    setAdmin(session.admin);
  }, []);

  const logout = useCallback(async () => {
    tokenRef.current = null;
    setAdmin(null);
    await writeSession(null);
  }, []);

  const getAccessToken = useCallback(() => tokenRef.current, []);
  const value = useMemo(
    () => ({ admin, ready, login, logout, getAccessToken }),
    [admin, ready, login, logout, getAccessToken]
  );

  return <AdminAuthContext.Provider value={value}>{children}</AdminAuthContext.Provider>;
}

export function useAdminAuth(): AdminAuthContextValue {
  const context = useContext(AdminAuthContext);
  if (!context) throw new Error("useAdminAuth must be used within an AdminAuthProvider");
  return context;
}
