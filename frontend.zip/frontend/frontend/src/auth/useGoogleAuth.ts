import { useMemo } from "react";
import {
  ResponseType,
  makeRedirectUri,
  useAuthRequest,
  useAutoDiscovery,
} from "expo-auth-session";

const GOOGLE_ISSUER = "https://accounts.google.com";

function getWebClientId(): string {
  return process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID?.trim() ?? "";
}

/**
 * Web-first Google OAuth (Expo SDK 57).
 * Uses the implicit id_token flow so no client secret is needed.
 * Backend verifies the id_token at POST /auth/google.
 */
export function useGoogleAuth() {
  const discovery = useAutoDiscovery(GOOGLE_ISSUER);
  const clientId = getWebClientId();

  const redirectUri = useMemo(
    () =>
      makeRedirectUri({
        scheme: "suvyatra",
      }),
    []
  );

  const [request, response, promptAsync] = useAuthRequest(
    {
      clientId,
      redirectUri,
      scopes: ["openid", "email", "profile"],
      responseType: ResponseType.IdToken,
      usePKCE: false,
      extraParams: { prompt: "select_account" },
    },
    discovery
  );

  const idToken =
    response?.type === "success"
      ? (response.params as Record<string, string | undefined>).id_token
      : undefined;

  return {
    configured: Boolean(clientId) && Boolean(discovery) && Boolean(request),
    request,
    response,
    idToken,
    promptAsync,
  };
}

export function getGoogleOAuthRedirectUri(): string {
  return makeRedirectUri({ scheme: "suvyatra" });
}
