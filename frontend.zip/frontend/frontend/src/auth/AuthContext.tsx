import React, {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";
import { BACKEND_BASE_URL } from "../services/backendApi";

export type SocialProvider = "Apple" | "Email" | "Google";

export type UserProfile = {
  _id?: string;
  id?: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
  avatar: string;
  memberSince: string;
  provider?: SocialProvider;
  role?: "user" | "admin";
};

type AuthContextValue = {
  user: UserProfile | null;
  isLoggedIn: boolean;
  termsAccepted: boolean;
  acceptTerms: () => Promise<void>;
  login: (email: string, password?: string, provider?: SocialProvider) => Promise<UserProfile>;
  register: (name: string, email: string, password?: string, provider?: SocialProvider) => Promise<UserProfile>;
  loginWithGoogle: (idToken: string) => Promise<UserProfile>;
  requestRegisterOtp: (name: string, email: string, password: string) => Promise<string>;
  resendRegisterOtp: (email: string) => Promise<void>;
  verifyRegisterOtp: (email: string, otp: string) => Promise<UserProfile>;
  requestPasswordReset: (email: string) => Promise<void>;
  verifyPasswordResetOtp: (email: string, otp: string) => Promise<void>;
  resetPassword: (email: string, otp: string, password: string) => Promise<void>;
  getAccessToken: () => string | null;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => void;
};

const STORAGE_KEY = "suvyatra_auth_v1";
const TERMS_STORAGE_KEY = "suvyatra_terms_accepted_v1";

function normalizeEmail(value: string): string {
  return value.trim().toLowerCase();
}

type StoredSession = {
  user: UserProfile;
  token?: string;
};

function getWebStorage(): Storage | null {
  try {
    return typeof localStorage !== "undefined" ? localStorage : null;
  } catch {
    return null;
  }
}

async function readStoredSession(): Promise<StoredSession | null> {
  try {
    const raw = Platform.OS === "web"
      ? getWebStorage()?.getItem(STORAGE_KEY) ?? null
      : await SecureStore.getItemAsync(STORAGE_KEY);
    if (!raw) {
      return null;
    }

    const parsed = JSON.parse(raw) as StoredSession | UserProfile;
    if ("user" in parsed && parsed.user) {
      return parsed as StoredSession;
    }

    return { user: parsed as UserProfile };
  } catch {
    return null;
  }
}

async function writeStoredSession(
  session: StoredSession | null,
  required = false
) {
  try {
    if (Platform.OS === "web") {
      const storage = getWebStorage();
      if (!storage && required) {
        throw new Error("Browser storage is unavailable.");
      }
      if (session) {
        storage?.setItem(STORAGE_KEY, JSON.stringify(session));
      } else {
        storage?.removeItem(STORAGE_KEY);
      }
      return;
    }

    if (session) {
      await SecureStore.setItemAsync(STORAGE_KEY, JSON.stringify(session));
    } else {
      await SecureStore.deleteItemAsync(STORAGE_KEY);
    }
  } catch (error) {
    if (required) {
      throw new Error("Could not save your account session on this device.");
    }
  }
}

async function readTermsAccepted(): Promise<boolean> {
  try {
    const value = Platform.OS === "web"
      ? getWebStorage()?.getItem(TERMS_STORAGE_KEY) ?? null
      : await SecureStore.getItemAsync(TERMS_STORAGE_KEY);
    return value === "true";
  } catch {
    return false;
  }
}

async function writeTermsAccepted(accepted: boolean) {
  try {
    if (Platform.OS === "web") {
      const storage = getWebStorage();
      if (accepted) {
        storage?.setItem(TERMS_STORAGE_KEY, "true");
      } else {
        storage?.removeItem(TERMS_STORAGE_KEY);
      }
      return;
    }

    if (accepted) {
      await SecureStore.setItemAsync(TERMS_STORAGE_KEY, "true");
    } else {
      await SecureStore.deleteItemAsync(TERMS_STORAGE_KEY);
    }
  } catch {
    // Continue to keep consent usable if device storage is unavailable.
  }
}

function profileFromEmail(email: string): UserProfile {
  const local = email.split("@")[0] || "Explorer";
  const name = local
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
  return {
    name: name || "SuvYatra Explorer",
    email,
    phone: "+977 9800 000 000",
    location: "Kathmandu, Nepal",
    bio: "Hello! I'm exploring Nepal with SuvYatra.",
    avatar: `https://i.pravatar.cc/150?u=${encodeURIComponent(email)}`,
    memberSince: new Date().toLocaleDateString("en-US", {
      month: "short",
      year: "numeric",
    }),
  };
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export class AuthenticationError extends Error {
  constructor(message: string, readonly code?: string) {
    super(message);
    this.name = "AuthenticationError";
  }
}

async function apiRequest(path: string, body: Record<string, unknown>) {
  const response = await fetch(`${BACKEND_BASE_URL}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new AuthenticationError(
      data?.message || "Authentication request failed.",
      data?.code
    );
  }

  return data;
}

async function getCurrentUser(token: string, fallbackUser: UserProfile): Promise<UserProfile> {
  const response = await fetch(`${BACKEND_BASE_URL}/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const data = await response.json().catch(() => ({}));

  if (!response.ok || !data.user) {
    throw new Error(data.message || "Saved session is no longer valid.");
  }

  return { ...fallbackUser, ...data.user } as UserProfile;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [ready, setReady] = useState(false);
  const tokenRef = useRef<string | null>(null);

  useEffect(() => {
    let mounted = true;
    const restoreSession = async () => {
      const [session, acceptedTerms] = await Promise.all([
        readStoredSession(),
        readTermsAccepted(),
      ]);
      if (mounted) {
        setTermsAccepted(acceptedTerms);
      }
      if (session?.token) {
        try {
          const restoredUser = await getCurrentUser(session.token, session.user);
          if (mounted) {
            tokenRef.current = session.token;
            setUser(restoredUser);
            await writeStoredSession({ user: restoredUser, token: session.token });
          }
        } catch {
          await writeStoredSession(null);
        }
      } else if (session) {
        await writeStoredSession(null);
      }
      if (mounted) {
        setReady(true);
      }
    };

    void restoreSession();
    return () => {
      mounted = false;
    };
  }, []);

  const acceptTerms = useCallback(async () => {
    setTermsAccepted(true);
    await writeTermsAccepted(true);
  }, []);

  const login = useCallback(async (identifier: string, password?: string, provider: SocialProvider = "Email") => {
    const loginIdentifier = identifier.trim();
    if (!password) {
      throw new Error("Password is required.");
    }

    const emailValue = normalizeEmail(loginIdentifier);
    const phoneValue = "";
    const appleIdValue = provider === "Apple" ? loginIdentifier : "";

    const payload = await apiRequest("/auth/login", {
      email: emailValue || undefined,
      phone: phoneValue || undefined,
      appleId: appleIdValue || undefined,
      password,
      provider,
    });
    const profile: UserProfile = {
      ...profileFromEmail(payload.user?.email || emailValue || ""),
      ...payload.user,
      name: payload.user?.name || payload.user?.email || "SuvYatra Explorer",
      email: payload.user?.email || emailValue || "",
      phone: payload.user?.phone || phoneValue || "",
      provider: (payload.user?.provider || provider) as SocialProvider,
      memberSince: payload.user?.memberSince
        ? new Date(payload.user.memberSince).toLocaleDateString("en-US", {
            month: "short",
            year: "numeric",
          })
        : new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" }),
    };
    const token = typeof payload.token === "string" ? payload.token : undefined;
    if (!token || !payload.user) {
      throw new Error("Login succeeded but the server did not return a valid session.");
    }
    await writeStoredSession({ user: profile, token }, true);
    tokenRef.current = token;
    setUser(profile);
    return profile;
  }, []);

  const register = useCallback(async (name: string, identifier: string, password?: string, provider: SocialProvider = "Email") => {
    if (!password) {
      throw new Error("Password is required to create an account.");
    }

    const loginIdentifier = identifier.trim();
    const emailValue = normalizeEmail(loginIdentifier);
    const phoneValue = "";
    const appleIdValue = provider === "Apple" ? loginIdentifier : "";

    const payload = await apiRequest("/auth/register", {
      name: name.trim().replace(/\s+/g, " "),
      email: emailValue || undefined,
      phone: phoneValue || undefined,
      appleId: appleIdValue || undefined,
      password,
      provider,
    });
    // Email signups now verify the Gmail inbox with an OTP first.
    if (payload?.needsVerification || payload?.code === "REGISTER_OTP_SENT") {
      throw new AuthenticationError(
        "A verification code has been sent to your Gmail. Please enter it to finish signup.",
        "REGISTER_OTP_SENT"
      );
    }
    if (typeof payload.token !== "string" || !payload.user) {
      throw new Error("Account creation succeeded, but the server did not return a login session.");
    }
    const profile: UserProfile = {
      ...profileFromEmail(payload.user?.email || emailValue || ""),
      ...payload.user,
      name: payload.user?.name || name,
      email: payload.user?.email || emailValue || "",
      phone: payload.user?.phone || phoneValue || "",
      provider: (payload.user?.provider || provider) as SocialProvider,
      memberSince: payload.user?.memberSince
        ? new Date(payload.user.memberSince).toLocaleDateString("en-US", {
            month: "short",
            year: "numeric",
          })
        : new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" }),
    };
    const token: string = payload.token;
    await writeStoredSession({ user: profile, token }, true);
    tokenRef.current = token;
    setUser(profile);
    return profile;
  }, []);

  const requestRegisterOtp = useCallback(async (name: string, email: string, password: string) => {
    const payload = await apiRequest("/auth/request-register-otp", {
      name: name.trim().replace(/\s+/g, " "),
      email: normalizeEmail(email),
      password,
    });
    return (payload?.email as string | undefined) || normalizeEmail(email);
  }, []);

  const resendRegisterOtp = useCallback(async (email: string) => {
    await apiRequest("/auth/resend-register-otp", { email: normalizeEmail(email) });
  }, []);

  const verifyRegisterOtp = useCallback(async (email: string, otp: string) => {
    const payload = await apiRequest("/auth/verify-register-otp", {
      email: normalizeEmail(email),
      otp: otp.trim(),
    });
    const profile: UserProfile = {
      ...profileFromEmail(payload.user?.email || normalizeEmail(email)),
      ...payload.user,
      name: payload.user?.name || payload.user?.email || "SuvYatra Explorer",
      email: payload.user?.email || normalizeEmail(email),
      provider: "Email",
      memberSince: payload.user?.memberSince
        ? new Date(payload.user.memberSince).toLocaleDateString("en-US", {
            month: "short",
            year: "numeric",
          })
        : new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" }),
    };
    const token = typeof payload.token === "string" ? payload.token : undefined;
    if (!token || !payload.user) {
      throw new Error("Verification succeeded but the server did not return a valid session.");
    }
    await writeStoredSession({ user: profile, token }, true);
    tokenRef.current = token;
    setUser(profile);
    return profile;
  }, []);

  const loginWithGoogle = useCallback(async (idToken: string) => {    if (!idToken) {
      throw new Error("Google sign-in was cancelled.");
    }
    const payload = await apiRequest("/auth/google", { idToken });
    const profile: UserProfile = {
      ...profileFromEmail(payload.user?.email || ""),
      ...payload.user,
      name: payload.user?.name || payload.user?.email || "SuvYatra Explorer",
      email: payload.user?.email || "",
      provider: "Google",
      memberSince: payload.user?.memberSince
        ? new Date(payload.user.memberSince).toLocaleDateString("en-US", {
            month: "short",
            year: "numeric",
          })
        : new Date().toLocaleDateString("en-US", { month: "short", year: "numeric" }),
    };
    const token = typeof payload.token === "string" ? payload.token : undefined;
    if (!token || !payload.user) {
      throw new Error("Google sign-in succeeded but the server did not return a valid session.");
    }
    await writeStoredSession({ user: profile, token }, true);
    tokenRef.current = token;
    setUser(profile);
    return profile;
  }, []);

  const requestPasswordReset = useCallback(async (email: string) => {
    await apiRequest("/auth/forgot-password", { email: normalizeEmail(email) });
  }, []);

  const verifyPasswordResetOtp = useCallback(async (email: string, otp: string) => {
    await apiRequest("/auth/verify-reset-otp", {
      email: normalizeEmail(email),
      otp: otp.trim(),
    });
  }, []);

  const resetPassword = useCallback(async (email: string, otp: string, password: string) => {
    await apiRequest("/auth/reset-password", {
      email: normalizeEmail(email),
      otp: otp.trim(),
      password,
    });
  }, []);

  const logout = useCallback(async () => {
    setUser(null);
    tokenRef.current = null;
    await writeStoredSession(null);
  }, []);

  const getAccessToken = useCallback(() => tokenRef.current, []);

  const updateProfile = useCallback((updates: Partial<UserProfile>) => {
    setUser((current) => {
      if (!current) {
        return current;
      }
      const next = { ...current, ...updates };
      void writeStoredSession({ user: next, token: tokenRef.current ?? undefined });
      return next;
    });
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isLoggedIn: !!user,
      termsAccepted,
      acceptTerms,
      login,
      register,
      loginWithGoogle,
      requestRegisterOtp,
      resendRegisterOtp,
      verifyRegisterOtp,
      requestPasswordReset,
      verifyPasswordResetOtp,
      resetPassword,
      getAccessToken,
      logout,
      updateProfile,
    }),
    [
      user,
      termsAccepted,
      acceptTerms,
      login,
      register,
      loginWithGoogle,
      requestRegisterOtp,
      resendRegisterOtp,
      verifyRegisterOtp,
      requestPasswordReset,
      verifyPasswordResetOtp,
      resetPassword,
      getAccessToken,
      logout,
      updateProfile,
    ]
  );

  return (
    <AuthContext.Provider value={value}>
      {ready ? children : null}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}