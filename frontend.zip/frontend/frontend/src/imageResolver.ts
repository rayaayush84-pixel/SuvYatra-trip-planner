import { BACKEND_BASE_URL, backendRequest } from "./services/backendApi";

export type ImageEntity = {
  id?: string;
  name: string;
  type: string;
  location?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  // Alternate field names used by different API records / legacy payloads.
  // They are normalized by normalizeImageEntity() — never read directly.
  imageUrl?: string;
  image_url?: string;
  photo?: string;
  photos?: string[];
  photoUrl?: string;
  picture?: string;
  pictures?: string[];
  thumbnail?: string;
  thumbnails?: string[];
  cover?: string;
  coverImage?: string;
};

export type RelevantImageReference = {
  uri: string;
  source: string;
  sourcePage: string;
  license: string;
  credit: string;
  description: string;
  relevance: "entity" | "category";
};

const candidateCache = new Map<string, Promise<RelevantImageReference[]>>();
const imageOwners = new Map<string, string>();
const nepalTripPlannerImagePath = "/catalog-images/suvyatra-nepal-trip-planner.png";
const IMAGE_LOOKUP_TIMEOUT_MS = 10_000;
const categoryFamilyStopwords = new Set([
  "atm",
  "bus",
  "cafe",
  "city",
  "and",
  "file",
  "hotel",
  "hotels",
  "hostel",
  "interior",
  "lobby",
  "lodge",
  "nepal",
  "of",
  "restaurant",
  "room",
  "resort",
  "view",
  "bhaktapur",
  "chitwan",
  "dharan",
  "ilam",
  "kathmandu",
  "kaski",
  "khumbu",
  "lalitpur",
  "lumbini",
  "manang",
  "mustang",
  "pokhara",
]);

export function clearRelevantImageCache(): void {
  candidateCache.clear();
  imageOwners.clear();
}

/**
 * Normalize the many image field names used across API records
 * (image, imageUrl, photo, photos, images, picture, thumbnail, cover …)
 * into the canonical { image, images } shape. Pass ANY record through
 * this before rendering so a differently-named field can never produce
 * an empty / broken image area.
 */
export function normalizeImageEntity<T extends ImageEntity>(entity: T): ImageEntity {
  const raw = entity as ImageEntity & Record<string, unknown>;
  const asString = (value: unknown): string | undefined =>
    typeof value === "string" && value.trim() ? value.trim() : undefined;
  const asStrings = (value: unknown): string[] =>
    Array.isArray(value)
      ? value.filter((entry): entry is string => typeof entry === "string" && !!entry.trim())
      : [];
  const primary =
    asString(raw.image) ??
    asString(raw.imageUrl) ??
    asString(raw.image_url) ??
    asString(raw.photo) ??
    asString(raw.photoUrl) ??
    asString(raw.picture) ??
    asString(raw.thumbnail) ??
    asString(raw.cover) ??
    asString(raw.coverImage);
  const extra = [
    ...asStrings(raw.images),
    ...asStrings(raw.photos),
    ...asStrings(raw.pictures),
    ...asStrings(raw.thumbnails),
    asString(raw.imageUrl),
    asString(raw.image_url),
    asString(raw.photo),
    asString(raw.photoUrl),
    asString(raw.picture),
    asString(raw.thumbnail),
    asString(raw.cover),
    asString(raw.coverImage),
  ].filter((uri): uri is string => !!uri);
  const images = [...new Set([primary, ...extra].filter((uri): uri is string => !!uri))];
  return {
    ...entity,
    image: images[0] ?? entity.image,
    images: images.length ? images : entity.images,
  };
}

/** All stored URIs for an entity, after field-name normalization. */
function extractStoredUris(entity: ImageEntity): string[] {
  const normalized = normalizeImageEntity(entity);
  return [...new Set([normalized.image, ...(normalized.images ?? [])].filter(Boolean))] as string[];
}

function backendOriginUrl(path: string): string | null {
  try {
    return new URL(path, BACKEND_BASE_URL).toString();
  } catch {
    return null;
  }
}

/**
 * Stored URIs that carry no attribution metadata (legacy / third-party
 * fields such as photo, thumbnail, coverImage). They still depict the
 * listing itself, so they outrank generic lookup results — but only when
 * they are actually loadable in the app (https, backend origin, or a
 * backend-served /catalog-images path). Device-local paths such as
 * file:// or C:\… are rejected: they render on one device and break on
 * every other screen.
 */
function bareStoredImages(entity: ImageEntity): RelevantImageReference[] {
  if (entity.imageSource && entity.imageSourcePage && entity.imageLicense) return [];
  const backendBase = (() => {
    try {
      return new URL(BACKEND_BASE_URL);
    } catch {
      return null;
    }
  })();
  const refs: RelevantImageReference[] = [];
  for (const raw of extractStoredUris(entity)) {
    let uri = raw;
    if (/^\/catalog-images\/[a-z0-9-]+\.png$/i.test(raw)) {
      const resolved = backendOriginUrl(raw);
      if (!resolved) continue;
      uri = resolved;
    } else if (!/^https:\/\//i.test(raw)) {
      if (!backendBase || backendBase.protocol !== "http:") continue;
      if (!raw.startsWith(`${backendBase.origin}/`)) continue;
    }
    refs.push({
      uri,
      source: "Listing photo",
      sourcePage: uri,
      license: "Provided by the listing",
      credit: "",
      description: `${entity.name}: photo provided with the listing.`,
      relevance: "entity",
    });
  }
  return refs;
}

type FallbackSpec = {
  match: (type: string, name: string) => boolean;
  uri: string;
  source: string;
  sourcePage: string;
  license: string;
  credit: string;
  description: string;
};

function wikimediaFallback(match: (type: string, name: string) => boolean, spec: Omit<FallbackSpec, "match">): FallbackSpec {
  return { match, ...spec };
}

const CATEGORY_FALLBACKS: FallbackSpec[] = [
  // Activity-specific fallbacks first (more specific than the generic kind).
  wikimediaFallback(
    (type, name) => type === "activity" && /boat|canoe|phewa|sail|paddle/i.test(name) && !/raft/i.test(name),
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f2/Boats_on_Phewa_Lake_%289207546652%29.jpg/1280px-Boats_on_Phewa_Lake_%289207546652%29.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Boats_on_Phewa_Lake_(9207546652).jpg",
      license: "CC BY-SA 2.0",
      credit: "Debarshi Ray",
      description: "Illustrative photo of row boats on Phewa Lake, Pokhara.",
    }
  ),
  wikimediaFallback(
    (type, name) => type === "activity" && /bungee/i.test(name),
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/d/dc/Nepal-bungy.jpg/960px-Nepal-bungy.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Nepal-bungy.jpg",
      license: "CC BY 2.0",
      credit: "Graham McLellan",
      description: "Illustrative photo of bungee jumping in Nepal.",
    }
  ),
  wikimediaFallback(
    (type, name) => type === "activity" && /trek|everest|annapurna|hike|climb|base camp/i.test(name),
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c2/Annapurna_Base_Camp_with_snow.jpg/960px-Annapurna_Base_Camp_with_snow.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Annapurna_Base_Camp_with_snow.jpg",
      license: "CC BY-SA 4.0",
      credit: "Samdesherpa",
      description: "Illustrative photo of Annapurna Base Camp, Nepal.",
    }
  ),
  wikimediaFallback(
    (type, name) => type === "activity" && /cycl|bike/i.test(name),
    {
      uri: "https://upload.wikimedia.org/wikipedia/commons/7/7a/Cycling_in_Remote_Area_Nepal.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail_unscaled",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Cycling_in_Remote_Area_Nepal.jpg",
      license: "CC BY-SA 4.0",
      credit: "Ravijung",
      description: "Illustrative photo of cycling in Nepal.",
    }
  ),
  wikimediaFallback(
    (type, name) => type === "activity" && /cultur|heritage|walk|temple|tour|sightsee|museum|durbar|village/i.test(name),
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/6/69/Historic_Pagoda_Style_Architecture_in_Kathmandu_Durbar_Square-IMG_4069.jpg/1280px-Historic_Pagoda_Style_Architecture_in_Kathmandu_Durbar_Square-IMG_4069.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Historic_Pagoda_Style_Architecture_in_Kathmandu_Durbar_Square-IMG_4069.jpg",
      license: "CC BY-SA 4.0",
      credit: "Bijay Chaurasia",
      description: "Illustrative photo of heritage architecture in Kathmandu Durbar Square.",
    }
  ),
  // Category fallbacks: relevant to the kind of service, never unrelated.
  wikimediaFallback(
    (type) => type === "hotel",
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0a/Pokhara-04-Hotel_Barahi-Pool-2013-gje.jpg/1280px-Pokhara-04-Hotel_Barahi-Pool-2013-gje.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Pokhara-04-Hotel_Barahi-Pool-2013-gje.jpg",
      license: "CC BY-SA 4.0",
      credit: "Gerd Eichmann",
      description: "Illustrative photo of a hotel pool in Pokhara, Nepal.",
    }
  ),
  wikimediaFallback(
    (type) => type === "restaurant",
    {
      uri: "https://live.staticflickr.com/4093/4812414829_57652164bb_b.jpg",
      source: "Flickr via Openverse",
      sourcePage: "https://www.flickr.com/photos/71401718@N00/4812414829",
      license: "CC BY 2.0",
      credit: "Wonderlane",
      description: "Illustrative photo of a restaurant interior in Kathmandu.",
    }
  ),
  wikimediaFallback(
    (type) => type === "transport",
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a3/TOURIST_BUS_PARK_POKHARA_NEPAL_FEB_2013_%288570572787%29.jpg/960px-TOURIST_BUS_PARK_POKHARA_NEPAL_FEB_2013_%288570572787%29.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:TOURIST_BUS_PARK_POKHARA_NEPAL_FEB_2013_(8570572787).jpg",
      license: "CC BY-SA 2.0",
      credit: "calflier001",
      description: "Illustrative photo of tourist buses in Pokhara, Nepal.",
    }
  ),
  wikimediaFallback(
    (type) => type === "activity",
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a2/Pokhara_Paragliding.jpg/960px-Pokhara_Paragliding.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Pokhara_Paragliding.jpg",
      license: "CC BY-SA 3.0",
      credit: "Shiva Kumar Khanal",
      description: "Illustrative photo of paragliding in Pokhara, Nepal.",
    }
  ),
  wikimediaFallback(
    () => true,
    {
      uri: "https://thumb.wikimedia.org/wikipedia/commons/thumb/5/53/Phewa_Lake_2603.jpg/1280px-Phewa_Lake_2603.jpg?utm_source=commons.wikimedia.org&utm_campaign=imageinfo&utm_content=thumbnail",
      source: "Wikimedia Commons",
      sourcePage: "https://commons.wikimedia.org/wiki/File:Phewa_Lake_2603.jpg",
      license: "CC BY-SA 4.0",
      credit: "Bijay chaurasia",
      description: "Illustrative photo of Phewa Lake, Pokhara, Nepal.",
    }
  ),
];

/**
 * Relevant category fallback image — used only when neither the listing
 * nor the live resolver yields an image. Hotel → hotel photo, activity →
 * activity-specific photo, and so on. Fallbacks are intentionally shared
 * across cards, so they are never ownership-claimed.
 */
export function categoryFallbackFor(entity: ImageEntity): RelevantImageReference | null {
  const type = entity.type.trim().toLocaleLowerCase();
  const name = entity.name.trim();
  const spec = CATEGORY_FALLBACKS.find((candidate) => candidate.match(type, name));
  if (!spec) return null;
  return {
    uri: spec.uri,
    source: spec.source,
    sourcePage: spec.sourcePage,
    license: spec.license,
    credit: spec.credit,
    description: spec.description,
    relevance: "category",
  };
}

function entityKey(entity: ImageEntity): string {
  return [entity.name, entity.type, entity.location]
    .map((part) => (part ?? "").trim().toLocaleLowerCase())
    .join("|");
}

function imageOwnerKeys(image: RelevantImageReference): string[] {
  if (
    image.relevance !== "category" ||
    image.source === "SuvYatra original illustration"
  ) return [image.uri];
  const encodedTitle = image.sourcePage.split("/").pop() ?? "";
  let title = encodedTitle;
  try {
    title = decodeURIComponent(encodedTitle);
  } catch (error) {
    console.warn("Could not decode a Commons image title for duplicate checking.", error);
  }
  const tokens = title
    .replace(/\.(jpe?g|png|webp|gif)$/i, "")
    .toLocaleLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .split(/\s+/)
    .filter((token) =>
      token.length > 2 &&
      !/^\d+$/.test(token) &&
      !categoryFamilyStopwords.has(token)
    );
  const familyKeys = tokens.slice(0, -1).map((token, index) =>
    `${image.source}|${token} ${tokens[index + 1]}`
  );
  return [image.uri, ...familyKeys];
}

function imageIsAvailable(image: RelevantImageReference, key: string): boolean {
  return imageOwnerKeys(image).every((ownerKey) => {
    const owner = imageOwners.get(ownerKey);
    return !owner || owner === key;
  });
}

function claimImage(image: RelevantImageReference, key: string): void {
  for (const ownerKey of imageOwnerKeys(image)) imageOwners.set(ownerKey, key);
}

function curatedCountryImage(entity: ImageEntity): RelevantImageReference | null {
  if (
    entity.type.trim().toLocaleLowerCase() !== "country" ||
    entity.name.trim().toLocaleLowerCase() !== "nepal"
  ) return null;

  const uri = new URL(nepalTripPlannerImagePath, BACKEND_BASE_URL).toString();
  return {
    uri,
    source: "SuvYatra original illustration",
    sourcePage: uri,
    license: "Project-owned illustration",
    credit: "SuvYatra",
    description: "Illustrated Nepal travel planning scene with Himalayan mountains, route, and itinerary.",
    relevance: "category",
  };
}

function storedRelevantImages(entity: ImageEntity): RelevantImageReference[] {
  const source = entity.imageSource;
  const sourcePage = entity.imageSourcePage;
  const license = entity.imageLicense;
  const name = entity.name.trim().toLocaleLowerCase();
  const urls = extractStoredUris(entity);
  const isProjectArtwork = source === "SuvYatra original illustration";
  const isLocalArtworkPath = (value: string) => /^\/catalog-images\/[a-z0-9-]+\.png$/i.test(value);
  if (
    !source ||
    !sourcePage ||
    !( /^https:\/\//i.test(sourcePage) || (isProjectArtwork && isLocalArtworkPath(sourcePage)) ) ||
    !license
  ) return [];
  if (
    source === "Wikimedia Commons" &&
    !/^https:\/\/commons\.wikimedia\.org\/wiki\/File:/i.test(sourcePage)
  ) {
    return [];
  }

  const backendBaseUrl = new URL(BACKEND_BASE_URL);
  const descriptions = `${sourcePage} ${entity.imageDescription ?? ""}`.toLocaleLowerCase();
  if (source !== "Wikimedia Commons" && !descriptions.includes(name)) return [];
  return urls
    .map((uri) => {
      if (isProjectArtwork && isLocalArtworkPath(uri)) {
        return new URL(uri, BACKEND_BASE_URL).toString();
      }
      return uri;
    })
    .filter((uri) => {
      const isHttps = /^https:\/\//i.test(uri);
      const isLocalBackendImage =
        isProjectArtwork &&
        backendBaseUrl.protocol === "http:" &&
        uri.startsWith(`${backendBaseUrl.origin}/`);
      return (isHttps || isLocalBackendImage) &&
        (source !== "Wikimedia Commons" ||
          /^https:\/\/(?:thumb\.wikimedia\.org|upload\.wikimedia\.org)\//i.test(uri));
    })
    .map((uri) => ({
      uri,
      source,
      sourcePage: isProjectArtwork && isLocalArtworkPath(sourcePage)
        ? new URL(sourcePage, BACKEND_BASE_URL).toString()
        : sourcePage,
      license,
      credit: entity.imageCredit ?? "",
      description: entity.imageDescription ?? "",
      relevance: entity.imageRelevance ?? ("entity" as const),
    }));
}

async function getCandidates(entity: ImageEntity): Promise<RelevantImageReference[]> {
  const key = entityKey(entity);
  let cached = candidateCache.get(key);
  if (!cached) {
    const params = new URLSearchParams({
      name: entity.name,
      type: entity.type,
      location: entity.location ?? "",
    });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), IMAGE_LOOKUP_TIMEOUT_MS);
    cached = backendRequest<{ images: RelevantImageReference[] }>(
      `/images/resolve?${params.toString()}`,
      { signal: controller.signal }
    )
      .then((result) => result.images)
      .finally(() => clearTimeout(timeout));
    candidateCache.set(key, cached);
    cached.catch(() => candidateCache.delete(key));
  }
  return cached;
}

/**
 * Ordered image candidates for an entity:
 *   1. attributed stored listing images (exact, any field name)
 *   2. unattributed but loadable stored listing photos
 *   3. live backend resolver results (Wikimedia, relevance-checked)
 *   4. relevant category fallback (hotel → hotel, activity → activity …)
 *
 * The UI walks this list on load error, so a card can never be left with
 * an empty area or a broken-image icon while any candidate remains.
 */
export async function resolveRelevantImageCandidates(
  entity: ImageEntity,
  excludedUris: string[] = []
): Promise<RelevantImageReference[]> {
  const key = entityKey(entity);
  const excluded = new Set(excludedUris);
  const ordered: RelevantImageReference[] = [];
  const countryImage = curatedCountryImage(entity);
  if (countryImage) {
    if (!excluded.has(countryImage.uri) && imageIsAvailable(countryImage, key)) {
      claimImage(countryImage, key);
      ordered.push(countryImage);
    }
    return ordered;
  }

  for (const stored of [...storedRelevantImages(entity), ...bareStoredImages(entity)]) {
    if (excluded.has(stored.uri) || ordered.some((item) => item.uri === stored.uri)) continue;
    if (imageIsAvailable(stored, key)) {
      claimImage(stored, key);
      ordered.push(stored);
    }
  }

  try {
    const candidates = await getCandidates(entity);
    for (const candidate of candidates) {
      if (excluded.has(candidate.uri) || ordered.some((item) => item.uri === candidate.uri)) continue;
      if (imageIsAvailable(candidate, key)) {
        claimImage(candidate, key);
        ordered.push(candidate);
      }
    }
  } catch {
    // Live lookup is best-effort; stored + fallback images still render.
  }

  // Category fallback is always available and never ownership-claimed, so
  // every card renders a relevant image even fully offline.
  const fallback = categoryFallbackFor(entity);
  if (fallback && !excluded.has(fallback.uri) && !ordered.some((item) => item.uri === fallback.uri)) {
    ordered.push(fallback);
  }
  return ordered;
}

export async function resolveRelevantImage(
  entity: ImageEntity,
  excludedUris: string[] = []
): Promise<RelevantImageReference | null> {
  const candidates = await resolveRelevantImageCandidates(entity, excludedUris);
  return candidates[0] ?? null;
}