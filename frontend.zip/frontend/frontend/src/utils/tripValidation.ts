// Complete Trip frontend validation — VALIDATE FIRST, THEN SEARCH/PLAN.
// Order (never reorder): destination → departure → return → travelers →
// budget → other required fields. Stops at the first failure so no API
// calls happen with invalid input.

import { BACKEND_BASE_URL } from "../services/backendApi";
import { isStrictAdISO, todayAdISO } from "./bsDate";
import type { DestinationSummary } from "../components/DestinationAutocomplete";
import type { LocationResult } from "../components/LocationAutocomplete";

export type TripValidationError = { field: string; message: string };

export const DESTINATION_ERROR =
  "Please select a valid Nepal destination.";

export const ORIGIN_ERROR =
  "Please select a valid origin from the suggestions.";

export function validateDestinationSelection(
  selected: DestinationSummary | null,
  rawText: string
): TripValidationError | null {
  const text = rawText.trim();
  if (!text) {
    return { field: "destination", message: DESTINATION_ERROR };
  }
  // Typing alone never validates — a recognized record must be selected and
  // must still match the visible text (exact or whole-word prefix, mirroring
  // the backend rule: "Chitwan" may resolve "Chitwan National Park").
  const selectedName = selected?.name.trim().toLowerCase() ?? "";
  const typed = text.toLowerCase();
  const matches =
    !!selected &&
    (selectedName === typed || (selectedName.startsWith(typed) && /^(\s|$)/.test(selectedName.slice(typed.length))));
  if (!matches) {
    return {
      field: "destination",
      message: "We couldn't recognize this destination. Please select a destination from the suggestions.",
    };
  }
  return null;
}

/** Confirm the destination against the live catalog (server is the source of truth). */
export async function confirmDestinationWithServer(
  name: string
): Promise<{ ok: true; destination: DestinationSummary } | { ok: false; message: string }> {
  try {
    const response = await fetch(
      `${BACKEND_BASE_URL}/destinations/validate?name=${encodeURIComponent(name.trim())}`
    );
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data?.success !== true || !data?.destination) {
      return { ok: false, message: typeof data?.message === "string" ? data.message : DESTINATION_ERROR };
    }
    return { ok: true, destination: data.destination as DestinationSummary };
  } catch {
    return { ok: false, message: "Could not verify the destination. Check your connection and try again." };
  }
}

export function validateOriginSelection(
  selected: LocationResult | null,
  rawText: string
): TripValidationError | null {
  const text = rawText.trim();
  if (!text) {
    return { field: "origin", message: ORIGIN_ERROR };
  }
  // Typing alone never validates — a recognized suggestion must be selected
  // (by record id) and must still match the visible text.
  const selectedId = selected?.refId ?? selected?._id;
  if (!selected || !selectedId || selected.name.trim().toLowerCase() !== text.toLowerCase()) {
    return {
      field: "origin",
      message: "We couldn't recognize this location. Please select a valid place.",
    };
  }
  return null;
}

/** Confirm the origin against the unified location service (server is the source of truth). */
export async function confirmOriginWithServer(
  selected: LocationResult | null,
  rawText: string
): Promise<{ ok: true; location: LocationResult } | { ok: false; message: string }> {
  const local = validateOriginSelection(selected, rawText);
  if (local) return { ok: false, message: local.message };
  try {
    const params = new URLSearchParams();
    const refId = selected?.refId ?? selected?._id;
    if (refId) params.set("id", String(refId));
    else params.set("name", rawText.trim());
    const response = await fetch(`${BACKEND_BASE_URL}/locations/validate?${params.toString()}`);
    const data = await response.json().catch(() => ({}));
    if (!response.ok || data?.success !== true || !data?.location) {
      return { ok: false, message: typeof data?.message === "string" ? data.message : ORIGIN_ERROR };
    }
    return { ok: true, location: data.location as LocationResult };
  } catch {
    return { ok: false, message: "Could not verify the origin. Check your connection and try again." };
  }
}

export type TripDateInput = {
  startDate: string;
  endDate: string;
  /** Return leg required (round trip). */
  requireReturn?: boolean;
  returnDate?: string;
};

export function validateTripDates({ startDate, endDate, requireReturn = false, returnDate }: TripDateInput): TripValidationError | null {
  if (!startDate.trim()) {
    return { field: "startDate", message: "Please select a departure date." };
  }
  if (!isStrictAdISO(startDate.trim())) {
    return { field: "startDate", message: "Please select a valid departure date." };
  }
  if (startDate.trim() < todayAdISO()) {
    return { field: "startDate", message: "Please select a future travel date." };
  }
  if (!endDate.trim()) {
    return { field: "endDate", message: "Please select a return date." };
  }
  if (!isStrictAdISO(endDate.trim())) {
    return { field: "endDate", message: "Please select a valid return date." };
  }
  if (endDate.trim() < startDate.trim()) {
    return { field: "endDate", message: "Return date must be after the departure date." };
  }
  if (requireReturn && returnDate !== undefined) {
    if (!returnDate.trim()) {
      return { field: "returnDate", message: "Please select a return date." };
    }
    if (!isStrictAdISO(returnDate.trim())) {
      return { field: "returnDate", message: "Please select a valid return date." };
    }
    if (returnDate.trim() <= startDate.trim()) {
      return { field: "returnDate", message: "Return date must be after the departure date." };
    }
  }
  return null;
}

export function validateTravelers(adultsRaw: string, childrenRaw: string): TripValidationError | null {
  const adults = Number(adultsRaw);
  const children = childrenRaw.trim() === "" ? 0 : Number(childrenRaw);
  if (!Number.isInteger(adults) || adults < 1 || adults > 20) {
    return { field: "adults", message: "Traveler count must be from 1 to 20 adults." };
  }
  if (!Number.isInteger(children) || children < 0 || children > 20 || adults + children > 20) {
    return { field: "children", message: "Child traveler count is invalid." };
  }
  return null;
}

export function validateBudgetInput(budgetRaw?: string): TripValidationError | null {
  if (budgetRaw === undefined || budgetRaw.trim() === "") return null;
  const amount = Number(budgetRaw);
  if (!Number.isFinite(amount) || amount < 0 || amount > 10000000) {
    return { field: "budget", message: "Enter a valid budget up to NPR 10,000,000." };
  }
  return null;
}

export type CompleteTripInput = {
  destinationText: string;
  selectedDestination: DestinationSummary | null;
  originText: string;
  selectedOrigin: LocationResult | null;
  startDate: string;
  endDate: string;
  adults: string;
  children: string;
  budget?: string;
};

/** Full ordered gate for starting Complete Trip planning. */
export function validateCompleteTripInput(input: CompleteTripInput): TripValidationError | null {
  return (
    validateDestinationSelection(input.selectedDestination, input.destinationText) ??
    validateOriginSelection(input.selectedOrigin, input.originText) ??
    validateTripDates({ startDate: input.startDate, endDate: input.endDate }) ??
    validateTravelers(input.adults, input.children) ??
    validateBudgetInput(input.budget) ??
    null
  );
}
