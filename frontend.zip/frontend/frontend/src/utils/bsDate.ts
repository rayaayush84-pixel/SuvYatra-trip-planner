// Central BS (Bikram Sambat) ↔ AD (Gregorian) date utilities for SuvYatra.
// All conversion goes through the `nepali-date-converter` library — never
// hand-rolled tables. The canonical stored format everywhere (DB, APIs,
// bookings, payments) is AD ISO: YYYY-MM-DD.

import NepaliDate from "nepali-date-converter";

export type BsDate = { year: number; month: number; day: number }; // month 1-12

const AD_MONTH_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const AD_MONTH_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

/** Local-timezone YYYY-MM-DD (avoids the UTC off-by-one of toISOString). */
export function toISODateLocal(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function todayAdISO(): string {
  return toISODateLocal(new Date());
}

/** Strict AD check: format + real calendar date (rejects 2026-02-30). */
export function isStrictAdISO(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d;
}

/** AD ISO → BS. Returns null for invalid input. */
export function adToBs(iso: string): BsDate | null {
  if (!isStrictAdISO(iso)) return null;
  try {
    const [y, m, d] = iso.split("-").map(Number);
    const bs = new NepaliDate(new Date(y, m - 1, d)).getBS();
    return { year: bs.year, month: bs.month + 1, day: bs.date };
  } catch {
    return null;
  }
}

/** BS → canonical AD ISO. Round-trip verified; null when the BS date is invalid. */
export function bsToAd(year: number, month: number, day: number): string | null {
  if (!Number.isInteger(year) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
  if (month < 1 || month > 12 || day < 1 || day > 32) return null;
  try {
    const js = new NepaliDate(year, month - 1, day).toJsDate();
    const iso = toISODateLocal(js);
    // Round-trip: the BS reading of the result must equal the input.
    const check = adToBs(iso);
    if (!check || check.year !== year || check.month !== month || check.day !== day) return null;
    return iso;
  } catch {
    return null;
  }
}

/** BS month display names, derived from the library (not hardcoded). */
let cachedBsMonthNames: string[] | null = null;
export function bsMonthNames(): string[] {
  if (!cachedBsMonthNames) {
    try {
      cachedBsMonthNames = Array.from({ length: 12 }, (_, i) =>
        new NepaliDate(2083, i, 1).format("MMMM")
      );
    } catch {
      cachedBsMonthNames = ["Baisakh", "Jestha", "Asar", "Shrawan", "Bhadra", "Aswin", "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra"];
    }
  }
  return cachedBsMonthNames;
}

export type BsMonthInfo = { daysInMonth: number; firstWeekday: number }; // Sunday-first weekday

/** Grid info for a BS month, probed through the library (no hardcoded tables). */
export function bsMonthInfo(year: number, month: number): BsMonthInfo {
  let daysInMonth = 30;
  for (let d = 32; d >= 28; d--) {
    if (bsToAd(year, month, d)) {
      daysInMonth = d;
      break;
    }
  }
  let firstWeekday = 0;
  try {
    firstWeekday = new NepaliDate(year, month - 1, 1).toJsDate().getDay();
  } catch {
    firstWeekday = 0;
  }
  return { daysInMonth, firstWeekday };
}

export function adMonthInfo(year: number, month: number): BsMonthInfo {
  const daysInMonth = new Date(year, month, 0).getDate();
  const firstWeekday = new Date(year, month - 1, 1).getDay();
  return { daysInMonth, firstWeekday };
}

/** "07 Oct 2026 · 21 Aswin 2083" — clean dual display for a canonical date. */
export function formatDualDisplay(iso: string): string {
  if (!isStrictAdISO(iso)) return iso;
  const [y, m, d] = iso.split("-").map(Number);
  const ad = `${String(d).padStart(2, "0")} ${AD_MONTH_SHORT[m - 1]} ${y}`;
  const bs = adToBs(iso);
  if (!bs) return ad;
  const names = bsMonthNames();
  return `${ad} · ${bs.day} ${names[bs.month - 1]} ${bs.year}`;
}

/** "7 October 2026" long AD form. */
export function formatAdLong(iso: string): string {
  if (!isStrictAdISO(iso)) return iso;
  const [y, m, d] = iso.split("-").map(Number);
  return `${d} ${AD_MONTH_LONG[m - 1]} ${y}`;
}

/** "AD: 2026-10-07 / BS: 2083-06-21" lines for the picker footer. */
export function formatAdBsLines(iso: string): { ad: string; bs: string } {
  const bs = adToBs(iso);
  return {
    ad: `AD: ${iso}`,
    bs: bs ? `BS: ${bs.year}-${String(bs.month).padStart(2, "0")}-${String(bs.day).padStart(2, "0")}` : "BS: —",
  };
}

/** Whole-day comparison on canonical ISO strings (lexicographic is safe). */
export function isBefore(a: string, b: string): boolean {
  return a < b;
}
