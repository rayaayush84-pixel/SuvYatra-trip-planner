// Shared quantity validation for guest, room and activity-participant counts.
// Single source of truth for limits and messages: every quantity input and
// every submit path uses these helpers so Adults / Children / Rooms /
// Participants behave identically everywhere.
//
// Business rule: per-field caps below (Adults 1-20, Children 0-20,
// Rooms 1-10, Participants 1-20). Tighter per-record limits (room capacity,
// slot capacity, transport/restaurant party size) are enforced separately by
// the screens and backend that own them and are NOT overridden here.

export type QuantityField = "adults" | "children" | "rooms" | "participants";

export const QUANTITY_LIMITS: Record<
  QuantityField,
  { min: number; max: number; label: string }
> = {
  adults: { min: 1, max: 20, label: "Adults" },
  children: { min: 0, max: 20, label: "Children" },
  rooms: { min: 1, max: 10, label: "Rooms" },
  participants: { min: 1, max: 20, label: "Participants" },
};

export const INVALID_WHOLE_NUMBER_MESSAGE = "Please enter a valid whole number.";

/** Keep keystrokes to plain digits (empty allowed while clearing). */
export function sanitizeQuantityText(text: string): string {
  return text.replace(/[^0-9]/g, "").slice(0, 3);
}

/** Strict parse: digits only, otherwise undefined (never NaN callers must guard). */
export function parseQuantityText(text: string): number | undefined {
  const trimmed = text.trim();
  if (!/^\d+$/.test(trimmed)) return undefined;
  const value = Number(trimmed);
  return Number.isSafeInteger(value) ? value : undefined;
}

export function quantityRangeMessage(field: QuantityField): string {
  const { min, max, label } = QUANTITY_LIMITS[field];
  return `${label} must be between ${min} and ${max}.`;
}

export function quantityMaxMessage(field: QuantityField): string {
  const { max, label } = QUANTITY_LIMITS[field];
  return `Maximum ${max} ${label.toLowerCase()} allowed.`;
}

/**
 * Submit/blur validation for a raw text field. Returns a short,
 * non-technical message, or null when the value is acceptable.
 * An empty Children field means 0 (matching historical behavior).
 */
export function validateQuantityText(text: string, field: QuantityField): string | null {
  const { min, max } = QUANTITY_LIMITS[field];
  if (text.trim() === "") {
    return field === "children" ? null : quantityRangeMessage(field);
  }
  const value = parseQuantityText(text);
  if (value === undefined) return INVALID_WHOLE_NUMBER_MESSAGE;
  if (value < min || value > max) return quantityRangeMessage(field);
  return null;
}

/**
 * Normalize anything unexpected (route params, stored state, API data) into a
 * safe integer inside [min, max]. Never NaN, never Infinity, never throws:
 * non-numeric becomes the minimum, decimals truncate, out-of-range clamps.
 */
export function normalizeQuantity(value: unknown, field: QuantityField): number {
  const { min, max } = QUANTITY_LIMITS[field];
  const numeric =
    typeof value === "number" ? value : Number(String(value ?? ""));
  if (Number.isNaN(numeric)) return min;
  if (numeric === Infinity) return max;
  if (numeric === -Infinity) return min;
  return Math.min(max, Math.max(min, Math.trunc(numeric)));
}

/**
 * Keystroke gate for controlled text inputs. Non-digit edits are ignored
 * entirely; a value above max keeps the previous text and reports capped so
 * the caller can show "Maximum X ... allowed.".
 */
export function handleQuantityTextChange(
  field: QuantityField,
  nextText: string,
  currentText: string
): { text: string; capped: boolean } {
  if (nextText !== "" && !/^\d+$/.test(nextText)) {
    return { text: currentText, capped: false };
  }
  const sanitized = sanitizeQuantityText(nextText);
  const parsed = parseQuantityText(sanitized);
  if (parsed !== undefined && parsed > QUANTITY_LIMITS[field].max) {
    return { text: currentText, capped: true };
  }
  return { text: sanitized, capped: false };
}
