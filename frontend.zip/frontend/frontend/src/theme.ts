export const colors = {
  primary: "#14B8A6",
  primaryDark: "#0E9488",
  secondary: "#F59E0B",
  accent: "#7C3AED",
  background: "#F4F8FB",
  surface: "#FFFFFF",
  text: "#102A43",
  textMuted: "#64748B",
  border: "#E2E8F0",
  white: "#FFFFFF",
  facebook: "#1877F2",
  apple: "#000000",
  star: "#FFB800",
  price: "#14B8A6",
  cardBackground: "#FFFFFF",
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 999,
};

// Shared elevation language: soft, premium shadows used by cards,
// sheets, buttons and popups across every screen.
export const shadows = {
  sm: {
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 1,
  },
  md: {
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 3,
  },
  lg: {
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.12,
    shadowRadius: 24,
    elevation: 6,
  },
} as const;

// Shared type scale: headings, titles, body and captions stay consistent
// no matter which screen renders them.
export const typography = {
  heroTitle: 32,
  pageTitle: 24,
  sectionTitle: 20,
  cardTitle: 17,
  body: 14,
  caption: 12,
} as const;

// Feedback colors for loading/empty/error/success messaging.
export const feedback = {
  success: "#15803D",
  successBackground: "#DCFCE7",
  danger: "#B42318",
  dangerBackground: "#FEF2F2",
  warning: "#B45309",
  warningBackground: "#FEF3C7",
  overlay: "rgba(8, 15, 28, 0.45)",
} as const;