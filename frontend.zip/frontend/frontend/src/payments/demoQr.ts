/**
 * Demo QR payment payload helpers (SuvYatra sandbox only — no real money).
 *
 * The QR encodes a JSON payload generated dynamically per booking:
 * {
 *   "type": "SUVYATRA_DEMO_PAYMENT",
 *   "demo": true,
 *   "bookingId": "...",      // database booking _id
 *   "bookingCode": "...",     // human booking reference
 *   "paymentId": "...",       // sandbox Payment ledger _id
 *   "amount": 1200,
 *   "currency": "NPR",
 *   "method": "esewa",
 *   "issuedAt": "2026-…",    // ISO timestamp
 *   "nonce": "…",            // unique per initiation
 * }
 *
 * No sensitive data (no tokens, passwords, or personal details) is embedded.
 * A scan is successful ONLY when every field validates against the booking
 * the user is currently paying for. Validation alone never marks anything
 * paid — the backend /confirm endpoint is the single source of truth.
 */

export const DEMO_QR_TYPE = "SUVYATRA_DEMO_PAYMENT";

/** Demo QR codes older than this are treated as expired. */
export const DEMO_QR_MAX_AGE_MS = 24 * 60 * 60 * 1000;

export type DemoQrPayload = {
  type: string;
  demo: boolean;
  bookingId: string;
  bookingCode: string;
  paymentId: string;
  amount: number;
  currency: string;
  method: string;
  issuedAt: string;
  nonce: string;
  /** Present only on complete-trip QR codes (one payment for the whole trip). */
  tripCheckoutId?: string;
  checkoutCode?: string;
};

export type DemoQrExpectation = {
  bookingId: string;
  bookingCode: string;
  amount: number;
  currency?: string;
};

export type DemoTripQrExpectation = {
  tripCheckoutId: string;
  checkoutCode: string;
  amount: number;
  currency?: string;
};

export function buildDemoQrPayload(input: {
  bookingId: string;
  bookingCode: string;
  paymentId: string;
  amount: number;
  currency?: string;
  method: string;
  /** Reuse an existing nonce/issuedAt so the QR stays stable across re-renders. */
  nonce?: string;
  issuedAt?: string;
  /** Set for complete-trip QR codes so the scanner can bind to the checkout. */
  tripCheckoutId?: string;
  checkoutCode?: string;
}): string {
  const payload: DemoQrPayload = {
    type: DEMO_QR_TYPE,
    demo: true,
    bookingId: input.bookingId,
    bookingCode: input.bookingCode,
    paymentId: input.paymentId,
    amount: Number(input.amount),
    currency: (input.currency || "NPR").toUpperCase(),
    method: input.method,
    issuedAt: input.issuedAt ?? new Date().toISOString(),
    nonce:
      input.nonce ??
      (typeof Math !== "undefined" && Math.random
        ? Math.random().toString(36).slice(2, 10).toUpperCase()
        : String(Date.now()).slice(-8)),
    ...(input.tripCheckoutId ? { tripCheckoutId: input.tripCheckoutId } : {}),
    ...(input.checkoutCode ? { checkoutCode: input.checkoutCode } : {}),
  };
  return JSON.stringify(payload);
}

export function parseDemoQrPayload(raw: string): { ok: true; payload: DemoQrPayload } | { ok: false; error: string } {
  if (!raw || typeof raw !== "string" || !raw.trim()) {
    return { ok: false, error: "No QR data was detected. Please scan the QR code shown for this booking." };
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw.trim());
  } catch {
    return { ok: false, error: "Invalid payment QR code. Please scan the QR code displayed for this booking." };
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    return { ok: false, error: "Invalid payment QR code. Please scan the QR code displayed for this booking." };
  }
  return { ok: true, payload: parsed as DemoQrPayload };
}

/**
 * Strictly validate scanned QR data against the booking being paid.
 * Returns the payload only when EVERY check passes.
 */
export function validateDemoQrForBooking(
  raw: string,
  expected: DemoQrExpectation,
  nowMs: number = Date.now()
): { ok: true; payload: DemoQrPayload } | { ok: false; error: string } {
  const INVALID = "Invalid payment QR code. Please scan the QR code displayed for this booking.";
  const parsed = parseDemoQrPayload(raw);
  if (!parsed.ok) return parsed;
  const p = parsed.payload;
  if (p.type !== DEMO_QR_TYPE || p.demo !== true) return { ok: false, error: INVALID };
  if (!p.bookingId || p.bookingId !== expected.bookingId) return { ok: false, error: INVALID };
  if (!p.bookingCode || p.bookingCode !== expected.bookingCode) return { ok: false, error: INVALID };
  if (!Number.isFinite(Number(p.amount)) || Number(p.amount) !== Number(expected.amount)) {
    return { ok: false, error: "This QR code is for a different amount. Please scan the QR code displayed for this booking." };
  }
  const expectedCurrency = (expected.currency || "NPR").toUpperCase();
  if (!p.currency || String(p.currency).toUpperCase() !== expectedCurrency) {
    return { ok: false, error: "This QR code is for a different currency. Please scan the QR code displayed for this booking." };
  }
  if (!p.paymentId || typeof p.paymentId !== "string") return { ok: false, error: INVALID };
  if (!p.nonce || typeof p.nonce !== "string") return { ok: false, error: INVALID };
  const issuedMs = Date.parse(p.issuedAt);
  if (!Number.isFinite(issuedMs)) return { ok: false, error: INVALID };
  if (nowMs - issuedMs > DEMO_QR_MAX_AGE_MS) {
    return { ok: false, error: "This demo QR code has expired. Please initiate the demo payment again to get a fresh QR code." };
  }
  if (issuedMs - nowMs > 5 * 60 * 1000) return { ok: false, error: INVALID };
  return { ok: true, payload: p };
}

/**
 * Strictly validate scanned QR data against a complete-trip checkout.
 * The QR must name THIS checkout and carry THIS grand total — a single
 * booking's QR from another payment can never confirm the whole trip.
 */
export function validateDemoQrForTripCheckout(
  raw: string,
  expected: DemoTripQrExpectation,
  nowMs: number = Date.now()
): { ok: true; payload: DemoQrPayload } | { ok: false; error: string } {
  const INVALID = "Invalid trip payment QR code. Please scan the QR code displayed for this trip.";
  const parsed = parseDemoQrPayload(raw);
  if (!parsed.ok) return parsed;
  const p = parsed.payload;
  if (p.type !== DEMO_QR_TYPE || p.demo !== true) return { ok: false, error: INVALID };
  if (!p.tripCheckoutId || p.tripCheckoutId !== expected.tripCheckoutId) {
    return { ok: false, error: INVALID };
  }
  if (!p.checkoutCode || p.checkoutCode !== expected.checkoutCode) {
    return { ok: false, error: INVALID };
  }
  if (!Number.isFinite(Number(p.amount)) || Number(p.amount) !== Number(expected.amount)) {
    return { ok: false, error: "This QR code is for a different amount. Please scan the QR code displayed for this trip." };
  }
  const expectedCurrency = (expected.currency || "NPR").toUpperCase();
  if (!p.currency || String(p.currency).toUpperCase() !== expectedCurrency) {
    return { ok: false, error: "This QR code is for a different currency. Please scan the QR code displayed for this trip." };
  }
  if (!p.paymentId || typeof p.paymentId !== "string") return { ok: false, error: INVALID };
  if (!p.nonce || typeof p.nonce !== "string") return { ok: false, error: INVALID };
  const issuedMs = Date.parse(p.issuedAt);
  if (!Number.isFinite(issuedMs)) return { ok: false, error: INVALID };
  if (nowMs - issuedMs > DEMO_QR_MAX_AGE_MS) {
    return { ok: false, error: "This demo QR code has expired. Please initiate the trip payment again to get a fresh QR code." };
  }
  if (issuedMs - nowMs > 5 * 60 * 1000) return { ok: false, error: INVALID };
  return { ok: true, payload: p };
}
