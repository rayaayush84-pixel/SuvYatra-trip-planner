// Single source of truth for demo/sandbox payment methods across My
// Bookings, Complete Trip checkout, QR branding, and validation.
// Demo only: no entry here implies a real gateway transfer — every flow
// labels itself DEMO and records demo:true server-side.

export type PaymentMethodId =
  | "esewa"
  | "khalti"
  | "imepay"
  | "fonepay"
  | "connectips"
  | "prabhupay"
  | "namastepay"
  | "bank_card";

export type PaymentBrand = {
  id: PaymentMethodId;
  label: string;
  color: string;
  softBg: string;
  scanText: string;
  instructions: string;
};

export const PAYMENT_METHODS: PaymentBrand[] = [
  {
    id: "esewa",
    label: "eSewa",
    color: "#1E8E3E",
    softBg: "#EAF6EC",
    scanText: "Scan this QR with eSewa to pay",
    instructions: "Open eSewa → Scan & Pay → scan the QR → complete the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "khalti",
    label: "Khalti",
    color: "#5C2D91",
    softBg: "#F1EAF9",
    scanText: "Scan this QR with Khalti to pay",
    instructions: "Open Khalti → Scan & Pay → scan the QR → complete the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "imepay",
    label: "IME Pay",
    color: "#C8102E",
    softBg: "#FDECEF",
    scanText: "Scan this QR with IME Pay to pay",
    instructions: "Open IME Pay → QR Scan → scan the QR → complete the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "fonepay",
    label: "FonePay",
    color: "#0B7A3E",
    softBg: "#EAF6EC",
    scanText: "Scan this QR with FonePay to pay",
    instructions: "Open your bank app → FonePay QR → scan the QR → complete the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "connectips",
    label: "ConnectIPS",
    color: "#0F766E",
    softBg: "#E4F3EF",
    scanText: "Scan this QR with ConnectIPS to pay",
    instructions: "Open ConnectIPS → scan the QR → authorize the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "prabhupay",
    label: "PrabhuPAY",
    color: "#B45309",
    softBg: "#FEF3E2",
    scanText: "Scan this QR with PrabhuPAY to pay",
    instructions: "Open PrabhuPAY → scan the QR → complete the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "namastepay",
    label: "Namaste Pay",
    color: "#1D4ED8",
    softBg: "#E8EEFB",
    scanText: "Scan this QR with Namaste Pay to pay",
    instructions: "Open Namaste Pay → scan the QR → complete the demo payment → return here and press Confirm Payment.",
  },
  {
    id: "bank_card",
    label: "Card",
    color: "#334155",
    softBg: "#EEF2F7",
    scanText: "Scan this demo QR to pay by card",
    instructions: "Use the demo card flow → complete the demo payment → return here and press Confirm Payment.",
  },
];

/** Wallet methods offered for new payments (bank card kept for legacy records). */
export const WALLET_METHOD_IDS: PaymentMethodId[] = [
  "esewa",
  "khalti",
  "imepay",
  "fonepay",
  "connectips",
  "prabhupay",
  "namastepay",
];

export function brandFor(method: string): PaymentBrand {
  return (
    PAYMENT_METHODS.find((brand) => brand.id === method) ?? {
      id: method as PaymentMethodId,
      label: method || "Demo",
      color: "#0F766E",
      softBg: "#E4F3EF",
      scanText: "Scan this demo QR to pay",
      instructions: "Complete the demo payment, then press Confirm Payment.",
    }
  );
}

export function methodLabel(method?: string): string {
  if (!method) return "Not chosen yet";
  return brandFor(method).label;
}
