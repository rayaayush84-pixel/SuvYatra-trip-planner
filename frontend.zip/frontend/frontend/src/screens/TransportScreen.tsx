import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "Transport">;
type TransportRecord = {
  _id: string;
  name: string;
  type?: string;
  provider?: string;
  route?: string;
  origin?: string;
  destination?: string;
  description?: string;
  departureTime?: string;
  arrivalTime?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  durationMinutes?: number;
  price?: number;
  currency?: string;
  capacity?: number;
  serviceMode?: string;
  bookingUrl?: string;
  contact?: { phone?: string; website?: string };
  latitude?: number;
  longitude?: number;
};
type TransportFilters = {
  types: string[];
  origins: string[];
  destinations: string[];
  serviceModes: string[];
};
type SavedItem = { _id: string; itemType: string; itemId?: string };

const EMPTY_FILTERS: TransportFilters = { types: [], origins: [], destinations: [], serviceModes: [] };

export default function TransportScreen({ navigation, route }: Props) {
  const { getAccessToken } = useAuth();
  const [records, setRecords] = useState<TransportRecord[]>([]);
  const [record, setRecord] = useState<TransportRecord | null>(null);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [query, setQuery] = useState(route.params?.location ?? "");
  const [submittedQuery, setSubmittedQuery] = useState(route.params?.location?.trim() ?? "");
  const [selectedType, setSelectedType] = useState("");
  const [selectedMode, setSelectedMode] = useState("");
  const [origin, setOrigin] = useState(route.params?.origin ?? "");
  const [destination, setDestination] = useState(route.params?.destination ?? "");
  const [sort, setSort] = useState("");
  const [savedItem, setSavedItem] = useState<SavedItem | null>(null);
  const [savedMap, setSavedMap] = useState<Record<string, SavedItem>>({});
  const [savingId, setSavingId] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (route.params?.origin !== undefined) setOrigin(route.params.origin);
    if (route.params?.destination !== undefined) setDestination(route.params.destination);
    if (route.params?.location !== undefined) {
      setQuery(route.params.location);
      setSubmittedQuery(route.params.location.trim());
    }
  }, [route.params?.location]);

  useEffect(() => {
    const timeout = setTimeout(() => setSubmittedQuery(query.trim()), 350);
    return () => clearTimeout(timeout);
  }, [query]);

  const params = useMemo(() => {
    const values = new URLSearchParams();
    if (submittedQuery) values.set("search", submittedQuery);
    if (selectedType) values.set("type", selectedType);
    if (selectedMode) values.set("serviceMode", selectedMode);
    if (origin.trim()) values.set("origin", origin.trim());
    if (destination.trim()) values.set("destination", destination.trim());
    if (sort) values.set("sort", sort);
    return values.toString();
  }, [destination, origin, selectedMode, selectedType, sort, submittedQuery]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    const recordsRequest = route.params?.transportId
      ? backendRequest<TransportRecord>(`/transports/${encodeURIComponent(route.params.transportId)}`, { signal: controller.signal })
      : backendRequest<TransportRecord[]>(`/transports?${params}`, { signal: controller.signal });
    const filtersRequest = backendRequest<TransportFilters>("/transports/filters", { signal: controller.signal });
    Promise.all([recordsRequest, filtersRequest])
      .then(([result, availableFilters]) => {
        setFilters(availableFilters);
        if (Array.isArray(result)) {
          setRecords(result);
          setRecord(null);
        } else {
          setRecord(result);
        }
      })
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load transport listings.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [params, reloadKey, route.params?.transportId]);

  useEffect(() => {
    const token = getAccessToken();
    if (!token || !record) {
      setSavedItem(null);
      return;
    }
    const controller = new AbortController();
    backendRequest<SavedItem[]>("/saved-items", {
      signal: controller.signal,
      headers: { Authorization: `Bearer ${token}` },
    }).then((items) => {
      if (!controller.signal.aborted) {
        setSavedItem(items.find((item) => item.itemType === "transport" && item.itemId === record._id) ?? null);
      }
    }).catch((requestError: unknown) => {
      if (!controller.signal.aborted) {
        setError(requestError instanceof Error ? requestError.message : "Could not check Saved Places.");
      }
    });
    return () => controller.abort();
  }, [getAccessToken, record?._id, reloadKey]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || record) {
        if (!token) setSavedMap({});
        return;
      }
      const controller = new AbortController();
      backendRequest<SavedItem[]>("/saved-items", {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((items) => {
          if (!controller.signal.aborted) {
            const map: Record<string, SavedItem> = {};
            for (const item of items) {
              if (item.itemType === "transport" && item.itemId) map[item.itemId] = item;
            }
            setSavedMap(map);
          }
        })
        .catch(() => {});
      return () => controller.abort();
    }, [getAccessToken, record?._id])
  );

  const openMaps = (item: TransportRecord) => {
    const queryText = item.latitude !== undefined && item.longitude !== undefined
      ? `${item.latitude},${item.longitude}`
      : [item.origin, item.destination, item.route].filter(Boolean).join(" to ");
    return Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(queryText)}`);
  };

  const toggleSaved = async (item: TransportRecord) => {
    const token = getAccessToken();
    if (!token) {
      navigation.navigate("Login", { notice: "Sign in to save transport options." });
      return;
    }
    setSaving(true);
    setError("");
    try {
      if (savedItem) {
        await backendRequest(`/saved-items/${savedItem._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            itemType: "transport",
            itemId: item._id,
            name: item.name,
            location: [item.origin, item.destination].filter(Boolean).join(" → ") || item.route,
            image: item.image,
            imageSource: item.imageSource,
            imageSourcePage: item.imageSourcePage,
            imageLicense: item.imageLicense,
            imageCredit: item.imageCredit,
            imageDescription: item.imageDescription,
            imageRelevance: item.imageRelevance,
          }),
        });
        setSavedItem(saved);
        showToast("Saved to your places");
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSaving(false);
    }
  };

  const toggleSavedForList = async (item: TransportRecord) => {
    const token = getAccessToken();
    if (!token) {
      navigation.navigate("Login", { notice: "Sign in to save transport options." });
      return;
    }
    setSavingId(item._id);
    setError("");
    try {
      const existing = savedMap[item._id];
      if (existing) {
        await backendRequest(`/saved-items/${existing._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedMap((current) => {
          const next = { ...current };
          delete next[item._id];
          return next;
        });
        if (savedItem?._id === existing._id) setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            itemType: "transport",
            itemId: item._id,
            name: item.name,
            location: [item.origin, item.destination].filter(Boolean).join(" → ") || item.route,
            image: item.image,
            imageSource: item.imageSource,
            imageSourcePage: item.imageSourcePage,
            imageLicense: item.imageLicense,
            imageCredit: item.imageCredit,
            imageDescription: item.imageDescription,
            imageRelevance: item.imageRelevance,
          }),
        });
        setSavedMap((current) => ({ ...current, [item._id]: saved }));
        showToast("Saved to your places");
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSavingId("");
    }
  };

  const addToTrip = (item: TransportRecord) => {
    navigation.navigate("MainTabs", {
      screen: "Trips",
      params: {
        destination: {
          id: item._id,
          category: "transport",
          name: item.name,
          location: [item.origin, item.destination].filter(Boolean).join(" → ") || item.route,
          description: `Transport${item.type ? ` · ${item.type}` : ""}`,
          latitude: item.latitude,
          longitude: item.longitude,
          tags: ["transport"],
        },
      },
    });
  };

  const clearFilters = () => {
    setQuery("");
    setSubmittedQuery("");
    setSelectedType("");
    setSelectedMode("");
    setOrigin("");
    setDestination("");
    setSort("");
  };

  const formatDuration = (minutes?: number) => {
    if (minutes === undefined) return "Duration unavailable";
    const hours = Math.floor(minutes / 60);
    const remaining = minutes % 60;
    return `${hours ? `${hours}h ` : ""}${remaining ? `${remaining}m` : ""}`.trim() || "0m";
  };

  // Same-city services (local taxis, hires, rentals) genuinely serve one
  // place: never render them as "X → X". Prefer their route text, else name
  // the locality honestly. Point-to-point routes render unchanged.
  const routeLabel = (item: { origin?: string; destination?: string; route?: string }) => {
    const o = item.origin?.trim() ?? "";
    const d = item.destination?.trim() ?? "";
    if (o && d && o.toLowerCase() === d.toLowerCase()) {
      const route = item.route?.trim() ?? "";
      if (route && route.toLowerCase() !== `${o.toLowerCase()} → ${d.toLowerCase()}`) return route;
      return `Local service in ${o}`;
    }
    return [o, d].filter(Boolean).join(" → ") || item.route?.trim() || "Route unavailable";
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} />
        <Text style={styles.headerTitle}>{record?.name ?? "Transportation"}</Text>
        <View style={styles.headerSpacer} />
      </View>
      {!record ? (
        <View style={styles.controls}>
          <View style={styles.routeRow}>
            <TextInput value={origin} onChangeText={setOrigin} placeholder="From" placeholderTextColor={colors.textMuted} style={styles.routeInput} />
            <Ionicons name="arrow-forward" size={17} color={colors.primary} />
            <TextInput value={destination} onChangeText={setDestination} placeholder="To" placeholderTextColor={colors.textMuted} style={styles.routeInput} />
          </View>
          {origin.trim() && destination.trim() && origin.trim().toLowerCase() === destination.trim().toLowerCase() ? (
            <Text style={styles.caveat}>Same city — showing local taxis, hires and rentals for {origin.trim()}.</Text>
          ) : null}
          <View style={styles.controlsFooter}>
            <View style={styles.sortRow}>
              {(["", "cheapest", "duration"] as const).map((option) => (
                <Pressable key={option || "name"} onPress={() => setSort(option)} style={[styles.sortChip, sort === option && styles.sortChipActive]}>
                  <Text style={[styles.sortText, sort === option && styles.sortTextActive]}>{option || "Name"}{option === "duration" ? ": fastest*" : option === "cheapest" ? ": price*" : ""}</Text>
                </Pressable>
              ))}
            </View>
            <Pressable onPress={clearFilters}><Text style={styles.linkText}>Clear all</Text></Pressable>
          </View>
          <Text style={styles.caveat}>*Sorted using stored listing data only; this is not live availability.</Text>
        </View>
      ) : null}
      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} /><Text style={styles.mutedText}>Loading verified transport data…</Text></View>
      ) : error ? (
        <View style={styles.center}><Text style={styles.errorText}>{error}</Text><Pressable onPress={() => setReloadKey((value) => value + 1)}><Text style={styles.linkText}>Try again</Text></Pressable></View>
      ) : record ? (
        <ScrollView contentContainerStyle={styles.detailContent}>
          <RelevantImage entity={{ name: record.name, type: "transport", location: [record.route, record.origin, record.destination].filter(Boolean).join(", "), image: record.image, images: record.images, imageSource: record.imageSource, imageSourcePage: record.imageSourcePage, imageLicense: record.imageLicense, imageCredit: record.imageCredit, imageDescription: record.imageDescription, imageRelevance: record.imageRelevance }} style={styles.transportHero} />
          {record.description ? <Text style={styles.bodyText}>{record.description}</Text> : null}
          <DetailRow label="Provider" value={record.provider} />
          <DetailRow label="Type" value={record.type} />
          <DetailRow label="Origin" value={record.origin} />
          <DetailRow label="Destination" value={record.destination} />
          <DetailRow label="Departure" value={record.departureTime} />
          <DetailRow label="Arrival" value={record.arrivalTime} />
          <DetailRow label="Duration" value={formatDuration(record.durationMinutes)} />
          <DetailRow label="Price" value={record.price !== undefined ? `${record.currency ?? "NPR"} ${record.price}` : undefined} />
          <DetailRow label="Capacity" value={record.capacity?.toString()} />
          <DetailRow label="Contact" value={record.contact?.phone} />
          <Text style={styles.caveat}>Availability shown in the trip planner is demo inventory, not live provider data. Confirm schedules with the operator before travelling.</Text>
          <Pressable
            style={styles.primaryButton}
            onPress={() => navigation.navigate("Booking", {
              vehicle: {
                id: record._id,
                name: record.name,
                type: record.type ?? "",
                price: record.price !== undefined ? `${record.currency ?? "NPR"} ${record.price}` : "",
                time: record.departureTime ?? "",
                image: record.image,
                location: [record.origin, record.destination].filter(Boolean).join(" → ") || record.route,
                imageSource: record.imageSource,
                imageSourcePage: record.imageSourcePage,
                imageLicense: record.imageLicense,
                imageCredit: record.imageCredit,
                imageDescription: record.imageDescription,
                imageRelevance: record.imageRelevance,
                origin: record.origin,
                destination: record.destination,
                departureTime: record.departureTime,
                arrivalTime: record.arrivalTime,
                durationMinutes: record.durationMinutes,
                unitPrice: record.price,
                currency: record.currency,
                capacity: record.capacity,
                serviceMode: record.serviceMode,
              },
              adults: 1,
            })}
            accessibilityRole="button"
            accessibilityLabel={`Select seats and book ${record.name}`}
          >
            <Ionicons name="ticket-outline" size={18} color={colors.white} />
            <Text style={styles.primaryButtonText}>Select seats & book</Text>
          </Pressable>
          <View style={styles.actionRow}>
            <ActionButton label="Route" icon="navigate-outline" onPress={() => void openMaps(record)} />
            <ActionButton label="Save" icon={savedItem ? "heart" : "heart-outline"} onPress={() => void toggleSaved(record)} disabled={saving} />
            <ActionButton label="Add to Trip" icon="add-circle-outline" onPress={() => addToTrip(record)} />
          </View>
          {record.bookingUrl ? <Pressable onPress={() => void Linking.openURL(record.bookingUrl!)}><Text style={styles.linkText}>Open provider booking page</Text></Pressable> : null}
        </ScrollView>
      ) : (
        <FlatList
          data={records}
          keyExtractor={(item) => item._id}
          contentContainerStyle={records.length ? styles.list : styles.emptyList}
          ListEmptyComponent={<View style={styles.center}><Ionicons name="bus-outline" size={30} color={colors.primary} /><Text style={styles.emptyTitle}>No verified transport listings</Text><Text style={styles.mutedText}>The database currently has no verified route, provider, or rental listings. Search again or clear filters.</Text></View>}
          renderItem={({ item }) => {
            const listSaved = savedMap[item._id];
            return (
            <View style={styles.card}>
              <View style={styles.cardHeading}>
                <Pressable
                  onPress={() => navigation.push("Transport", { transportId: item._id })}
                  style={styles.cardNav}
                  accessibilityRole="button"
                  accessibilityLabel={`View details for ${item.name}`}
                >
                  <RelevantImage entity={{ name: item.name, type: "transport", location: [item.route, item.origin, item.destination].filter(Boolean).join(", "), image: item.image, images: item.images, imageSource: item.imageSource, imageSourcePage: item.imageSourcePage, imageLicense: item.imageLicense, imageCredit: item.imageCredit, imageDescription: item.imageDescription, imageRelevance: item.imageRelevance }} style={styles.iconCircle} />
                  <View style={styles.cardHeadingText}>
                    <Text style={styles.name}>{item.name}</Text>
                    <Text style={styles.meta}>{[item.provider, item.type, item.serviceMode].filter(Boolean).join(" · ") || "Provider/type unavailable"}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={19} color={colors.primary} />
                </Pressable>
                <Pressable
                  onPress={() => void toggleSavedForList(item)}
                  disabled={savingId === item._id}
                  accessibilityRole="button"
                  accessibilityLabel={listSaved ? `Remove ${item.name} from Saved` : `Save ${item.name}`}
                >
                  {savingId === item._id ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : (
                    <Ionicons
                      name={listSaved ? "heart" : "heart-outline"}
                      size={22}
                      color={listSaved ? "#D9435F" : colors.primary}
                    />
                  )}
                </Pressable>
              </View>
              <Pressable
                onPress={() => navigation.push("Transport", { transportId: item._id })}
                accessibilityRole="button"
                accessibilityLabel={`View details for ${item.name}`}
              >
                <Text style={styles.routeText}>{routeLabel(item)}</Text>
                <View style={styles.infoRow}>
                  <Text style={styles.infoText}>{item.price !== undefined ? `${item.currency ?? "NPR"} ${item.price}` : "Price unavailable"}</Text>
                  {item.durationMinutes !== undefined ? (
                    <Text style={styles.infoText}>{formatDuration(item.durationMinutes)}</Text>
                  ) : null}
                  {item.capacity !== undefined ? <Text style={styles.infoText}>{item.capacity} seats</Text> : null}
                </View>
              </Pressable>
            </View>
            );
          }}
        />
      )}
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

function DetailRow({ label, value }: { label: string; value?: string }) {
  return <View style={styles.detailRow}><Text style={styles.detailLabel}>{label}</Text><Text style={styles.bodyText}>{value || "Information unavailable"}</Text></View>;
}

function ActionButton({ label, icon, onPress, disabled }: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  disabled?: boolean;
}) {
  return <Pressable disabled={disabled} onPress={onPress} style={styles.actionButton}><Ionicons name={icon} size={17} color={colors.primary} /><Text style={styles.actionText}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  headerTitle: { color: colors.text, fontSize: 19, fontWeight: "800", flex: 1, textAlign: "center" },
  headerSpacer: { width: 24 },
  controls: { paddingHorizontal: spacing.lg, paddingBottom: spacing.sm },
  routeRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: spacing.sm },
  routeInput: { flex: 1, backgroundColor: colors.surface, borderRadius: radius.md, color: colors.text, paddingHorizontal: spacing.md, paddingVertical: 10 },
  filterBlock: { marginTop: spacing.xs },
  filterTitle: { color: colors.textMuted, fontSize: 12, fontWeight: "700", marginBottom: 5 },
  chips: { gap: 7, paddingBottom: 4 },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 6, backgroundColor: colors.surface },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { color: colors.text, fontSize: 12 },
  chipTextActive: { color: colors.white, fontWeight: "700" },
  controlsFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: spacing.xs },
  sortRow: { flexDirection: "row", gap: 5 },
  sortChip: { borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 8, paddingVertical: 5 },
  sortChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  sortText: { color: colors.text, fontSize: 10 },
  sortTextActive: { color: colors.white },
  caveat: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: spacing.sm },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 110 },
  emptyList: { flexGrow: 1, justifyContent: "center", padding: spacing.xl },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl, gap: spacing.sm },
  emptyTitle: { fontSize: 17, color: colors.text, fontWeight: "800", textAlign: "center" },
  mutedText: { color: colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: "center" },
  errorText: { color: "#B42318", textAlign: "center" },
  linkText: { color: colors.primary, fontWeight: "700", paddingVertical: 8 },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.md, gap: spacing.sm, borderWidth: 1, borderColor: colors.border, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.07, shadowRadius: 12, elevation: 2 },
  cardHeading: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  cardNav: { flex: 1, flexDirection: "row", alignItems: "center", gap: spacing.sm },
  iconCircle: { width: 40, height: 40, borderRadius: 20, backgroundColor: "#E8F3F0", alignItems: "center", justifyContent: "center" },
  transportHero: { width: "100%", height: 210, borderRadius: radius.md },
  cardHeadingText: { flex: 1 },
  name: { color: colors.text, fontSize: 16, fontWeight: "800" },
  meta: { color: colors.textMuted, fontSize: 11, marginTop: 3 },
  routeText: { color: colors.text, fontSize: 15, fontWeight: "700" },
  infoRow: { flexDirection: "row", gap: spacing.md, flexWrap: "wrap" },
  infoText: { color: colors.textMuted, fontSize: 12 },
  detailContent: { padding: spacing.lg, paddingBottom: 120, gap: spacing.md },
  detailRow: { borderBottomWidth: 1, borderColor: colors.border, paddingBottom: spacing.sm },
  detailLabel: { color: colors.textMuted, fontSize: 11, fontWeight: "700", marginBottom: 3 },
  bodyText: { color: colors.text, fontSize: 13, lineHeight: 20 },
  primaryButton: { minHeight: 48, borderRadius: radius.md, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, marginTop: spacing.sm },
  primaryButtonText: { color: colors.white, fontSize: 14, fontWeight: "800" },
  actionRow: { flexDirection: "row", justifyContent: "space-between" },
  actionButton: { flexDirection: "row", alignItems: "center", gap: 4, padding: 6 },
  actionText: { color: colors.primary, fontSize: 11, fontWeight: "700" },
});
