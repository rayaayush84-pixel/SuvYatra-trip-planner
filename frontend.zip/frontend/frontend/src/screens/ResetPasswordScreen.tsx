import React, { useState } from "react";
import {
  ActivityIndicator,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "ResetPassword">;
const AUTH_BG =
  require("../../../assets/WhatsApp Image 2026-09-10 at 11.13.41 PM (1).jpeg");
const PASSWORD_MESSAGE =
  "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character.";

function isStrongPassword(value: string) {
  return (
    value.length >= 8 &&
    /[A-Z]/.test(value) &&
    /[a-z]/.test(value) &&
    /\d/.test(value) &&
    /[^A-Za-z0-9]/.test(value)
  );
}

export default function ResetPasswordScreen({ navigation, route }: Props) {
  const { resetPassword } = useAuth();
  const { email, otp } = route.params;
  const adminMode = route.params.admin === true;
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const confirmRef = React.useRef<TextInput>(null);

  const passwordError = submitted && !isStrongPassword(password) ? PASSWORD_MESSAGE : "";
  const confirmError =
    submitted && password !== confirmPassword ? "Passwords do not match." : "";

  const submit = async () => {
    setSubmitted(true);
    setError("");
    if (!isStrongPassword(password) || password !== confirmPassword) return;

    setBusy(true);
    try {
      await resetPassword(email, otp, password);
      if (adminMode) {
        navigation.reset({ index: 0, routes: [{ name: "AdminLogin" }] });
        return;
      }
      navigation.reset({
        index: 0,
        routes: [
          {
            name: "Login",
            params: {
              provider: "Email",
              identifier: email,
              notice: "Your password has been reset successfully. You can now log in.",
            },
          },
        ],
      });
    } catch (resetError) {
      setError(
        resetError instanceof Error ? resetError.message : "Could not reset your password."
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.hero}>
          <ImageBackground source={AUTH_BG} style={styles.heroImage} resizeMode="cover">
            <View style={styles.heroOverlay} />
            <BackButton
              navigation={navigation}
              style={styles.backButton}
              iconColor="#FFFFFF"
              label="Back to reset code"
            />
            <View style={styles.brandBlock}>
              <Text style={styles.brandText}>SuvYatra</Text>
              <Text style={styles.brandTagline}>Your AI Trip Planner</Text>
            </View>
          </ImageBackground>
        </View>

        <ScrollView
          style={styles.formScroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.formPanel}>
            <Text style={styles.title}>Create a new password</Text>
            <Text style={styles.subtitle}>
              Choose a strong password for {email}.
            </Text>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>New Password</Text>
              <View style={[styles.fieldBox, !!passwordError && styles.fieldBoxError]}>
                <Ionicons name="lock-closed-outline" size={18} color="#64748B" />
                <TextInput
                  value={password}
                  onChangeText={(value) => {
                    setPassword(value);
                    setError("");
                  }}
                  placeholder="New password"
                  placeholderTextColor="#9CA3AF"
                  style={styles.fieldInput}
                  secureTextEntry
                  autoCapitalize="none"
                  autoCorrect={false}
                  autoComplete="new-password"
                  editable={!busy}
                  returnKeyType="next"
                  onSubmitEditing={() => confirmRef.current?.focus()}
                />
              </View>
              {!!passwordError && <Text style={styles.fieldError}>{passwordError}</Text>}
              <Text style={styles.passwordHint}>
                At least 8 characters, with uppercase and lowercase letters, a number, and a special character.
              </Text>
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Confirm New Password</Text>
              <View style={[styles.fieldBox, !!confirmError && styles.fieldBoxError]}>
                <Ionicons name="lock-closed-outline" size={18} color="#64748B" />
                <TextInput
                  value={confirmPassword}
                  onChangeText={(value) => {
                    setConfirmPassword(value);
                    setError("");
                  }}
                  placeholder="Confirm new password"
                  placeholderTextColor="#9CA3AF"
                  style={styles.fieldInput}
                  secureTextEntry
                  autoCapitalize="none"
                  autoCorrect={false}
                  autoComplete="new-password"
                  editable={!busy}
                  ref={confirmRef}
                  returnKeyType="go"
                  onSubmitEditing={() => void submit()}
                />
              </View>
              {!!confirmError && <Text style={styles.fieldError}>{confirmError}</Text>}
            </View>

            {error ? (
              <View style={styles.errorBox} accessibilityRole="alert">
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : null}

            <Pressable
              style={({ pressed }) => [
                styles.submitButton,
                busy && styles.submitButtonDisabled,
                pressed && !busy && styles.submitButtonPressed,
              ]}
              onPress={submit}
              disabled={busy}
              accessibilityRole="button"
              accessibilityState={{ disabled: busy }}
            >
              {busy ? (
                <View style={styles.submitContent}>
                  <ActivityIndicator color="#FFFFFF" />
                  <Text style={styles.submitText}>Resetting...</Text>
                </View>
              ) : (
                <View style={styles.submitContent}>
                  <Text style={styles.submitText}>Reset Password</Text>
                  <Ionicons name="arrow-forward" size={17} color="#FFFFFF" />
                </View>
              )}
            </Pressable>
            <Pressable
              style={styles.footerAction}
              onPress={() => navigation.navigate("Login")}
              disabled={busy}
              accessibilityRole="link"
            >
              <Text style={styles.footerText}>Back to Login</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFFFFF" },
  flex: { flex: 1 },
  hero: { height: 230, width: "100%" },
  heroImage: { flex: 1, justifyContent: "center" },
  heroOverlay: { ...StyleSheet.absoluteFill, backgroundColor: "rgba(10, 28, 49, 0.35)" },
  backButton: {
    position: "absolute",
    top: spacing.md,
    left: spacing.lg,
    zIndex: 2,
    width: 42,
    height: 42,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(15, 23, 42, 0.35)",
  },
  brandBlock: { alignItems: "center", paddingHorizontal: spacing.xl, paddingTop: spacing.lg },
  brandText: { color: "#FFFFFF", fontSize: 38, lineHeight: 46, fontWeight: "900" },
  brandTagline: { color: "#FFFFFF", fontSize: 15, fontWeight: "700", marginTop: spacing.xs },
  formScroll: { flex: 1, marginTop: -24 },
  content: { flexGrow: 1 },
  formPanel: {
    flexGrow: 1,
    width: "100%",
    maxWidth: 520,
    alignSelf: "center",
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.xxxl,
  },
  title: { color: "#102A43", fontSize: 25, fontWeight: "800" },
  subtitle: { color: "#64748B", fontSize: 14, lineHeight: 21, marginTop: spacing.sm, marginBottom: spacing.xl },
  fieldGroup: { marginBottom: spacing.lg },
  fieldLabel: { color: "#26384D", fontSize: 13, fontWeight: "700", marginBottom: spacing.sm },
  fieldBox: {
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    backgroundColor: "#FFFFFF",
  },
  fieldBoxError: { borderColor: "#EF4444" },
  fieldInput: { flex: 1, minHeight: 50, color: "#102A43", fontSize: 15, paddingVertical: 0 },
  fieldError: { color: "#B91C1C", fontSize: 12, lineHeight: 18, marginTop: spacing.xs },
  passwordHint: { color: "#64748B", fontSize: 11, lineHeight: 16, marginTop: spacing.xs },
  errorBox: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#FECACA",
    backgroundColor: "#FEF2F2",
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  errorText: { color: "#B91C1C", fontSize: 13, lineHeight: 19 },
  submitButton: {
    minHeight: 54,
    borderRadius: radius.md,
    backgroundColor: "#10B981",
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.sm,
  },
  submitButtonDisabled: { opacity: 0.65 },
  submitButtonPressed: { opacity: 0.85 },
  submitContent: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm },
  submitText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" },
  footerAction: { alignSelf: "center", paddingVertical: spacing.md, marginTop: spacing.xs },
  footerText: { color: "#0E9488", fontSize: 14, fontWeight: "700" },
});
