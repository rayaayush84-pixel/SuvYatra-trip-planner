import React, { useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import * as ImagePicker from "expo-image-picker";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "EditProfile">;

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[+\d][\d\s-]{7,16}$/;

export default function EditProfileScreen({ navigation }: Props) {
  const { user, updateProfile } = useAuth();

  const [name, setName] = useState(user?.name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [location, setLocation] = useState(user?.location ?? "");
  const [bio, setBio] = useState(user?.bio ?? "");
  const [avatar, setAvatar] = useState(user?.avatar ?? "");
  const [pickingPhoto, setPickingPhoto] = useState(false);
  const [saving, setSaving] = useState(false);

  const errors = useMemo(() => {
    const result: Record<string, string> = {};
    if (name.trim().length < 2) {
      result.name = "Please enter your full name.";
    }
    if (!EMAIL_REGEX.test(email.trim())) {
      result.email = "Enter a valid email address.";
    }
    if (phone.trim() && !PHONE_REGEX.test(phone.trim())) {
      result.phone = "Enter a valid phone number.";
    }
    return result;
  }, [name, email, phone]);

  const canSave =
    Object.keys(errors).length === 0 &&
    !saving &&
    user != null &&
    (name !== user.name ||
      email !== user.email ||
      phone !== user.phone ||
      location !== user.location ||
      bio !== user.bio ||
      avatar !== user.avatar);

  // Enter-key focus chain for the profile fields.
  const nameRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const phoneRef = useRef<TextInput>(null);
  const locationRef = useRef<TextInput>(null);

  const changePhoto = async () => {
    try {
      setPickingPhoto(true);      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.7,
      });
      if (!result.canceled && result.assets?.[0]?.uri) {
        setAvatar(result.assets[0].uri);
      }
    } catch {
      Alert.alert("Photo unavailable", "Could not open the photo library.");
    } finally {
      setPickingPhoto(false);
    }
  };

  const save = async () => {
    if (!canSave) {
      return;
    }    setSaving(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    updateProfile({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      location: location.trim(),
      bio: bio.trim(),
      avatar,
    });
    setSaving(false);
    Alert.alert("Profile updated", "Your changes have been saved.", [
      { text: "OK", onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.header}>
          <BackButton navigation={navigation} style={styles.backButton} iconSize={24} />
          <Text style={styles.headerTitle}>Edit Profile</Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.avatarSection}>
            <Image source={{ uri: avatar }} style={styles.avatar} />
            <Pressable
              style={({ pressed }) => [
                styles.photoButton,
                pressed && styles.buttonPressed,
              ]}
              onPress={changePhoto}
              disabled={pickingPhoto}
              accessibilityRole="button"
              accessibilityLabel="Change profile photo"
            >
              {pickingPhoto ? (
                <ActivityIndicator size="small" color={colors.primaryDark} />
              ) : (
                <Ionicons name="camera-outline" size={17} color={colors.primaryDark} />
              )}
              <Text style={styles.photoText}>Change Photo</Text>
            </Pressable>
          </View>

          <Field
            label="Full name"
            value={name}
            onChangeText={setName}
            placeholder="Your full name"
            autoCapitalize="words"
            error={errors.name}
            inputRef={nameRef}
            returnKeyType="next"
            onSubmitEditing={() => emailRef.current?.focus()}
          />
          <Field
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
            error={errors.email}
            inputRef={emailRef}
            returnKeyType="next"
            onSubmitEditing={() => phoneRef.current?.focus()}
          />
          <Field
            label="Phone"
            value={phone}
            onChangeText={setPhone}
            placeholder="+977 9800 000 000"
            keyboardType="phone-pad"
            error={errors.phone}
            inputRef={phoneRef}
            returnKeyType="next"
            onSubmitEditing={() => locationRef.current?.focus()}
          />
          <Field
            label="Location"
            value={location}
            onChangeText={setLocation}
            placeholder="City, Country"
            inputRef={locationRef}
            returnKeyType="go"
            onSubmitEditing={() => void save()}
          />

          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>About you</Text>
            <TextInput
              value={bio}
              onChangeText={setBio}
              placeholder="Tell travellers a little about yourself…"
              placeholderTextColor="#9CA3AF"
              style={[styles.textarea, { minHeight: 90 }]}
              multiline
              maxLength={200}
              textAlignVertical="top"
            />
            <Text style={styles.charHint}>{bio.length}/200</Text>
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.saveButton,
              !canSave && styles.saveButtonDisabled,
              pressed && canSave && styles.buttonPressed,
            ]}
            onPress={save}
            disabled={!canSave}
            accessibilityRole="button"
            accessibilityState={{ disabled: !canSave }}
          >
            {saving ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.saveText}>Save Changes</Text>
            )}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  keyboardType,
  autoCapitalize,
  inputRef,
  returnKeyType,
  onSubmitEditing,
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder: string;
  error?: string;
  keyboardType?: "email-address" | "phone-pad" | "default";
  autoCapitalize?: "none" | "words";
  inputRef?: React.RefObject<TextInput | null>;
  returnKeyType?: "next" | "go" | "done" | "default";
  onSubmitEditing?: () => void;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={styles.fieldGroup}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View
        style={[
          styles.fieldBox,
          focused && styles.fieldBoxFocused,
          !!error && styles.fieldBoxError,
        ]}
      >
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#9CA3AF"
          style={styles.fieldInput}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          underlineColorAndroid="transparent"
          ref={inputRef}
          returnKeyType={returnKeyType}
          onSubmitEditing={onSubmitEditing ? () => onSubmitEditing() : undefined}
        />
      </View>
      {!!error && <Text style={styles.fieldError}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  flex: {
    flex: 1,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  backButton: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    textAlign: "center",
    flex: 1,
  },

  headerSpacer: {
    width: 40,
  },

  content: {
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.xxxl,
  },

  avatarSection: {
    alignItems: "center",
    marginBottom: spacing.xl,
  },

  avatar: {
    width: 104,
    height: 104,
    borderRadius: radius.full,
    borderWidth: 3,
    borderColor: "#B4E6D1",
  },

  photoButton: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.full,
    borderWidth: 1.5,
    borderColor: "#B4E6D1",
    backgroundColor: "#EAF8F2",
  },

  photoText: {
    color: colors.primaryDark,
    fontSize: 13.5,
    fontWeight: "700",
    marginLeft: 6,
  },

  fieldGroup: {
    marginBottom: spacing.lg,
  },

  fieldLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: colors.text,
    marginBottom: 6,
  },

  fieldBox: {
    backgroundColor: colors.white,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    minHeight: 50,
    justifyContent: "center",
  },

  fieldBoxFocused: {
    borderColor: colors.primary,
  },

  fieldBoxError: {
    borderColor: "#EF4444",
  },

  fieldInput: {
    color: colors.text,
    fontSize: 15,
    paddingVertical: spacing.md - 2,
  },

  fieldError: {
    color: "#EF4444",
    fontSize: 12,
    marginTop: 4,
  },

  textarea: {
    backgroundColor: colors.white,
    borderWidth: 1.5,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: 15,
    marginTop: 6,
  },

  charHint: {
    alignSelf: "flex-end",
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 4,
  },

  saveButton: {
    backgroundColor: colors.primary,
    minHeight: 52,
    borderRadius: radius.md,
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.sm,
  },

  saveButtonDisabled: {
    backgroundColor: "#BFE6D6",
  },

  saveText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: "700",
  },

  buttonPressed: {
    opacity: 0.85,
  },
});