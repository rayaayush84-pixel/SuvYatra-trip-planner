import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "AdminLoginActivity">;

type LoginEvent = {
  _id: string;
  userId: string;
  name: string;
  email: string;
  status: "successful";
  loginAt: string;
};

export default function AdminLoginActivityScreen({ navigation }: Props) {
  const { getAccessToken, user } = useAuth();
  const [events, setEvents] = useState<LoginEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const token = getAccessToken();
    if (!token) {
      setError("Sign in with an administrator account to view login activity.");
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    setLoading(true);
    setError("");
    backendRequest<{ events: LoginEvent[] }>("/admin/login-activity", {
      headers: { Authorization: `Bearer ${token}` },
      signal: controller.signal,
    })
      .then((result) => setEvents(result.events))
      .catch((requestError) => {
        if (!controller.signal.aborted) {
          setError(
            requestError instanceof Error
              ? requestError.message
              : "Could not load login activity."
          );
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [getAccessToken, reloadKey]);

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} />
        <Text style={styles.title}>User login activity</Text>
        <View style={styles.headerSpacer} />
      </View>

      {user?.role !== "admin" ? (
        <View style={styles.empty}>
          <Text style={styles.message}>Administrator access is required.</Text>
        </View>
      ) : loading ? (
        <View style={styles.empty}><ActivityIndicator color={colors.primary} /></View>
      ) : error ? (
        <View style={styles.empty}>
          <Text style={styles.message}>{error}</Text>
          <Pressable onPress={() => setReloadKey((key) => key + 1)} accessibilityRole="button">
            <Text style={styles.retry}>Try again</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={events}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.list}
          ListEmptyComponent={<Text style={styles.message}>No successful login events have been recorded.</Text>}
          renderItem={({ item }) => {
            const timestamp = new Date(item.loginAt);
            return (
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <Text style={styles.name}>{item.name}</Text>
                  <Text style={styles.status}>Successful</Text>
                </View>
                <Text style={styles.email}>{item.email || "No email on account"}</Text>
                <Text style={styles.id}>User ID: {item.userId}</Text>
                <View style={styles.timestamp}>
                  <Ionicons name="time-outline" size={15} color={colors.textMuted} />
                  <Text style={styles.date}>
                    {timestamp.toLocaleDateString()} · {timestamp.toLocaleTimeString()}
                  </Text>
                </View>
              </View>
            );
          }}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  title: { color: colors.text, fontSize: 17, fontWeight: "700" },
  headerSpacer: { width: 23 },
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  name: { color: colors.text, fontSize: 15, fontWeight: "700" },
  email: { color: colors.textMuted, fontSize: 13, marginTop: spacing.xs },
  id: { color: colors.textMuted, fontSize: 11, marginTop: spacing.sm },
  status: { color: colors.primaryDark, fontSize: 11, fontWeight: "700" },
  timestamp: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: spacing.md },
  date: { color: colors.textMuted, fontSize: 12 },
  empty: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl },
  message: { color: colors.textMuted, textAlign: "center", lineHeight: 20 },
  retry: { color: colors.primaryDark, fontWeight: "700", marginTop: spacing.md },
});
