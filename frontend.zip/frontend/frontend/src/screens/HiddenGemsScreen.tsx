import React, { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { DestinationDetails, HiddenGemDetails, RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import { DEFAULT_HIDDEN_GEMS } from "../data/hiddenGems";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "HiddenGems">;
type SavedItem = {
  _id: string;
  itemType: string;
  name: string;
};

function gemsForDestination(destination?: DestinationDetails): HiddenGemDetails[] {
  const source = destination?.hiddenGems?.length
    ? destination.hiddenGems
    : DEFAULT_HIDDEN_GEMS;

  return source.map((item) =>
    typeof item === "string"
      ? { name: item, location: destination?.location }
      : item
  );
}

function normalized(value: string | undefined): string {
  return value?.trim().toLocaleLowerCase() ?? "";
}

export default function HiddenGemsScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const destination = route.params?.destination;
  const userId = user?._id ?? user?.id;
  const [catalogGems, setCatalogGems] = useState<HiddenGemDetails[]>([]);
  const [catalogLoading, setCatalogLoading] = useState(!destination);
  const [catalogError, setCatalogError] = useState("");
  const [query, setQuery] = useState("");
  const [savedItems, setSavedItems] = useState<SavedItem[]>([]);
  const [savedLoading, setSavedLoading] = useState(false);
  const [savedError, setSavedError] = useState("");
  const [savingName, setSavingName] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };

  const gems = useMemo(() => {
    if (destination) return gemsForDestination(destination);
    const unique = new Map<string, HiddenGemDetails>();
    for (const gem of [...DEFAULT_HIDDEN_GEMS, ...catalogGems]) {
      unique.set(normalized(gem.name), gem);
    }
    return Array.from(unique.values());
  }, [catalogGems, destination]);

  useFocusEffect(
    useCallback(() => {
      if (destination) {
        setCatalogLoading(false);
        return;
      }
      const controller = new AbortController();
      setCatalogLoading(true);
      setCatalogError("");
      backendRequest<Array<{
        _id: string;
        name: string;
        province?: string;
        country?: string;
        description?: string;
        image?: string;
        images?: string[];
        imageSource?: string;
        imageSourcePage?: string;
        imageLicense?: string;
        imageCredit?: string;
        imageDescription?: string;
        imageRelevance?: "entity" | "category";
        highlights?: string[];
        tags?: string[];
      }>>("/destinations?featured=hidden", { signal: controller.signal })
        .then((records) => {
          if (controller.signal.aborted) return;
          setCatalogGems(records.map((record) => ({
            id: record._id,
            name: record.name,
            location: [record.province, record.country].filter(Boolean).join(", ") || undefined,
            province: record.province,
            description: record.description,
            whyHiddenGem: record.description,
            thingsToDo: record.highlights || [],
            tags: (record.tags || []).filter((tag) => normalized(tag) !== "hidden"),
            image: record.image,
            images: record.images,
            imageSource: record.imageSource,
            imageSourcePage: record.imageSourcePage,
            imageLicense: record.imageLicense,
            imageCredit: record.imageCredit,
            imageDescription: record.imageDescription,
            imageRelevance: record.imageRelevance,
          })));
        })
        .catch((error: unknown) => {
          if (!controller.signal.aborted) {
            setCatalogError(error instanceof Error ? error.message : "Could not load managed destinations.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setCatalogLoading(false);
        });
      return () => controller.abort();
    }, [destination])
  );

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId) {
        setSavedItems([]);
        setSavedLoading(false);
        return;
      }

      const controller = new AbortController();
      setSavedLoading(true);
      setSavedError("");
      backendRequest<SavedItem[]>(
        `/saved-items?userId=${encodeURIComponent(userId)}`,
        {
          signal: controller.signal,
          headers: { Authorization: `Bearer ${token}` },
        }
      )
        .then((items) => setSavedItems(items.filter((item) => item.itemType === "hidden-gem")))
        .catch((error: unknown) => {
          if (!controller.signal.aborted) {
            setSavedError(error instanceof Error ? error.message : "Could not load saved gems.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setSavedLoading(false);
        });

      return () => controller.abort();
    }, [getAccessToken, userId])
  );

  const visibleGems = useMemo(() => {
    const searchTerms = query.trim().toLocaleLowerCase();
    return gems.filter((gem) => {
      const searchable = [
        gem.name,
        gem.location,
        gem.province,
        gem.description,
        gem.whyHiddenGem,
        gem.whyVisit,
        ...(gem.tags ?? []),
      ]
        .filter(Boolean)
        .join(" ")
        .toLocaleLowerCase();

      return !searchTerms || searchable.includes(searchTerms);
    });
  }, [gems, query]);

  const toggleSaved = async (gem: HiddenGemDetails) => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", {
        notice: "Sign in to save Hidden Gems to your Saved Places.",
      });
      return;
    }

    setSavingName(gem.name);
    setSavedError("");
    try {
      const existing = savedItems.find(
        (item) => item.itemType === "hidden-gem" && item.name === gem.name
      );
      if (existing) {
        await backendRequest(`/saved-items/${existing._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItems((current) => current.filter((item) => item._id !== existing._id));
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            userId,
            itemType: "hidden-gem",
            name: gem.name,
            location: gem.location,
            image: gem.image,
          }),
        });
        setSavedItems((current) => [...current, saved]);
        showToast("Saved to your places");
      }
    } catch (error) {
      setSavedError(error instanceof Error ? error.message : "Could not update saved gems.");
    } finally {
      setSavingName("");
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <BackButton navigation={navigation} />
          <View style={styles.headerText}>
            <Text style={styles.eyebrow}>GO A LITTLE FURTHER</Text>
            <Text style={styles.title}>Hidden Gems</Text>
          </View>
          <View style={styles.headerSpacer} />
        </View>

        <Text style={styles.intro}>
          Find quieter places and distinctive experiences from the destination data SuvYatra already has.
        </Text>

        <View style={styles.resultsHeader}>
          <Text style={styles.resultsTitle}>
            {destination?.name ? `Gems around ${destination.name}` : "Places to explore"}
          </Text>
          <Text style={styles.resultCount}>{visibleGems.length}</Text>
        </View>

        {catalogError ? <Text style={styles.errorText}>{catalogError}</Text> : null}
        {catalogLoading ? (
          <View style={styles.loadingRow}>
            <ActivityIndicator size="small" color={colors.primary} />
            <Text style={styles.loadingText}>Loading managed destinations…</Text>
          </View>
        ) : null}
        {savedError ? <Text style={styles.errorText}>{savedError}</Text> : null}
        {savedLoading && (
          <View style={styles.loadingRow}>
            <ActivityIndicator size="small" color={colors.primary} />
            <Text style={styles.loadingText}>Checking your saved places…</Text>
          </View>
        )}

        {visibleGems.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="filter-outline" size={30} color={colors.primary} />
            <Text style={styles.emptyTitle}>No matching records yet</Text>
            <Text style={styles.emptyText}>
              No records found yet. This catalogue only matches facts present in the current destination data.
            </Text>
          </View>
        ) : (
          visibleGems.map((gem, index) => {
            const isSaved = savedItems.some(
              (item) => item.itemType === "hidden-gem" && item.name === gem.name
            );
            return (
              <View key={`${gem.name}-${index}`} style={styles.card}>
                <Pressable
                  onPress={() => navigation.push("HiddenGemDetail", { gem })}
                  accessibilityRole="button"
                  accessibilityLabel={`View details for ${gem.name}`}
                >
                  <RelevantImage entity={{ name: gem.name, type: "destination", location: gem.location, image: gem.image, images: gem.images, imageSource: gem.imageSource, imageSourcePage: gem.imageSourcePage, imageLicense: gem.imageLicense, imageCredit: gem.imageCredit, imageDescription: gem.imageDescription, imageRelevance: gem.imageRelevance }} style={styles.cardImage} />
                </Pressable>
                <View style={styles.cardBody}>
                  <View style={styles.cardTitleRow}>
                    <Text style={styles.cardTitle}>{gem.name}</Text>
                    <Pressable
                      onPress={() => void toggleSaved(gem)}
                      disabled={savingName === gem.name}
                      accessibilityRole="button"
                      accessibilityLabel={isSaved ? `Remove ${gem.name} from Saved` : `Save ${gem.name}`}
                    >
                      {savingName === gem.name ? (
                        <ActivityIndicator size="small" color={colors.primary} />
                      ) : (
                        <Ionicons
                          name={isSaved ? "heart" : "heart-outline"}
                          size={23}
                          color={isSaved ? "#D9435F" : colors.primary}
                        />
                      )}
                    </Pressable>
                  </View>
                  <View style={styles.locationRow}>
                    <Ionicons name="location-outline" size={14} color={colors.textMuted} />
                    <Text style={styles.locationText}>{gem.location ?? "Location not provided"}</Text>
                  </View>
                  <Text style={styles.cardDescription}>
                    {gem.description ?? "A description is not included in the current destination data."}
                  </Text>
                  <Text style={styles.gemReasonLabel}>Why is this a hidden gem?</Text>
                  <Text style={styles.gemReason}>
                    {gem.whyHiddenGem ?? "A source-backed reason is not included in the current record."}
                  </Text>
                  {gem.tags?.length ? (
                    <View style={styles.chipRow}>
                      {gem.tags.map((tag) => (
                        <Text key={tag} style={styles.tag}>{tag}</Text>
                      ))}
                    </View>
                  ) : (
                    <Text style={styles.missingData}>Activity and experience tags are not listed.</Text>
                  )}
                  <Pressable
                    onPress={() => navigation.push("HiddenGemDetail", { gem })}
                    style={styles.detailsButton}
                    accessibilityRole="button"
                  >
                    <Text style={styles.detailsButtonText}>View details</Text>
                    <Ionicons name="arrow-forward" size={16} color={colors.white} />
                  </Pressable>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: 100 },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  headerText: { flex: 1 },
  headerSpacer: { width: 23 },
  eyebrow: { color: colors.primary, fontSize: 10, fontWeight: "800", letterSpacing: 1.3 },
  title: { color: colors.text, fontSize: 27, fontWeight: "900", marginTop: 2 },
  intro: { color: colors.textMuted, fontSize: 14, lineHeight: 21, marginTop: spacing.md },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 8 },
  missingData: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 6 },
  resultsHeader: { flexDirection: "row", alignItems: "center", marginTop: spacing.xl, marginBottom: spacing.md },
  resultsTitle: { flex: 1, color: colors.text, fontSize: 17, fontWeight: "800" },
  resultCount: { color: colors.primary, fontSize: 13, fontWeight: "800" },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    overflow: "hidden",
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 3,
  },
  cardImage: { height: 200, width: "100%" },
  imagePlaceholder: { alignItems: "center", justifyContent: "center", backgroundColor: "#E8F3F0" },
  cardBody: { padding: spacing.md },
  cardTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.md },
  cardTitle: { flex: 1, color: colors.text, fontSize: 19, fontWeight: "800" },
  locationRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 5 },
  locationText: { color: colors.textMuted, fontSize: 12 },
  cardDescription: { color: colors.text, fontSize: 13, lineHeight: 19, marginTop: spacing.sm },
  gemReasonLabel: { color: colors.text, fontSize: 12, fontWeight: "800", marginTop: spacing.md },
  gemReason: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: 3 },
  tag: {
    color: colors.primaryDark,
    backgroundColor: "#E8F3F0",
    borderRadius: radius.full,
    overflow: "hidden",
    paddingHorizontal: 9,
    paddingVertical: 5,
    fontSize: 10,
    fontWeight: "700",
  },
  detailsButton: {
    minHeight: 48,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    marginTop: spacing.md,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 2,
  },
  detailsButtonText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  loadingRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginBottom: spacing.md },
  loadingText: { color: colors.textMuted, fontSize: 12 },
  errorText: { color: "#B42318", fontSize: 12, marginBottom: spacing.md },
  emptyState: {
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.xl,
    gap: spacing.sm,
  },
  emptyTitle: { color: colors.text, fontSize: 15, fontWeight: "800" },
  emptyText: { color: colors.textMuted, fontSize: 12, textAlign: "center", lineHeight: 18 },
});
