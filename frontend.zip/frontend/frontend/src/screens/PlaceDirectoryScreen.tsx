import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "PlaceDirectory">;
type Module = RootStackParamList["PlaceDirectory"]["module"];
type Place = {
  _id: string;
  name: string;
  module: Module;
  category?: string;
  serviceType?: string;
  description?: string;
  location?: string;
  address?: string;
  city?: string;
  district?: string;
  province?: string;
  destination?: string;
  images?: string[];
  image?: string;
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  products?: string[];
  services?: string[];
  nearbyAttractions?: string[];
  openingHours?: Record<string, string>;
  contact?: { phone?: string; website?: string };
  latitude?: number;
  longitude?: number;
  price?: number;
  currency?: string;
  durationMinutes?: number;
  capacityPerSlot?: number;
  minAge?: number;
  difficulty?: string;
  indoorOutdoor?: string;
  participantType?: string;
  bestSeason?: string;
  provider?: string;
  requirements?: string[];
  safetyInformation?: string;
  bookingUrl?: string;
  verifiedServices?: string[];
  supportedNetworks?: string[];
};
type SearchResponse = { items: Place[]; page: number; limit: number; total: number };
type FilterOptions = {
  categories: string[];
  cities: string[];
  districts: string[];
  provinces: string[];
  difficulties: string[];
  seasons: string[];
  participantTypes: string[];
  indoorOutdoor: string[];
  services: string[];
  verifiedServices: string[];
  supportedNetworks: string[];
};
type SavedItem = { _id: string; itemType: string; itemId?: string };

const EMPTY_FILTERS: FilterOptions = {
  categories: [], cities: [], districts: [], provinces: [], difficulties: [], seasons: [], participantTypes: [], indoorOutdoor: [], services: [], verifiedServices: [], supportedNetworks: [],
};
const TITLES: Record<Module, string> = {
  activity: "Activities",
  shopping: "Shopping",
  petrol: "Petrol Pumps & EV Charging",
  hospital: "Hospitals & Health Services",
  atm: "ATMs & Banking",
};
const MODULE_CATEGORIES: Record<Module, string[]> = {
  activity: [
    "Paragliding", "Rock Climbing", "Bungee Jumping", "Rafting", "Zipline", "Trekking",
    "Camping", "Mountain Biking", "Canyoning", "Sunrise / Sunset", "Wildlife Safari",
    "Bird Watching", "Nature Walk", "Waterfalls", "Viewpoints", "Mountain Experiences",
    "Temple Visits", "Heritage Sites", "Cultural Experiences", "Cooking Classes",
    "Village Experiences", "Arts & Handicrafts", "Yoga & Meditation", "Spa & Wellness",
    "Leisure", "Photography",
  ],
  shopping: [
    "Souvenirs", "Handicrafts", "Pashmina & Wool", "Thangka & Traditional Art", "Jewellery",
    "Trekking Gear", "Clothing & Fashion", "Yoga / Spiritual Items", "Tea & Coffee",
    "Local Food & Spices", "Books", "Supermarkets / Groceries", "Local Markets", "Shopping Malls",
  ],
  petrol: ["Petrol", "Diesel", "EV Charging", "EV Charging Stations"],
  hospital: [
    "Emergency", "Hospitals", "Clinics", "Dental", "Eye Care", "Children's/Pediatric",
    "Women's Health", "Specialist Care", "Pharmacies", "Diagnostic/Laboratory",
  ],
  atm: ["ATM", "Cash Withdrawal", "Bank Branch", "Currency Exchange"],
};

export default function PlaceDirectoryScreen({ navigation, route }: Props) {
  const { getAccessToken } = useAuth();
  const { module, placeId } = route.params;
  const isActivity = module === "activity";
  const [query, setQuery] = useState(route.params.search ?? "");
  const [submittedQuery, setSubmittedQuery] = useState(route.params.search?.trim() ?? "");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedPriceMax, setSelectedPriceMax] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("");
  const [selectedSeason, setSelectedSeason] = useState("");
  const [selectedIndoorOutdoor, setSelectedIndoorOutdoor] = useState("");
  const [selectedParticipantType, setSelectedParticipantType] = useState("");
  const [selectedDurationMax, setSelectedDurationMax] = useState("");
  const [openNow, setOpenNow] = useState(false);
  const [open24Hours, setOpen24Hours] = useState(false);
  const [verifiedEmergency, setVerifiedEmergency] = useState(false);
  const [selectedService, setSelectedService] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [items, setItems] = useState<Place[]>([]);
  const [detail, setDetail] = useState<Place | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedItem, setSavedItem] = useState<SavedItem | null>(null);
  const [savedMap, setSavedMap] = useState<Record<string, SavedItem>>({});
  const [savingId, setSavingId] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const timeout = setTimeout(() => setSubmittedQuery(query.trim()), 350);
    return () => clearTimeout(timeout);
  }, [query]);

  const searchParams = useMemo(() => {
    const params = new URLSearchParams({ module, page: "1", limit: "30" });
    if (submittedQuery) params.set("search", submittedQuery);
    if (selectedCategory) params.set("category", selectedCategory);
    if (selectedCity) params.set("city", selectedCity);
    if (openNow) params.set("openNow", "true");
    if (open24Hours) params.set("open24Hours", "true");
    if (verifiedEmergency) params.set("verifiedServices", "Emergency Department");
    if (selectedService) params.set("service", selectedService);
    if (selectedNetwork) params.set("supportedNetworks", selectedNetwork);
    if ((isActivity || module === "shopping") && selectedPriceMax) params.set("maxPrice", selectedPriceMax);
    if (isActivity) {
      if (selectedDifficulty) params.set("difficulty", selectedDifficulty);
      if (selectedSeason) params.set("bestSeason", selectedSeason);
      if (selectedIndoorOutdoor) params.set("indoorOutdoor", selectedIndoorOutdoor);
      if (selectedParticipantType) params.set("participantType", selectedParticipantType);
      if (selectedDurationMax) params.set("maxDuration", selectedDurationMax);
    }
    return params.toString();
  }, [isActivity, module, open24Hours, openNow, selectedCategory, selectedCity, selectedDifficulty, selectedDurationMax, selectedIndoorOutdoor, selectedNetwork, selectedParticipantType, selectedPriceMax, selectedSeason, selectedService, submittedQuery, verifiedEmergency]);

  useEffect(() => {
    const controller = new AbortController();
    backendRequest<FilterOptions>(`/places/filters?module=${encodeURIComponent(module)}`, { signal: controller.signal })
      .then(setFilters)
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load category filters.");
        }
      });
    return () => controller.abort();
  }, [module, reloadKey]);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    if (placeId) {
      backendRequest<Place>(`/places/${encodeURIComponent(placeId)}`, { signal: controller.signal })
        .then((place) => {
          setDetail(place);
          setItems([]);
        })
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setDetail(null);
            setError(requestError instanceof Error ? requestError.message : "Could not load place details.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
    } else {
      backendRequest<SearchResponse>(`/places?${searchParams}`, { signal: controller.signal })
        .then((response) => {
          setItems(response.items);
          setPage(response.page);
          setTotal(response.total);
          setDetail(null);
        })
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) setError(requestError instanceof Error ? requestError.message : "Could not search verified listings.");
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
    }
    return () => controller.abort();
  }, [placeId, reloadKey, searchParams]);

  useEffect(() => {
    const token = getAccessToken();
    if (!token || !detail) {
      setSavedItem(null);
      return;
    }
    const controller = new AbortController();
    backendRequest<SavedItem[]>("/saved-items", {
      signal: controller.signal,
      headers: { Authorization: `Bearer ${token}` },
    }).then((saved) => {
      if (!controller.signal.aborted) {
        setSavedItem(saved.find((item) => item.itemType === module && item.itemId === detail._id) ?? null);
      }
    }).catch((requestError: unknown) => {
      if (!controller.signal.aborted) setError(requestError instanceof Error ? requestError.message : "Could not check Saved Places.");
    });
    return () => controller.abort();
  }, [detail?._id, getAccessToken, module, reloadKey]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || detail) {
        if (!token) setSavedMap({});
        return;
      }
      const controller = new AbortController();
      backendRequest<SavedItem[]>("/saved-items", {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((saved) => {
          if (!controller.signal.aborted) {
            const map: Record<string, SavedItem> = {};
            for (const entry of saved) {
              if (entry.itemType === module && entry.itemId) map[entry.itemId] = entry;
            }
            setSavedMap(map);
          }
        })
        .catch(() => {});
      return () => controller.abort();
    }, [detail?._id, getAccessToken, module])
  );

  const clearFilters = () => {
    setQuery("");
    setSubmittedQuery("");
    setSelectedCategory("");
    setSelectedCity("");
    setSelectedPriceMax("");
    setSelectedDifficulty("");
    setSelectedSeason("");
    setSelectedIndoorOutdoor("");
    setSelectedParticipantType("");
    setSelectedDurationMax("");
    setOpenNow(false);
    setOpen24Hours(false);
    setVerifiedEmergency(false);
    setSelectedService("");
    setSelectedNetwork("");
  };

  const loadMore = async () => {
    if (loadingMore || items.length >= total) return;
    setLoadingMore(true);
    try {
      const next = new URLSearchParams(searchParams);
      next.set("page", String(page + 1));
      const response = await backendRequest<SearchResponse>(`/places?${next}`);
      setItems((current) => [...current, ...response.items]);
      setPage(response.page);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not load more results.");
    } finally {
      setLoadingMore(false);
    }
  };

  const toggleSaved = async () => {
    if (!detail) return;
    const token = getAccessToken();
    if (!token) {
      navigation.navigate("Login", { notice: "Sign in to save places." });
      return;
    }
    setSaving(true);
    setError("");
    try {
      if (savedItem) {
        await backendRequest(`/saved-items/${savedItem._id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
        setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            itemType: module,
            itemId: detail._id,
            name: detail.name,
            location: detail.location ?? detail.city,
            image: detail.image ?? detail.images?.[0],
            imageSource: detail.imageSource,
            imageSourcePage: detail.imageSourcePage,
            imageLicense: detail.imageLicense,
            imageCredit: detail.imageCredit,
            imageDescription: detail.imageDescription,
            imageRelevance: detail.imageRelevance,
          }),
        });
        setSavedItem(saved);
        showToast("Saved to your places");
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSaving(false);
    }
  };

  const toggleSavedForList = async (place: Place) => {
    const token = getAccessToken();
    if (!token) {
      navigation.navigate("Login", { notice: "Sign in to save places." });
      return;
    }
    setSavingId(place._id);
    setError("");
    try {
      const existing = savedMap[place._id];
      if (existing) {
        await backendRequest(`/saved-items/${existing._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedMap((current) => {
          const next = { ...current };
          delete next[place._id];
          return next;
        });
        if (savedItem?._id === existing._id) setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            itemType: module,
            itemId: place._id,
            name: place.name,
            location: [place.address, place.location, place.city, place.district].filter(Boolean).join(", ") || place.city,
            image: place.image ?? place.images?.[0],
            imageSource: place.imageSource,
            imageSourcePage: place.imageSourcePage,
            imageLicense: place.imageLicense,
            imageCredit: place.imageCredit,
            imageDescription: place.imageDescription,
            imageRelevance: place.imageRelevance,
          }),
        });
        setSavedMap((current) => ({ ...current, [place._id]: saved }));
        showToast("Saved to your places");
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSavingId("");
    }
  };

  const addToTrip = () => {
    if (!detail) return;
    navigation.navigate("MainTabs", {
      screen: "Trips",
      params: {
        destination: {
          id: detail._id,
          category: detail.module,
          name: detail.name,
          location: detail.location ?? detail.city ?? detail.district,
          description: detail.description,
          image: detail.image ?? detail.images?.[0],
          latitude: detail.latitude,
          longitude: detail.longitude,
          tags: [detail.category, detail.serviceType].filter((value): value is string => Boolean(value)),
        },
      },
    });
  };

  const openMaps = (place: Place) => {
    const queryText = place.latitude !== undefined && place.longitude !== undefined
      ? `${place.latitude},${place.longitude}`
      : [place.name, place.address, place.location, place.city].filter(Boolean).join(", ");
    return Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(queryText)}`);
  };
  const openDirections = (place: Place) => {
    const destination = place.latitude !== undefined && place.longitude !== undefined
      ? `${place.latitude},${place.longitude}`
      : [place.name, place.address, place.location, place.city].filter(Boolean).join(", ");
    return Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`);
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} />
        <Text style={styles.title}>{detail?.name ?? TITLES[module]}</Text>
        <View style={styles.headerSpace} />
      </View>
      {!detail ? (
        <View style={styles.filters}>
          {!isActivity ? (
            <>
              <FilterRow title="Category" options={[...new Set([...MODULE_CATEGORIES[module], ...filters.categories])]} value={selectedCategory} onChange={setSelectedCategory} />
              <FilterRow title="City" options={filters.cities} value={selectedCity} onChange={setSelectedCity} />
            </>
          ) : null}
          <FilterRow title="Verified services" options={[...new Set([...filters.services, ...filters.verifiedServices])]} value={selectedService} onChange={setSelectedService} />
          {module === "atm" ? <FilterRow title="Verified card network" options={filters.supportedNetworks} value={selectedNetwork} onChange={setSelectedNetwork} /> : null}
          {isActivity ? (
            <>
              <FilterRow title="Difficulty" options={filters.difficulties} value={selectedDifficulty} onChange={setSelectedDifficulty} />
              <FilterRow title="Season" options={filters.seasons} value={selectedSeason} onChange={setSelectedSeason} />
              <FilterRow title="Indoor / outdoor" options={filters.indoorOutdoor} value={selectedIndoorOutdoor} onChange={setSelectedIndoorOutdoor} />
              <FilterRow title="Solo / group" options={filters.participantTypes} value={selectedParticipantType} onChange={setSelectedParticipantType} />
            </>
          ) : null}
          {module === "shopping" ? (
            <View style={styles.priceRow}>
              <Text style={styles.filterTitle}>Budget</Text>
              {["", "1000", "5000", "10000"].map((value) => (
                <Pressable key={`shopping-budget-${value || "any"}`} onPress={() => setSelectedPriceMax(value)} style={[styles.priceChip, selectedPriceMax === value && styles.activeChip]}>
                  <Text style={[styles.chipText, selectedPriceMax === value && styles.activeText]}>{value ? `≤ NPR ${value}` : "Any"}</Text>
                </Pressable>
              ))}
            </View>
          ) : null}
          {!isActivity ? (
            <View style={styles.priceRow}>
              <Text style={styles.filterTitle}>Hours & services</Text>
              <Pressable onPress={() => setOpenNow((value) => !value)} style={[styles.priceChip, openNow && styles.activeChip]}>
                <Text style={[styles.chipText, openNow && styles.activeText]}>Open now*</Text>
              </Pressable>
              {["petrol", "hospital", "atm"].includes(module) ? (
                <Pressable onPress={() => setOpen24Hours((value) => !value)} style={[styles.priceChip, open24Hours && styles.activeChip]}>
                  <Text style={[styles.chipText, open24Hours && styles.activeText]}>Verified 24/7*</Text>
                </Pressable>
              ) : null}
              {module === "hospital" ? (
                <Pressable onPress={() => setVerifiedEmergency((value) => !value)} style={[styles.priceChip, verifiedEmergency && styles.activeChip]}>
                  <Text style={[styles.chipText, verifiedEmergency && styles.activeText]}>Emergency department*</Text>
                </Pressable>
              ) : null}
            </View>
          ) : null}
          <View style={styles.filterFooter}>
            <Text style={styles.dataNote}>Verified listings only</Text>
            <Pressable onPress={clearFilters}><Text style={styles.link}>Clear all filters</Text></Pressable>
          </View>
          {!isActivity ? <Text style={styles.dataNote}>*These filters return only records with matching verified hours/services. Near-me search is unavailable because there is no device-location permission flow or Places API. Results are database records only.</Text> : null}
          {module === "hospital" ? <Text style={styles.emergencyNote}>Emergency listings and care details are shown only when verified records exist. SuvYatra is not an emergency dispatch service.</Text> : null}
        </View>
      ) : null}
      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} /><Text style={styles.bodyText}>Loading verified data…</Text></View>
      ) : error ? (
        <View style={styles.center}><Text style={styles.error}>{error}</Text><Pressable onPress={() => setReloadKey((current) => current + 1)}><Text style={styles.link}>Try again</Text></Pressable></View>
      ) : detail ? (
        <ScrollView contentContainerStyle={styles.detail}>
          <RelevantImage entity={{ name: detail.name, type: module, location: [detail.address, detail.location, detail.city, detail.district].filter(Boolean).join(", "), image: detail.image, images: detail.images, imageSource: detail.imageSource, imageSourcePage: detail.imageSourcePage, imageLicense: detail.imageLicense, imageCredit: detail.imageCredit, imageDescription: detail.imageDescription, imageRelevance: detail.imageRelevance }} style={styles.heroImage} />
          <Text style={styles.bodyText}>{[detail.category, detail.serviceType].filter(Boolean).join(" · ") || "Category unavailable"}</Text>
          {detail.description ? <Text style={styles.bodyText}>{detail.description}</Text> : null}
          <Detail label="Location" value={[detail.address, detail.location, detail.city, detail.district, detail.province].filter(Boolean).join(", ")} />
          <Detail label="Products" value={detail.products?.join(", ")} />
          <Detail label="Services" value={[...(detail.services ?? []), ...(detail.verifiedServices ?? [])].join(", ")} />
          <Detail label="Supported card networks" value={detail.supportedNetworks?.join(", ")} />
          <Detail label="Nearby attractions" value={detail.nearbyAttractions?.join(", ")} />
          <Detail label="Opening hours" value={detail.openingHours ? Object.entries(detail.openingHours).map(([day, hours]) => `${day}: ${hours}`).join("\n") : undefined} />
          <Detail label="Contact" value={detail.contact?.phone} />
          <Detail label="Website" value={detail.contact?.website} />
          {isActivity ? (
            <>
              <Detail label="Provider" value={detail.provider} />
              <Detail label="Duration" value={detail.durationMinutes !== undefined ? `${detail.durationMinutes} minutes` : undefined} />
              <Detail label="Estimated price" value={detail.price !== undefined ? `${detail.currency ?? "NPR"} ${detail.price} (estimate)` : undefined} />
              {typeof detail.minAge === "number" && detail.minAge >= 18 ? (
                <View style={styles.ageBadge}>
                  <Ionicons name="alert-circle" size={18} color="#B91C1C" />
                  <Text style={styles.ageBadgeText}>18+ Only — participants must be 18 or older.</Text>
                </View>
              ) : null}
              <Detail label="Difficulty" value={detail.difficulty} />
              <Detail label="Indoor/outdoor" value={detail.indoorOutdoor} />
              <Detail label="Participant type" value={detail.participantType} />
              <Detail label="Best season" value={detail.bestSeason} />
              <Detail label="Requirements" value={detail.requirements?.join(", ")} />
              <Detail label="Safety information" value={detail.safetyInformation} />
              <Text style={styles.dataNote}>Availability shown in the trip planner is demo inventory, not live provider data. No reservation or safety guarantee is implied.</Text>
              <Pressable
                style={styles.primaryButton}
                onPress={() => navigation.navigate("Booking", {
                  activity: {
                    id: detail._id,
                    name: detail.name,
                    location: [detail.address, detail.location, detail.city, detail.district].filter(Boolean).join(", "),
                    price: detail.price,
                    currency: detail.currency,
                    durationMinutes: detail.durationMinutes,
                    capacityPerSlot: undefined,
                    minAge: detail.minAge,
                    image: detail.image,
                    images: detail.images,
                    imageSource: detail.imageSource,
                    imageSourcePage: detail.imageSourcePage,
                    imageLicense: detail.imageLicense,
                    imageCredit: detail.imageCredit,
                    imageDescription: detail.imageDescription,
                    imageRelevance: detail.imageRelevance,
                  },
                  adults: 1,
                })}
                accessibilityRole="button"
                accessibilityLabel={`Book ${detail.name}`}
              >
                <Ionicons name="ticket-outline" size={18} color={colors.white} />
                <Text style={styles.primaryButtonText}>Book activity</Text>
              </Pressable>
            </>
          ) : null}
          <View style={styles.buttonRow}>
            <Action label="Maps" icon="map-outline" onPress={() => void openMaps(detail)} />
            <Action label="Directions" icon="navigate-outline" onPress={() => void openDirections(detail)} />
            <Action label="Save" icon={savedItem ? "heart" : "heart-outline"} onPress={() => void toggleSaved()} disabled={saving} />
            <Action label="Add to Trip" icon="add-circle-outline" onPress={addToTrip} />
          </View>
          {detail.bookingUrl ? <Pressable style={styles.providerButton} onPress={() => void Linking.openURL(detail.bookingUrl!)}><Text style={styles.providerButtonText}>Continue to provider</Text></Pressable> : null}
          {module === "hospital" && detail.contact?.phone ? <Pressable style={styles.providerButton} onPress={() => void Linking.openURL(`tel:${detail.contact?.phone}`)}><Text style={styles.providerButtonText}>Call {detail.contact.phone}</Text></Pressable> : null}
        </ScrollView>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item._id}
          contentContainerStyle={items.length ? styles.list : styles.emptyList}
          onEndReached={() => void loadMore()}
          onEndReachedThreshold={0.5}
          ListFooterComponent={loadingMore ? <ActivityIndicator color={colors.primary} /> : null}
          ListEmptyComponent={
            <View style={styles.center}>
              <Ionicons name={iconForModule(module)} size={30} color={colors.primary} />
              <Text style={styles.emptyTitle}>No verified {moduleLabel(module)} listings</Text>
              <Text style={styles.bodyText}>There are no verified records for this category in the database. No businesses, prices, opening hours, services, or availability are fabricated. A verified data source must be configured or reviewed listings added by an administrator.</Text>
            </View>
          }
          renderItem={({ item }) => {
            const listSaved = savedMap[item._id];
            return (
            <View style={styles.card}>
              <Pressable
                onPress={() => navigation.push("PlaceDirectory", { module, placeId: item._id })}
                style={styles.cardMain}
                accessibilityRole="button"
                accessibilityLabel={`View details for ${item.name}`}
              >
                <RelevantImage entity={{ name: item.name, type: module, location: [item.address, item.location, item.city, item.district].filter(Boolean).join(", "), image: item.image, images: item.images, imageSource: item.imageSource, imageSourcePage: item.imageSourcePage, imageLicense: item.imageLicense, imageCredit: item.imageCredit, imageDescription: item.imageDescription, imageRelevance: item.imageRelevance }} style={styles.thumbnail} />
                <View style={styles.cardText}>
                  <Text style={styles.cardTitle}>{item.name}</Text>
                  <Text style={styles.bodyText}>{[item.category, item.serviceType, item.city].filter(Boolean).join(" · ") || "Location/category unavailable"}</Text>
                  {item.price !== undefined ? <Text style={styles.bodyText}>NPR {item.price}{module === "activity" ? " (estimate)" : ""}</Text> : null}
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.primary} />
              </Pressable>
              <Pressable
                onPress={() => void toggleSavedForList(item)}
                disabled={savingId === item._id}
                accessibilityRole="button"
                accessibilityLabel={listSaved ? `Remove ${item.name} from Saved` : `Save ${item.name}`}
              >
                {savingId === item._id ? (
                  <ActivityIndicator size="small" color={colors.primary} />
                ) : (
                  <Ionicons
                    name={listSaved ? "heart" : "heart-outline"}
                    size={22}
                    color={listSaved ? "#D9435F" : colors.primary}
                  />
                )}
              </Pressable>
            </View>
            );
          }}
        />
      )}
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

function moduleLabel(module: Module) {
  return module === "atm" ? "ATM/banking" : module === "hospital" ? "health service" : module === "petrol" ? "fuel/EV" : module;
}

function iconForModule(module: Module): keyof typeof Ionicons.glyphMap {
  if (module === "activity") return "trail-sign-outline";
  if (module === "shopping") return "bag-outline";
  if (module === "petrol") return "car-outline";
  if (module === "hospital") return "medkit-outline";
  return "card-outline";
}

function FilterRow({ title, options, value, onChange }: {
  title: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
}) {
  if (!options.length) return null;
  return (
    <View style={styles.filterGroup}>
      <Text style={styles.filterTitle}>{title}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
        {options.map((option) => (
          <Pressable key={option} onPress={() => onChange(value === option ? "" : option)} style={[styles.chip, value === option && styles.activeChip]}>
            <Text style={[styles.chipText, value === option && styles.activeText]}>{option}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function Detail({ label, value }: { label: string; value?: string }) {
  return <View style={styles.detailRow}><Text style={styles.filterTitle}>{label}</Text><Text style={styles.bodyText}>{value || "Information unavailable"}</Text></View>;
}

function Action({ label, icon, onPress, disabled }: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  disabled?: boolean;
}) {
  return <Pressable disabled={disabled} onPress={onPress} style={styles.action}><Ionicons name={icon} size={17} color={colors.primary} /><Text style={styles.actionText}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  title: { flex: 1, textAlign: "center", fontWeight: "800", color: colors.text, fontSize: 18 },
  headerSpace: { width: 24 },
  filters: { paddingHorizontal: spacing.lg, paddingBottom: spacing.sm },
  filterGroup: { marginTop: spacing.xs },
  filterTitle: { color: colors.textMuted, fontSize: 11, fontWeight: "700", marginBottom: 4 },
  chips: { gap: 6, paddingBottom: 4 },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: 15, paddingHorizontal: 9, paddingVertical: 5 },
  activeChip: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { color: colors.text, fontSize: 11 },
  activeText: { color: colors.white, fontWeight: "700" },
  priceRow: { flexDirection: "row", gap: 6, alignItems: "center", flexWrap: "wrap", marginTop: spacing.xs },
  priceChip: { borderWidth: 1, borderColor: colors.border, borderRadius: 13, paddingHorizontal: 7, paddingVertical: 4 },
  filterFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: spacing.sm },
  dataNote: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginVertical: 4 },
  ageBadge: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#FEF2F2", borderWidth: 1, borderColor: "#FECACA", borderRadius: radius.md, padding: spacing.md, marginVertical: spacing.sm },
  ageBadgeText: { flex: 1, color: "#B91C1C", fontSize: 13, fontWeight: "800" },
  emergencyNote: { color: "#B42318", fontSize: 12, lineHeight: 17, fontWeight: "700", marginVertical: 5 },
  link: { color: colors.primary, fontSize: 12, fontWeight: "700" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: spacing.sm, padding: spacing.xl },
  emptyList: { flexGrow: 1, justifyContent: "center" },
  emptyTitle: { color: colors.text, fontWeight: "800", fontSize: 17, textAlign: "center" },
  bodyText: { color: colors.textMuted, fontSize: 12, lineHeight: 18 },
  error: { color: "#B42318", textAlign: "center" },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 110 },
  card: { flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.sm, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.06, shadowRadius: 10, elevation: 2 },
  cardMain: { flex: 1, flexDirection: "row", alignItems: "center", gap: spacing.sm },
  thumbnail: { width: 72, height: 72, borderRadius: radius.md },
  cardText: { flex: 1, gap: 3 },
  cardTitle: { color: colors.text, fontWeight: "800", fontSize: 15 },
  detail: { padding: spacing.lg, paddingBottom: 120, gap: spacing.sm },
  heroImage: { width: "100%", height: 230, borderRadius: radius.lg },
  detailRow: { borderBottomWidth: 1, borderBottomColor: colors.border, paddingBottom: spacing.sm },
  buttonRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: spacing.sm },
  action: { flexDirection: "row", alignItems: "center", gap: 4, padding: 5 },
  actionText: { color: colors.primary, fontSize: 11, fontWeight: "700" },
  providerButton: { alignItems: "center", backgroundColor: colors.primary, padding: spacing.md, borderRadius: radius.md },
  providerButtonText: { color: colors.white, fontWeight: "800" },
  primaryButton: { minHeight: 48, borderRadius: radius.md, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, marginTop: spacing.sm },
  primaryButtonText: { color: colors.white, fontWeight: "800" },
});
