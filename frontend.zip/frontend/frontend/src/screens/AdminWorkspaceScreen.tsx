import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import { useAdminAuth } from "../auth/AdminAuthContext";
import { useAuth } from "../auth/AuthContext";
import AdminManagementPanel, { AdminSection } from "./AdminManagementPanel";

type Props = NativeStackScreenProps<RootStackParamList, "AdminDashboard">;

const sections: { id: AdminSection; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { id: "dashboard", label: "Dashboard", icon: "grid-outline" },
  { id: "users", label: "Users", icon: "people-outline" },
  { id: "destinations", label: "Destinations", icon: "location-outline" },
  { id: "hotels", label: "Hotels", icon: "bed-outline" },
  { id: "restaurants", label: "Restaurants", icon: "restaurant-outline" },
  { id: "activities", label: "Activities", icon: "trail-sign-outline" },
  { id: "transport", label: "Transport", icon: "bus-outline" },
  { id: "bookings", label: "Bookings", icon: "calendar-outline" },
  { id: "approvals", label: "Pending Trip Approvals", icon: "hourglass-outline" },
  { id: "payments", label: "Payments", icon: "card-outline" },
  { id: "reviews", label: "Reviews & feedback", icon: "chatbubble-ellipses-outline" },
  { id: "chatbot", label: "Chatbot / AI", icon: "sparkles-outline" },
  { id: "analytics", label: "Analytics", icon: "bar-chart-outline" },
  { id: "settings", label: "Settings", icon: "settings-outline" },
];

const COLORS = {
  green: "#047857",
  navy: "#102A43",
  muted: "#64748B",
  border: "#E2E8F0",
  surface: "#FFFFFF",
  background: "#F1F5F9",
};

export default function AdminWorkspaceScreen({ navigation }: Props) {
  const { admin: legacyAdmin, ready: legacyReady, getAccessToken: getLegacyToken, logout: legacyLogout } = useAdminAuth();
  const { user, getAccessToken: getUserToken, logout: userLogout } = useAuth();
  const { width: windowWidth } = useWindowDimensions();
  // The admin always lives inside the shared mobile-sized web container
  // (maxWidth 430), so breakpoints must follow the container — not a wide
  // desktop window — otherwise the desktop sidebar would crush the content.
  // Native keeps the real window width (tablets retain the sidebar).
  const width = Platform.OS === "web" ? Math.min(windowWidth, 430) : windowWidth;
  const [section, setSection] = useState<AdminSection>("dashboard");
  const [reloadKey, setReloadKey] = useState(0);
  const [signingOut, setSigningOut] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isDesktop = width >= 900;
  const isMobile = width < 600;

  // Unified auth: an admin is either the legacy env-admin session OR a
  // unified-login user whose role is "admin". The unified session is preferred.
  const unifiedAdmin = user?.role === "admin"
    ? { email: user.email, role: "admin" as const }
    : null;
  const admin = unifiedAdmin ?? legacyAdmin;
  const ready = legacyReady;
  const token = unifiedAdmin ? getUserToken() : getLegacyToken();

  useEffect(() => {
    if (ready && !admin && !signingOut) {
      navigation.reset({ index: 0, routes: [{ name: "Login" }] });
    }
  }, [admin, navigation, ready, signingOut]);

  const logoutAdmin = useCallback(async () => {
    setSigningOut(true);
    try {
      if (unifiedAdmin) await userLogout();
      else await legacyLogout();
      navigation.reset({ index: 0, routes: [{ name: "Login" }] });
    } catch {
      setSigningOut(false);
    }
  }, [unifiedAdmin, userLogout, legacyLogout, navigation]);

  if (!ready || !admin) {
    return <SafeAreaView style={styles.loading}><ActivityIndicator color={COLORS.green} /></SafeAreaView>;
  }

  if (!token) {
    return <SafeAreaView style={styles.loading}><ActivityIndicator color={COLORS.green} /></SafeAreaView>;
  }

  const sidebar = (
    <View style={isDesktop ? styles.sidebar : isMobile ? styles.mobileMenuNavigation : styles.mobileNavigation}>
      {sections.map((entry) => (
        <Pressable
          key={entry.id}
          accessibilityRole="button"
          accessibilityState={{ selected: section === entry.id }}
          onPress={() => {
            setSection(entry.id);
            setMobileMenuOpen(false);
          }}
          style={[
            styles.navItem,
            isDesktop ? null : styles.mobileNavItem,
            section === entry.id && styles.navItemActive,
          ]}
        >
          <Ionicons name={entry.icon} size={18} color={section === entry.id ? COLORS.green : COLORS.muted} />
          <Text style={[styles.navLabel, section === entry.id && styles.navLabelActive]}>{entry.label}</Text>
        </Pressable>
      ))}
      {isDesktop ? (
        <Pressable style={[styles.navItem, styles.navLogout]} onPress={() => void logoutAdmin()}>
          <Ionicons name="log-out-outline" size={18} color="#B91C1C" />
          <Text style={styles.logoutText}>Log out</Text>
        </Pressable>
      ) : null}
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "bottom"]}>
      <View style={styles.app}>
        <View style={[styles.topbar, isMobile && styles.topbarMobile]}>
          <View style={styles.brandMark}><Ionicons name="compass-outline" size={21} color="#FFFFFF" /></View>
          <View style={styles.brandCopy}>
            <Text style={styles.brandTitle}>SuvYatra Admin</Text>
            <Text style={styles.brandCaption}>Management console</Text>
          </View>
          <View style={styles.topbarSpacer} />
          <View style={[styles.identity, isMobile && styles.identityMobile]}>
            {!isMobile ? <View style={styles.identityIcon}><Ionicons name="person" size={15} color={COLORS.green} /></View> : null}
            <View style={styles.identityText}>
              {!isMobile ? <Text style={styles.identityName}>Administrator</Text> : null}
              <Text style={styles.identityEmail} numberOfLines={1}>{admin.email}</Text>
            </View>
          </View>
          {!isDesktop ? (
            <>
              {isMobile ? (
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={mobileMenuOpen ? "Close admin menu" : "Open admin menu"}
                  accessibilityState={{ expanded: mobileMenuOpen }}
                  style={styles.mobileMenuButton}
                  onPress={() => setMobileMenuOpen((open) => !open)}
                >
                  <Ionicons name={mobileMenuOpen ? "close" : "menu"} size={23} color={COLORS.navy} />
                </Pressable>
              ) : null}
              <Pressable accessibilityRole="button" accessibilityLabel="Log out" style={styles.mobileLogout} onPress={() => void logoutAdmin()}>
                <Ionicons name="log-out-outline" size={20} color="#B91C1C" />
              </Pressable>
            </>
          ) : null}
        </View>
        {isMobile && mobileMenuOpen ? (
          <ScrollView style={styles.mobileMenu} contentContainerStyle={styles.mobileMenuContent}>
            {sidebar}
          </ScrollView>
        ) : null}
        {!isDesktop && !isMobile ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.navScroller} contentContainerStyle={styles.mobileNavContent}>
            {sidebar}
          </ScrollView>
        ) : null}
        <View style={styles.body}>
          {isDesktop ? sidebar : null}
          <AdminManagementPanel
            section={section}
            admin={admin}
            token={token}
            reloadKey={reloadKey}
            onDataChanged={() => setReloadKey((current) => current + 1)}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  app: { flex: 1, width: "100%", backgroundColor: COLORS.background },
  topbar: { minHeight: 66, flexDirection: "row", alignItems: "center", paddingHorizontal: 20, gap: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: COLORS.surface },
  topbarMobile: { paddingHorizontal: 10, gap: 7 },
  brandMark: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.green },
  brandCopy: { gap: 1, flexShrink: 0 },
  brandTitle: { color: COLORS.navy, fontSize: 14, fontWeight: "900" },
  brandCaption: { color: COLORS.muted, fontSize: 10 },
  topbarSpacer: { flex: 1 },
  identity: { flexDirection: "row", alignItems: "center", gap: 8, minWidth: 0 },
  identityMobile: { maxWidth: 112 },
  identityIcon: { width: 32, height: 32, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: "#D1FAE5" },
  identityText: { maxWidth: 220, minWidth: 0 },
  identityName: { color: COLORS.navy, fontSize: 11, fontWeight: "800" },
  identityEmail: { color: COLORS.muted, fontSize: 10 },
  body: { flex: 1, flexDirection: "row", minHeight: 0 },
  sidebar: { width: 226, paddingHorizontal: 12, paddingVertical: 15, gap: 4, borderRightWidth: 1, borderRightColor: COLORS.border, backgroundColor: COLORS.surface },
  navItem: { minHeight: 41, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 11, borderRadius: 9 },
  navItemActive: { backgroundColor: "#ECFDF5" },
  navLabel: { color: COLORS.muted, fontSize: 11, fontWeight: "700" },
  navLabelActive: { color: COLORS.green, fontWeight: "800" },
  navLogout: { marginTop: "auto", borderTopWidth: 1, borderTopColor: COLORS.border, borderRadius: 0, paddingTop: 12 },
  logoutText: { color: "#B91C1C", fontSize: 11, fontWeight: "800" },
  mobileNavigation: { flexDirection: "row", alignItems: "center", gap: 4 },
  mobileMenuNavigation: { flexDirection: "column", alignItems: "stretch", gap: 4 },
  mobileMenuButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: "#F1F5F9" },
  mobileMenu: { maxHeight: 330, flexGrow: 0, borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: COLORS.surface },
  mobileMenuContent: { paddingHorizontal: 10, paddingVertical: 8 },
  navScroller: { maxHeight: 54, borderBottomWidth: 1, borderBottomColor: COLORS.border, backgroundColor: COLORS.surface },
  mobileNavContent: { alignItems: "center", paddingHorizontal: 10, gap: 4 },
  mobileNavItem: { minHeight: 37, paddingHorizontal: 10 },
  mobileLogout: { width: 34, height: 34, alignItems: "center", justifyContent: "center" },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.background },
});
