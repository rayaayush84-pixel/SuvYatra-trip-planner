import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { useFocusEffect } from "@react-navigation/native";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { colors, radius, spacing } from "../theme";
import { useAuth } from "../auth/AuthContext";
import { backendRequest, BACKEND_BASE_URL } from "../services/backendApi";
import RelevantImage from "../components/RelevantImage";
import DemoMethodQr from "../components/DemoMethodQr";
import DemoQrScanner from "../components/DemoQrScanner";
import {
  buildDemoQrPayload,
  validateDemoQrForBooking,
  type DemoQrPayload,
} from "../payments/demoQr";
import { WALLET_METHOD_IDS, brandFor, methodLabel } from "../payments/methods";

type Props = NativeStackScreenProps<RootStackParamList, "Bookings">;

type ItemType = "hotel" | "transport" | "restaurant" | "activity" | "trip" | "flight";

type Booking = {
  _id: string;
  bookingCode: string;
  itemType?: string;
  itemId?: string;
  itemName: string;
  location?: string;
  checkIn?: string;
  checkOut?: string;
  serviceTime?: string;
  guests: number;
  adults?: number;
  children?: number;
  rooms?: number;
  roomTypeName?: string;
  seatNumbers?: string[];
  tableLabel?: string;
  tripId?: string;
  /** Parent complete-trip checkout (one payment for the whole trip, if any). */
  paymentId?: string;
  paymentReference?: string;
  amount: number;
  currency: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";  paymentMethod: string;
  paymentStatus: "not_configured" | "pending" | "paid" | "failed" | "refunded";
  origin?: string;
  approvalStatus?: "pending" | "approved" | "rejected";
  submittedForApprovalAt?: string;
  approvalDeadline?: string;
  approvedAt?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  amountIsEstimate?: boolean;
  status: "pending" | "confirmed" | "accepted" | "rejected" | "completed" | "cancelled";
  createdAt?: string;
  paymentConfirmedAt?: string;
};

type PaymentMethodValue = string;

type QrInfo = {
  payload: string;
  amount: number;
  currency: string;
  bookingCode: string;
  method?: string;
  instructions?: string;
  paymentInitiated?: boolean;
  paymentConfirmed?: boolean;
};

type PayResponse = {
  booking: Booking;
  payment?: { _id: string } & Record<string, unknown>;
  qr: QrInfo;
  paymentInitiated: boolean;
  paymentConfirmed: boolean;
};

type ConfirmResponse = {
  booking: Booking;
  paymentConfirmed: boolean;
};

type QrResponse = {
  qr: QrInfo;
};

type CancelResponse = {
  booking?: Booking;
  message?: string;
};

type LedgerPayment = {
  _id: string;
  status: "PENDING" | "PAID" | "FAILED" | "REFUNDED";
  reference?: string;
  method?: string;
  amount?: number;
  currency?: string;
  demo?: boolean;
  createdAt?: string;
};

type LedgerResponse = {
  payments: LedgerPayment[];
};

type TripItineraryDay = {
  day: number;
  date?: string;
  focus?: string;
  items: { entityType?: string; name: string; estimatedCost?: number }[];
};

type TripSelectionLeg = {
  label?: string;
  name?: string;
  vehicleType?: string;
  provider?: string;
  origin?: string;
  destination?: string;
  date?: string;
  departureTime?: string;
  arrivalTime?: string;
  durationMinutes?: number;
  serviceMode?: string;
  unitPrice?: number;
  priceBasis?: string;
  adults?: number;
  children?: number;
  detail?: string;
  seats?: string[];
  amount?: number;
};

type TripSelections = {
  startDate?: string;
  endDate?: string;
  destination?: string;
  destinationProvince?: string;
  destinationCountry?: string;
  origin?: string;
  party?: { adults?: number; children?: number; rooms?: number; participants?: number };
  hotel?: {
    name?: string; location?: string; room?: string; roomTypeId?: string;
    bedConfiguration?: string; breakfastIncluded?: boolean;
    capacityAdults?: number; capacityChildren?: number; rating?: number;
    checkIn?: string; checkOut?: string; nights?: number; rooms?: number;
    nightlyRate?: number; amount?: number;
  } | null;
  outbound?: TripSelectionLeg | null;
  return?: TripSelectionLeg | null;
  local?: TripSelectionLeg | null;
  activity?: {
    name?: string; location?: string; date?: string; slot?: string;
    durationMinutes?: number; meetingPoint?: string; unitPrice?: number;
    participants?: number; amount?: number;
  } | null;
  restaurant?: {
    name?: string; location?: string; category?: string; cuisine?: string[];
    priceRange?: string; date?: string; guests?: number;
  } | null;
  stops?: { kind?: string; name?: string; location?: string }[];
  totals?: { hotel?: number; transportation?: number; activities?: number; total?: number; currency?: string };
};

type TripItinerary = {
  _id: string;
  name?: string;
  destination?: string;
  origin?: string;
  startDate?: string;
  endDate?: string;
  adults?: number;
  children?: number;
  selections?: TripSelections | null;
  plannedItems?: { itemId?: string; category?: string; name?: string; location?: string }[];
  itinerary?: TripItineraryDay[];
  recommendations?: {
    hotels?: { name: string }[];
    transport?: { name: string }[];
    restaurants?: { name: string }[];
  };
};

const PAYMENT_METHODS: PaymentMethodValue[] = [...WALLET_METHOD_IDS, "bank_card"];

function formatDates(booking: Booking): string {
  if (!booking.checkIn) {
    return booking.serviceTime ? new Date(booking.serviceTime).toLocaleString() : "Dates to be confirmed";
  }
  const start = new Date(booking.checkIn);
  const end = booking.checkOut ? new Date(booking.checkOut) : undefined;
  const format = (date: Date) =>
    date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  return end ? `${format(start)} – ${format(end)}` : format(start);
}

function formatDateTime(value?: string): string {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleString(undefined, { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
}

function guestsLabel(b: Booking): string {
  if (b.adults !== undefined) {
    const adults = b.adults ?? 0;
    const children = b.children ?? 0;
    const rooms = b.rooms ?? 1;
    return `${adults} adult${adults === 1 ? "" : "s"} · ${children} child${children === 1 ? "" : "ren"} · ${rooms} room${rooms === 1 ? "" : "s"}`;
  }
  return `${b.guests} guest${b.guests === 1 ? "" : "s"}`;
}

function durationLabel(b: Booking): string | null {
  if (!b.checkIn || !b.checkOut) return null;
  const start = new Date(b.checkIn).getTime();
  const end = new Date(b.checkOut).getTime();
  if (Number.isNaN(start) || Number.isNaN(end) || end < start) return null;
  const nights = Math.round((end - start) / 86400000);
  const days = nights + 1;
  return `${nights} night${nights === 1 ? "" : "s"} · ${days} day${days === 1 ? "" : "s"}`;
}

function itemIcon(itemType?: string): keyof typeof Ionicons.glyphMap {
  const t = (itemType ?? "").toLowerCase();
  if (t === "hotel") return "bed-outline";
  if (t === "transport") return "bus-outline";
  if (t === "flight") return "airplane-outline";
  if (t === "restaurant") return "restaurant-outline";
  if (t === "activity") return "walk-outline";
  if (t === "trip") return "map-outline";
  return "receipt-outline";
}

function mapsUrl(booking: Booking): string {
  const query = booking.location?.trim() || booking.itemName;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

function statusMeta(booking: Booking): { label: string; color: string; bg: string } {
  if (booking.status === "accepted") return { label: "✓ Trip Approved", color: "#047857", bg: "#D1FAE5" };
  if (booking.status === "rejected") return { label: "✕ Trip Rejected", color: "#B91C1C", bg: "#FEE2E2" };
  if (booking.status === "confirmed") return { label: "Confirmed", color: colors.primaryDark, bg: "#EAF8F2" };
  if (booking.status === "pending") return { label: "Pending", color: "#B45309", bg: "#FEF3C7" };
  if (booking.status === "completed") return { label: "Completed", color: colors.textMuted, bg: "#F3F5F4" };
  return { label: "Cancelled", color: "#DC2626", bg: "#FEF2F2" };
}

/** True for complete-trip records governed by admin approval (not standalone services). */
function isTripBooking(booking: Booking): boolean {
  return booking.itemType === "trip" || !!booking.tripId || !!booking.paymentId;
}

type BookingTab = "transport" | "hotels" | "activities" | "trips";

const BOOKING_TABS: { id: BookingTab; label: string; icon: keyof typeof Ionicons.glyphMap }[] = [
  { id: "transport", label: "Transport", icon: "bus-outline" },
  { id: "hotels", label: "Hotels", icon: "bed-outline" },
  { id: "activities", label: "Activities", icon: "walk-outline" },
  { id: "trips", label: "Trips", icon: "map-outline" },
];

/**
 * Which My Bookings tab owns a booking. Uses only existing record fields:
 * anything trip-linked (itemType "trip", tripId, or one-payment paymentId)
 * is a Trip booking; standalone transport/flight and hotel go to their own
 * tabs. Standalone restaurant/activity/unknown records return "other" and
 * render in an explicit fallback section instead of being misclassified.
 */
function bookingTabOf(booking: Booking): BookingTab | "other" {
  if (isTripBooking(booking)) return "trips";
  const t = (booking.itemType ?? "").toLowerCase();
  if (t === "transport" || t === "flight") return "transport";
  if (t === "hotel") return "hotels";
  if (t === "activity") return "activities";
  return "other";
}

/** Standalone hotel booking: the only kind gated on admin acceptance before pay. */
function isStandaloneHotelBooking(booking: Booking): boolean {
  return (booking.itemType ?? "").toLowerCase() === "hotel" && !booking.tripId && !booking.paymentId;
}

/**
 * Mirrors the server rule in POST /bookings/:id/pay: an unpaid "confirmed"
 * hotel booking implies admin acceptance (payment itself marks paid at once),
 * so either signal unlocks Pay.
 */
function hotelPayApproved(booking: Booking): boolean {
  return booking.approvalStatus === "approved" || booking.status === "confirmed";
}

function paymentMeta(booking: Booking, initiated: boolean): { label: string; color: string; bg: string } {
  // Terminal booking states are never "waiting": completion and rejection are
  // final admin decisions, so they outrank the approval check below. (A paid
  // trip awaiting approval only exists while status is pending/confirmed.)
  const terminal =
    booking.status === "completed" ||
    booking.status === "rejected" ||
    booking.status === "cancelled";
  if (booking.paymentStatus === "paid" && !terminal && isTripBooking(booking) && booking.approvalStatus === "pending") {
    return { label: "WAITING FOR ADMIN APPROVAL", color: "#92400E", bg: "#FFFBEB" };
  }
  if (booking.paymentStatus === "paid") return { label: "PAID", color: "#047857", bg: "#D1FAE5" };
  if (booking.paymentStatus === "refunded") return { label: "REFUNDED", color: "#7C3AED", bg: "#EDE9FE" };
  if (booking.paymentStatus === "failed") return { label: "PAYMENT FAILED", color: "#DC2626", bg: "#FEE2E2" };
  if (initiated) return { label: "PAYMENT INITIATED — NOT CONFIRMED", color: "#B45309", bg: "#FEF3C7" };
  if (booking.paymentStatus === "pending") return { label: "PAYMENT PENDING", color: "#92400E", bg: "#FEF3C7" };
  if (
    booking.paymentStatus === "not_configured" &&
    (booking.itemType ?? "").toLowerCase() === "trip" &&
    booking.status === "confirmed"
  ) {
    return { label: "AWAITING PAYMENT", color: "#92400E", bg: "#FFFBEB" };
  }
  return { label: "PAYMENT PENDING", color: colors.textMuted, bg: "#F1F5F9" };
}

function BookingCard({
  booking,
  onChanged,
  onNotice,
  onDeleted,
  onRefresh,
  tripCheckoutCode,
}: {
  booking: Booking;
  onChanged: (next: Booking) => void;
  onNotice: (msg: string) => void;
  onDeleted: (id: string) => void;
  onRefresh: () => void;
  /** Set when this booking is displayed inside its complete-trip group. */
  tripCheckoutCode?: string | null;
}) {
  const { getAccessToken } = useAuth();
  const [expanded, setExpanded] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [method, setMethod] = useState<PaymentMethodValue>("esewa");
  const [qr, setQr] = useState<QrInfo | null>(null);
  const [initiated, setInitiated] = useState(false);
  const [busy, setBusy] = useState<"pay" | "confirm" | "qr" | "cancel" | "delete" | "ledger" | "pdf" | null>(null);
  const [actionError, setActionError] = useState("");
  const [ledger, setLedger] = useState<LedgerPayment[] | null>(null);
  const [ledgerError, setLedgerError] = useState("");
  const [tripPlan, setTripPlan] = useState<TripItinerary | null>(null);
  const [tripPlanLoading, setTripPlanLoading] = useState(false);
  // Stable seed for the dynamic demo QR payload (rebuilt from current method/amount).
  const [demoSeed, setDemoSeed] = useState<{ paymentId: string; nonce: string; issuedAt: string } | null>(null);
  const [scanOpen, setScanOpen] = useState(false);

  const status = statusMeta(booking);
  const payment = paymentMeta(booking, initiated);
  const isPaid = booking.paymentStatus === "paid";
  // Bookings paid through the complete-trip one-payment checkout never pay
  // per-item: they are charged, confirmed, and managed together as one trip.
  const tripManaged = !!booking.paymentId;
  // Hotel approval gate (mirrors POST /bookings/:id/pay): a standalone hotel
  // booking shows Pay only after admin acceptance. Closed bookings
  // (cancelled/rejected/completed) never show pay actions for any type.
  const standaloneHotel = isStandaloneHotelBooking(booking);
  const hotelApproved = hotelPayApproved(booking);
  const bookingClosedForPay =
    booking.status === "cancelled" || booking.status === "rejected" || booking.status === "completed";
  // Single complete-trip record (no parent checkout): payable ONLY after the
  // admin confirms it. Standalone transport/activity keep their existing
  // pending|confirmed rule; standalone hotels keep the approval gate below.
  const isTripRecord = (booking.itemType ?? "").toLowerCase() === "trip" && !tripManaged;
  const canPay =
    !isPaid &&
    !tripManaged &&
    !bookingClosedForPay &&
    (isTripRecord ? booking.status === "confirmed" : (booking.status === "pending" || booking.status === "confirmed")) &&
    (!standaloneHotel || hotelApproved);
  const canCancel =
    (booking.status === "pending" || booking.status === "confirmed") &&
    (!tripManaged || !isPaid);

  const authHeaders = useCallback(() => {
    const token = getAccessToken();
    if (!token) throw new Error("Sign in again to manage this booking.");
    return { Authorization: `Bearer ${token}` };
  }, [getAccessToken]);

  const handlePay = useCallback(async (methodOverride?: PaymentMethodValue) => {
    setActionError("");
    setBusy("pay");
    const chosen = methodOverride ?? method;
    try {
      const result = await backendRequest<PayResponse>(`/bookings/${booking._id}/pay`, {
        method: "POST",
        headers: { ...authHeaders(), "Content-Type": "application/json" },
        body: JSON.stringify({ paymentMethod: chosen }),
      });
      onChanged(result.booking);
      if (result.qr) setQr(result.qr);
      const nonce =
        typeof Math !== "undefined" && Math.random
          ? Math.random().toString(36).slice(2, 10).toUpperCase()
          : String(Date.now()).slice(-8);
      setDemoSeed({
        paymentId: result.payment?._id ?? result.booking._id,
        nonce,
        issuedAt: new Date().toISOString(),
      });
      // NEVER mark paid here — only initiated. Paid happens exclusively via
      // /confirm after a valid demo QR scan.
      setInitiated(result.paymentInitiated === true);
      if (result.paymentConfirmed === true) {
        // Backend contract says paymentConfirmed:false on pay; guard anyway.
        setActionError("Unexpected: server reported confirmed on pay. Please scan the QR to verify.");
      } else {
        onNotice(`Demo ${methodLabel(chosen)} payment initiated for ${result.booking.bookingCode}. NOT paid yet — scan the QR with your payment app, then press "I Have Paid".`);
      }
      setPayOpen(true);
    } catch (e) {
      setActionError(e instanceof Error ? e.message : "Could not initiate payment.");
    } finally {
      setBusy(null);
    }
  }, [authHeaders, booking._id, method, onChanged, onNotice]);

  const handleMethodChange = useCallback((next: PaymentMethodValue) => {
    setMethod(next);
    // Selecting a method immediately initiates it server-side and shows its
    // QR: the pay section only renders for unpaid bookings, so tapping a
    // chip means "pay with this provider now".
    if (!isPaid) void handlePay(next);
  }, [handlePay, isPaid]);

  const demoQrPayload = demoSeed
    ? buildDemoQrPayload({
        bookingId: booking._id,
        bookingCode: booking.bookingCode,
        paymentId: demoSeed.paymentId,
        amount: booking.amount,
        currency: booking.currency,
        method,
        nonce: demoSeed.nonce,
        issuedAt: demoSeed.issuedAt,
      })
    : "";

  const validateScan = useCallback(
    (raw: string) =>
      validateDemoQrForBooking(raw, {
        bookingId: booking._id,
        bookingCode: booking.bookingCode,
        amount: booking.amount,
        currency: booking.currency,
      }),
    [booking._id, booking.bookingCode, booking.amount, booking.currency]
  );

  // The ONLY path that can mark this booking paid: a strictly validated demo
  // QR scan followed by a successful backend /confirm.
  const handleConfirmScan = useCallback(async (payload: DemoQrPayload) => {
    setScanOpen(false);
    setActionError("");
    setBusy("confirm");
    try {
      const result = await backendRequest<ConfirmResponse>(`/bookings/${booking._id}/confirm`, {
        method: "POST",
        headers: { ...authHeaders(), "Content-Type": "application/json" },
        // The backend verifies this amount against the stored booking total.
        body: JSON.stringify({ paymentReference: `DEMOQR-${payload.nonce}`, amount: booking.amount }),
      });
      // Only claim confirmed when the server says so AND booking is paid.
      if (result.paymentConfirmed === true && result.booking.paymentStatus === "paid") {
        onChanged(result.booking);
        setInitiated(false);
        onNotice(`Payment Successful for ${result.booking.bookingCode} via Demo ${method} Payment (sandbox only).`);
      } else {
        onChanged(result.booking);
        setActionError("Server did not confirm payment yet. Please scan the QR code again.");
      }
    } catch (e) {
      setActionError(e instanceof Error ? e.message : "Could not confirm demo payment.");
    } finally {
      setBusy(null);
    }
  }, [authHeaders, booking._id, booking.amount, method, onChanged, onNotice]);

  const openScan = useCallback(() => {
    setPayOpen(true);
    setActionError("");
    if (initiated && !isPaid && demoSeed) {
      setScanOpen(true);
    } else if (!isPaid) {
      setActionError("Press Pay Through Online first to generate the demo QR code, then scan it.");
    }
  }, [demoSeed, initiated, isPaid]);

  // "I Have Paid" — manual demo confirmation without the camera: confirms
  // with the same generated demo reference the scanner would produce.
  // Only enabled after Pay generated the QR (initiated), and only the
  // backend /confirm success marks anything paid.
  const handleManualConfirm = useCallback(() => {
    if (!initiated || isPaid || !demoSeed) {
      setActionError("Press Pay Through Online first to generate the demo QR code, then confirm.");
      return;
    }
    void handleConfirmScan({ nonce: demoSeed.nonce } as DemoQrPayload);
  }, [demoSeed, handleConfirmScan, initiated, isPaid]);

  const handleViewQr = useCallback(async () => {
    setActionError("");
    setBusy("qr");
    try {
      const result = await backendRequest<QrResponse>(`/bookings/${booking._id}/qr`, {
        headers: { ...authHeaders() },
      });
      setQr(result.qr);
      if (typeof result.qr.paymentInitiated === "boolean") setInitiated(result.qr.paymentInitiated && !result.qr.paymentConfirmed);
      if (result.qr.paymentConfirmed === true) {
        // QR says confirmed but booking object is source of truth for paid badge;
        // refresh list state via notice only — do not locally force paid.
        onNotice(`QR for ${result.qr.bookingCode}: paymentConfirmed=${String(result.qr.paymentConfirmed)}. Paid badge updates only after /confirm returns paid.`);
      }
    } catch (e) {
      setActionError(e instanceof Error ? e.message : "Could not load QR.");
    } finally {
      setBusy(null);
    }
  }, [authHeaders, booking._id, onNotice]);

  const handleCancel = useCallback(async () => {    setActionError("");
    const doCancel = async () => {
      setBusy("cancel");
      try {
        const result = await backendRequest<CancelResponse>(`/bookings/${booking._id}/cancel`, {
          method: "POST",
          headers: { ...authHeaders() },
        });
        if (result.booking) {
          onChanged(result.booking);
        } else {
          onChanged({ ...booking, status: "cancelled" });
        }
        onNotice(`Booking ${booking.bookingCode} cancelled — inventory restored.`);
      } catch (e) {
        setActionError(e instanceof Error ? e.message : "Could not cancel booking.");
      } finally {
        setBusy(null);
      }
    };
    if (typeof window !== "undefined" && typeof window.confirm === "function") {
      if (window.confirm(`Cancel booking ${booking.bookingCode}? Inventory will be restored.`)) void doCancel();
    } else {
      Alert.alert("Cancel booking", `Cancel booking ${booking.bookingCode}? Inventory will be restored.`, [
        { text: "Keep booking", style: "cancel" },
        { text: "Cancel booking", style: "destructive", onPress: () => void doCancel() },
      ]);
    }
  }, [authHeaders, booking, onChanged, onNotice]);

  const handleDelete = useCallback(async () => {
    setActionError("");
    const doDelete = async () => {
      setBusy("delete");
      try {
        const result = await backendRequest<{ deleted: boolean; wasPaid?: boolean; message?: string }>(`/bookings/${booking._id}`, {
          method: "DELETE",
          headers: { ...authHeaders() },
        });
        if (result.deleted === true) {
          onDeleted(booking._id);
          onNotice(result.message || `Booking ${booking.bookingCode} deleted.`);
        } else {
          setActionError("The server did not confirm deletion. Please refresh and try again.");
        }
      } catch (e) {
        setActionError(e instanceof Error ? e.message : "Could not delete booking.");
      } finally {
        setBusy(null);
      }
    };
    const paidWarning = isPaid
      ? " This booking has already been paid. Deleting it does not automatically issue a refund."
      : "";
    const question = `Delete this booking (${booking.bookingCode})?${paidWarning}`;
    if (typeof window !== "undefined" && typeof window.confirm === "function") {
      if (window.confirm(question)) void doDelete();
    } else {
      Alert.alert("Delete this booking?", `${booking.bookingCode}.${paidWarning}`, [
        { text: "Cancel", style: "cancel" },
        { text: "Delete", style: "destructive", onPress: () => void doDelete() },
      ]);
    }
  }, [authHeaders, booking._id, booking.bookingCode, isPaid, onDeleted, onNotice]);

  const openMaps = useCallback(() => {
    void Linking.openURL(mapsUrl(booking)).catch(() => {
      setActionError("Could not open maps link.");
    });
  }, [booking]);

  // Booking PDFs: the completed trip record; hotel / transport bookings (any
  // status); activity bookings ONLY once completed by the admin. The backend
  // enforces ownership and the trip/activity completion rules.
  const pdfKind = (booking.itemType ?? "").toLowerCase();
  const canDownloadPdf =
    (pdfKind === "trip" && booking.status === "completed") ||
    pdfKind === "hotel" ||
    pdfKind === "transport" ||
    (pdfKind === "activity" && booking.status === "completed");
  const pdfButtonLabel = pdfKind === "trip" ? "Download Trip PDF" : "Download PDF";

  const handleDownloadPdf = useCallback(async () => {
    setActionError("");
    setBusy("pdf");
    try {
      const token = getAccessToken();
      if (!token) throw new Error("Sign in again to download this booking PDF.");
      const url = `${BACKEND_BASE_URL}/bookings/${booking._id}/pdf`;
      if (Platform.OS === "web") {
        const response = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!response.ok) {
          let message = `Could not download the booking PDF (${response.status}).`;
          try {
            const body: unknown = await response.json();
            if (body && typeof body === "object" && "message" in body && typeof body.message === "string") {
              message = body.message;
            }
          } catch {
            // Non-JSON body (e.g. Express default 404 page) means the running
            // backend does not have the PDF route — it needs a restart.
            if (response.status === 404) {
              message = "Booking PDF endpoint not found (404). Restart the backend server to pick up the latest changes, then try again.";
            }
          }
          throw new Error(message);
        }
        const blob = await response.blob();
        const objectUrl = URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        anchor.href = objectUrl;
        // Prefer the server's filename (per-type); fall back to a local one.
        const disposition = response.headers.get("Content-Disposition") || "";
        const serverName = /filename="([^"]+)"/.exec(disposition)?.[1];
        anchor.download = serverName || `SuvYatra_${booking.bookingCode}.pdf`;
        document.body.appendChild(anchor);
        anchor.click();
        anchor.remove();
        setTimeout(() => URL.revokeObjectURL(objectUrl), 5000);
        onNotice(`Booking PDF downloaded for ${booking.bookingCode}.`);
      } else {
        // Native shells cannot attach headers to a system download/view URL,
        // so the token travels as a query parameter the PDF endpoint verifies.
        await Linking.openURL(`${url}?token=${encodeURIComponent(token)}`);
      }
    } catch (e) {
      setActionError(e instanceof Error ? e.message : "Could not download the booking PDF.");
    } finally {
      setBusy(null);
    }
  }, [booking._id, booking.bookingCode, getAccessToken, onNotice]);

  const shortTripId = typeof booking.tripId === "string" && booking.tripId.length > 8
    ? `…${booking.tripId.slice(-6)}`
    : booking.tripId;

  const handleLedger = useCallback(async () => {
    setLedgerError("");
    setBusy("ledger");
    try {
      const result = await backendRequest<LedgerResponse>(`/bookings/${booking._id}/payments`, {
        headers: { ...authHeaders() },
      });
      setLedger(result.payments ?? []);
    } catch (e) {
      setLedgerError(e instanceof Error ? e.message : "Could not load payment ledger.");
    } finally {
      setBusy(null);
    }
  }, [authHeaders, booking._id]);

  // Day-by-day itinerary for complete-trip records, loaded from the linked
  // trip plan only when the trip is expanded. Only services actually in the
  // plan are shown — empty days/services are skipped, never rendered blank.
  useEffect(() => {
    if (!expanded || booking.itemType !== "trip" || !booking.tripId || tripPlan || tripPlanLoading) return;
    let active = true;
    const controller = new AbortController();
    setTripPlanLoading(true);
    (async () => {
      try {
        const token = getAccessToken();
        if (!token) return;
        const plan = await backendRequest<TripItinerary>(`/trips/${booking.tripId}`, {
          headers: { Authorization: `Bearer ${token}` },
          signal: controller.signal,
        });
        if (active) setTripPlan(plan);
      } catch {
        if (active) setTripPlan(null);
      } finally {
        if (active) setTripPlanLoading(false);
      }
    })();
    return () => {
      active = false;
      controller.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expanded, booking.itemType, booking.tripId]);

  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <RelevantImage
          entity={{
            name: booking.itemName.replace(/^activities near /i, "").trim(),
            type:
              booking.itemType === "transport"
                ? "transport"
                : booking.itemType === "hotel"
                  ? "hotel"
                  : booking.itemType === "activity"
                    ? "activity"
                    : "destination",
            location: booking.location,
            image: booking.image,
            images: booking.images,
            imageSource: booking.imageSource,
            imageSourcePage: booking.imageSourcePage,
            imageLicense: booking.imageLicense,
            imageCredit: booking.imageCredit,
            imageDescription: booking.imageDescription,
            imageRelevance: booking.imageRelevance,
          }}
          style={styles.imagePlaceholder}
        />
        <View style={styles.cardInfo}>
          <Text style={styles.bookingCode}>Booking ID: {booking.bookingCode}</Text>
          <Text style={styles.name}>{booking.itemName}</Text>
          <View style={styles.locationRow}>
            <Ionicons name="location-outline" size={12} color={colors.textMuted} />
            <Text style={styles.location}>{booking.location || "Nepal"}</Text>
          </View>
          <Text style={styles.serviceType}>
            <Ionicons name={itemIcon(booking.itemType)} size={11} color={colors.textMuted} /> {(booking.itemType ?? "booking").toUpperCase()}
          </Text>
        </View>
        <View style={styles.badgeColumn}>
          <View style={[styles.statusPill, { backgroundColor: status.bg }]}>
            <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
          </View>
          <View style={[styles.statusPill, styles.paymentPill, { backgroundColor: payment.bg }]}>
            <Text style={[styles.statusText, { color: payment.color }]}>{payment.label}</Text>
          </View>
        </View>
      </View>

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Ionicons name="calendar-outline" size={15} color={colors.textMuted} />
          <Text style={styles.detailText}>{formatDates(booking)}</Text>
        </View>
        <View style={styles.detailRow}>
          <Ionicons name="people-outline" size={15} color={colors.textMuted} />
          <Text style={styles.detailText}>{guestsLabel(booking)}</Text>
        </View>
        {durationLabel(booking) ? (
          <View style={styles.detailRow}>
            <Ionicons name="time-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>Duration: {durationLabel(booking)}</Text>
          </View>
        ) : null}
        {booking.createdAt ? (
          <View style={styles.detailRow}>
            <Ionicons name="calendar-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>Booked: {formatDateTime(booking.createdAt)}</Text>
          </View>
        ) : null}
        {booking.seatNumbers && booking.seatNumbers.length ? (
          <View style={styles.detailRow}>
            <Ionicons name="ticket-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>Seats: {booking.seatNumbers.join(", ")}</Text>
          </View>
        ) : null}
        {booking.tableLabel ? (
          <View style={styles.detailRow}>
            <Ionicons name="restaurant-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>Table {booking.tableLabel}</Text>
          </View>
        ) : null}
        {booking.origin ? (
          <View style={styles.detailRow}>
            <Ionicons name="navigate-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>From {booking.origin}</Text>
          </View>
        ) : null}
        {booking.tripId ? (
          <View style={styles.detailRow}>
            <Ionicons name="map-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>Trip {shortTripId}</Text>
          </View>
        ) : null}
        {tripManaged ? (
          <View style={styles.detailRow}>
            <Ionicons name="card-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>
              Paid together · Trip {tripCheckoutCode ?? booking.paymentId}
            </Text>
          </View>
        ) : null}
        {booking.paymentReference ? (
          <View style={styles.detailRow}>
            <Ionicons name="receipt-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>Ref {booking.paymentReference}</Text>
          </View>
        ) : null}
        <View style={styles.detailRow}>
          <Ionicons name="card-outline" size={15} color={colors.textMuted} />
          <Text style={styles.detailText}>
            {booking.currency} {booking.amount.toLocaleString("en-IN")} · {booking.paymentMethod || "no method"}
          </Text>
        </View>
        {standaloneHotel && !isPaid && booking.status === "pending" && !hotelApproved ? (
          <View style={styles.detailRow}>
            <Ionicons name="hourglass-outline" size={15} color="#92400E" />
            <Text style={[styles.detailText, { color: "#92400E", fontWeight: "700" }]}>
              Awaiting Admin Approval — Pay Now appears after the admin accepts this booking.
            </Text>
          </View>
        ) : null}
        {isTripRecord && !isPaid && booking.status === "pending" ? (
          <View style={styles.detailRow}>
            <Ionicons name="hourglass-outline" size={15} color="#92400E" />
            <Text style={[styles.detailText, { color: "#92400E", fontWeight: "700" }]}>
              Pending Admin Confirmation — Pay Now appears after the admin confirms this trip.
            </Text>
          </View>
        ) : null}
        {isTripRecord && !isPaid && booking.status === "confirmed" ? (
          <View style={styles.detailRow}>
            <Ionicons name="checkmark-circle-outline" size={15} color="#047857" />
            <Text style={[styles.detailText, { color: "#047857", fontWeight: "700" }]}>
              Confirmed by Admin — payment required.
            </Text>
          </View>
        ) : null}
        {pdfKind === "activity" && (booking.status === "pending" || booking.status === "confirmed") ? (
          <View style={styles.detailRow}>
            <Ionicons name="hourglass-outline" size={15} color="#92400E" />
            <Text style={[styles.detailText, { color: "#92400E", fontWeight: "700" }]}>
              Your activity booking PDF will be available after admin completion.
            </Text>
          </View>
        ) : null}
        {standaloneHotel && !isPaid && hotelApproved && !bookingClosedForPay ? (
          <View style={styles.detailRow}>
            <Ionicons name="checkmark-circle-outline" size={15} color="#047857" />
            <Text style={[styles.detailText, { color: "#047857", fontWeight: "700" }]}>
              Approved by Admin — payment required.
            </Text>
          </View>
        ) : null}
        {(standaloneHotel || isTripRecord) && booking.status === "rejected" ? (
          <View style={styles.detailRow}>
            <Ionicons name="close-circle-outline" size={15} color="#B91C1C" />
            <Text style={[styles.detailText, { color: "#B91C1C", fontWeight: "700" }]}>
              Booking Rejected by admin{booking.rejectionReason ? ` — ${booking.rejectionReason}` : ""}.
            </Text>
          </View>
        ) : null}
      </View>

      {expanded ? (
        <View style={styles.expandedBox}>
          <Text style={styles.expandedTitle}>Booking details</Text>
          <Text style={styles.expandedText}>Booking ID: {booking.bookingCode}</Text>
          <Text style={styles.expandedText}>Service: {booking.itemName} ({booking.itemType ?? "n/a"})</Text>
          <Text style={styles.expandedText}>Location: {booking.location ?? "Nepal"}</Text>
          <Text style={styles.expandedText}>Check-in: {formatDateTime(booking.checkIn)}</Text>
          <Text style={styles.expandedText}>Check-out: {formatDateTime(booking.checkOut)}</Text>
          {booking.serviceTime ? <Text style={styles.expandedText}>Service time: {formatDateTime(booking.serviceTime)}</Text> : null}
          <Text style={styles.expandedText}>Guests: {guestsLabel(booking)} (total {booking.guests})</Text>
          {booking.roomTypeName ? <Text style={styles.expandedText}>Room type: {booking.roomTypeName}</Text> : null}
          {booking.seatNumbers && booking.seatNumbers.length ? <Text style={styles.expandedText}>Seats: {booking.seatNumbers.join(", ")}</Text> : null}
          {booking.tableLabel ? <Text style={styles.expandedText}>Table: {booking.tableLabel}</Text> : null}
          {booking.tripId ? <Text style={styles.expandedText}>Trip: {shortTripId}</Text> : null}
          {booking.paymentReference ? <Text style={styles.expandedText}>Payment reference: {booking.paymentReference}</Text> : null}
          <Text style={styles.expandedText}>Amount: {booking.currency} {booking.amount.toLocaleString("en-IN")}</Text>
          <Text style={styles.expandedText}>Payment method: {booking.paymentMethod || "—"}</Text>
          <Text style={styles.expandedText}>Payment status: {booking.paymentStatus}{initiated && booking.paymentStatus !== "paid" ? " (initiated locally — awaiting /confirm)" : ""}</Text>
          <View style={styles.ledgerBox}>
            <Text style={styles.expandedTitle}>Payment ledger (sandbox / test)</Text>
            {ledger ? (
              ledger.length ? ledger.map((entry) => (
                <Text key={entry._id} style={styles.expandedText}>
                  {entry.status} · {entry.method ?? "no method"} · {entry.currency ?? booking.currency} {(entry.amount ?? 0).toLocaleString("en-IN")}
                  {entry.reference ? ` · Ref ${entry.reference}` : ""}
                  {entry.demo === false ? "" : " · demo"}
                </Text>
              )) : <Text style={styles.expandedText}>No ledger entries yet — press Pay to initiate a sandbox payment.</Text>
            ) : (
              <Pressable
                onPress={handleLedger}
                disabled={busy !== null}
                accessibilityRole="button"
                accessibilityLabel={`Load payment ledger for ${booking.bookingCode}`}
                style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}
              >
                <Text style={styles.smallButtonText}>{busy === "ledger" ? "Loading…" : "Load ledger"}</Text>
              </Pressable>
            )}
            {ledgerError ? <Text style={styles.actionError}>{ledgerError}</Text> : null}
          </View>
      <Text style={styles.expandedText}>Booking status: {booking.status}</Text>
      <Text style={styles.expandedText}>
        Admin confirmation:{" "}
        {booking.approvalStatus === "approved"
          ? "Confirmed"
          : booking.approvalStatus === "rejected"
            ? "Rejected"
            : "Pending"}
      </Text>
          {booking.createdAt ? <Text style={styles.expandedText}>Created: {formatDateTime(booking.createdAt)}</Text> : null}
          {booking.itemType === "trip" && booking.tripId ? (
            <TripPlanDetails
              tripPlan={tripPlan}
              tripPlanLoading={tripPlanLoading}
              booking={booking}
            />
          ) : null}
          <Pressable onPress={openMaps} accessibilityRole="link" style={({ pressed }) => [styles.mapLink, pressed && styles.buttonPressed]}>
            <Ionicons name="map-outline" size={14} color={colors.primaryDark} />
            <Text style={styles.mapLinkText}> Map / directions: {booking.location || booking.itemName}</Text>
          </Pressable>
          <Text style={styles.mapUrl} selectable>{`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(booking.location?.trim() || booking.itemName)}`}</Text>
        </View>
      ) : null}

      {isPaid ? (
        <View style={styles.successBox}>
          <Text style={styles.successTitle}>Payment Successful ✓</Text>
          <Text style={styles.expandedText}>Booking ID: {booking.bookingCode}</Text>
          <Text style={styles.expandedText}>Amount: {booking.currency} {booking.amount.toLocaleString("en-IN")}</Text>
          <Text style={styles.expandedText}>Payment method: Demo {methodLabel(booking.paymentMethod)} Payment</Text>
          {booking.paymentReference ? <Text style={styles.expandedText}>Transaction ID: {booking.paymentReference}</Text> : null}
          {booking.paymentConfirmedAt ? <Text style={styles.expandedText}>Paid at: {formatDateTime(booking.paymentConfirmedAt)}</Text> : null}
          {isTripBooking(booking) && booking.approvalStatus === "pending" ? (
            <View>
              <Text style={styles.expandedText}>STATUS: Waiting for Admin Approval</Text>
              <Text style={styles.expandedText}>Expected response within 120 minutes of payment.</Text>
              {booking.approvalDeadline ? <Text style={styles.expandedText}>Respond by: {formatDateTime(booking.approvalDeadline)}</Text> : null}
            </View>
          ) : null}
          {isTripBooking(booking) && booking.approvalStatus === "approved" ? (
            <Text style={styles.expandedText}>STATUS: ✓ Trip Approved — approved by SuvYatra{booking.approvedAt ? ` on ${formatDateTime(booking.approvedAt)}` : ""}.</Text>
          ) : null}
          {isTripBooking(booking) && booking.approvalStatus === "rejected" ? (
            <View>
              <Text style={styles.expandedText}>STATUS: ✕ Trip Rejected{booking.rejectedAt ? ` on ${formatDateTime(booking.rejectedAt)}` : ""}.</Text>
              {booking.rejectionReason ? <Text style={styles.expandedText}>Reason: {booking.rejectionReason}</Text> : null}
              <Text style={styles.expandedText}>Refund processing is not included in this demo.</Text>
            </View>
          ) : null}
          <Text style={styles.expandedText}>Sandbox record only — no real money moved.</Text>
          <View style={styles.buttonGrid}>
            <Pressable
              onPress={() => { setPayOpen(false); onRefresh(); }}
              accessibilityRole="button"
              accessibilityLabel={`View my bookings after paying ${booking.bookingCode}`}
              style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed]}
            >
              <Text style={styles.smallButtonText}>View My Booking</Text>
            </Pressable>
            <Pressable
              onPress={() => { setPayOpen(false); setExpanded(true); }}
              accessibilityRole="button"
              accessibilityLabel={`View trip details for ${booking.bookingCode}`}
              style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed]}
            >
              <Text style={styles.smallButtonText}>View Trip Details</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      {payOpen && canPay ? (
        <View style={styles.payBox}>
          <Text style={styles.expandedTitle}>Demo Payment — pick a method</Text>
          <View style={styles.methodRow}>
            {PAYMENT_METHODS.map((m) => (
              <Pressable
                key={m}
                onPress={() => handleMethodChange(m)}
                accessibilityRole="button"
                accessibilityLabel={`Pay with ${methodLabel(m)}`}
                style={({ pressed }) => [styles.methodChip, method === m && styles.methodChipActive, pressed && styles.buttonPressed]}
              >
                <Text style={[styles.methodText, method === m && styles.methodTextActive]}>{methodLabel(m)}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={styles.payNote}>Tapping a method initiates the demo payment (Pending) and shows its QR. Payment becomes Successful ONLY after you confirm below and the server confirms it.</Text>
          {!isPaid && initiated && demoQrPayload ? (
            <View>
              <Text style={styles.expandedTitle}>Scan QR & Pay</Text>
              <DemoMethodQr
                method={method}
                amount={booking.amount}
                currency={booking.currency}
                bookingCode={booking.bookingCode}
                payload={demoQrPayload}
                status="pending"
              />
              <Text style={styles.expandedText}>Scan this QR code using your payment app</Text>
              <Text style={styles.expandedText}>{brandFor(method).instructions}</Text>
              <Pressable
                onPress={openScan}
                disabled={busy !== null}
                accessibilityRole="button"
                accessibilityLabel={`Scan demo QR for ${booking.bookingCode}`}
                style={({ pressed }) => [styles.confirmButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}
              >
                <Text style={styles.confirmButtonText}>Scan QR Code</Text>
              </Pressable>
              <Pressable
                onPress={handleManualConfirm}
                disabled={busy !== null}
                accessibilityRole="button"
                accessibilityLabel={`Confirm demo payment for ${booking.bookingCode}`}
                style={({ pressed }) => [styles.confirmButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}
              >
                <Text style={styles.confirmButtonText}>{busy === "confirm" ? "Processing Payment…" : "I Have Paid"}</Text>
              </Pressable>
            </View>
          ) : null}
          {qr && !demoQrPayload ? (
            <View style={styles.qrBox}>
              <Text style={styles.expandedTitle}>QR payload (scan / copy in sandbox)</Text>
              <Text style={styles.qrPayload} selectable>{qr.payload}</Text>
              <Text style={styles.expandedText}>Amount: {qr.currency} {qr.amount.toLocaleString("en-IN")}</Text>
              <Text style={styles.expandedText}>Booking: {qr.bookingCode} · Method: {qr.method ?? method}</Text>
              {qr.instructions ? <Text style={styles.expandedText}>Instructions: {qr.instructions}</Text> : null}
              <Text style={styles.expandedText}>Initiated: {String(qr.paymentInitiated ?? initiated)} · Confirmed: {String(qr.paymentConfirmed ?? isPaid)}</Text>
            </View>
          ) : null}
          <DemoQrScanner
            visible={scanOpen}
            bookingLabel={`${booking.itemName} · ${booking.bookingCode} · ${booking.currency} ${booking.amount}`}
            validate={validateScan}
            onSuccess={(payload) => void handleConfirmScan(payload)}
            onClose={() => setScanOpen(false)}
          />
        </View>
      ) : null}

      {actionError ? <Text style={styles.actionError}>{actionError}</Text> : null}

      <View style={styles.cardBottom}>
        <Text style={styles.price}>{booking.currency} {booking.amount.toLocaleString("en-IN")}</Text>
      </View>
      <View style={styles.buttonGrid}>
        <Pressable onPress={() => setExpanded((v) => !v)} accessibilityRole="button" style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed]}>
          <Text style={styles.smallButtonText}>{expanded ? "Hide details" : "View Details"}</Text>
        </Pressable>
        {tripManaged ? (
          <Text style={styles.tripManagedNote}>Part of one trip payment — no separate charge.</Text>
        ) : canPay ? (
          <>
            <Pressable onPress={() => setPayOpen((v) => !v)} accessibilityRole="button" style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed]}>
              <Text style={styles.smallButtonText}>{payOpen ? "Hide payment" : standaloneHotel || isTripRecord ? "Pay Now" : "Pay Through Online"}</Text>
            </Pressable>
            <Pressable onPress={openScan} disabled={busy !== null} accessibilityRole="button" style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}>
              <Text style={styles.smallButtonText}>{busy === "confirm" ? "…" : "Scan"}</Text>
            </Pressable>
            <Pressable onPress={handleViewQr} disabled={busy !== null} accessibilityRole="button" style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}>
              <Text style={styles.smallButtonText}>{busy === "qr" ? "…" : "View QR"}</Text>
            </Pressable>
          </>
        ) : null}
        {canDownloadPdf ? (
          <Pressable onPress={handleDownloadPdf} disabled={busy !== null} accessibilityRole="button" accessibilityLabel={`Download PDF for ${booking.bookingCode}`} style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}>
            <Text style={styles.smallButtonText}>{busy === "pdf" ? "Preparing…" : pdfButtonLabel}</Text>
          </Pressable>
        ) : null}
        {canCancel ? (
          <Pressable onPress={handleCancel} disabled={busy !== null} accessibilityRole="button" accessibilityLabel={`Cancel booking ${booking.bookingCode}`} style={({ pressed }) => [styles.cancelButton, pressed && styles.buttonPressed]}>
            <Text style={styles.cancelText}>{busy === "cancel" ? "Cancelling…" : "Cancel"}</Text>
          </Pressable>
        ) : null}
          <Pressable onPress={handleDelete} disabled={busy !== null} accessibilityRole="button" accessibilityLabel={`Delete booking ${booking.bookingCode}`} style={({ pressed }) => [styles.cancelButton, pressed && styles.buttonPressed, busy !== null && styles.buttonDisabled]}>
            <Text style={styles.cancelText}>{busy === "delete" ? "Deleting…" : "Delete Booking"}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

/** Complete saved trip details for a trip booking: journey, party, every
 * selected service, ordered stops, itinerary days, and the price breakdown —
 * all from the saved trip plan, never placeholders. */
function TripPlanDetails({
  tripPlan,
  tripPlanLoading,
  booking,
}: {
  tripPlan: TripItinerary | null;
  tripPlanLoading: boolean;
  booking: Booking;
}) {
  const sel = tripPlan?.selections ?? null;
  const text = (value: unknown): string | null => {
    if (value === undefined || value === null) return null;
    const str = String(value).trim();
    return str ? str : null;
  };
  const money = (value: unknown, currency?: string): string | null => {
    if (value === undefined || value === null || !Number.isFinite(Number(value))) return null;
    return `${currency || "NPR"} ${Number(value).toLocaleString("en-IN")}`;
  };
  const duration = (minutes?: number): string | null => {
    if (minutes === undefined || !Number.isFinite(minutes) || minutes <= 0) return null;
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${h ? `${h}h ` : ""}${m ? `${m}m` : ""}`.trim() || null;
  };
  const legs = [sel?.outbound, sel?.return, sel?.local].filter(
    (leg): leg is TripSelectionLeg => !!leg && (!!leg.name || !!leg.label)
  );
  const plannedStops = (sel?.stops ?? []).filter((s) => !!s?.name);
  const fallbackStops = (!plannedStops.length ? tripPlan?.plannedItems ?? [] : []).filter((s) => !!s?.name);
  const days = (tripPlan?.itinerary ?? []).filter((d) => d.items && d.items.length > 0);
  const party = sel?.party;
  const totals = sel?.totals;
  const hotel = sel?.hotel;
  const activity = sel?.activity;
  const restaurant = sel?.restaurant;

  if (tripPlanLoading && !tripPlan) {
    return (
      <View style={styles.ledgerBox}>
        <Text style={styles.expandedTitle}>Complete trip details</Text>
        <Text style={styles.expandedText}>Loading saved trip plan…</Text>
      </View>
    );
  }

  return (
    <View style={styles.ledgerBox}>
      <Text style={styles.expandedTitle}>Complete trip details</Text>

      <Text style={styles.itineraryDayTitle}>Journey</Text>
      {text(tripPlan?.origin) || text(booking.origin) ? (
        <Text style={styles.expandedText}>From {text(tripPlan?.origin) ?? text(booking.origin)}</Text>
      ) : null}
      {text(tripPlan?.destination) || text(booking.location) ? (
        <Text style={styles.expandedText}>
          To {text(tripPlan?.destination) ?? text(booking.location)}
          {text(sel?.destinationProvince) ? ` · ${text(sel?.destinationProvince)}` : ""}
          {text(sel?.destinationCountry) ? `, ${text(sel?.destinationCountry)}` : ""}
        </Text>
      ) : null}
      <Text style={styles.expandedText}>
        Dates: {tripPlan?.startDate ? formatDateTime(tripPlan.startDate).split(",")[0] : "—"}
        {" → "}
        {tripPlan?.endDate ? formatDateTime(tripPlan.endDate).split(",")[0] : "—"}
      </Text>
      {durationLabel(booking) ? <Text style={styles.expandedText}>Duration: {durationLabel(booking)}</Text> : null}

      <Text style={styles.itineraryDayTitle}>Travelers</Text>
      <Text style={styles.expandedText}>
        {party?.adults ?? booking.adults ?? booking.guests ?? 0} adult(s)
        {" · "}{party?.children ?? booking.children ?? 0} child(ren)
        {" · "}{party?.rooms ?? booking.rooms ?? 1} room(s)
        {party?.participants !== undefined ? ` · ${party.participants} participant(s)` : ""}
      </Text>

      {hotel && text(hotel.name) ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Accommodation</Text>
          <Text style={styles.expandedText}>{text(hotel.name)}</Text>
          {text(hotel.location) ? <Text style={styles.expandedText}>{text(hotel.location)}</Text> : null}
          {text(hotel.room) ? <Text style={styles.expandedText}>Room: {text(hotel.room)}</Text> : null}
          {hotel.bedConfiguration ? <Text style={styles.expandedText}>{hotel.bedConfiguration}</Text> : null}
          {hotel.breakfastIncluded ? <Text style={styles.expandedText}>Breakfast included</Text> : null}
          {hotel.capacityAdults !== undefined || hotel.capacityChildren !== undefined ? (
            <Text style={styles.expandedText}>
              Fits up to {hotel.capacityAdults ?? "—"} adult(s) · {hotel.capacityChildren ?? "—"} child(ren)
            </Text>
          ) : null}
          {hotel.rating !== undefined ? <Text style={styles.expandedText}>Rating: {hotel.rating}</Text> : null}
          {text(hotel.checkIn) || text(hotel.checkOut) ? (
            <Text style={styles.expandedText}>Stay: {text(hotel.checkIn) ?? "—"} → {text(hotel.checkOut) ?? "—"}</Text>
          ) : null}
          {hotel.nights !== undefined || hotel.rooms !== undefined ? (
            <Text style={styles.expandedText}>
              {hotel.nights !== undefined ? `${hotel.nights} night(s)` : ""}
              {hotel.nights !== undefined && hotel.rooms !== undefined ? " · " : ""}
              {hotel.rooms !== undefined ? `${hotel.rooms} room(s)` : ""}
            </Text>
          ) : null}
          {money(hotel.nightlyRate) ? <Text style={styles.expandedText}>Rate: {money(hotel.nightlyRate)}/night</Text> : null}
          {money(hotel.amount) ? <Text style={styles.expandedText}>Hotel total: {money(hotel.amount)}</Text> : null}
        </View>
      ) : null}

      {legs.length ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Transportation</Text>
          {legs.map((leg, i) => (
            <View key={`${leg.label ?? leg.name}-${i}`}>
              <Text style={styles.expandedText}>· {text(leg.label) ?? text(leg.name)}</Text>
              {text(leg.vehicleType) || text(leg.provider) ? (
                <Text style={styles.expandedText}>
                  {"  "}{[text(leg.vehicleType), text(leg.provider)].filter(Boolean).join(" · ")}
                </Text>
              ) : null}
              {text(leg.origin) || text(leg.destination) ? (
                <Text style={styles.expandedText}>{"  "}Route: {text(leg.origin) ?? "—"} → {text(leg.destination) ?? "—"}</Text>
              ) : null}
              {text(leg.date) ? <Text style={styles.expandedText}>{"  "}Date: {text(leg.date)}</Text> : null}
              {text(leg.departureTime) || text(leg.arrivalTime) ? (
                <Text style={styles.expandedText}>{"  "}Time: {text(leg.departureTime) ?? "—"} → {text(leg.arrivalTime) ?? "—"}</Text>
              ) : null}
              {duration(leg.durationMinutes) ? <Text style={styles.expandedText}>{"  "}Duration: {duration(leg.durationMinutes)}</Text> : null}
              {leg.adults !== undefined || leg.children !== undefined ? (
                <Text style={styles.expandedText}>{"  "}Passengers: {leg.adults ?? 0} adult(s) · {leg.children ?? 0} child(ren)</Text>
              ) : null}
              {leg.seats?.length ? <Text style={styles.expandedText}>{"  "}Seats: {leg.seats.join(", ")}</Text> : null}
              {money(leg.unitPrice) ? (
                <Text style={styles.expandedText}>{"  "}Fare: {money(leg.unitPrice)}{leg.priceBasis ? ` (${leg.priceBasis})` : ""}</Text>
              ) : null}
              {money(leg.amount) ? <Text style={styles.expandedText}>{"  "}Leg total: {money(leg.amount)}</Text> : null}
            </View>
          ))}
        </View>
      ) : null}

      {activity && text(activity.name) ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Activity</Text>
          <Text style={styles.expandedText}>· {text(activity.name)}</Text>
          {text(activity.location) ? <Text style={styles.expandedText}>{"  "}{text(activity.location)}</Text> : null}
          {text(activity.date) ? <Text style={styles.expandedText}>{"  "}Date: {text(activity.date)}{text(activity.slot) ? ` @ ${text(activity.slot)}` : ""}</Text> : null}
          {activity.durationMinutes ? <Text style={styles.expandedText}>{"  "}Duration: {duration(activity.durationMinutes)}</Text> : null}
          {text(activity.meetingPoint) ? <Text style={styles.expandedText}>{"  "}Meeting point: {text(activity.meetingPoint)}</Text> : null}
          {activity.participants !== undefined ? <Text style={styles.expandedText}>{"  "}Participants: {activity.participants}</Text> : null}
          {money(activity.unitPrice) ? <Text style={styles.expandedText}>{"  "}Price: {money(activity.unitPrice)}/person</Text> : null}
          {money(activity.amount) ? <Text style={styles.expandedText}>{"  "}Activity total: {money(activity.amount)}</Text> : null}
        </View>
      ) : null}

      {restaurant && text(restaurant.name) ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Restaurant</Text>
          <Text style={styles.expandedText}>· {text(restaurant.name)}</Text>
          {text(restaurant.location) ? <Text style={styles.expandedText}>{"  "}{text(restaurant.location)}</Text> : null}
          {text(restaurant.category) || restaurant.cuisine?.length ? (
            <Text style={styles.expandedText}>{"  "}{[text(restaurant.category), (restaurant.cuisine ?? []).join(", ")].filter(Boolean).join(" · ")}</Text>
          ) : null}
          {text(restaurant.priceRange) ? <Text style={styles.expandedText}>{"  "}Price range: {text(restaurant.priceRange)}</Text> : null}
          {text(restaurant.date) ? <Text style={styles.expandedText}>{"  "}Date: {text(restaurant.date)}</Text> : null}
          {restaurant.guests !== undefined ? <Text style={styles.expandedText}>{"  "}Guests: {restaurant.guests} · pay at venue</Text> : null}
        </View>
      ) : null}

      {plannedStops.length ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Planned stops (in order)</Text>
          {plannedStops.map((s, i) => (
            <Text key={`${s.name}-${i}`} style={styles.expandedText}>
              {i + 1}. {s.name}{s.kind ? ` (${s.kind})` : ""}{s.location ? ` · ${s.location}` : ""}
            </Text>
          ))}
        </View>
      ) : fallbackStops.length ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Planned stops</Text>
          {fallbackStops.map((s, i) => (
            <Text key={`${s.name}-${i}`} style={styles.expandedText}>
              {i + 1}. {s.name}{s.category ? ` (${s.category})` : ""}{s.location ? ` · ${s.location}` : ""}
            </Text>
          ))}
        </View>
      ) : null}

      {days.length ? (
        <View>
          <Text style={styles.itineraryDayTitle}>Day-by-day itinerary</Text>
          {days.map((d) => (
            <View key={d.day} style={styles.itineraryDay}>
              <Text style={styles.itineraryDayTitle}>
                DAY {d.day}{d.date ? ` · ${formatDateTime(d.date)}` : ""}{d.focus ? ` — ${d.focus}` : ""}
              </Text>
              {d.items.map((item, i) => (
                <Text key={`${d.day}-${i}`} style={styles.expandedText}>
                  · {item.name}
                  {item.entityType ? ` (${item.entityType})` : ""}
                  {Number.isFinite(item.estimatedCost) ? ` · NPR ${Number(item.estimatedCost).toLocaleString("en-IN")}` : ""}
                </Text>
              ))}
            </View>
          ))}
        </View>
      ) : null}

      <Text style={styles.itineraryDayTitle}>Price breakdown</Text>
      {money(totals?.hotel) ? <Text style={styles.expandedText}>Hotel: {money(totals?.hotel)}</Text> : null}
      {money(totals?.transportation) ? <Text style={styles.expandedText}>Transportation: {money(totals?.transportation)}</Text> : null}
      {money(totals?.activities) ? <Text style={styles.expandedText}>Activities: {money(totals?.activities)}</Text> : null}
      <Text style={styles.expandedText}>
        Final total: {booking.currency} {Number(booking.amount).toLocaleString("en-IN")}
      </Text>
      <Text style={styles.expandedText}>
        Payment: {booking.paymentStatus}{booking.paymentMethod ? ` (${booking.paymentMethod})` : ""}
        {booking.paymentReference ? ` · Ref ${booking.paymentReference}` : ""}
      </Text>
      <Text style={styles.expandedText}>Booking status: {booking.status}</Text>
    </View>
  );
}

type TripSummary = {
  trip: { _id: string; name?: string; destination?: string; startDate?: string; endDate?: string };
  checkout?: {
    _id: string;
    checkoutCode: string;
    paymentId: string;
    paymentMethod: string;
    totalAmount: number;
    currency?: string;
    paymentStatus: "PENDING" | "PAID" | "FAILED";
    referenceId?: string;
    completedAt?: string;
    approvalStatus?: "pending" | "approved" | "rejected";
    approvalDeadline?: string;
  } | null;
  totals: { subtotal: number; taxesAndFees: number; total: number; currency: string };
};

function TripGroupCard({
  summary,
  items,
  onChanged,
  onNotice,
  onDeleted,
  onRefresh,
}: {
  summary: TripSummary | null;
  items: Booking[];
  onChanged: (next: Booking) => void;
  onNotice: (msg: string) => void;
  onDeleted: (id: string) => void;
  onRefresh: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const checkout = summary?.checkout ?? null;
  const currency = checkout?.currency ?? items[0]?.currency ?? "NPR";
  const total = checkout ? checkout.totalAmount : items.reduce((sum, b) => sum + (Number(b.amount) || 0), 0);
  const allPaid = items.length > 0 && items.every((b) => b.paymentStatus === "paid");
  const anyFailed = checkout?.paymentStatus === "FAILED";
  const anyRejected = items.some((b) => b.approvalStatus === "rejected") || checkout?.approvalStatus === "rejected";
  const allApproved = allPaid && items.every((b) => b.approvalStatus === "approved") && checkout?.approvalStatus !== "pending";
  const waitingApproval = allPaid && !anyRejected && !allApproved;
  const statusLabel = anyRejected ? "✕ TRIP REJECTED" : allApproved ? "✓ TRIP APPROVED" : allPaid && waitingApproval ? "WAITING FOR ADMIN APPROVAL" : allPaid ? "PAID ✓" : anyFailed ? "PAYMENT FAILED" : "PAYMENT PENDING";
  const statusColor = anyRejected ? "#B91C1C" : allApproved ? "#047857" : waitingApproval && allPaid ? "#92400E" : allPaid ? "#047857" : anyFailed ? "#B91C1C" : "#92400E";
  const statusBg = anyRejected ? "#FEE2E2" : allApproved ? "#EAF8F2" : waitingApproval && allPaid ? "#FFFBEB" : allPaid ? "#EAF8F2" : anyFailed ? "#FEF2F2" : "#FFFBEB";
  const firstImage = items.find((b) => b.image || (b.images && b.images.length));
  const tripName = summary?.trip?.name ?? "Complete Trip";

  return (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <RelevantImage
          entity={{
            name: summary?.trip?.destination || items[0]?.itemName || "Nepal trip",
            type: "destination",
            location: summary?.trip?.destination || items[0]?.location,
            image: firstImage?.image,
            images: firstImage?.images,
            imageSource: firstImage?.imageSource,
            imageSourcePage: firstImage?.imageSourcePage,
            imageLicense: firstImage?.imageLicense,
            imageCredit: firstImage?.imageCredit,
            imageDescription: firstImage?.imageDescription,
            imageRelevance: firstImage?.imageRelevance,
          }}
          style={styles.imagePlaceholder}
        />
        <View style={styles.cardInfo}>
          <Text style={styles.bookingCode}>COMPLETE TRIP · ONE PAYMENT</Text>
          <Text style={styles.name}>{tripName}</Text>
          <View style={styles.locationRow}>
            <Ionicons name="location-outline" size={12} color={colors.textMuted} />
            <Text style={styles.location}>{summary?.trip?.destination || items[0]?.location || "Nepal"}</Text>
          </View>
          <Text style={styles.serviceType}>{items.length} SERVICE(S) PAID TOGETHER</Text>
        </View>
        <View style={styles.badgeColumn}>
          <View style={[styles.statusPill, { backgroundColor: statusBg }]}>
            <Text style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
          </View>
        </View>
      </View>

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Ionicons name="card-outline" size={15} color={colors.textMuted} />
          <Text style={styles.detailText}>Total Paid: {currency} {Number(total).toLocaleString("en-IN")}</Text>
        </View>
        {checkout ? (
          <>
            <View style={styles.detailRow}>
              <Ionicons name="receipt-outline" size={15} color={colors.textMuted} />
              <Text style={styles.detailText}>
                {methodLabel(checkout.paymentMethod)} · Trip {checkout.checkoutCode} · Pay {checkout.paymentId}
              </Text>
            </View>
            {checkout.referenceId ? (
              <View style={styles.detailRow}>
                <Ionicons name="checkmark-circle-outline" size={15} color={colors.textMuted} />
                <Text style={styles.detailText}>Demo transaction: {checkout.referenceId}</Text>
              </View>
            ) : null}
          </>
        ) : (
          <Text style={styles.detailText}>Paid per service before the one-payment checkout — shown together for the trip.</Text>
        )}
      </View>

      <View style={styles.buttonGrid}>
        <Pressable onPress={() => setExpanded((v) => !v)} accessibilityRole="button" style={({ pressed }) => [styles.smallButton, pressed && styles.buttonPressed]}>
          <Text style={styles.smallButtonText}>{expanded ? "Hide details" : "View Details"}</Text>
        </Pressable>
      </View>

      {expanded ? (
        <View style={{ marginTop: 8 }}>
          {items.map((b) => (
            <BookingCard key={b._id} booking={b} onChanged={onChanged} onNotice={onNotice} onDeleted={onDeleted} onRefresh={onRefresh} tripCheckoutCode={checkout?.checkoutCode ?? null} />
          ))}
        </View>
      ) : null}
    </View>
  );
}

function buildItinerary(list: Booking[]): { day: number; dateKey: string; items: Booking[] }[] {
  const active = list.filter((b) => b.status === "confirmed" || b.status === "pending");
  const sorted = [...active].sort((a, b) => {
    const ta = a.checkIn ? new Date(a.checkIn).getTime() : Number.MAX_SAFE_INTEGER;
    const tb = b.checkIn ? new Date(b.checkIn).getTime() : Number.MAX_SAFE_INTEGER;
    if (Number.isNaN(ta) && Number.isNaN(tb)) return 0;
    if (Number.isNaN(ta)) return 1;
    if (Number.isNaN(tb)) return -1;
    return ta - tb;
  });
  // Group by calendar date so same-day bookings share a DAY number.
  const groups: { day: number; dateKey: string; items: Booking[] }[] = [];
  const keyOf = (b: Booking) => {
    if (b.checkIn) {
      const d = new Date(b.checkIn);
      if (!Number.isNaN(d.getTime())) return d.toDateString();
    }
    if (b.serviceTime) {
      const d = new Date(b.serviceTime);
      if (!Number.isNaN(d.getTime())) return d.toDateString();
    }
    return "To be scheduled";
  };
  sorted.forEach((b) => {
    const k = keyOf(b);
    const last = groups[groups.length - 1];
    if (last && last.dateKey === k) {
      last.items.push(b);
    } else {
      groups.push({ day: groups.length + 1, dateKey: k, items: [b] });
    }
  });
  return groups;
}

export default function BookingsListScreen({ navigation }: Props) {
  const { getAccessToken } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [tripSummaries, setTripSummaries] = useState<Record<string, TripSummary>>({});
  const [tab, setTab] = useState<BookingTab>("transport");
  const tabAutoSelected = useRef(false);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token) {
        setBookings([]);
        setError("Sign in with a registered account to view saved bookings.");
        setLoading(false);
        return undefined;
      }
      const controller = new AbortController();
      setLoading(true);
      setError("");
      backendRequest<{ bookings: Booking[] }>("/bookings", {
        headers: { Authorization: `Bearer ${token}` },
        signal: controller.signal,
      })
        .then((result) => setBookings(result.bookings))
        .catch((requestError) => {
          if (!controller.signal.aborted) {
            setError(requestError instanceof Error ? requestError.message : "Could not load bookings.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
      return () => controller.abort();
    }, [getAccessToken, reloadKey])
  );

  const handleChanged = useCallback((next: Booking) => {
    setBookings((current) => current.map((item) => (item._id === next._id ? next : item)));
  }, []);

  const handleDeleted = useCallback((id: string) => {
    // Remove immediately, then re-fetch to confirm the database state.
    setBookings((current) => current.filter((item) => item._id !== id));
    // Drop cached trip summaries so groups rebuild from the re-fetch.
    setTripSummaries({});
    setReloadKey((k) => k + 1);
  }, []);

  const handleNotice = useCallback((msg: string) => {
    setNotice(msg);
  }, []);

  const handleRefresh = useCallback(() => {
    setReloadKey((k) => k + 1);
  }, []);

  // Complete-trip groups: active bookings that share a tripId render as ONE
  // overall trip booking (single total, single payment) instead of several
  // unrelated payments.
  const tripGroups = useMemo(() => {
    const byTrip = new Map<string, Booking[]>();
    for (const b of bookings) {
      if (!b.tripId || b.status === "cancelled") continue;
      const list = byTrip.get(b.tripId) ?? [];
      list.push(b);
      byTrip.set(b.tripId, list);
    }
    return [...byTrip.entries()].map(([tripId, items]) => ({ tripId, items }));
  }, [bookings]);

  const groupedIds = useMemo(() => {
    const ids = new Set<string>();
    for (const group of tripGroups) {
      for (const b of group.items) ids.add(b._id);
    }
    return ids;
  }, [tripGroups]);

  const standaloneBookings = useMemo(
    () => bookings.filter((b) => !groupedIds.has(b._id)),
    [bookings, groupedIds]
  );

  // Tab separation uses only existing record fields (see bookingTabOf).
  // Trip-linked records inside tripId groups render as TripGroupCards;
  // trip-linked records WITHOUT a tripId render as individual cards in Trips.
  const transportBookings = useMemo(
    () => standaloneBookings.filter((b) => bookingTabOf(b) === "transport"),
    [standaloneBookings]
  );
  const hotelBookings = useMemo(
    () => standaloneBookings.filter((b) => bookingTabOf(b) === "hotels"),
    [standaloneBookings]
  );
  const activityBookings = useMemo(
    () => standaloneBookings.filter((b) => bookingTabOf(b) === "activities"),
    [standaloneBookings]
  );
  const tripLooseBookings = useMemo(
    () => standaloneBookings.filter((b) => bookingTabOf(b) === "trips"),
    [standaloneBookings]
  );
  const otherBookings = useMemo(
    () => standaloneBookings.filter((b) => bookingTabOf(b) === "other"),
    [standaloneBookings]
  );
  const tripGroupItems = useMemo(
    () => tripGroups.flatMap((group) => group.items),
    [tripGroups]
  );
  const tripCount = tripGroupItems.length + tripLooseBookings.length;

  const selectTab = useCallback((next: BookingTab) => {
    tabAutoSelected.current = true;
    setTab(next);
  }, []);

  // Once after load, land on the first non-empty tab so users with only one
  // booking kind don't stare at an empty default. Never overrides a choice.
  useEffect(() => {
    if (loading || tabAutoSelected.current) return;
    tabAutoSelected.current = true;
    if (transportBookings.length > 0) setTab("transport");
    else if (hotelBookings.length > 0) setTab("hotels");
    else if (activityBookings.length > 0) setTab("activities");
    else if (tripCount > 0) setTab("trips");
  }, [loading, transportBookings.length, hotelBookings.length, activityBookings.length, tripCount]);

  const tabFlatBookings =
    tab === "transport"
      ? transportBookings
      : tab === "hotels"
        ? hotelBookings
        : tab === "activities"
          ? activityBookings
          : tripLooseBookings;
  const tabItineraryBookings =
    tab === "trips" ? [...tripGroupItems, ...tripLooseBookings] : tabFlatBookings;
  const itinerary = useMemo(() => buildItinerary(tabItineraryBookings), [tabItineraryBookings]);

  useEffect(() => {
    const token = getAccessToken();
    if (!token || tripGroups.length === 0) return;
    let cancelled = false;
    (async () => {
      const entries = await Promise.all(
        tripGroups.map(async ({ tripId }) => {
          try {
            const summary = await backendRequest<TripSummary>(`/trips/${tripId}/summary`, {
              headers: { Authorization: `Bearer ${token}` },
            });
            return [tripId, summary] as const;
          } catch {
            return null;
          }
        })
      );
      if (cancelled) return;
      setTripSummaries((current) => {
        const next = { ...current };
        for (const entry of entries) {
          if (entry) next[entry[0]] = entry[1];
        }
        return next;
      });
    })();
    return () => {
      cancelled = true;
    };
  }, [getAccessToken, tripGroups]);

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} style={styles.backButton} iconSize={24} />
        <Text style={styles.headerTitle}>My Bookings</Text>
        <View style={styles.headerSpacer} />
      </View>

      <FlatList
        data={tabFlatBookings}
        keyExtractor={(item) => item._id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View>
            {notice ? (
              <View style={styles.noticeBox}>
                <Ionicons name="information-circle-outline" size={16} color={colors.primaryDark} />
                <Text style={styles.noticeText}>{notice}</Text>
              </View>
            ) : null}
            {error ? (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
                <Pressable onPress={() => setReloadKey((k) => k + 1)} accessibilityRole="button">
                  <Text style={styles.retryText}>Try again</Text>
                </Pressable>
              </View>
            ) : null}
            <View
              style={styles.tabRow}
              accessibilityRole="tablist"
              accessibilityLabel="My Bookings sections"
            >
              {BOOKING_TABS.map((t) => {
                const count =
                  t.id === "transport"
                    ? transportBookings.length
                    : t.id === "hotels"
                      ? hotelBookings.length
                      : t.id === "activities"
                        ? activityBookings.length
                        : tripCount;
                const active = tab === t.id;
                return (
                  <Pressable
                    key={t.id}
                    onPress={() => selectTab(t.id)}
                    accessibilityRole="tab"
                    accessibilityState={{ selected: active }}
                    accessibilityLabel={`${t.label} bookings, ${count}`}
                    style={({ pressed }) => [
                      styles.tabButton,
                      active && styles.tabButtonActive,
                      pressed && styles.buttonPressed,
                    ]}
                  >
                    <Ionicons
                      name={t.icon}
                      size={16}
                      color={active ? colors.white : colors.primaryDark}
                    />
                    <Text style={[styles.tabText, active && styles.tabTextActive]}>
                      {t.label} ({count})
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            {tab === "trips" && tripGroups.length > 0 ? (
              <View style={{ marginBottom: 4 }}>
                <Text style={styles.itineraryTitle}>Complete trips · paid together</Text>
                {tripGroups.map((group) => (
                  <TripGroupCard
                    key={group.tripId}
                    summary={tripSummaries[group.tripId] ?? null}
                    items={group.items}
                    onChanged={handleChanged}
                    onNotice={handleNotice}
                    onDeleted={handleDeleted}
                    onRefresh={handleRefresh}
                  />
                ))}
              </View>
            ) : null}
            <View style={styles.itineraryBox}>
              <Text style={styles.itineraryTitle}>Trip itinerary</Text>
              {itinerary.length === 0 ? (
                <Text style={styles.itineraryEmpty}>
                  {loading ? "Loading itinerary…" : "No confirmed or pending bookings to build an itinerary yet."}
                </Text>
              ) : (
                itinerary.map((group) => (
                  <View key={`${group.day}-${group.dateKey}`} style={styles.dayBlock}>
                    <View style={styles.dayHeader}>
                      <View style={styles.dayBadge}>
                        <Text style={styles.dayBadgeText}>DAY {group.day}</Text>
                      </View>
                      <Text style={styles.dayDate}>{group.dateKey}</Text>
                    </View>
                    {group.items.map((b) => (
                      <View key={b._id} style={styles.timelineRow}>
                        <View style={styles.timelineRail}>
                          <View style={styles.timelineDot}>
                            <Ionicons name={itemIcon(b.itemType)} size={13} color={colors.primaryDark} />
                          </View>
                          <View style={styles.timelineLine} />
                        </View>
                        <View style={styles.timelineBody}>
                          <Text style={styles.timelineName}>{b.itemName}</Text>
                          <Text style={styles.timelineSub}>
                            {(b.itemType ?? "booking").toUpperCase()} · {formatDates(b)} · {b.location ?? "Nepal"}
                          </Text>
                          <Text style={styles.timelineSub}>ID {b.bookingCode} · {b.status} · payment {b.paymentStatus}</Text>
                        </View>
                      </View>
                    ))}
                  </View>
                ))
              )}
            </View>
          </View>
        }
        ListEmptyComponent={
          loading ? (
            <View style={styles.emptyState}>
              <ActivityIndicator color={colors.primary} />
            </View>
          ) : tabFlatBookings.length === 0 && (tab !== "trips" || tripGroups.length === 0) && !error ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>
                {tab === "transport"
                  ? "No transport bookings yet. Book a bus, jeep, car, or other ride to see it here."
                  : tab === "hotels"
                    ? "No hotel bookings yet. Book a stay through Hotels to see it here."
                    : tab === "activities"
                      ? "No activity bookings yet."
                      : "No trip bookings yet. Plan a complete trip to see it here."}
              </Text>
              <Pressable
                onPress={() =>
                  tab === "transport"
                    ? navigation.navigate("Transport")
                    : tab === "hotels"
                      ? navigation.navigate("Hotels")
                      : tab === "activities"
                        ? navigation.navigate("PlaceDirectory", { module: "activity" })
                        : navigation.navigate("DestinationTrip", {})
                }
                accessibilityRole="button"
                accessibilityLabel={
                  tab === "transport"
                    ? "Browse transportation"
                    : tab === "hotels"
                      ? "Browse hotels"
                      : tab === "activities"
                        ? "Browse activities"
                        : "Plan your trip"
                }
                style={({ pressed }) => [styles.primaryButton, pressed && styles.buttonPressed, { alignSelf: "stretch", marginTop: spacing.md }]}
              >
                <Text style={styles.primaryButtonText}>
                  {tab === "transport" ? "Browse Transportation" : tab === "hotels" ? "Browse Hotels" : tab === "activities" ? "Browse Activities" : "Plan Your Trip"}
                </Text>
              </Pressable>
            </View>
          ) : null
        }
        ListFooterComponent={
          otherBookings.length > 0 ? (
            <View style={styles.otherBox}>
              <Text style={styles.itineraryTitle}>Other services</Text>
              <Text style={styles.itineraryEmpty}>
                These bookings are kept here so no record is lost. Tell us if they need their own section.
              </Text>
              {otherBookings.map((item) => (
                <BookingCard
                  key={item._id}
                  booking={item}
                  onChanged={handleChanged}
                  onNotice={handleNotice}
                  onDeleted={handleDeleted}
                  onRefresh={handleRefresh}
                />
              ))}
            </View>
          ) : null
        }
        renderItem={({ item }) => <BookingCard booking={item} onChanged={handleChanged} onNotice={handleNotice} onDeleted={handleDeleted} onRefresh={handleRefresh} />}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  backButton: { width: 40, height: 40, borderRadius: radius.full, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 18, fontWeight: "700", color: colors.text, textAlign: "center", flex: 1 },
  headerSpacer: { width: 40 },
  list: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xxxl },
  tabRow: { flexDirection: "row", gap: 8, marginBottom: spacing.md },
  tabButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
    borderRadius: radius.full,
    paddingVertical: 10,
    paddingHorizontal: 8,
  },
  tabButtonActive: { backgroundColor: colors.primaryDark, borderColor: colors.primaryDark },
  tabText: { fontSize: 12.5, fontWeight: "800", color: colors.text },
  tabTextActive: { color: colors.white },
  otherBox: { backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg, marginTop: spacing.md },
  emptyState: { alignItems: "center", padding: spacing.xl },
  emptyText: { color: colors.textMuted, fontSize: 14, lineHeight: 20, textAlign: "center" },
  retryText: { color: colors.primaryDark, fontSize: 14, fontWeight: "700", marginTop: spacing.md },
  noticeBox: { flexDirection: "row", gap: 8, backgroundColor: "#EAF8F2", borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md, alignItems: "flex-start" },
  noticeText: { color: colors.primaryDark, fontSize: 13, lineHeight: 18, flex: 1 },
  errorBox: { backgroundColor: "#FEF2F2", borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md },
  errorText: { color: "#B91C1C", fontSize: 13, lineHeight: 18 },
  itineraryBox: { backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.md },
  itineraryTitle: { fontSize: 16, fontWeight: "800", color: colors.text, marginBottom: spacing.sm },
  itineraryEmpty: { fontSize: 13, color: colors.textMuted, lineHeight: 18 },
  dayBlock: { marginTop: spacing.md },
  dayHeader: { flexDirection: "row", alignItems: "center", marginBottom: spacing.sm },
  dayBadge: { backgroundColor: colors.primaryDark, borderRadius: radius.full, paddingHorizontal: 10, paddingVertical: 4 },
  dayBadgeText: { color: colors.white, fontSize: 11, fontWeight: "800" },
  dayDate: { marginLeft: 8, fontSize: 12.5, fontWeight: "700", color: colors.text },
  timelineRow: { flexDirection: "row", marginBottom: spacing.sm },
  timelineRail: { alignItems: "center", width: 28 },
  timelineDot: { width: 26, height: 26, borderRadius: 13, backgroundColor: "#EAF8F2", alignItems: "center", justifyContent: "center" },
  timelineLine: { width: 2, flex: 1, minHeight: 18, backgroundColor: colors.border, marginTop: 2 },
  timelineBody: { flex: 1, marginLeft: spacing.sm, backgroundColor: colors.background, borderRadius: radius.md, padding: spacing.sm },
  timelineName: { fontSize: 13.5, fontWeight: "700", color: colors.text },
  timelineSub: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.07, shadowRadius: 12, elevation: 2 },
  cardTop: { flexDirection: "row", alignItems: "flex-start" },
  imagePlaceholder: { width: 54, height: 54, borderRadius: radius.md, backgroundColor: "#EAF8F2", alignItems: "center", justifyContent: "center" },
  cardInfo: { flex: 1, marginLeft: spacing.md },
  bookingCode: { fontSize: 11, fontWeight: "700", color: colors.textMuted },
  name: { fontSize: 15, fontWeight: "700", color: colors.text, marginTop: 2 },
  locationRow: { flexDirection: "row", alignItems: "center", marginTop: 3 },
  location: { fontSize: 12.5, color: colors.textMuted, marginLeft: 4 },
  serviceType: { fontSize: 11, color: colors.textMuted, marginTop: 4, fontWeight: "700" },
  badgeColumn: { alignItems: "flex-end", gap: 6 },
  statusPill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.full },
  paymentPill: { maxWidth: 170 },
  statusText: { fontSize: 11.5, fontWeight: "700", textAlign: "right" },
  details: { marginTop: spacing.md, paddingTop: spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  detailRow: { flexDirection: "row", alignItems: "center", marginTop: 4 },
  detailText: { fontSize: 13, color: colors.textMuted, marginLeft: 8, flex: 1 },
  expandedBox: { marginTop: spacing.md, backgroundColor: colors.background, borderRadius: radius.md, padding: spacing.md },
  ledgerBox: { marginTop: spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, paddingTop: spacing.sm },
  expandedTitle: { fontSize: 13.5, fontWeight: "800", color: colors.text, marginBottom: 6 },
  expandedText: { fontSize: 12.5, color: colors.textMuted, marginTop: 3, lineHeight: 17 },
  itineraryDay: { marginTop: 8, gap: 2 },
  itineraryDayTitle: { fontSize: 12.5, fontWeight: "800", color: colors.text },
  mapLink: { flexDirection: "row", alignItems: "center", marginTop: spacing.sm },
  mapLinkText: { color: colors.primaryDark, fontSize: 13, fontWeight: "700" },
  mapUrl: { fontSize: 11, color: colors.textMuted, marginTop: 4 },
  payBox: { marginTop: spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, paddingTop: spacing.md },
  methodRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: spacing.sm },
  methodChip: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.full, paddingHorizontal: 12, paddingVertical: 7, marginRight: 6, marginBottom: 6 },
  methodChipActive: { backgroundColor: colors.primaryDark, borderColor: colors.primaryDark },
  methodText: { fontSize: 12.5, fontWeight: "700", color: colors.text },
  methodTextActive: { color: colors.white },
  primaryButton: { backgroundColor: colors.primaryDark, borderRadius: radius.full, paddingVertical: 10, alignItems: "center", marginTop: 4 },
  primaryButtonText: { color: colors.white, fontSize: 13.5, fontWeight: "800" },
  payNote: { fontSize: 11.5, color: "#92400E", marginTop: 6, lineHeight: 16 },
  qrBox: { backgroundColor: colors.background, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.md },
  qrPayload: { fontSize: 12, color: colors.text, backgroundColor: colors.white, borderRadius: radius.sm, padding: spacing.sm, marginVertical: 6 },
  inputLabel: { fontSize: 12.5, fontWeight: "700", color: colors.text, marginTop: spacing.md, marginBottom: 6 },
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 10, fontSize: 13, color: colors.text, backgroundColor: colors.white },
  confirmButton: { backgroundColor: "#0E9488", borderRadius: radius.full, paddingVertical: 10, alignItems: "center", marginTop: spacing.sm },
  confirmButtonText: { color: colors.white, fontSize: 13.5, fontWeight: "800" },
  successBox: { backgroundColor: "#EAF8F2", borderWidth: 1, borderColor: "#047857", borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm },
  successTitle: { color: "#047857", fontSize: 15, fontWeight: "900", marginBottom: 4 },
  actionError: { color: "#B91C1C", fontSize: 12.5, marginTop: spacing.sm, lineHeight: 17 },
  cardBottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: spacing.md, paddingTop: spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  price: { fontSize: 16, fontWeight: "700", color: colors.primaryDark },
  buttonGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: spacing.sm },
  smallButton: { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.background, paddingHorizontal: spacing.md, paddingVertical: 8, borderRadius: radius.full, marginRight: 6, marginBottom: 6 },
  smallButtonText: { color: colors.text, fontSize: 12.5, fontWeight: "700" },
  cancelButton: { borderWidth: 1.5, borderColor: "#FECACA", backgroundColor: "#FEF2F2", paddingHorizontal: spacing.lg, paddingVertical: 8, borderRadius: radius.full, marginBottom: 6 },
  cancelText: { color: "#EF4444", fontSize: 13, fontWeight: "700" },
  tripManagedNote: { fontSize: 12, color: colors.textMuted, fontStyle: "italic", marginTop: 4, flex: 1 },
  buttonPressed: { opacity: 0.75 },
  buttonDisabled: { opacity: 0.6 },
});


