import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { AdminIdentity } from "../auth/AdminAuthContext";
import { backendRequest } from "../services/backendApi";

export type AdminSection =
  | "dashboard"
  | "users"
  | "destinations"
  | "hotels"
  | "restaurants"
  | "activities"
  | "transport"
  | "approvals"
  | "bookings"
  | "payments"
  | "reviews"
  | "chatbot"
  | "analytics"
  | "settings";

type AdminManagementPanelProps = {
  section: AdminSection;
  admin: AdminIdentity;
  token: string;
  reloadKey: number;
  onDataChanged: () => void;
};

type DataRecord = Record<string, unknown> & { _id: string };
type ListResponse = {
  total: number;
  matching?: number;
  page: number;
  pageCount: number;
  users?: DataRecord[];
  bookings?: DataRecord[];
  payments?: DataRecord[];
  records?: DataRecord[];
};
type BookingSummary = {
  total: number;
  paid: number;
  unpaid: number;
  pending: number;
  notConfigured: number;
  failed: number;
  refunded: number;
  totalRevenue: number;
  currency: string;
};
type BookingDetail = {
  booking: DataRecord;
  siblings: DataRecord[];
  ledger: DataRecord[];
};
type TripPaymentsResponse = {
  total: number;
  page: number;
  pageCount: number;
  tripPayments: DataRecord[];
};
type Overview = {
  totals: Record<string, number>;
  last30Days: { registrations: number; bookings: number };
  trends: { registrations: { date: string; count: number }[]; bookings: { date: string; count: number }[] };
  popular: Record<string, { name: string; count: number }[]>;
};
type FieldDefinition = {
  key: string;
  label: string;
  kind?: "text" | "textarea" | "csv" | "number" | "boolean" | "json" | "date" | "time" | "roomTypes";
  placeholder?: string;
};
type RoomTypeDraft = {
  key: string;
  _id?: string;
  name: string;
  capacityAdults: string;
  capacityChildren: string;
  totalRooms: string;
  nightlyRate: string;
};
type ResourceDefinition = {
  title: string;
  fields: FieldDefinition[];
  subheading: (record: DataRecord) => string;
};

const API_GREEN = "#047857";
const API_NAVY = "#102A43";
const API_MUTED = "#64748B";
const API_BORDER = "#E2E8F0";
const API_SURFACE = "#FFFFFF";
const API_BG = "#F1F5F9";

const resources: Record<string, ResourceDefinition> = {
  destinations: {
    title: "Destinations",
    fields: [
      { key: "name", label: "Name", placeholder: "Destination name" },
      { key: "slug", label: "Slug", placeholder: "unique-destination-slug" },
      { key: "province", label: "Province / region" },
      { key: "country", label: "Country" },
      { key: "description", label: "Description", kind: "textarea" },
      { key: "image", label: "Image URL or project asset path" },
      { key: "images", label: "Additional images", kind: "csv", placeholder: "URL, URL" },
      { key: "openingHours", label: "Opening hours (JSON)", kind: "json", placeholder: '{"daily":"09:00-17:00"}' },
      { key: "highlights", label: "Highlights", kind: "csv" },
      { key: "tags", label: "Tags (use popular / hidden for classification)", kind: "csv" },
    ],
    subheading: (record) => `${asText(record.province) || "Region not set"} · ${asText(record.country) || "Country not set"}`,
  },
  hotels: {
    title: "Hotels",
    fields: [
      { key: "name", label: "Name" }, { key: "location", label: "Location" },
      { key: "city", label: "City" }, { key: "district", label: "District" },
      { key: "province", label: "Province" }, { key: "destination", label: "Destination" },
      { key: "description", label: "Description", kind: "textarea" },
      { key: "image", label: "Image URL or project asset path" },
      { key: "images", label: "Additional images", kind: "csv" },
      { key: "pricePerNight", label: "Price per night (NPR)", kind: "number" },
      { key: "available", label: "Available to users", kind: "boolean" },
      { key: "propertyTypes", label: "Property types", kind: "csv" },
      { key: "amenities", label: "Amenities", kind: "csv" },
      { key: "roomTypes", label: "Room types", kind: "roomTypes" },
      { key: "checkInTime", label: "Check-in time", kind: "time" }, { key: "checkOutTime", label: "Check-out time", kind: "time" },
      { key: "policies", label: "Policies", kind: "csv" },
    ],
    subheading: (record) => `${asText(record.city) || asText(record.location) || "Location not set"} · ${record.pricePerNight ? `NPR ${asText(record.pricePerNight)} / night` : "Price not set"}`,
  },
  restaurants: {
    title: "Restaurants",
    fields: [
      { key: "name", label: "Name" }, { key: "category", label: "Category" },
      { key: "location", label: "Location" }, { key: "address", label: "Address" },
      { key: "city", label: "City" }, { key: "district", label: "District" },
      { key: "province", label: "Province" }, { key: "destination", label: "Destination" },
      { key: "cuisine", label: "Cuisine", kind: "csv" },
      { key: "description", label: "Description", kind: "textarea" },
      { key: "image", label: "Image URL or project asset path" }, { key: "images", label: "Additional images", kind: "csv" },
      { key: "openingHours", label: "Opening hours (JSON)", kind: "json", placeholder: '{"monday":"09:00-21:00"}' },
      { key: "priceRange", label: "Price range" }, { key: "rating", label: "Rating", kind: "number" },
      { key: "tables", label: "Tables (JSON)", kind: "json", placeholder: '[{"label":"T1","seats":4}]' },
    ],
    subheading: (record) => `${asText(record.category) || asText(record.cuisine) || "Category not set"} · ${asText(record.city) || "Location not set"}`,
  },
  activities: {
    title: "Activities",
    fields: [
      { key: "name", label: "Name" }, { key: "category", label: "Activity type / category" },
      { key: "serviceType", label: "Service type" }, { key: "description", label: "Description", kind: "textarea" },
      { key: "location", label: "Location" }, { key: "city", label: "City" }, { key: "district", label: "District" },
      { key: "province", label: "Province" }, { key: "destination", label: "Destination" },
      { key: "image", label: "Image URL or project asset path" }, { key: "images", label: "Additional images", kind: "csv" },
      { key: "price", label: "Price", kind: "number" }, { key: "durationMinutes", label: "Duration (minutes)", kind: "number" },
      { key: "slots", label: "Time slots", kind: "csv", placeholder: "09:00, 11:00, 14:00" },
      { key: "capacityPerSlot", label: "Capacity per slot", kind: "number" },
      { key: "difficulty", label: "Difficulty" }, { key: "bestSeason", label: "Best season" },
      { key: "provider", label: "Provider" }, { key: "openingHours", label: "Opening hours (JSON)", kind: "json" },
      { key: "requirements", label: "Requirements", kind: "csv" }, { key: "safetyInformation", label: "Safety information", kind: "textarea" },
    ],
    subheading: (record) => `${asText(record.category) || "Activity"} · ${asText(record.city) || asText(record.location) || "Location not set"}`,
  },
  transport: {
    title: "Transport",
    fields: [
      { key: "name", label: "Name" }, { key: "type", label: "Vehicle / service type" },
      { key: "provider", label: "Provider" }, { key: "route", label: "Route" },
      { key: "origin", label: "Origin" }, { key: "destination", label: "Destination" },
      { key: "description", label: "Details", kind: "textarea" },
      { key: "image", label: "Image URL or project asset path" }, { key: "images", label: "Additional images", kind: "csv" },
      { key: "price", label: "Price (NPR)", kind: "number" }, { key: "currency", label: "Currency" },
      { key: "durationMinutes", label: "Duration (minutes)", kind: "number" },
      { key: "departureTime", label: "Departure time", kind: "time" }, { key: "arrivalTime", label: "Arrival time", kind: "time" },
      { key: "serviceMode", label: "Service mode (private/shared/scheduled/rental)" },
      { key: "capacity", label: "Capacity", kind: "number" }, { key: "bookingUrl", label: "Booking URL" },
      { key: "seatMap", label: "Seat map (JSON)", kind: "json", placeholder: '{"rows":9,"seatsPerRow":4}' },
      { key: "seatLabels", label: "Explicit seat labels", kind: "csv", placeholder: "1A, 1B, 1C" },
    ],
    subheading: (record) => `${asText(record.type) || "Transport"} · ${asText(record.origin) || "Origin"} → ${asText(record.destination) || "Destination"}`,
  },
  reviews: {
    title: "Reviews",
    fields: [
      { key: "userName", label: "Display name" }, { key: "itemType", label: "Reviewed item type" },
      { key: "itemName", label: "Reviewed item" }, { key: "rating", label: "Rating (1-5)", kind: "number" },
      { key: "comment", label: "Review", kind: "textarea" },
    ],
    subheading: (record) => `${asText(record.itemName) || "Item not set"} · ${asText(record.rating) || "No rating"} / 5${record.isHidden ? " · Hidden" : ""}`,
  },
  feedback: {
    title: "Support feedback",
    fields: [
      { key: "subject", label: "Subject" }, { key: "message", label: "Message", kind: "textarea" },
      { key: "status", label: "Status (open / in_progress / closed)" },
    ],
    subheading: (record) => `${asText(record.status) || "open"} · ${asText((record.user as DataRecord | null)?.email) || "No account linked"}`,
  },
};

function asText(value: unknown): string {
  if (value === null || value === undefined) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return value.map(asText).join(", ");
  return JSON.stringify(value);
}

function formatDate(value: unknown): string {
  const date = new Date(asText(value));
  return Number.isNaN(date.getTime())
    ? "Date unavailable"
    : `${date.toLocaleDateString()} · ${date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
}

function parsePickerDate(value: string, kind: "date" | "time"): Date {
  const now = new Date();
  if (kind === "time") {
    const match = value.match(/^(\d{1,2})(?::(\d{2})(?::\d{2})?)?\s*(AM|PM)?$/i);
    if (!match) return now;
    let hours = Number(match[1]);
    const minutes = Number(match[2] || 0);
    if (match[3]) {
      hours = hours % 12 + (match[3].toUpperCase() === "PM" ? 12 : 0);
    }
    if (hours > 23 || minutes > 59) return now;
    now.setHours(hours, minutes, 0, 0);
    return now;
  }

  const dateOnly = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (dateOnly) {
    const date = new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]));
    if (
      date.getFullYear() === Number(dateOnly[1])
      && date.getMonth() === Number(dateOnly[2]) - 1
      && date.getDate() === Number(dateOnly[3])
    ) return date;
    return now;
  }
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? now : parsed;
}

function formatPickerValue(value: Date, kind: "date" | "time"): string {
  if (kind === "time") {
    return `${String(value.getHours()).padStart(2, "0")}:${String(value.getMinutes()).padStart(2, "0")}`;
  }
  return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
}

function displayPickerValue(value: string, kind: "date" | "time"): string {
  if (kind === "time" && !/^\d{1,2}(?::\d{2}(?::\d{2})?)?\s*(AM|PM)?$/i.test(value)) return value;
  if (kind === "date" && /^\d{4}-\d{2}-\d{2}$/.test(value)
    && formatPickerValue(parsePickerDate(value, kind), kind) !== value) return value;
  if (kind === "date" && Number.isNaN(new Date(value).getTime())) return value;
  const parsed = parsePickerDate(value, kind);
  return kind === "time"
    ? parsed.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
    : parsed.toLocaleDateString();
}

function makeHeaders(token: string, json = false): HeadersInit {
  return {
    Authorization: `Bearer ${token}`,
    ...(json ? { "Content-Type": "application/json" } : {}),
  };
}

export default function AdminManagementPanel({
  section,
  admin,
  token,
  reloadKey,
  onDataChanged,
}: AdminManagementPanelProps) {
  // Same container rule as the workspace: on web the admin lives in the
  // shared mobile-sized container, so compact layout follows it.
  const { width: windowWidth } = useWindowDimensions();
  const viewportWidth = Platform.OS === "web" ? Math.min(windowWidth, 430) : windowWidth;
  const compactLayout = viewportWidth < 600;
  const [query, setQuery] = useState("");
  const [appliedQuery, setAppliedQuery] = useState("");
  const [status, setStatus] = useState("");
  const [visibility, setVisibility] = useState("all");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [page, setPage] = useState(1);
  const [localReloadKey, setLocalReloadKey] = useState(0);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [data, setData] = useState<ListResponse | Overview | Record<string, unknown> | null>(null);
  const [selected, setSelected] = useState<DataRecord | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<DataRecord | null>(null);
  const [bookingDetail, setBookingDetail] = useState<BookingDetail | null>(null);
  const [bookingDetailLoading, setBookingDetailLoading] = useState(false);
  const [bookingSummary, setBookingSummary] = useState<BookingSummary | null>(null);
  const [paymentFilter, setPaymentFilter] = useState("");
  const [bookingsView, setBookingsView] = useState<"bookings" | "trips">("bookings");
  const [bookingCategory, setBookingCategory] = useState<"all" | "transport" | "hotels" | "activities" | "trips">("all");
  const [tripPayments, setTripPayments] = useState<TripPaymentsResponse | null>(null);
  const [tripsLoading, setTripsLoading] = useState(false);
  const [selectedTrip, setSelectedTrip] = useState<DataRecord | null>(null);
  const [tripDetail, setTripDetail] = useState<{ tripPayment: DataRecord; bookings: DataRecord[] } | null>(null);
  const [tripDetailLoading, setTripDetailLoading] = useState(false);
  const [approvals, setApprovals] = useState<{ total: number; approvals: DataRecord[] } | null>(null);
  const [approvalsLoading, setApprovalsLoading] = useState(false);
  const [selectedApproval, setSelectedApproval] = useState<DataRecord | null>(null);
  const [approvalDetail, setApprovalDetail] = useState<{ kind: string; checkout?: DataRecord; bookings?: DataRecord[]; booking?: DataRecord } | null>(null);
  const [approvalDetailLoading, setApprovalDetailLoading] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [deciding, setDeciding] = useState(false);
  const [userDetails, setUserDetails] = useState<DataRecord | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<DataRecord | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [roomTypes, setRoomTypes] = useState<RoomTypeDraft[]>([]);
  const [pickerField, setPickerField] = useState<FieldDefinition | null>(null);
  const [knowledgeText, setKnowledgeText] = useState("");
  const [knowledgeSource, setKnowledgeSource] = useState("");
  const [knowledgeUrl, setKnowledgeUrl] = useState("");

  const resource = section === "reviews" ? "reviews" : section;
  const title = section === "dashboard" ? "Dashboard" :
    section === "analytics" ? "Analytics" :
    section === "chatbot" ? "Chatbot knowledge" :
    section === "settings" ? "Admin settings" :
    section === "users" ? "User management" :
    section === "bookings" ? "Bookings" :
    section === "approvals" ? "Pending Trip Approvals" :
    section === "payments" ? "Payments" :
    resources[resource]?.title || section;

  const refresh = useCallback(() => setLocalReloadKey((current) => current + 1), []);

  useEffect(() => {
    setPage(1);
    setStatus("");
    setPaymentFilter("");
    setBookingsView("bookings");
    setBookingCategory("all");
    setBookingDetail(null);
    setTripDetail(null);
    setSelectedApproval(null);
    setApprovalDetail(null);
    setRejectReason("");
  }, [section]);

  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    setLoading(true);
    setError("");
    setNotice("");
    let path = "";
    if (section === "dashboard" || section === "analytics") {
      path = "/admin/overview";
    } else if (section === "users") {
      const params = new URLSearchParams({ search: appliedQuery, sort, page: String(page) });
      if (status) params.set("status", status);
      path = `/admin/users?${params.toString()}`;
    } else if (section === "bookings") {
      const params = new URLSearchParams({ search: appliedQuery, page: String(page) });
      if (status) params.set("status", status);
      if (paymentFilter) params.set("paymentStatus", paymentFilter);
      if (bookingCategory !== "all") params.set("category", bookingCategory);
      path = `/admin/bookings?${params.toString()}`;
    } else if (section === "payments") {
      const params = new URLSearchParams({ search: appliedQuery, page: String(page) });
      if (status) params.set("status", status);
      path = `/admin/payments?${params.toString()}`;
    } else if (resources[resource]) {
      const params = new URLSearchParams({ search: appliedQuery, sort, page: String(page) });
      if (section === "reviews" && visibility !== "all") params.set("visibility", visibility);
      if (section === "reviews" && visibility === "feedback") path = `/admin/resources/feedback?${params.toString()}`;
      else path = `/admin/resources/${resource}?${params.toString()}`;
    } else if (section === "chatbot") {
      path = "/admin/chatbot/status";
    } else {
      setData(null);
      setLoading(false);
      return () => { active = false; controller.abort(); };
    }
    backendRequest<ListResponse | Overview | Record<string, unknown>>(path, {
      signal: controller.signal,
      headers: makeHeaders(token),
    })
      .then((result) => { if (active) setData(result); })
      .catch((requestError: unknown) => {
        if (active && !controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load admin data.");
        }
      })
      .finally(() => { if (active && !controller.signal.aborted) setLoading(false); });
    return () => { active = false; controller.abort(); };
  }, [appliedQuery, localReloadKey, page, reloadKey, resource, section, sort, status, paymentFilter, bookingCategory, token, visibility]);

  // Payment summary cards + complete-trip checkouts for the Bookings section.
  // Loaded from live database records — never hardcoded.
  useEffect(() => {
    if (section !== "bookings") return;
    let active = true;
    const controller = new AbortController();
    backendRequest<BookingSummary>("/admin/bookings-summary", {
      signal: controller.signal,
      headers: makeHeaders(token),
    })
      .then((result) => { if (active) setBookingSummary(result); })
      .catch(() => { if (active) setBookingSummary(null); });
    return () => { active = false; controller.abort(); };
  }, [section, localReloadKey, reloadKey, token]);

  useEffect(() => {
    if (section !== "bookings" || bookingsView !== "trips") return;
    let active = true;
    const controller = new AbortController();
    setTripsLoading(true);
    const params = new URLSearchParams({ search: appliedQuery, page: String(page) });
    if (paymentFilter && ["PENDING", "PAID", "FAILED"].includes(paymentFilter.toUpperCase())) {
      params.set("status", paymentFilter.toUpperCase());
    }
    backendRequest<TripPaymentsResponse>(`/admin/trip-payments?${params.toString()}`, {
      signal: controller.signal,
      headers: makeHeaders(token),
    })
      .then((result) => { if (active) setTripPayments(result); })
      .catch(() => { if (active) setTripPayments(null); })
      .finally(() => { if (active) setTripsLoading(false); });
    return () => { active = false; controller.abort(); };
  }, [section, bookingsView, appliedQuery, page, paymentFilter, localReloadKey, reloadKey, token]);

  // Pending trip approvals: trips waiting for an admin accept/reject, before
  // payment (to confirm) as well as after it.
  useEffect(() => {
    if (section !== "approvals") return;
    let active = true;
    const controller = new AbortController();
    setApprovalsLoading(true);
    const params = new URLSearchParams({ page: String(page) });
    backendRequest<{ total: number; page: number; pageCount: number; approvals: DataRecord[] }>(`/admin/approvals?${params.toString()}`, {
      signal: controller.signal,
      headers: makeHeaders(token),
    })
      .then((result) => { if (active) setApprovals({ total: result.total, approvals: result.approvals || [] }); })
      .catch(() => { if (active) setApprovals(null); })
      .finally(() => { if (active) setApprovalsLoading(false); });
    return () => { active = false; controller.abort(); };
  }, [section, page, localReloadKey, reloadKey, token]);

  const openApprovalDetails = useCallback(async (item: DataRecord) => {
    setSelectedApproval(item);
    setApprovalDetail(null);
    setRejectReason("");
    setApprovalDetailLoading(true);
    try {
      const detail = await backendRequest<{ kind: string; checkout?: DataRecord; bookings?: DataRecord[]; booking?: DataRecord }>(
        `/admin/approvals/${encodeURIComponent(asText(item.kind) || "checkout")}/${encodeURIComponent(item._id)}`,
        { headers: makeHeaders(token) }
      );
      setApprovalDetail(detail);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not load approval details.");
    } finally {
      setApprovalDetailLoading(false);
    }
  }, [token]);

  const decideApproval = useCallback(async (decision: "accept" | "reject") => {
    if (!selectedApproval || deciding) return;
    if (decision === "reject" && !rejectReason.trim()) {
      setError("Please provide a reason for rejecting this trip.");
      return;
    }
    const title = decision === "accept" ? "Accept trip" : "Reject trip";
    const message = decision === "accept"
      ? "Are you sure you want to accept this trip?"
      : `Reject this trip?${rejectReason.trim() ? `\nReason: ${rejectReason.trim()}` : ""}\nNo refund is issued automatically.`;
    const doDecide = async () => {
      setDeciding(true);
      setError("");
      setNotice("");
      try {
        await backendRequest(
          `/admin/approvals/${encodeURIComponent(asText(selectedApproval.kind) || "checkout")}/${encodeURIComponent(selectedApproval._id)}/${decision}`,
          {
            method: "POST",
            headers: makeHeaders(token, true),
            body: JSON.stringify(decision === "reject" ? { reason: rejectReason.trim() } : {}),
          }
        );
        setNotice(decision === "accept" ? "Trip accepted — the traveller sees it in their bookings." : "Trip rejected. No refund is issued automatically in demo mode.");
        setSelectedApproval(null);
        setApprovalDetail(null);
        setRejectReason("");
        refresh();
        onDataChanged();
      } catch (requestError) {
        setError(requestError instanceof Error ? requestError.message : `Could not ${decision} the trip.`);
      } finally {
        setDeciding(false);
      }
    };
    if (typeof window !== "undefined" && typeof window.confirm === "function") {
      if (window.confirm(decision === "accept" ? "Are you sure you want to accept this trip?" : message)) void doDecide();
    } else {
      Alert.alert(title, message, [
        { text: "Cancel", style: "cancel" },
        { text: decision === "accept" ? "Accept" : "Reject", style: decision === "accept" ? "default" : "destructive", onPress: () => void doDecide() },
      ]);
    }
  }, [selectedApproval, deciding, rejectReason, token, refresh, onDataChanged]);

  const openBookingDetails = useCallback(async (booking: DataRecord) => {
    setSelectedBooking(booking);
    setBookingDetail(null);
    setBookingDetailLoading(true);
    try {
      const detail = await backendRequest<BookingDetail>(
        `/admin/bookings/${encodeURIComponent(booking._id)}`,
        { headers: makeHeaders(token) }
      );
      setBookingDetail(detail);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not load booking details.");
    } finally {
      setBookingDetailLoading(false);
    }
  }, [token]);

  const openTripDetails = useCallback(async (tripPayment: DataRecord) => {
    setSelectedTrip(tripPayment);
    setTripDetail(null);
    setTripDetailLoading(true);
    try {
      const detail = await backendRequest<{ tripPayment: DataRecord; bookings: DataRecord[] }>(
        `/admin/trip-payments/${encodeURIComponent(tripPayment._id)}`,
        { headers: makeHeaders(token) }
      );
      setTripDetail(detail);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not load trip details.");
    } finally {
      setTripDetailLoading(false);
    }
  }, [token]);

  const submit = useCallback(async (path: string, method: string, body?: unknown, successMessage?: string) => {
    setSaving(true);
    setError("");
    setNotice("");
    try {
      await backendRequest(path, {
        method,
        headers: makeHeaders(token, body !== undefined),
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      });
      setNotice(successMessage ?? "Changes saved to the database.");
      refresh();
      onDataChanged();
      return true;
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not save changes.");
      return false;
    } finally {
      setSaving(false);
    }
  }, [onDataChanged, refresh, token]);

  const openEditor = useCallback((record: DataRecord | null) => {
    const definition = resources[resource];
    if (!definition) return;
    setEditing(record);
    setForm(Object.fromEntries(definition.fields.map((field) => {
      const value = record?.[field.key];
      return [
        field.key,
        field.kind === "boolean"
          ? asText(value ?? true)
          : field.kind === "json" && value !== undefined
            ? JSON.stringify(value, null, 2)
            : field.kind === "csv" && Array.isArray(value)
              ? value.map(asText).join(", ")
              : asText(value),
      ];
    })));
    const existingRoomTypes = record?.roomTypes;
    setRoomTypes(Array.isArray(existingRoomTypes)
      ? existingRoomTypes.map((value, index) => {
        const roomType = typeof value === "object" && value !== null
          ? value as Record<string, unknown>
          : {};
        return {
          key: asText(roomType._id) || `room-type-${index}`,
          ...(asText(roomType._id) ? { _id: asText(roomType._id) } : {}),
          name: asText(roomType.name),
          capacityAdults: asText(roomType.capacityAdults),
          capacityChildren: asText(roomType.capacityChildren),
          totalRooms: asText(roomType.totalRooms),
          nightlyRate: asText(roomType.nightlyRate),
        };
      })
      : []);
    setEditorOpen(true);
  }, [resource]);

  const saveResource = useCallback(async () => {
    const definition = resources[resource];
    if (!definition) return;
    const body: Record<string, unknown> = {};
    try {
      for (const field of definition.fields) {
        const raw = form[field.key] ?? "";
        if (field.kind === "roomTypes") {
          continue;
        } else if (field.kind === "json") {
          if (raw.trim()) body[field.key] = JSON.parse(raw);
          else if (editing) body[field.key] = {};
        } else if (field.kind === "csv") {
          body[field.key] = raw.split(",").map((value) => value.trim()).filter(Boolean);
        } else if (field.kind === "number") {
          if (raw.trim()) {
            const value = Number(raw);
            if (!Number.isFinite(value)) throw new Error(`${field.label} must be a valid number.`);
            body[field.key] = value;
          }
        } else if (field.kind === "boolean") {
          body[field.key] = raw === "true";
        } else {
          body[field.key] = raw.trim();
        }
      }
      if (resource === "hotels") {
        body.roomTypes = roomTypes.map((roomType) => {
          const capacityAdults = Number(roomType.capacityAdults);
          const capacityChildren = Number(roomType.capacityChildren);
          const totalRooms = Number(roomType.totalRooms);
          const nightlyRate = roomType.nightlyRate.trim() ? Number(roomType.nightlyRate) : undefined;
          if (
            !roomType.name.trim() ||
            !Number.isInteger(capacityAdults) || capacityAdults < 1 || capacityAdults > 12 ||
            !Number.isInteger(capacityChildren) || capacityChildren < 0 || capacityChildren > 12 ||
            !Number.isInteger(totalRooms) || totalRooms < 0 || totalRooms > 10000 ||
            (nightlyRate !== undefined && (!Number.isFinite(nightlyRate) || nightlyRate <= 0))
          ) {
            throw new Error(`Complete the room type "${roomType.name || "unnamed"}": set a name, 1–12 adult capacity, 0–12 child capacity, 0–10,000 rooms, and an optional positive nightly rate.`);
          }
          return {
            ...(roomType._id ? { _id: roomType._id } : {}),
            name: roomType.name.trim(),
            capacityAdults,
            capacityChildren,
            totalRooms,
            ...(nightlyRate !== undefined ? { nightlyRate } : {}),
          };
        });
      }
    } catch (parseError) {
      setError(parseError instanceof Error ? parseError.message : "Check the form values.");
      return;
    }
    const path = editing
      ? `/admin/resources/${resource}/${encodeURIComponent(editing._id)}`
      : `/admin/resources/${resource}`;
    if (await submit(path, editing ? "PUT" : "POST", body)) {
      setEditorOpen(false);
      setEditing(null);
    }
  }, [editing, form, resource, roomTypes, submit]);

  const userRows = (data as ListResponse | null)?.users || [];
  const recordRows = (data as ListResponse | null)?.records || [];
  const bookingRows = (data as ListResponse | null)?.bookings || [];
  const paymentRows = (data as ListResponse | null)?.payments || [];
  const overview = data && "totals" in data && "popular" in data
    ? data as Overview
    : null;
  const listMeta = data as ListResponse | null;

  const applySearch = () => {
    setPage(1);
    setAppliedQuery(query.trim());
  };

  const viewUser = async (user: DataRecord) => {
    setSelected(user);
    setUserDetails(null);
    setError("");
    try {
      const detail = await backendRequest<DataRecord>(`/admin/users/${encodeURIComponent(user._id)}`, {
        headers: makeHeaders(token),
      });
      setUserDetails(detail);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not load user details.");
    }
  };

  const toggleUser = async () => {
    if (!userDetails) return;
    const statusNext = userDetails.status === "disabled" ? "active" : "disabled";
    const result = await submit(`/admin/users/${encodeURIComponent(userDetails._id)}/status`, "PATCH", { status: statusNext });
    if (result) {
      const updated = { ...userDetails, status: statusNext };
      setUserDetails(updated);
      setSelected(updated);
    }
  };

  const deleteRecord = (record: DataRecord) => {
    const type = section === "reviews" && visibility === "feedback" ? "feedback" : resource;
    const label = asText(record.name || record.itemName || record.subject) || "this item";
    // NOTE: react-native-web's Alert.alert is a no-op, so the web dialog must
    // use window.confirm (same pattern as decideApproval below). Native keeps
    // the Alert dialog.
    const doDelete = () => {
      void submit(`/admin/resources/${type}/${encodeURIComponent(record._id)}`, "DELETE", undefined, "Deleted successfully.");
    };
    if (typeof window !== "undefined" && typeof window.confirm === "function") {
      if (window.confirm(`Permanently delete "${label}"? This cannot be undone.`)) doDelete();
      return;
    }
    Alert.alert("Are you sure you want to delete this item?", `Permanently delete “${label}”? This cannot be undone.`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => doDelete() },
    ]);
  };

  const toggleReview = async (record: DataRecord) => {
    await submit(`/admin/resources/reviews/${encodeURIComponent(record._id)}`, "PUT", {
      isHidden: record.isHidden !== true,
    });
  };

  const updateBooking = async (booking: DataRecord, nextStatus: string) => {
    await submit(`/admin/bookings/${encodeURIComponent(booking._id)}/status`, "PATCH", { status: nextStatus });
  };

  const ingestText = async () => {
    if (!knowledgeText.trim()) {
      setError("Enter tourism information to add to the existing knowledge base.");
      return;
    }
    const success = await submit("/admin/chatbot/knowledge", "POST", {
      text: knowledgeText,
      source: knowledgeSource.trim() || "admin",
    });
    if (success) {
      setKnowledgeText("");
      setKnowledgeSource("");
    }
  };

  const ingestUrl = async () => {
    if (!knowledgeUrl.trim()) {
      setError("Enter a source URL to ingest.");
      return;
    }
    const success = await submit("/admin/chatbot/knowledge", "POST", { url: knowledgeUrl.trim() });
    if (success) setKnowledgeUrl("");
  };

  const panelHeader = (
    <View style={styles.panelHeader}>
      <View>
        <Text style={styles.eyebrow}>SUVYATRA ADMINISTRATION</Text>
        <Text style={styles.pageTitle}>{title}</Text>
      </View>
      {["bookings", "destinations", "hotels", "restaurants", "activities", "transport", "reviews"].includes(section) &&
      !(section === "reviews" && visibility === "feedback") ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Add ${title.toLowerCase()}`}
          style={styles.primaryButton}
          onPress={() => openEditor(null)}
        >
          <Ionicons name="add" size={18} color="#FFFFFF" />
          <Text style={styles.primaryButtonText}>Add new</Text>
        </Pressable>
      ) : null}
    </View>
  );

  const searchControls = ["users", "bookings", "payments", "destinations", "hotels", "restaurants", "activities", "transport", "reviews"].includes(section);
  const actualResource = section === "reviews" && visibility === "feedback" ? "feedback" : resource;
  const displayRecords = section === "reviews" && visibility === "feedback"
    ? (recordRows as DataRecord[])
    : (recordRows as DataRecord[]);

  return (
    <View style={[styles.panel, compactLayout && styles.panelCompact]}>
      {panelHeader}
      {section === "reviews" ? (
        <View style={styles.chipRow}>
          {[
            ["all", "All reviews"],
            ["visible", "Visible"],
            ["hidden", "Hidden"],
            ["feedback", "Support feedback"],
          ].map(([key, label]) => (
            <FilterChip key={key} label={label} active={visibility === key} onPress={() => {
              setVisibility(key); setPage(1); setStatus("");
            }} />
          ))}
        </View>
      ) : null}
      {searchControls ? (
        <View style={styles.toolbar}>
          <TextInput
            accessibilityLabel={`Search ${title.toLowerCase()}`}
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={applySearch}
            placeholder={`Search ${title.toLowerCase()}…`}
            placeholderTextColor="#94A3B8"
            style={styles.searchInput}
            returnKeyType="search"
          />
          <Pressable style={styles.secondaryButton} onPress={applySearch}>
            <Ionicons name="search" size={17} color={API_NAVY} />
            <Text style={styles.secondaryButtonText}>Search</Text>
          </Pressable>
          {section !== "bookings" && section !== "reviews" ? (
            <Pressable style={styles.secondaryButton} onPress={() => {
              setSort((current) => current === "newest" ? "oldest" : "newest");
              setPage(1);
            }}>
              <Ionicons name="swap-vertical" size={17} color={API_NAVY} />
              <Text style={styles.secondaryButtonText}>{sort === "newest" ? "Newest" : "Oldest"}</Text>
            </Pressable>
          ) : null}
          {section === "users" ? (
            <View style={styles.chipRow}>
              {[["", "All"], ["active", "Active"], ["disabled", "Disabled"]].map(([key, label]) => (
                <FilterChip key={key || "all"} label={label} active={status === key} onPress={() => {
                  setStatus(key); setPage(1);
                }} />
              ))}
            </View>
          ) : null}
          {section === "bookings" ? (
            <View style={styles.chipColumn}>
              <View style={styles.chipRowTight}>
                <Text style={styles.chipGroupLabel}>Payment:</Text>
                {[["", "All"], ["paid", "Paid"], ["unpaid", "Unpaid"], ["pending", "Pending"], ["failed", "Failed"], ["refunded", "Refunded"]].map(([key, label]) => (
                  <FilterChip key={key || "all-pay"} label={label} active={paymentFilter === key} onPress={() => {
                    setPaymentFilter(key); setPage(1);
                  }} />
                ))}
              </View>
              <View style={styles.chipRowTight}>
                <Text style={styles.chipGroupLabel}>Booking:</Text>
                {[["", "All"], ["pending", "Pending"], ["confirmed", "Confirmed"], ["cancelled", "Cancelled"], ["completed", "Completed"]].map(([key, label]) => (
                  <FilterChip key={key || "all-status"} label={label} active={status === key} onPress={() => {
                    setStatus(key); setPage(1);
                  }} />
                ))}
              </View>
              <View style={styles.chipRowTight}>
                <Text style={styles.chipGroupLabel}>View:</Text>
                {[["bookings", "Bookings"], ["trips", "Complete trips"]].map(([key, label]) => (
                  <FilterChip key={key} label={label} active={bookingsView === key} onPress={() => {
                    setBookingsView(key as "bookings" | "trips"); setPage(1);
                  }} />
                ))}
              </View>
              {bookingsView === "bookings" ? (
                <View style={styles.chipRowTight}>
                  <Text style={styles.chipGroupLabel}>Category:</Text>
                  {[["all", "All"], ["transport", "Transportation"], ["hotels", "Hotels"], ["activities", "Activities"], ["trips", "Trips"]].map(([key, label]) => (
                    <FilterChip key={key} label={label} active={bookingCategory === key} onPress={() => {
                      setBookingCategory(key as typeof bookingCategory); setPage(1);
                    }} />
                  ))}
                </View>
              ) : null}
            </View>
          ) : null}
          {section === "payments" ? (
            <View style={styles.chipRow}>
              {[["", "All"], ["PENDING", "Pending"], ["PAID", "Paid"], ["FAILED", "Failed"], ["REFUNDED", "Refunded"]].map(([key, label]) => (
                <FilterChip key={key || "all"} label={label} active={status === key} onPress={() => {
                  setStatus(key); setPage(1);
                }} />
              ))}
            </View>
          ) : null}
        </View>
      ) : null}

      {notice ? <Text style={styles.notice}>{notice}</Text> : null}
      {error ? (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{error}</Text>
          <Pressable onPress={() => { setError(""); refresh(); }}><Text style={styles.retry}>Retry</Text></Pressable>
        </View>
      ) : null}

      {loading ? <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading real database data…</Text></View> : null}

      {!loading && (section === "dashboard" || section === "analytics") && overview ? (
        <AnalyticsView data={overview} detailed={section === "analytics"} />
      ) : null}

      {!loading && section === "settings" ? (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Administrator session</Text>
          <Detail label="Signed in as" value={admin.email} />
          <Detail label="Role" value="Administrator" />
          <Text style={styles.muted}>Admin credentials and the password hash remain on the backend. Session credentials are never exposed in this screen.</Text>
        </View>
      ) : null}

      {!loading && section === "chatbot" ? (
        <ChatbotPanel
          data={(data || {}) as Record<string, unknown>}
          knowledgeText={knowledgeText}
          setKnowledgeText={setKnowledgeText}
          knowledgeSource={knowledgeSource}
          setKnowledgeSource={setKnowledgeSource}
          knowledgeUrl={knowledgeUrl}
          setKnowledgeUrl={setKnowledgeUrl}
          onIngestText={() => void ingestText()}
          onIngestUrl={() => void ingestUrl()}
          saving={saving}
          refresh={refresh}
        />
      ) : null}

      {!loading && section === "users" ? (
        <ScrollView contentContainerStyle={styles.list}>
          <Text style={styles.countText}>{listMeta?.matching ?? userRows.length} matching · {listMeta?.total ?? userRows.length} total users</Text>
          {userRows.length ? userRows.map((user) => (
            <Pressable key={user._id} style={styles.rowCard} onPress={() => void viewUser(user)}>
              <View style={styles.avatar}><Ionicons name="person-outline" size={20} color={API_GREEN} /></View>
              <View style={styles.rowText}>
                <Text style={styles.rowTitle}>{asText(user.name)}</Text>
                <Text style={styles.rowSub}>{asText(user.email) || "No email"} · {formatDate(user.createdAt)}</Text>
                <Text style={styles.rowSub}>{asText(user.location) || "Location not available"} · {asText(user.status) || "active"}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={API_MUTED} />
            </Pressable>
          )) : <EmptyState text={appliedQuery ? "No users match this search." : "No registered users yet."} />}
          <Pagination page={page} pageCount={listMeta?.pageCount || 1} onPage={setPage} />
        </ScrollView>
      ) : null}

      {!loading && section === "bookings" && bookingsView === "bookings" ? (
        <ScrollView contentContainerStyle={styles.list}>
          {bookingSummary ? (
            <View style={styles.metricGrid}>
              <View style={styles.smallMetric}><Text style={styles.metricValue}>{bookingSummary.total}</Text><Text style={styles.metricLabel}>Total bookings</Text></View>
              <View style={styles.smallMetric}><Text style={[styles.metricValue, styles.paidValue]}>{bookingSummary.paid}</Text><Text style={styles.metricLabel}>Paid</Text></View>
              <View style={styles.smallMetric}><Text style={[styles.metricValue, styles.unpaidValue]}>{bookingSummary.unpaid}</Text><Text style={styles.metricLabel}>Unpaid</Text></View>
              <View style={styles.smallMetric}><Text style={styles.metricValue}>{bookingSummary.pending}</Text><Text style={styles.metricLabel}>Pending</Text></View>
              <View style={styles.smallMetric}><Text style={styles.metricValue}>{bookingSummary.failed}</Text><Text style={styles.metricLabel}>Failed</Text></View>
              <View style={styles.smallMetric}><Text style={[styles.metricValue, styles.paidValue]}>{bookingSummary.currency} {bookingSummary.totalRevenue.toLocaleString()}</Text><Text style={styles.metricLabel}>Total revenue (paid)</Text></View>
            </View>
          ) : null}
          <Text style={styles.countText}>{listMeta?.total || 0} booking records · search by name, email, booking ID, payment ID, destination, or type</Text>
          {bookingRows.length ? bookingRows.map((booking) => {
            const user = booking.user as DataRecord | null;
            const tripPayment = booking.tripPayment as DataRecord | null;
            const currentStatus = asText(booking.status);
            const payStatus = asText(booking.paymentStatus).toUpperCase();
            const itemTypeText = asText(booking.itemType).toLowerCase();
            // Trip rows (single trip record or trip-linked service): Complete
            // unlocks only after verified payment. Standalone bookings keep
            // their existing actions.
            const isTripRow = itemTypeText === "trip" || !!asText((booking as DataRecord).tripId) || !!(booking as DataRecord).trip;
            const tripPaid = payStatus === "PAID";
            const actions = currentStatus === "pending"
              ? (itemTypeText === "hotel" && !asText((booking as DataRecord).tripId)
                ? [["confirmed", "Confirm"], ["rejected", "Reject"], ["cancelled", "Cancel"]]
                : [["confirmed", "Confirm"], ["cancelled", "Cancel"]])
              : currentStatus === "confirmed"
                ? (isTripRow && !tripPaid
                  ? [["cancelled", "Cancel"]]
                  : [["completed", "Complete"], ["cancelled", "Cancel"]])
                : [];
            return (
              <View key={booking._id} style={styles.rowCard}>
                <View style={styles.rowText}>
                  <Text style={styles.rowTitle}>{asText(booking.itemName) || "Booking"} · {asText(booking.bookingCode)}</Text>
                  <Text style={styles.rowSub}>{asText(user?.name) || "Account unavailable"} · {asText(user?.email)}</Text>
                  <Text style={styles.rowSub}>
                    Type: {asText(booking.itemType)} · Destination: {asText(booking.location) || asText((booking.trip as DataRecord | null)?.destination) || "—"}
                  </Text>
                  {asText(booking.itemType).toLowerCase() === "transport" || asText(booking.itemType).toLowerCase() === "flight" ? (
                    <Text style={styles.rowSub}>
                      Route: {asText(booking.origin) ? `${asText(booking.origin)} → ` : ""}{asText(booking.location) || "—"}
                      {Array.isArray(booking.seatNumbers) && booking.seatNumbers.length ? ` · Seats: ${(booking.seatNumbers as unknown[]).map(asText).join(", ")}` : ""}
                      {asText(booking.serviceTime) ? ` · Time: ${asText(booking.serviceTime)}` : ""}
                    </Text>
                  ) : null}
                  {asText(booking.itemType).toLowerCase() === "hotel" ? (
                    <Text style={styles.rowSub}>
                      Stay: {asText(booking.checkIn) ? formatDate(booking.checkIn) : "—"} → {asText(booking.checkOut) ? formatDate(booking.checkOut) : "—"}
                      {asText(booking.rooms) ? ` · ${asText(booking.rooms)} room(s)` : ""}
                      {asText(booking.roomTypeName) ? ` · ${asText(booking.roomTypeName)}` : ""}
                      {asText(booking.adults) || asText(booking.children) ? ` · Guests: ${asText(booking.adults) || 0}A/${asText(booking.children) || 0}C` : ""}
                    </Text>
                  ) : null}
                  {asText(booking.itemType).toLowerCase() === "activity" ? (
                    <Text style={styles.rowSub}>
                      Date: {asText(booking.checkIn) ? formatDate(booking.checkIn) : "—"}
                      {asText(booking.serviceTime) ? ` · Slot: ${asText(booking.serviceTime)}` : ""}
                      {asText(booking.guests) ? ` · Participants: ${asText(booking.guests)}` : ""}
                    </Text>
                  ) : null}
                  <Text style={styles.rowSub}>
                    Travel: {asText(booking.checkIn) ? formatDate(booking.checkIn) : "—"} · Booked: {formatDate(booking.createdAt)}
                  </Text>
                  <Text style={styles.rowSub}>
                    {asText(booking.currency) || "NPR"} {asText(booking.amount)} · {asText(booking.paymentMethod) || "no method yet"}
                  </Text>
                  <Text style={styles.rowSub}>
                    Payment: <Text style={payStatus === "PAID" ? styles.paidValue : payStatus === "FAILED" ? styles.unpaidValue : styles.mutedInline}>{payStatus || "UNKNOWN"}</Text>
                    {" · "}Booking: {currentStatus}
                  </Text>
                  <Text style={styles.rowSub}>
                    Pay ref: {asText(booking.paymentReference) || asText(tripPayment?.referenceId) || asText(tripPayment?.paymentId) || "none yet"}
                    {tripPayment?.checkoutCode ? ` · Trip: ${asText(tripPayment.checkoutCode)}` : ""}
                  </Text>
                  <Pressable style={styles.secondaryButton} onPress={() => void openBookingDetails(booking)}>
                    <Text style={styles.secondaryButtonText}>View booking details</Text>
                  </Pressable>
                  {actions.length ? <View style={styles.inlineActions}>{actions.map(([next, label]) => (
                    <Pressable key={next} style={next === "cancelled" || next === "rejected" ? styles.dangerButton : styles.smallPrimary} onPress={() => void updateBooking(booking, next)}>
                      <Text style={next === "cancelled" || next === "rejected" ? styles.dangerText : styles.smallPrimaryText}>{label}</Text>
                    </Pressable>
                  ))}</View> : <Text style={styles.muted}>This booking is in a final status.</Text>}
                  {currentStatus === "confirmed" && isTripRow && !tripPaid ? (
                    <Text style={styles.muted}>Complete unlocks after verified payment.</Text>
                  ) : null}
                </View>
              </View>
            );
          }) : <EmptyState text={appliedQuery ? "No bookings match this search." : "No bookings are stored yet."} />}
          <Pagination page={page} pageCount={listMeta?.pageCount || 1} onPage={setPage} />
        </ScrollView>
      ) : null}

      {!loading && section === "bookings" && bookingsView === "trips" ? (
        <ScrollView contentContainerStyle={styles.list}>
          <Text style={styles.countText}>
            {(tripPayments?.total ?? 0)} complete-trip checkouts · one grand-total payment per trip
          </Text>
          {tripsLoading ? (
            <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading trip checkouts…</Text></View>
          ) : (tripPayments?.tripPayments?.length ? tripPayments.tripPayments.map((tp) => {
            const user = tp.user as DataRecord | null;
            const trip = tp.trip as DataRecord | null;
            const payStatus = asText(tp.paymentStatus).toUpperCase();
            return (
              <View key={tp._id} style={styles.rowCard}>
                <View style={styles.rowText}>
                  <Text style={styles.rowTitle}>
                    {asText(trip?.destination) || asText(trip?.name) || "Complete trip"} · {asText(tp.checkoutCode)}
                  </Text>
                  <Text style={styles.rowSub}>{asText(user?.name) || "Account unavailable"} · {asText(user?.email)}</Text>
                  <Text style={styles.rowSub}>
                    Grand total: {asText(tp.currency) || "NPR"} {asText(tp.totalAmount)} · {asText(tp.paymentMethod)}
                  </Text>
                  <Text style={styles.rowSub}>
                    Payment: <Text style={payStatus === "PAID" ? styles.paidValue : styles.mutedInline}>{payStatus}</Text>
                    {" · "}Pay ID: {asText(tp.paymentId)} · Ref: {asText(tp.referenceId) || "none yet"}
                  </Text>
                  <Text style={styles.rowSub}>
                    Services: {Array.isArray(tp.breakdown) ? tp.breakdown.map((b: unknown) => `${asText((b as DataRecord)?.category)} ${asText((b as DataRecord)?.amount)}`).join(" · ") : `${asText((tp.bookingIds as unknown[] | undefined)?.length) || 0} linked bookings`}
                  </Text>
                  <Text style={styles.rowSub}>Created: {formatDate(tp.createdAt)}</Text>
                  <Pressable style={styles.secondaryButton} onPress={() => void openTripDetails(tp)}>
                    <Text style={styles.secondaryButtonText}>View trip + services</Text>
                  </Pressable>
                </View>
              </View>
            );
          }) : <EmptyState text="No complete-trip checkouts yet. They appear after a user reviews a trip and continues to payment." />)}
          <Pagination page={tripPayments?.page || 1} pageCount={tripPayments?.pageCount || 1} onPage={setPage} />
        </ScrollView>
      ) : null}

      {!loading && section === "approvals" ? (
        <ScrollView contentContainerStyle={styles.list}>
          <Text style={styles.countText}>
            {(approvals?.total ?? 0)} trips waiting for a decision · unpaid trips appear here before payment
          </Text>
          {approvalsLoading ? (
            <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading pending approvals…</Text></View>
          ) : (approvals?.approvals?.length ? approvals.approvals.map((item) => {
            const user = item.user as DataRecord | null;
            const trip = item.trip as DataRecord | null;
            const deadline = asText(item.approvalDeadline);
            return (
              <View key={`${asText(item.kind)}-${item._id}`} style={styles.rowCard}>
                <View style={styles.rowText}>
                  <Text style={styles.rowTitle}>
                    {asText(item.kind) === "booking" ? asText(item.bookingCode) : asText((item as DataRecord).checkoutCode) || "Complete trip"}
                    {" · "}{asText(trip?.destination) || asText(trip?.name) || "Trip"}
                  </Text>
                  <Text style={styles.rowSub}>{asText(user?.name) || "Account unavailable"} · {asText(user?.email)}</Text>
                  <Text style={styles.rowSub}>
                    Total: {asText(item.currency) || "NPR"} {asText(item.totalAmount)} · {asText(item.paymentMethod)}
                  </Text>
                  <Text style={styles.rowSub}>
                    Paid: {asText(item.completedAt) ? formatDate(item.completedAt) : "—"}
                    {" · "}Submitted: {asText(item.submittedForApprovalAt) ? formatDate(item.submittedForApprovalAt) : "—"}
                  </Text>
                  <Text style={styles.rowSub}>
                    Respond by: {deadline ? formatDate(deadline) : "—"} (within 120 minutes of payment)
                  </Text>
                  <Text style={styles.rowSub}>Ref: {asText(item.referenceId) || "none yet"}</Text>
                  <Pressable style={styles.secondaryButton} onPress={() => void openApprovalDetails(item)}>
                    <Text style={styles.secondaryButtonText}>Open trip · accept or reject</Text>
                  </Pressable>
                </View>
              </View>
            );
          }) : <EmptyState text="No trips are waiting for approval. Submitted trips appear here automatically." />)}
        </ScrollView>
      ) : null}

      {!loading && section === "payments" ? (
        <ScrollView contentContainerStyle={styles.list}>
          <Text style={styles.countText}>{listMeta?.total || 0} payment records (sandbox / test ledger)</Text>
          {paymentRows.length ? paymentRows.map((payment) => {
            const user = payment.user as DataRecord | null;
            const booking = payment.booking as DataRecord | null;
            return (
              <View key={payment._id} style={styles.rowCard}>
                <View style={styles.rowText}>
                  <Text style={styles.rowTitle} selectable>{asText(payment._id)}</Text>
                  <Text style={styles.rowSub}>
                    {booking ? `${asText(booking.bookingCode)} · ${asText(booking.itemName)}` : "Booking unavailable"}
                  </Text>
                  <Text style={styles.rowSub}>{asText(user?.name) || "Account unavailable"} · {asText(user?.email)}</Text>
                  <Text style={styles.rowSub}>
                    {asText(payment.currency) || "NPR"} {asText(payment.amount)} · {asText(payment.method) || "no method"} · {asText(payment.status)}
                  </Text>
                  <Text style={styles.rowSub}>Ref: {asText(payment.reference) || "none yet"}</Text>
                  <Text style={styles.rowSub}>
                    {payment.demo === false ? "Live record" : "Demo / sandbox payment"}
                    {payment.providerVerified === true ? " · provider verified" : ""}
                    {" · "}{formatDate(payment.createdAt)}
                  </Text>
                </View>
              </View>
            );
          }) : <EmptyState text={appliedQuery ? "No payments match this search." : "No payments are recorded yet."} />}
          <Pagination page={page} pageCount={listMeta?.pageCount || 1} onPage={setPage} />
        </ScrollView>
      ) : null}

      {!loading && ["destinations", "hotels", "restaurants", "activities", "transport", "reviews"].includes(section) ? (
        <ScrollView contentContainerStyle={styles.list}>
          <Text style={styles.countText}>{listMeta?.total || 0} records</Text>
          {displayRecords.length ? displayRecords.map((record) => (
            <View key={record._id} style={styles.rowCard}>
              <View style={styles.rowText}>
                <Text style={styles.rowTitle}>{asText(record.name || record.itemName || record.userName) || "Review"}</Text>
                <Text style={styles.rowSub}>{resources[actualResource]?.subheading(record) || ""}</Text>
                {actualResource === "reviews" ? <Text style={styles.reviewBody}>{asText(record.comment)}</Text> : null}
                {actualResource === "feedback" ? <Text style={styles.reviewBody}>{asText(record.message)}</Text> : null}
                <Text style={styles.rowSub}>{formatDate(record.createdAt)}</Text>
                <View style={styles.inlineActions}>
                  {actualResource === "reviews" ? (
                    <Pressable style={styles.secondaryButton} onPress={() => void toggleReview(record)}>
                      <Text style={styles.secondaryButtonText}>{record.isHidden ? "Restore review" : "Hide review"}</Text>
                    </Pressable>
                  ) : actualResource === "feedback" ? (
                    [["open", "Open"], ["in_progress", "In progress"], ["closed", "Close"]].map(([next, label]) => (
                      <Pressable key={next} style={asText(record.status) === next ? styles.smallPrimary : styles.secondaryButton} onPress={() => void submit(`/admin/resources/feedback/${encodeURIComponent(record._id)}`, "PUT", { status: next })}>
                        <Text style={asText(record.status) === next ? styles.smallPrimaryText : styles.secondaryButtonText}>{label}</Text>
                      </Pressable>
                    ))
                  ) : null}
                  {actualResource !== "feedback" ? (
                    <Pressable style={styles.secondaryButton} onPress={() => openEditor(record)}>
                      <Ionicons name="create-outline" size={16} color={API_NAVY} /><Text style={styles.secondaryButtonText}>Edit</Text>
                    </Pressable>
                  ) : null}
                  <Pressable
                    style={[styles.dangerButton, saving && styles.buttonDisabled]}
                    onPress={() => deleteRecord(record)}
                    disabled={saving}
                    accessibilityRole="button"
                    accessibilityLabel={`Delete ${asText(record.name || record.itemName || record.userName) || "record"}`}
                    accessibilityState={{ disabled: saving }}
                  >
                    <Ionicons name="trash-outline" size={15} color="#B91C1C" /><Text style={styles.dangerText}>{saving ? "Deleting…" : "Delete"}</Text>
                  </Pressable>
                </View>
              </View>
            </View>
          )) : <EmptyState text={appliedQuery ? `No ${title.toLowerCase()} match this search.` : `No ${title.toLowerCase()} records are stored yet.`} />}
          <Pagination page={page} pageCount={listMeta?.pageCount || 1} onPage={setPage} />
        </ScrollView>
      ) : null}

      <Modal visible={!!selected} transparent animationType="fade" onRequestClose={() => setSelected(null)}>
        <View style={styles.backdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeading}>
              <Text style={styles.cardTitle}>Registered user</Text>
              <Pressable onPress={() => setSelected(null)} accessibilityLabel="Close user details"><Ionicons name="close" size={22} color={API_NAVY} /></Pressable>
            </View>
            {userDetails ? (
              <ScrollView>
                <Detail label="Name" value={asText(userDetails.name)} />
                <Detail label="Email" value={asText(userDetails.email)} />
                <Detail label="Registered" value={formatDate(userDetails.createdAt)} />
                <Detail label="Location" value={asText(userDetails.location) || "Location not available"} />
                <Detail label="Bio" value={asText(userDetails.bio) || "Not provided"} />
                <Detail label="Provider" value={asText(userDetails.provider) || "Not available"} />
                <Detail label="Member since" value={formatDate(userDetails.memberSince)} />
                <Detail label="Account status" value={asText(userDetails.status) || "active"} />
                <Text style={styles.privacyNote}>Password, password hash, authentication token, and private account fields are not returned.</Text>
                <Pressable style={userDetails.status === "disabled" ? styles.primaryButton : styles.dangerButton} onPress={() => void toggleUser()}>
                  <Text style={userDetails.status === "disabled" ? styles.primaryButtonText : styles.dangerText}>
                    {userDetails.status === "disabled" ? "Re-enable account" : "Disable account"}
                  </Text>
                </Pressable>
              </ScrollView>
            ) : <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading user details…</Text></View>}
          </View>
        </View>
      </Modal>

      <Modal visible={!!selectedBooking} transparent animationType="fade" onRequestClose={() => { setSelectedBooking(null); setBookingDetail(null); }}>
        <View style={styles.backdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeading}>
              <Text style={styles.cardTitle}>Booking details</Text>
              <Pressable onPress={() => { setSelectedBooking(null); setBookingDetail(null); }} accessibilityLabel="Close booking details"><Ionicons name="close" size={22} color={API_NAVY} /></Pressable>
            </View>
            {bookingDetailLoading && !bookingDetail ? (
              <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading booking details…</Text></View>
            ) : (selectedBooking || bookingDetail) ? (
              <ScrollView>
                {(() => {
                  const full = (bookingDetail?.booking || selectedBooking || {}) as DataRecord;
                  const user = full.user as DataRecord | null;
                  const trip = full.trip as DataRecord | null;
                  const tripPayment = full.tripPayment as DataRecord | null;
                  const siblings = bookingDetail?.siblings || [];
                  const ledger = bookingDetail?.ledger || [];
                  return (
                    <View>
                      <Text style={styles.sectionLabel}>User information</Text>
                      <Detail label="Name" value={asText(user?.name) || "Account unavailable"} />
                      <Detail label="Email" value={asText(user?.email) || "Not available"} />
                      {asText(user?.phone) ? <Detail label="Phone" value={asText(user?.phone)} /> : null}
                      <Text style={styles.sectionLabel}>Booking information</Text>
                      <Detail label="Booking code" value={asText(full.bookingCode) || "Not available"} />
                      <Detail label="Type" value={asText(full.itemType)} />
                      <Detail label="Service" value={asText(full.itemName)} />
                      <Detail label="Destination" value={asText(full.location) || (trip ? asText((trip as DataRecord).destination) : "") || "Not provided"} />
                      <Detail label="Travel date" value={asText(full.checkIn) ? formatDate(full.checkIn) : asText(full.serviceTime) || "Not applicable"} />
                      <Detail label="Booking date" value={formatDate(full.createdAt)} />
                      <Detail label="Guests / rooms" value={`${asText(full.adults) || "0"} adults · ${asText(full.children) || "0"} children · ${asText(full.rooms) || "0"} rooms`} />
                      {trip ? <Detail label="Trip" value={`${asText((trip as DataRecord).name)} · ${asText((trip as DataRecord).destination)}`} /> : null}
                      <Text style={styles.sectionLabel}>Payment information</Text>
                      <Detail label="Amount" value={`${asText(full.currency) || "NPR"} ${asText(full.amount)}`.trim()} />
                      <Detail label="Payment method" value={asText(full.paymentMethod) || asText(tripPayment?.paymentMethod) || "Not chosen yet"} />
                      <Detail label="Payment status" value={asText(full.paymentStatus).toUpperCase()} />
                      <Detail label="Payment ID" value={asText(tripPayment?.paymentId) || "—"} />
                      <Detail label="Reference ID" value={asText(full.paymentReference) || asText(tripPayment?.referenceId) || "none yet"} />
                      <Detail label="Paid at" value={asText(full.paymentConfirmedAt) ? formatDate(full.paymentConfirmedAt) : "Not paid yet"} />
                      {ledger.length ? (
                        <View>
                          <Text style={styles.sectionLabel}>Payment ledger</Text>
                          {ledger.map((entry) => (
                            <Text key={entry._id} style={styles.rowSub}>
                              {asText(entry.currency)} {asText(entry.amount)} · {asText(entry.method)} · {asText(entry.status)} · Ref: {asText(entry.reference) || "—"}
                            </Text>
                          ))}
                        </View>
                      ) : null}
                      <Text style={styles.sectionLabel}>Status</Text>
                      <Detail label="Booking status" value={asText(full.status)} />
                      {siblings.length ? (
                        <View>
                          <Text style={styles.sectionLabel}>Linked services (same trip/payment)</Text>
                          {siblings.map((sibling) => (
                            <Text key={sibling._id} style={styles.rowSub}>
                              {asText(sibling.itemType)} · {asText(sibling.itemName)} · {asText(sibling.bookingCode)} · {asText(sibling.paymentStatus).toUpperCase()}
                            </Text>
                          ))}
                        </View>
                      ) : null}
                    </View>
                  );
                })()}
              </ScrollView>
            ) : null}
          </View>
        </View>
      </Modal>

      <Modal visible={!!selectedTrip} transparent animationType="fade" onRequestClose={() => { setSelectedTrip(null); setTripDetail(null); }}>
        <View style={styles.backdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeading}>
              <Text style={styles.cardTitle}>Complete trip details</Text>
              <Pressable onPress={() => { setSelectedTrip(null); setTripDetail(null); }} accessibilityLabel="Close trip details"><Ionicons name="close" size={22} color={API_NAVY} /></Pressable>
            </View>
            {tripDetailLoading && !tripDetail ? (
              <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading trip details…</Text></View>
            ) : (selectedTrip || tripDetail) ? (
              <ScrollView>
                {(() => {
                  const tp = (tripDetail?.tripPayment || selectedTrip || {}) as DataRecord;
                  const user = tp.user as DataRecord | null;
                  const trip = (tripDetail?.tripPayment as DataRecord | null)?.trip as DataRecord | null
                    ?? (tp.trip as DataRecord | null);
                  const bookings = tripDetail?.bookings || [];
                  return (
                    <View>
                      <Text style={styles.sectionLabel}>User</Text>
                      <Detail label="Name" value={asText(user?.name) || "Account unavailable"} />
                      <Detail label="Email" value={asText(user?.email) || "Not available"} />
                      <Text style={styles.sectionLabel}>Trip</Text>
                      <Detail label="Checkout ID" value={asText(tp.checkoutCode)} />
                      <Detail label="Destination" value={trip ? asText((trip as DataRecord).destination) || asText((trip as DataRecord).name) : "—"} />
                      <Detail label="Created" value={formatDate(tp.createdAt)} />
                      <Text style={styles.sectionLabel}>Selected services ({bookings.length})</Text>
                      {bookings.length ? bookings.map((b) => (
                        <Text key={b._id} style={styles.rowSub}>
                          {asText(b.itemType)} · {asText(b.itemName)} · {asText(b.currency)} {asText(b.amount)} · {asText(b.status)}
                        </Text>
                      )) : <Text style={styles.muted}>Services load with the trip payment record.</Text>}
                      <Text style={styles.sectionLabel}>Payment</Text>
                      <Detail label="Grand total" value={`${asText(tp.currency) || "NPR"} ${asText(tp.totalAmount)}`} />
                      <Detail label="Method" value={asText(tp.paymentMethod)} />
                      <Detail label="Payment ID" value={asText(tp.paymentId)} />
                      <Detail label="Payment status" value={asText(tp.paymentStatus).toUpperCase()} />
                      <Detail label="Reference" value={asText(tp.referenceId) || "none yet"} />
                    </View>
                  );
                })()}
              </ScrollView>
            ) : null}
          </View>
        </View>
      </Modal>

      <Modal visible={!!selectedApproval} transparent animationType="fade" onRequestClose={() => { setSelectedApproval(null); setApprovalDetail(null); setRejectReason(""); }}>
        <View style={styles.backdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeading}>
              <Text style={styles.cardTitle}>Pending trip decision</Text>
              <Pressable onPress={() => { setSelectedApproval(null); setApprovalDetail(null); setRejectReason(""); }} accessibilityLabel="Close approval details"><Ionicons name="close" size={22} color={API_NAVY} /></Pressable>
            </View>
            {approvalDetailLoading && !approvalDetail ? (
              <View style={styles.loading}><ActivityIndicator color={API_GREEN} /><Text style={styles.muted}>Loading trip details…</Text></View>
            ) : (selectedApproval || approvalDetail) ? (
              <ScrollView>
                {(() => {
                  const item = (approvalDetail?.kind === "booking" ? approvalDetail.booking : approvalDetail?.checkout) || selectedApproval || ({} as DataRecord);
                  const user = item.user as DataRecord | null;
                  const trip = item.trip as DataRecord | null;
                  const services = (approvalDetail?.bookings || []) as DataRecord[];
                  const tripPlan = trip?.itinerary as { day: number; date?: string; items?: { name: string; entityType?: string; estimatedCost?: number }[] }[] | undefined;
                  return (
                    <View>
                      <Text style={styles.sectionLabel}>Booking</Text>
                      <Detail label="Booking ID" value={asText(item.checkoutCode) || asText(item.bookingCode) || "—"} />
                      <Detail label="Payment ID" value={asText(item.paymentId) || "—"} />
                      <Text style={styles.sectionLabel}>Customer</Text>
                      <Detail label="Name" value={asText(user?.name) || "Account unavailable"} />
                      <Detail label="Email" value={asText(user?.email) || "Not available"} />
                      <Text style={styles.sectionLabel}>Trip</Text>
                      <Detail label="Origin" value={asText(trip?.origin) || "—"} />
                      <Detail label="Destination" value={asText(trip?.destination) || asText(trip?.name) || "—"} />
                      {(() => {
                        const t = (trip || {}) as DataRecord;
                        return (
                          <View>
                            <Detail label="Start date" value={asText(t.startDate) ? formatDate(t.startDate) : "—"} />
                            <Detail label="Return date" value={asText(t.endDate) ? formatDate(t.endDate) : "—"} />
                          </View>
                        );
                      })()}
                      {(() => {
                        const adults = trip ? asText((trip as DataRecord).adults) : "";
                        const children = trip ? asText((trip as DataRecord).children) : "";
                        return (
                          <Detail label="Travellers" value={adults && adults !== "0" ? `${adults} adult(s)${children && children !== "0" ? ` · ${children} child(ren)` : ""}` : "—"} />
                        );
                      })()}
                      <Text style={styles.sectionLabel}>Complete itinerary</Text>
                      {tripPlan && tripPlan.filter((d) => d.items && d.items.length > 0).length ? (
                        tripPlan.filter((d) => d.items && d.items.length > 0).map((d) => (
                          <View key={d.day}>
                            <Text style={styles.rowSub}>DAY {d.day}{d.date ? ` · ${asText(d.date)}` : ""}</Text>
                            {d.items!.map((stop, i) => (
                              <Text key={`${d.day}-${i}`} style={styles.rowSub}>
                                · {stop.name}{stop.entityType ? ` (${stop.entityType})` : ""}{Number.isFinite(stop.estimatedCost) ? ` · NPR ${Number(stop.estimatedCost)}` : ""}
                              </Text>
                            ))}
                          </View>
                        ))
                      ) : <Text style={styles.muted}>Day-by-day stops live in the saved trip plan.</Text>}
                      <Text style={styles.sectionLabel}>Selected services ({services.length})</Text>
                      {services.length ? services.map((b) => (
                        <Text key={b._id} style={styles.rowSub}>
                          {asText(b.itemType)} · {asText(b.itemName)} · {asText(b.currency)} {asText(b.amount)} · {asText(b.status)}
                        </Text>
                      )) : <Text style={styles.muted}>Services load with the trip record.</Text>}
                      <Text style={styles.sectionLabel}>Payment</Text>
                      <Detail label="Total amount" value={`${asText(item.currency) || "NPR"} ${asText(item.totalAmount)}`} />
                      <Detail label="Payment method" value={asText(item.paymentMethod)} />
                      <Detail label="Transaction ID" value={asText(item.referenceId) || "none yet"} />
                      <Detail label="Payment date" value={asText(item.completedAt) ? formatDate(item.completedAt) : "—"} />
                      <Detail label="Submitted for approval" value={asText(item.submittedForApprovalAt) ? formatDate(item.submittedForApprovalAt) : "—"} />
                      <Detail label="Approval deadline" value={asText(item.approvalDeadline) ? formatDate(item.approvalDeadline) : "—"} />
                      <Text style={styles.sectionLabel}>Decision</Text>
                      <Text style={styles.fieldLabel}>Rejection reason (required to reject)</Text>
                      <TextInput
                        value={rejectReason}
                        onChangeText={setRejectReason}
                        placeholder="Please provide a reason for rejecting this trip."
                        placeholderTextColor="#94A3B8"
                        style={[styles.formInput, styles.textArea]}
                        multiline
                      />
                      <View style={styles.inlineActions}>
                        <Pressable disabled={deciding} style={styles.smallPrimary} onPress={() => void decideApproval("accept")}>
                          {deciding ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.smallPrimaryText}>ACCEPT TRIP</Text>}
                        </Pressable>
                        <Pressable disabled={deciding} style={styles.dangerButton} onPress={() => void decideApproval("reject")}>
                          <Text style={styles.dangerText}>REJECT TRIP</Text>
                        </Pressable>
                      </View>
                      <Text style={styles.muted}>Rejecting never issues a refund automatically in demo mode.</Text>
                    </View>
                  );
                })()}
              </ScrollView>
            ) : null}
          </View>
        </View>
      </Modal>
      <Modal visible={editorOpen} transparent animationType="slide" onRequestClose={() => setEditorOpen(false)}>
        <View style={styles.backdrop}>
          <View style={styles.editorCard}>
            <View style={styles.modalHeading}>
              <Text style={styles.cardTitle}>{editing ? `Edit ${resources[resource]?.title}` : `Add ${resources[resource]?.title}`}</Text>
              <Pressable onPress={() => setEditorOpen(false)} accessibilityLabel="Close editor"><Ionicons name="close" size={22} color={API_NAVY} /></Pressable>
            </View>
            <ScrollView keyboardShouldPersistTaps="handled">
              {(resources[resource]?.fields || []).map((field) => (
                <View key={field.key} style={styles.formField}>
                  <Text style={styles.fieldLabel}>{field.label}</Text>
                  {field.kind === "boolean" ? (
                    <Pressable style={styles.secondaryButton} onPress={() => setForm((current) => ({
                      ...current, [field.key]: current[field.key] === "true" ? "false" : "true",
                    }))}>
                      <Ionicons name={form[field.key] === "true" ? "checkbox" : "square-outline"} size={18} color={API_GREEN} />
                      <Text style={styles.secondaryButtonText}>{form[field.key] === "true" ? "Enabled" : "Disabled"}</Text>
                    </Pressable>
                  ) : field.kind === "roomTypes" ? (
                    <RoomTypesEditor value={roomTypes} onChange={setRoomTypes} />
                  ) : field.kind === "date" || field.kind === "time" ? (
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`Choose ${field.label.toLowerCase()}`}
                      style={[styles.formInput, styles.pickerInput]}
                      onPress={() => setPickerField(field)}
                    >
                      <Text style={form[field.key] ? styles.pickerValue : styles.pickerPlaceholder}>
                        {form[field.key] ? displayPickerValue(form[field.key], field.kind) : `Select ${field.label.toLowerCase()}`}
                      </Text>
                      <Ionicons name={field.kind === "date" ? "calendar-outline" : "time-outline"} size={18} color={API_GREEN} />
                    </Pressable>
                  ) : (
                    <TextInput
                      value={form[field.key] || ""}
                      onChangeText={(value) => setForm((current) => ({ ...current, [field.key]: value }))}
                      placeholder={field.placeholder || field.label}
                      placeholderTextColor="#94A3B8"
                      style={[styles.formInput, field.kind === "textarea" || field.kind === "json" ? styles.textArea : null]}
                      keyboardType={field.kind === "number" ? "decimal-pad" : "default"}
                      multiline={field.kind === "textarea" || field.kind === "json"}
                      autoCapitalize={field.kind === "json" ? "none" : "sentences"}
                      returnKeyType={field.kind === "textarea" || field.kind === "json" ? "default" : "done"}
                      onSubmitEditing={
                        field.kind === "textarea" || field.kind === "json"
                          ? undefined
                          : () => {
                              if (!saving) void saveResource();
                            }
                      }
                    />
                  )}
                </View>
              ))}
              <Pressable disabled={saving} style={styles.primaryButton} onPress={() => void saveResource()}>
                {saving ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.primaryButtonText}>{editing ? "Save changes" : "Create record"}</Text>}
              </Pressable>
            </ScrollView>
          </View>
        </View>
      </Modal>
      <AdminDateTimePicker
        field={pickerField}
        value={pickerField ? form[pickerField.key] || "" : ""}
        onCancel={() => setPickerField(null)}
        onSelect={(value) => {
          if (pickerField) setForm((current) => ({ ...current, [pickerField.key]: value }));
          setPickerField(null);
        }}
      />
    </View>
  );
}

function RoomTypesEditor({
  value,
  onChange,
}: {
  value: RoomTypeDraft[];
  onChange: (roomTypes: RoomTypeDraft[]) => void;
}) {
  const updateRoomType = (key: string, field: keyof Omit<RoomTypeDraft, "key" | "_id">, text: string) => {
    onChange(value.map((roomType) => roomType.key === key ? { ...roomType, [field]: text } : roomType));
  };
  return (
    <View style={styles.roomTypesEditor}>
      {value.map((roomType, index) => (
        <View key={roomType.key} style={styles.roomTypeEditorCard}>
          <View style={styles.roomTypeEditorHeading}>
            <Text style={styles.roomTypeEditorTitle}>Room type {index + 1}</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Remove room type ${index + 1}`}
              onPress={() => onChange(value.filter((entry) => entry.key !== roomType.key))}
            >
              <Ionicons name="trash-outline" size={18} color="#B91C1C" />
            </Pressable>
          </View>
          <TextInput
            value={roomType.name}
            onChangeText={(text) => updateRoomType(roomType.key, "name", text)}
            placeholder="Room name (e.g. Deluxe Double)"
            placeholderTextColor="#94A3B8"
            style={styles.formInput}
          />
          <View style={styles.roomTypeInputRow}>
            <View style={styles.roomTypeInput}>
              <Text style={styles.roomTypeInputLabel}>Adults / room</Text>
              <TextInput value={roomType.capacityAdults} onChangeText={(text) => updateRoomType(roomType.key, "capacityAdults", text)} keyboardType="number-pad" placeholder="2" placeholderTextColor="#94A3B8" style={styles.formInput} />
            </View>
            <View style={styles.roomTypeInput}>
              <Text style={styles.roomTypeInputLabel}>Children / room</Text>
              <TextInput value={roomType.capacityChildren} onChangeText={(text) => updateRoomType(roomType.key, "capacityChildren", text)} keyboardType="number-pad" placeholder="1" placeholderTextColor="#94A3B8" style={styles.formInput} />
            </View>
          </View>
          <View style={styles.roomTypeInputRow}>
            <View style={styles.roomTypeInput}>
              <Text style={styles.roomTypeInputLabel}>Rooms in inventory</Text>
              <TextInput value={roomType.totalRooms} onChangeText={(text) => updateRoomType(roomType.key, "totalRooms", text)} keyboardType="number-pad" placeholder="0" placeholderTextColor="#94A3B8" style={styles.formInput} />
            </View>
            <View style={styles.roomTypeInput}>
              <Text style={styles.roomTypeInputLabel}>Nightly rate (optional)</Text>
              <TextInput value={roomType.nightlyRate} onChangeText={(text) => updateRoomType(roomType.key, "nightlyRate", text)} keyboardType="decimal-pad" placeholder="Uses hotel rate if blank" placeholderTextColor="#94A3B8" style={styles.formInput} />
            </View>
          </View>
        </View>
      ))}
      <Pressable
        accessibilityRole="button"
        style={styles.secondaryButton}
        onPress={() => onChange([...value, {
          key: `new-room-type-${Date.now()}-${value.length}`,
          name: "",
          capacityAdults: "2",
          capacityChildren: "0",
          totalRooms: "1",
          nightlyRate: "",
        }])}
      >
        <Ionicons name="add" size={17} color={API_GREEN} />
        <Text style={styles.secondaryButtonText}>Add room type</Text>
      </Pressable>
    </View>
  );
}

function AdminDateTimePicker({
  field,
  value,
  onCancel,
  onSelect,
}: {
  field: FieldDefinition | null;
  value: string;
  onCancel: () => void;
  onSelect: (value: string) => void;
}) {
  const kind = field?.kind === "time" ? "time" : "date";
  const [selectedDate, setSelectedDate] = useState(() => new Date());
  const [visibleMonth, setVisibleMonth] = useState(() => new Date());

  useEffect(() => {
    if (!field) return;
    const parsed = parsePickerDate(value, kind);
    setSelectedDate(parsed);
    setVisibleMonth(new Date(parsed.getFullYear(), parsed.getMonth(), 1));
  }, [field, kind, value]);

  const monthLabel = visibleMonth.toLocaleDateString([], { month: "long", year: "numeric" });
  const firstWeekday = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth(), 1).getDay();
  const daysInMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + 1, 0).getDate();
  const selectedTime = `${String(selectedDate.getHours()).padStart(2, "0")}:${String(selectedDate.getMinutes()).padStart(2, "0")}`;

  return (
    <Modal visible={!!field} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.backdrop}>
        <View style={styles.pickerCard}>
          <View style={styles.modalHeading}>
            <Text style={styles.cardTitle}>{field?.label || "Select date or time"}</Text>
            <Pressable onPress={onCancel} accessibilityLabel="Close date and time picker">
              <Ionicons name="close" size={22} color={API_NAVY} />
            </Pressable>
          </View>
          {kind === "time" ? (
            <>
              <Text style={styles.pickerSectionLabel}>Hour</Text>
              <View style={styles.pickerOptions}>
                {Array.from({ length: 24 }, (_, hour) => (
                  <Pressable
                    key={hour}
                    accessibilityRole="button"
                    accessibilityState={{ selected: selectedDate.getHours() === hour }}
                    style={[styles.pickerOption, selectedDate.getHours() === hour && styles.pickerOptionSelected]}
                    onPress={() => setSelectedDate((current) => {
                      const next = new Date(current);
                      next.setHours(hour);
                      return next;
                    })}
                  >
                    <Text style={[styles.pickerOptionText, selectedDate.getHours() === hour && styles.pickerOptionTextSelected]}>
                      {String(hour).padStart(2, "0")}
                    </Text>
                  </Pressable>
                ))}
              </View>
              <Text style={styles.pickerSectionLabel}>Minute</Text>
              <ScrollView style={styles.minutePickerScroll} contentContainerStyle={styles.pickerOptions}>
                {Array.from({ length: 60 }, (_, minute) => (
                  <Pressable
                    key={minute}
                    accessibilityRole="button"
                    accessibilityState={{ selected: selectedDate.getMinutes() === minute }}
                    style={[styles.pickerOption, selectedDate.getMinutes() === minute && styles.pickerOptionSelected]}
                    onPress={() => setSelectedDate((current) => {
                      const next = new Date(current);
                      next.setMinutes(minute);
                      return next;
                    })}
                  >
                    <Text style={[styles.pickerOptionText, selectedDate.getMinutes() === minute && styles.pickerOptionTextSelected]}>
                      {String(minute).padStart(2, "0")}
                    </Text>
                  </Pressable>
                ))}
              </ScrollView>
              <Text style={styles.pickerSelection}>Selected: {displayPickerValue(selectedTime, "time")}</Text>
            </>
          ) : (
            <>
              <View style={styles.calendarHeading}>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Previous month"
                  style={styles.calendarNavButton}
                  onPress={() => setVisibleMonth((current) => new Date(current.getFullYear(), current.getMonth() - 1, 1))}
                >
                  <Ionicons name="chevron-back" size={18} color={API_NAVY} />
                </Pressable>
                <Text style={styles.calendarMonth}>{monthLabel}</Text>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Next month"
                  style={styles.calendarNavButton}
                  onPress={() => setVisibleMonth((current) => new Date(current.getFullYear(), current.getMonth() + 1, 1))}
                >
                  <Ionicons name="chevron-forward" size={18} color={API_NAVY} />
                </Pressable>
              </View>
              <View style={styles.calendarGrid}>
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                  <Text key={day} style={styles.calendarWeekday}>{day}</Text>
                ))}
                {Array.from({ length: firstWeekday }, (_, index) => (
                  <View key={`empty-${index}`} style={styles.calendarDay} />
                ))}
                {Array.from({ length: daysInMonth }, (_, index) => {
                  const day = index + 1;
                  const isSelected = selectedDate.getFullYear() === visibleMonth.getFullYear()
                    && selectedDate.getMonth() === visibleMonth.getMonth()
                    && selectedDate.getDate() === day;
                  return (
                    <Pressable
                      key={day}
                      accessibilityRole="button"
                      accessibilityLabel={`${monthLabel} ${day}`}
                      accessibilityState={{ selected: isSelected }}
                      style={[styles.calendarDay, isSelected && styles.calendarDaySelected]}
                      onPress={() => setSelectedDate((current) => new Date(visibleMonth.getFullYear(), visibleMonth.getMonth(), day, current.getHours(), current.getMinutes()))}
                    >
                      <Text style={[styles.calendarDayText, isSelected && styles.calendarDayTextSelected]}>{day}</Text>
                    </Pressable>
                  );
                })}
              </View>
              <Text style={styles.pickerSelection}>
                Selected: {selectedDate.toLocaleDateString()}
              </Text>
            </>
          )}
          <View style={styles.pickerActions}>
            <Pressable style={styles.secondaryButton} onPress={() => onSelect("")}>
              <Text style={styles.secondaryButtonText}>Clear</Text>
            </Pressable>
            <Pressable style={styles.primaryButton} onPress={() => onSelect(formatPickerValue(selectedDate, kind))}>
              <Text style={styles.primaryButtonText}>Choose</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function FilterChip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && styles.activeChip]}>
      <Text style={[styles.chipText, active && styles.activeChipText]}>{label}</Text>
    </Pressable>
  );
}

function Pagination({ page, pageCount, onPage }: { page: number; pageCount: number; onPage: (page: number) => void }) {
  if (pageCount <= 1) return null;
  return (
    <View style={styles.pagination}>
      <Pressable disabled={page <= 1} style={styles.secondaryButton} onPress={() => onPage(page - 1)}><Text style={styles.secondaryButtonText}>Previous</Text></Pressable>
      <Text style={styles.muted}>Page {page} of {pageCount}</Text>
      <Pressable disabled={page >= pageCount} style={styles.secondaryButton} onPress={() => onPage(page + 1)}><Text style={styles.secondaryButtonText}>Next</Text></Pressable>
    </View>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return <View style={styles.detail}><Text style={styles.detailLabel}>{label}</Text><Text style={styles.detailValue}>{value}</Text></View>;
}

function EmptyState({ text }: { text: string }) {
  return <View style={styles.empty}><Ionicons name="file-tray-outline" size={32} color="#94A3B8" /><Text style={styles.muted}>{text}</Text></View>;
}

function AnalyticsView({ data, detailed }: { data: Overview; detailed: boolean }) {
  const { width: windowWidth } = useWindowDimensions();
  const compactLayout = (Platform.OS === "web" ? Math.min(windowWidth, 430) : windowWidth) < 600;
  const metricTiles = [
    ["users", "Total users", "people-outline"],
    ["bookings", "Bookings", "calendar-outline"],
    ["destinations", "Destinations", "location-outline"],
    ["hotels", "Hotels", "bed-outline"],
    ["restaurants", "Restaurants", "restaurant-outline"],
    ["activities", "Activities", "trail-sign-outline"],
    ["transport", "Transport options", "bus-outline"],
  ] as const;
  const popularCategories = [
    ["Destinations", data.popular.destinations || []],
    ["Hotels", data.popular.hotels || []],
    ["Restaurants", data.popular.restaurants || []],
    ["Activities in trip plans", data.popular.activities || []],
    ["Transport bookings", data.popular.transport || []],
  ] as const;
  const maxTrend = Math.max(1, ...data.trends.registrations.map((row) => row.count), ...data.trends.bookings.map((row) => row.count));
  return (
    <ScrollView contentContainerStyle={styles.analyticsContent}>
      <View style={styles.metricGrid}>
        {metricTiles.map(([key, label, icon]) => (
          <View key={key} style={styles.metricCard}>
            <Ionicons name={icon} size={21} color={API_GREEN} />
            <Text style={styles.metricValue}>{data.totals[key] ?? 0}</Text>
            <Text style={styles.metricLabel}>{label}</Text>
          </View>
        ))}
      </View>
      <View style={styles.metricGrid}>
        <View style={styles.smallMetric}><Text style={styles.metricValue}>{data.last30Days.registrations}</Text><Text style={styles.metricLabel}>New registrations · last 30 days</Text></View>
        <View style={styles.smallMetric}><Text style={styles.metricValue}>{data.last30Days.bookings}</Text><Text style={styles.metricLabel}>Bookings · last 30 days</Text></View>
      </View>
      {detailed ? (
        <>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>7-day registrations and bookings</Text>
            {data.trends.registrations.map((entry, index) => {
              const booking = data.trends.bookings[index];
              return (
                compactLayout ? (
                  <View key={entry.date} style={styles.compactTrendDay}>
                    <Text style={styles.trendDate}>{entry.date}</Text>
                    <View style={styles.compactTrendRow}>
                      <Text style={styles.trendLabel}>Users</Text>
                      <View style={styles.trendTrack}>
                        <View style={[styles.trendBar, { width: `${Math.max(entry.count ? 5 : 0, entry.count / maxTrend * 100)}%` }]} />
                      </View>
                      <Text style={styles.trendValue}>{entry.count}</Text>
                    </View>
                    <View style={styles.compactTrendRow}>
                      <Text style={styles.trendLabel}>Bookings</Text>
                      <View style={styles.trendTrack}>
                        <View style={[styles.trendBar, styles.bookingBar, { width: `${Math.max(booking.count ? 5 : 0, booking.count / maxTrend * 100)}%` }]} />
                      </View>
                      <Text style={styles.trendValue}>{booking.count}</Text>
                    </View>
                  </View>
                ) : (
                  <View key={entry.date} style={styles.trendRow}>
                    <Text style={styles.trendDate}>{entry.date.slice(5)}</Text>
                    <Text style={styles.trendLabel}>Users</Text>
                    <View style={styles.trendTrack}><View style={[styles.trendBar, { width: `${Math.max(entry.count ? 5 : 0, entry.count / maxTrend * 100)}%` }]} /></View>
                    <Text style={styles.trendValue}>{entry.count}</Text>
                    <Text style={styles.trendLabel}>Bookings</Text>
                    <View style={styles.trendTrack}><View style={[styles.trendBar, styles.bookingBar, { width: `${Math.max(booking.count ? 5 : 0, booking.count / maxTrend * 100)}%` }]} /></View>
                    <Text style={styles.trendValue}>{booking.count}</Text>
                  </View>
                )
              );
            })}
          </View>
          {popularCategories.map(([label, items]) => (
            <View key={label} style={styles.card}>
              <Text style={styles.cardTitle}>Popular {label.toLowerCase()} · based on stored plans/bookings</Text>
              {items.length ? items.map((item) => (
                <View key={item.name} style={styles.popularRow}>
                  <Text style={styles.rowTitle}>{item.name}</Text><Text style={styles.rowSub}>{item.count} recorded</Text>
                </View>
              )) : <Text style={styles.muted}>No usage data is available yet.</Text>}
            </View>
          ))}
        </>
      ) : (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Recent activity</Text>
          <Text style={styles.muted}>New registrations and bookings are counted from MongoDB records created in the last 30 days.</Text>
        </View>
      )}
    </ScrollView>
  );
}

function ChatbotPanel({
  data, knowledgeText, setKnowledgeText, knowledgeSource, setKnowledgeSource,
  knowledgeUrl, setKnowledgeUrl, onIngestText, onIngestUrl, saving, refresh,
}: {
  data: Record<string, unknown>;
  knowledgeText: string;
  setKnowledgeText: (value: string) => void;
  knowledgeSource: string;
  setKnowledgeSource: (value: string) => void;
  knowledgeUrl: string;
  setKnowledgeUrl: (value: string) => void;
  onIngestText: () => void;
  onIngestUrl: () => void;
  saving: boolean;
  refresh: () => void;
}) {
  const configured = data.configured === true;
  return (
    <ScrollView contentContainerStyle={styles.analyticsContent}>
      <View style={styles.card}>
        <View style={styles.modalHeading}>
          <Text style={styles.cardTitle}>Knowledge service status</Text>
          <Pressable style={styles.secondaryButton} onPress={refresh}><Ionicons name="refresh" size={17} color={API_NAVY} /><Text style={styles.secondaryButtonText}>Refresh</Text></Pressable>
        </View>
        <Detail label="Status" value={asText(data.status) || "Unknown"} />
        {data.chunks !== undefined ? <Detail label="Indexed chunks" value={asText(data.chunks)} /> : null}
        {data.message ? <Text style={styles.muted}>{asText(data.message)}</Text> : null}
      </View>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Add tourism information</Text>
        <Text style={styles.muted}>Text is sent to the existing RAG ingestion API. The system does not currently provide source editing or deletion.</Text>
        <TextInput value={knowledgeSource} onChangeText={setKnowledgeSource} placeholder="Source label" placeholderTextColor="#94A3B8" style={styles.formInput} returnKeyType="done" onSubmitEditing={onIngestText} />
        <TextInput value={knowledgeText} onChangeText={setKnowledgeText} placeholder="Paste verified travel information…" placeholderTextColor="#94A3B8" style={[styles.formInput, styles.textArea]} multiline />
        <Pressable disabled={saving || !configured} style={[styles.primaryButton, !configured && styles.disabledButton]} onPress={onIngestText}>
          <Text style={styles.primaryButtonText}>Add text to knowledge base</Text>
        </Pressable>
        <TextInput value={knowledgeUrl} onChangeText={setKnowledgeUrl} placeholder="https://source.example/travel-information" placeholderTextColor="#94A3B8" style={styles.formInput} autoCapitalize="none" keyboardType="url" returnKeyType="go" onSubmitEditing={onIngestUrl} />
        <Pressable disabled={saving || !configured} style={[styles.secondaryButton, !configured && styles.disabledButton]} onPress={onIngestUrl}>
          <Text style={styles.secondaryButtonText}>Ingest source URL</Text>
        </Pressable>
        {!configured ? <Text style={styles.muted}>Configure CHATBOT_API_URL and CHATBOT_ADMIN_API_KEY in the backend environment to enable ingestion. No key is sent to this browser.</Text> : null}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  panel: { flex: 1, minWidth: 0, backgroundColor: API_BG, paddingHorizontal: 24, paddingTop: 22, paddingBottom: 18 },
  panelCompact: { paddingHorizontal: 12, paddingTop: 14, paddingBottom: 12 },
  panelHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12, marginBottom: 18 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.25, color: API_GREEN },
  pageTitle: { fontSize: 25, fontWeight: "800", color: API_NAVY, marginTop: 4 },
  toolbar: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 8, marginBottom: 12 },
  searchInput: { flexGrow: 1, flexBasis: 200, minHeight: 42, borderColor: API_BORDER, borderWidth: 1, borderRadius: 10, backgroundColor: API_SURFACE, paddingHorizontal: 12, color: API_NAVY },
  primaryButton: { minHeight: 40, alignSelf: "flex-start", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 13, backgroundColor: API_GREEN, borderRadius: 10 },
  primaryButtonText: { color: "#FFFFFF", fontWeight: "700", fontSize: 12 },
  secondaryButton: { minHeight: 36, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingHorizontal: 10, borderWidth: 1, borderColor: API_BORDER, backgroundColor: API_SURFACE, borderRadius: 9 },
  secondaryButtonText: { color: API_NAVY, fontSize: 11, fontWeight: "700" },
  smallPrimary: { minHeight: 32, alignItems: "center", justifyContent: "center", paddingHorizontal: 10, borderRadius: 8, backgroundColor: API_GREEN },
  smallPrimaryText: { color: "#FFFFFF", fontSize: 11, fontWeight: "700" },
  dangerButton: { minHeight: 32, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, paddingHorizontal: 9, borderWidth: 1, borderColor: "#FECACA", borderRadius: 8, backgroundColor: "#FFF7F7" },
  buttonDisabled: { opacity: 0.6 },
  dangerText: { color: "#B91C1C", fontSize: 11, fontWeight: "700" },
  disabledButton: { opacity: 0.5 },
  list: { paddingBottom: 24, gap: 10 },
  countText: { color: API_MUTED, fontSize: 12, marginBottom: 2 },
  rowCard: { flexDirection: "row", alignItems: "flex-start", gap: 12, borderRadius: 12, borderColor: API_BORDER, borderWidth: 1, backgroundColor: API_SURFACE, padding: 14 },
  rowText: { flex: 1, gap: 4 },
  rowTitle: { color: API_NAVY, fontSize: 14, fontWeight: "800" },
  rowSub: { color: API_MUTED, fontSize: 11, lineHeight: 16 },
  reviewBody: { color: "#334155", fontSize: 12, lineHeight: 18, marginTop: 3 },
  inlineActions: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 7, marginTop: 8 },
  avatar: { width: 38, height: 38, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: "#ECFDF5" },
  chipRow: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 6, marginBottom: 12 },
  chipColumn: { gap: 6, marginBottom: 12 },
  chipRowTight: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 6 },
  chipGroupLabel: { color: API_NAVY, fontSize: 11, fontWeight: "800", marginRight: 2 },
  sectionLabel: { color: API_GREEN, fontSize: 11, fontWeight: "800", letterSpacing: 0.5, marginTop: 12, marginBottom: 2 },
  paidValue: { color: "#047857", fontWeight: "800" },
  unpaidValue: { color: "#B91C1C", fontWeight: "800" },
  mutedInline: { color: API_MUTED, fontWeight: "700" },
  chip: { borderWidth: 1, borderColor: API_BORDER, borderRadius: 99, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: API_SURFACE },
  activeChip: { backgroundColor: "#D1FAE5", borderColor: "#A7F3D0" },
  chipText: { color: API_MUTED, fontSize: 11, fontWeight: "700" },
  activeChipText: { color: API_GREEN },
  analyticsContent: { paddingBottom: 32, gap: 14 },
  metricGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  metricCard: { flexGrow: 1, flexBasis: 140, minHeight: 112, justifyContent: "center", gap: 5, borderRadius: 12, borderColor: API_BORDER, borderWidth: 1, backgroundColor: API_SURFACE, padding: 14 },
  smallMetric: { flexGrow: 1, flexBasis: 200, gap: 4, borderRadius: 12, borderColor: API_BORDER, borderWidth: 1, backgroundColor: API_SURFACE, padding: 16 },
  metricValue: { color: API_NAVY, fontSize: 24, fontWeight: "800" },
  metricLabel: { color: API_MUTED, fontSize: 11 },
  card: { borderRadius: 12, borderColor: API_BORDER, borderWidth: 1, backgroundColor: API_SURFACE, padding: 16, gap: 12 },
  cardTitle: { color: API_NAVY, fontSize: 15, fontWeight: "800" },
  trendRow: { flexDirection: "row", alignItems: "center", gap: 7, minHeight: 25 },
  compactTrendDay: { gap: 5, paddingVertical: 5, borderBottomColor: API_BORDER, borderBottomWidth: StyleSheet.hairlineWidth },
  compactTrendRow: { flexDirection: "row", alignItems: "center", gap: 8, minHeight: 24 },
  trendDate: { width: 42, color: API_MUTED, fontSize: 10 },
  trendLabel: { width: 46, color: API_MUTED, fontSize: 10 },
  trendTrack: { flex: 1, height: 7, borderRadius: 5, overflow: "hidden", backgroundColor: "#E2E8F0" },
  trendBar: { height: 7, borderRadius: 5, backgroundColor: API_GREEN },
  bookingBar: { backgroundColor: "#0EA5E9" },
  trendValue: { width: 20, color: API_NAVY, fontSize: 10, textAlign: "right" },
  popularRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderBottomColor: API_BORDER, borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 7 },
  detail: { flexDirection: "row", justifyContent: "space-between", gap: 12, borderBottomColor: API_BORDER, borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 9 },
  detailLabel: { flex: 1, color: API_MUTED, fontSize: 12 },
  detailValue: { flex: 1.3, color: API_NAVY, fontSize: 12, fontWeight: "700", textAlign: "right" },
  privacyNote: { color: API_MUTED, fontSize: 11, lineHeight: 16, marginVertical: 14 },
  muted: { color: API_MUTED, fontSize: 12, lineHeight: 18 },
  notice: { color: "#047857", fontWeight: "700", fontSize: 12, marginBottom: 10 },
  errorBox: { borderRadius: 9, borderColor: "#FECACA", borderWidth: 1, backgroundColor: "#FFF7F7", padding: 12, marginBottom: 10 },
  errorText: { color: "#B91C1C", fontSize: 12 },
  retry: { color: API_GREEN, fontWeight: "800", marginTop: 6, fontSize: 12 },
  loading: { alignItems: "center", justifyContent: "center", gap: 8, padding: 30 },
  empty: { minHeight: 150, alignItems: "center", justifyContent: "center", gap: 8, padding: 24 },
  pagination: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 12 },
  backdrop: { flex: 1, justifyContent: "center", alignItems: "center", padding: 18, backgroundColor: "rgba(15,23,42,0.45)" },
  modalCard: { width: "100%", maxWidth: 520, maxHeight: "82%", borderRadius: 16, backgroundColor: API_SURFACE, padding: 20 },
  editorCard: { width: "100%", maxWidth: 680, maxHeight: "92%", borderRadius: 16, backgroundColor: API_SURFACE, padding: 20 },
  modalHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  formField: { marginBottom: 12, gap: 5 },
  fieldLabel: { color: API_NAVY, fontSize: 11, fontWeight: "800" },
  formInput: { minHeight: 40, borderWidth: 1, borderColor: API_BORDER, borderRadius: 9, paddingHorizontal: 11, paddingVertical: 9, color: API_NAVY, backgroundColor: API_SURFACE, fontSize: 12 },
  pickerInput: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  pickerValue: { color: API_NAVY, fontSize: 12 },
  pickerPlaceholder: { color: "#94A3B8", fontSize: 12 },
  pickerCard: { width: "100%", maxWidth: 420, maxHeight: "90%", borderRadius: 16, backgroundColor: API_SURFACE, padding: 20 },
  pickerSectionLabel: { color: API_NAVY, fontSize: 11, fontWeight: "800", marginBottom: 6 },
  pickerOptions: { flexDirection: "row", flexWrap: "wrap", gap: 5 },
  pickerOption: { width: "9%", minHeight: 34, alignItems: "center", justifyContent: "center", borderRadius: 8, backgroundColor: "#F1F5F9" },
  pickerOptionSelected: { backgroundColor: "#D1FAE5" },
  pickerOptionText: { color: API_NAVY, fontSize: 12 },
  pickerOptionTextSelected: { color: API_GREEN, fontWeight: "800" },
  minutePickerScroll: { maxHeight: 132, marginBottom: 8 },
  pickerSelection: { color: API_MUTED, fontSize: 12, fontWeight: "700", marginTop: 12 },
  pickerActions: { flexDirection: "row", justifyContent: "flex-end", alignItems: "center", gap: 8, marginTop: 16 },
  roomTypesEditor: { gap: 10 },
  roomTypeEditorCard: { gap: 8, borderWidth: 1, borderColor: API_BORDER, borderRadius: 10, padding: 10, backgroundColor: "#F8FAFC" },
  roomTypeEditorHeading: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  roomTypeEditorTitle: { color: API_NAVY, fontSize: 12, fontWeight: "800" },
  roomTypeInputRow: { flexDirection: "row", gap: 8 },
  roomTypeInput: { flex: 1, gap: 4 },
  roomTypeInputLabel: { color: API_MUTED, fontSize: 10, fontWeight: "700" },
  calendarHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  calendarNavButton: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: 9, backgroundColor: "#F1F5F9" },
  calendarMonth: { color: API_NAVY, fontSize: 14, fontWeight: "800" },
  calendarGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", gap: 2 },
  calendarWeekday: { width: "12.5%", paddingVertical: 7, color: API_MUTED, fontSize: 10, fontWeight: "700", textAlign: "center" },
  calendarDay: { width: "12.5%", height: 38, alignItems: "center", justifyContent: "center", borderRadius: 8 },
  calendarDaySelected: { backgroundColor: API_GREEN },
  calendarDayText: { color: API_NAVY, fontSize: 12 },
  calendarDayTextSelected: { color: "#FFFFFF", fontWeight: "800" },
  textArea: { minHeight: 95, textAlignVertical: "top" },
});
