import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import { useAdminAuth } from "../auth/AdminAuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "AdminDashboard">;
type RegisteredUser = {
  _id: string;
  name: string;
  email: string;
  createdAt: string;
  location: string;
  bio: string;
  provider: string;
  memberSince: string | null;
  status?: string;
};
type UserListResponse = {
  total: number;
  matching: number;
  page: number;
  pageCount: number;
  users: RegisteredUser[];
};

function formatDateTime(value: string | null | undefined): string {
  if (!value) return "Registration date unavailable";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Registration date unavailable";
  return `${date.toLocaleDateString()} · ${date.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  })}`;
}

export default function AdminDashboardScreen({ navigation }: Props) {
  const { admin, ready, getAccessToken, logout } = useAdminAuth();
  const [data, setData] = useState<UserListResponse>({
    total: 0,
    matching: 0,
    page: 1,
    pageCount: 1,
    users: [],
  });
  const [query, setQuery] = useState("");
  const [appliedQuery, setAppliedQuery] = useState("");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [page, setPage] = useState(1);
  const [reloadKey, setReloadKey] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedUser, setSelectedUser] = useState<RegisteredUser | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState("");
  const [signingOut, setSigningOut] = useState(false);

  useEffect(() => {
    if (ready && !admin && !signingOut) {
      navigation.reset({ index: 0, routes: [{ name: "AdminLogin" }] });
    }
  }, [admin, navigation, ready, signingOut]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token) {
        setLoading(false);
        return;
      }
      const controller = new AbortController();
      const params = new URLSearchParams({
        search: appliedQuery,
        sort,
        page: String(page),
      });
      setLoading(true);
      setError("");
      backendRequest<UserListResponse>(`/admin/users?${params.toString()}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(setData)
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setError(requestError instanceof Error ? requestError.message : "Could not load registered users.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
      return () => controller.abort();
    }, [appliedQuery, getAccessToken, page, reloadKey, sort])
  );

  const viewUser = async (user: RegisteredUser) => {
    const token = getAccessToken();
    if (!token) return;
    setSelectedUser(user);
    setDetailLoading(true);
    setDetailError("");
    try {
      const details = await backendRequest<RegisteredUser>(
        `/admin/users/${encodeURIComponent(user._id)}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setSelectedUser(details);
    } catch (requestError) {
      setDetailError(requestError instanceof Error ? requestError.message : "Could not load user details.");
    } finally {
      setDetailLoading(false);
    }
  };

  const signOut = async () => {
    setSigningOut(true);
    await logout();
    navigation.reset({ index: 0, routes: [{ name: "Login" }] });
  };

  if (!ready || !admin) {
    return <SafeAreaView style={styles.center}><ActivityIndicator color={colors.primary} /></SafeAreaView>;
  }

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <View style={styles.header}>
        <View style={styles.headerCopy}>
          <Text style={styles.eyebrow}>SUVYATRA ADMIN</Text>
          <Text style={styles.title}>Dashboard</Text>
          <Text style={styles.adminEmail}>{admin.email}</Text>
        </View>
        <Pressable style={styles.logoutButton} onPress={() => void signOut()} accessibilityRole="button">
          <Ionicons name="log-out-outline" size={18} color="#B91C1C" />
          <Text style={styles.logoutText}>Log out</Text>
        </Pressable>
      </View>

      <View style={styles.summary}>
        <View style={styles.summaryIcon}><Ionicons name="people-outline" size={22} color={colors.primaryDark} /></View>
        <View>
          <Text style={styles.total}>{data.total}</Text>
          <Text style={styles.summaryLabel}>Total registered users</Text>
        </View>
        <Pressable
          style={styles.refresh}
          onPress={() => setReloadKey((current) => current + 1)}
          accessibilityRole="button"
          accessibilityLabel="Refresh registered users"
        >
          <Ionicons name="refresh-outline" size={20} color={colors.primaryDark} />
        </Pressable>
      </View>

      <View style={styles.searchRow}>
        <View style={styles.searchInputWrap}>
          <Ionicons name="search-outline" size={19} color={colors.textMuted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            onSubmitEditing={() => { setPage(1); setAppliedQuery(query.trim()); }}
            placeholder="Search name or email"
            placeholderTextColor={colors.textMuted}
            style={styles.searchInput}
            returnKeyType="search"
            accessibilityLabel="Search users by name or email"
          />
        </View>
        <Pressable
          style={styles.sortButton}
          onPress={() => { setPage(1); setSort((current) => current === "newest" ? "oldest" : "newest"); }}
          accessibilityRole="button"
          accessibilityLabel={`Sort by ${sort === "newest" ? "oldest" : "newest"} registration`}
        >
          <Ionicons name="swap-vertical" size={17} color={colors.primaryDark} />
          <Text style={styles.sortText}>{sort === "newest" ? "Newest" : "Oldest"}</Text>
        </Pressable>
      </View>
      <Pressable style={styles.searchAction} onPress={() => { setPage(1); setAppliedQuery(query.trim()); }}>
        <Text style={styles.searchActionText}>Search users</Text>
      </Pressable>

      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>
      ) : error ? (
        <View style={styles.center}>
          <Text style={styles.error}>{error}</Text>
          <Pressable onPress={() => setReloadKey((current) => current + 1)}><Text style={styles.retry}>Try again</Text></Pressable>
        </View>
      ) : (
        <FlatList
          data={data.users}
          keyExtractor={(item) => item._id}
          contentContainerStyle={data.users.length ? styles.list : styles.emptyList}
          ListHeaderComponent={<Text style={styles.resultCount}>{data.matching} matching user{data.matching === 1 ? "" : "s"}</Text>}
          ListEmptyComponent={<Text style={styles.emptyText}>{appliedQuery ? "No users match your search." : "No registered users yet."}</Text>}
          renderItem={({ item }) => (
            <Pressable style={styles.userCard} onPress={() => void viewUser(item)} accessibilityRole="button" accessibilityLabel={`View ${item.name}`}>
              <View style={styles.userIcon}><Ionicons name="person-outline" size={19} color={colors.primaryDark} /></View>
              <View style={styles.userCopy}>
                <Text style={styles.userName}>{item.name}</Text>
                <Text style={styles.userEmail}>{item.email || "No email on account"}</Text>
                <Text style={styles.userDate}>{formatDateTime(item.createdAt)}</Text>
                <Text style={styles.userLocation}>{item.location || "Location not available"}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
            </Pressable>
          )}
          ListFooterComponent={data.pageCount > 1 ? (
            <View style={styles.pagination}>
              <Pressable disabled={page <= 1} onPress={() => setPage((current) => Math.max(1, current - 1))}>
                <Text style={[styles.pageButton, page <= 1 && styles.disabled]}>Previous</Text>
              </Pressable>
              <Text style={styles.pageLabel}>Page {page} of {data.pageCount}</Text>
              <Pressable disabled={page >= data.pageCount} onPress={() => setPage((current) => Math.min(data.pageCount, current + 1))}>
                <Text style={[styles.pageButton, page >= data.pageCount && styles.disabled]}>Next</Text>
              </Pressable>
            </View>
          ) : null}
        />
      )}

      <Modal visible={!!selectedUser} transparent animationType="slide" onRequestClose={() => setSelectedUser(null)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>User details</Text>
              <Pressable onPress={() => setSelectedUser(null)} accessibilityRole="button" accessibilityLabel="Close user details">
                <Ionicons name="close" size={23} color={colors.text} />
              </Pressable>
            </View>
            {detailLoading ? <ActivityIndicator color={colors.primary} /> : detailError ? <Text style={styles.error}>{detailError}</Text> : selectedUser ? (
              <View style={styles.details}>
                <Detail label="Name" value={selectedUser.name} />
                <Detail label="Email" value={selectedUser.email || "No email on account"} />
                <Detail label="Registered" value={formatDateTime(selectedUser.createdAt)} />
                <Detail label="Location" value={selectedUser.location || "Location not available"} />
                <Detail label="Sign-in provider" value={selectedUser.provider || "Not available"} />
                <Detail label="Account status" value={selectedUser.status || "Not available"} />
                <Detail label="Member since" value={formatDateTime(selectedUser.memberSince)} />
                <Detail label="Bio" value={selectedUser.bio || "Not provided"} />
                <Text style={styles.privacyNote}>Passwords, password hashes, and authentication tokens are never included.</Text>
              </View>
            ) : null}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return <View style={styles.detail}><Text style={styles.detailLabel}>{label}</Text><Text style={styles.detailValue}>{value}</Text></View>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: spacing.sm },
  headerCopy: { flex: 1 },
  eyebrow: { color: colors.primaryDark, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  title: { color: colors.text, fontSize: 25, fontWeight: "800", marginTop: 3 },
  adminEmail: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  logoutButton: { flexDirection: "row", alignItems: "center", gap: 4, borderWidth: 1, borderColor: "#FECACA", borderRadius: radius.md, paddingHorizontal: spacing.sm, paddingVertical: spacing.sm },
  logoutText: { color: "#B91C1C", fontSize: 12, fontWeight: "700" },
  summary: { flexDirection: "row", alignItems: "center", gap: spacing.md, marginHorizontal: spacing.lg, marginVertical: spacing.md, padding: spacing.md, backgroundColor: colors.white, borderRadius: radius.lg },
  summaryIcon: { width: 42, height: 42, borderRadius: radius.full, backgroundColor: "#E6FFFA", alignItems: "center", justifyContent: "center" },
  total: { color: colors.text, fontSize: 23, fontWeight: "800" },
  summaryLabel: { color: colors.textMuted, fontSize: 12 },
  refresh: { marginLeft: "auto", padding: spacing.sm },
  searchRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginHorizontal: spacing.lg },
  searchInputWrap: { flex: 1, flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.md, backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border },
  searchInput: { flex: 1, minHeight: 44, color: colors.text, fontSize: 13 },
  sortButton: { minHeight: 44, flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: spacing.sm, backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border },
  sortText: { color: colors.primaryDark, fontSize: 11, fontWeight: "700" },
  searchAction: { alignSelf: "flex-end", paddingHorizontal: spacing.lg, paddingVertical: spacing.xs },
  searchActionText: { color: colors.primaryDark, fontSize: 12, fontWeight: "700" },
  list: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xl },
  resultCount: { color: colors.textMuted, fontSize: 12, marginBottom: spacing.sm },
  userCard: { flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md, marginBottom: spacing.sm, backgroundColor: colors.white, borderRadius: radius.lg },
  userIcon: { width: 38, height: 38, borderRadius: radius.full, alignItems: "center", justifyContent: "center", backgroundColor: "#E6FFFA" },
  userCopy: { flex: 1 },
  userName: { color: colors.text, fontSize: 14, fontWeight: "800" },
  userEmail: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  userDate: { color: colors.textMuted, fontSize: 11, marginTop: 6 },
  userLocation: { color: colors.textMuted, fontSize: 11, marginTop: 3 },
  emptyList: { flexGrow: 1, justifyContent: "center", alignItems: "center", padding: spacing.xl },
  emptyText: { color: colors.textMuted, textAlign: "center" },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl },
  error: { color: "#B91C1C", textAlign: "center", lineHeight: 20 },
  retry: { color: colors.primaryDark, fontWeight: "700", marginTop: spacing.md },
  pagination: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: spacing.lg },
  pageButton: { color: colors.primaryDark, fontSize: 12, fontWeight: "700" },
  pageLabel: { color: colors.textMuted, fontSize: 12 },
  disabled: { opacity: 0.4 },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(15,23,42,0.45)" },
  modalCard: { maxHeight: "85%", backgroundColor: colors.white, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: spacing.lg },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.md },
  modalTitle: { color: colors.text, fontSize: 19, fontWeight: "800" },
  details: { gap: spacing.md, paddingBottom: spacing.lg },
  detail: { borderBottomWidth: 1, borderBottomColor: colors.border, paddingBottom: spacing.sm },
  detailLabel: { color: colors.textMuted, fontSize: 11, fontWeight: "700" },
  detailValue: { color: colors.text, fontSize: 13, marginTop: 3 },
  privacyNote: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: spacing.sm },
});
