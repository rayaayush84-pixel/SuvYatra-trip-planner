import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { DestinationDetails, HiddenGemDetails, RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import { DEFAULT_HIDDEN_GEMS } from "../data/hiddenGems";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "Destination">;
type SavedItem = { _id: string; itemType: string; itemId?: string; name: string };

const BOOKING_ACTIONS = [
  { id: "hotel", label: "Book Hotel", icon: "bed-outline" },
  { id: "jeep", label: "Book Jeep", icon: "car-outline" },
  { id: "bike", label: "Book Bike", icon: "bicycle-outline" },
  { id: "bus", label: "Book Bus", icon: "bus-outline" },
  { id: "activity", label: "Book Activity", icon: "walk-outline" },
];

const QUICK_ACTIONS = [
  { id: "map", label: "Map", icon: "map-outline" },
  { id: "hidden", label: "Hidden Gems", icon: "sparkles-outline" },
  { id: "weather", label: "Weather", icon: "partly-sunny-outline" },
  { id: "reviews", label: "Reviews", icon: "chatbubble-ellipses-outline" },
];

export default function DestinationScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const [savedItem, setSavedItem] = useState<SavedItem | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedError, setSavedError] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };
  const destination: DestinationDetails = route.params?.destination ?? {
    name: "Phewa Lake",
    location: "Pokhara Nepal",
    rating: "4.8",
    reviews: "1.2k",
    description:
      "A beautiful lake in Pokhara, known for boating, stunning views and tranquility.",
    bestTime: "Sep-Nov , Feb-Apr",
    price: "Rs 1,200",
    image: "",
    hiddenGems: DEFAULT_HIDDEN_GEMS,
    categories: ["Book Hotel", "Book Jeep", "Book Bike", "Book Bus", "Book Activities"],
  };

  const hiddenGems: HiddenGemDetails[] = (destination.hiddenGems ?? DEFAULT_HIDDEN_GEMS).map((item) => {
    if (typeof item === "string") {
      return {
        name: item,
        location: destination.location,
      };
    }
    return {
      ...item,
    };
  });

  const openGemDetails = (item: HiddenGemDetails) =>
    navigation.push("HiddenGemDetail", { gem: item });

  const matchesSaved = (entry: SavedItem) => {
    if (entry.itemType !== "destination") return false;
    if (destination.id && entry.itemId) return entry.itemId === destination.id;
    return entry.name === destination.name;
  };

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId) {
        setSavedItem(null);
        return;
      }
      const controller = new AbortController();
      backendRequest<SavedItem[]>(`/saved-items?userId=${encodeURIComponent(userId)}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((items) => {
          if (!controller.signal.aborted) setSavedItem(items.find(matchesSaved) ?? null);
        })
        .catch(() => {});
      return () => controller.abort();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [destination.id, destination.name, getAccessToken, userId])
  );

  const toggleSaved = async () => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", {
        notice: "Sign in to save destinations to your Saved Places.",
      });
      return;
    }
    setSaving(true);
    setSavedError("");
    try {
      if (savedItem) {
        await backendRequest(`/saved-items/${savedItem._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            userId,
            itemType: "destination",
            itemId: destination.id,
            name: destination.name,
            location: destination.location,
            image: destination.image,
            imageSource: destination.imageSource,
            imageSourcePage: destination.imageSourcePage,
            imageLicense: destination.imageLicense,
            imageCredit: destination.imageCredit,
            imageDescription: destination.imageDescription,
            imageRelevance: destination.imageRelevance,
          }),
        });
        setSavedItem(saved);
        showToast("Saved to your places");
      }
    } catch (error) {
      setSavedError(error instanceof Error ? error.message : "Could not update Saved Places.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <BackButton navigation={navigation} iconSize={22} />
        <Text style={styles.headerTitle}>Destination Details</Text>
        <View style={styles.headerIcons}>
          <Pressable
            onPress={() => void toggleSaved()}
            disabled={saving}
            accessibilityRole="button"
            accessibilityLabel={savedItem ? `Remove ${destination.name} from Saved` : `Save ${destination.name}`}
          >
            {saving ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <Ionicons
                name={savedItem ? "heart" : "heart-outline"}
                size={20}
                color={savedItem ? "#D9435F" : colors.text}
              />
            )}
          </Pressable>
          <Pressable accessibilityLabel="More options">
            <Ionicons name="apps" size={20} color={colors.text} />
          </Pressable>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <RelevantImage entity={{ name: destination.name, type: "destination", location: destination.location, image: destination.image, images: destination.images, imageSource: destination.imageSource, imageSourcePage: destination.imageSourcePage, imageLicense: destination.imageLicense, imageCredit: destination.imageCredit, imageDescription: destination.imageDescription, imageRelevance: destination.imageRelevance }} style={styles.heroImage} />

        <Text style={styles.name}>{destination.name}</Text>
        <View style={styles.locationRow}>
          <Ionicons name="location-outline" size={14} color={colors.textMuted} />
          <Text style={styles.locationText}>{destination.location}</Text>
        </View>

        {destination.rating ? (
          <View style={styles.ratingRow}>
            <Text style={styles.ratingValue}>{destination.rating}</Text>
            {[1, 2, 3, 4, 5].map((i) => (
              <Ionicons key={i} name="star" size={14} color="#FFB800" />
            ))}
            {destination.reviews ? <Text style={styles.reviewsText}>({destination.reviews} reviews)</Text> : null}
          </View>
        ) : null}

        <Text style={styles.description}>{destination.description}</Text>
        {savedError ? <Text style={styles.errorText}>{savedError}</Text> : null}

        <View style={styles.infoSection}>
          <InfoRow title="Things to do" values={destination.thingsToDo ?? hiddenGems.map((item) => item.name)} />
          <InfoRow title="Estimated cost" value={destination.estimatedCost ?? destination.price ?? "Not available in current destination data."} />
          <InfoRow title="Accommodation" value={destination.accommodation ?? "Current accommodation listings are not available here."} />
          <InfoRow title="Transportation" value={destination.transportation ?? "Schedules and fares are not provided here; confirm current local options."} />
          <InfoRow title="Safety" value={destination.safety ?? "Check current local and weather advice before traveling."} />
          <InfoRow title="Nearby services" values={destination.nearbyServices ?? ["No location-verified services in current destination data."]} />
        </View>

        <View style={styles.bestTimeRow}>
          <Text style={styles.bestTimeLabel}>Best Time to Visit</Text>
          <Text style={styles.bestTimeValue}>{destination.bestTime}</Text>
        </View>

        <View style={styles.actionsRow}>
          {QUICK_ACTIONS.map((action) => (
            <Pressable
              key={action.id}
              style={styles.actionButton}
              onPress={() => {
                if (action.id === "map") {
                  navigation.push("Map", {
                    query: destination.name,
                    latitude: destination.latitude,
                    longitude: destination.longitude,
                  });
                } else if (action.id === "weather") {
                  navigation.push("Weather");
                } else if (action.id === "reviews") {
                  navigation.push("Rating");
                } else if (action.id === "hidden") {
                  navigation.push("HiddenGems", { destination });
                }
              }}
            >
              <Ionicons name={action.icon as any} size={20} color={colors.text} />
              <Text style={styles.actionLabel}>{action.label}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.bookingSection}>
          <Text style={styles.nearbyTitle}>Booking options</Text>
          <View style={styles.bookingGrid}>
            {BOOKING_ACTIONS.map((action) => (
              <Pressable
                key={action.id}
                style={styles.bookingButton}
                onPress={() => {
                  if (action.id === "hotel") {
                    navigation.push("Hotels", { location: destination.location });
                  } else if (action.id === "jeep" || action.id === "bike" || action.id === "bus") {
                    navigation.push("Transport", {
                      destination: destination.name,
                      location: destination.location,
                    });
                  } else {
                    navigation.push("Booking", {
                      trip: {
                        name: `Activities near ${destination.name}`,
                        location: destination.location,
                        price: destination.estimatedCost ?? destination.price,
                        image: destination.image,
                      },
                    });
                  }
                }}
              >
                <Ionicons name={action.icon as any} size={18} color={colors.primary} />
                <Text style={styles.bookingText}>{action.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.nearbyHeader}>
          <Text style={styles.nearbyTitle}>Hidden Gems</Text>
        </View>

        <View
          style={styles.hiddenGemsWrap}
        >
          {hiddenGems.map((item) => (
            <View key={item.name} style={styles.gemCard}>
              <RelevantImage entity={{ name: item.name, type: "destination", location: item.location ?? destination.location, image: item.image, images: item.images, imageSource: item.imageSource, imageSourcePage: item.imageSourcePage, imageLicense: item.imageLicense, imageCredit: item.imageCredit, imageDescription: item.imageDescription, imageRelevance: item.imageRelevance }} style={styles.gemImage} />
              <Text style={styles.gemTitle}>{item.name}</Text>
              <View style={styles.gemMetaRow}>
                <Ionicons name="location-outline" size={12} color={colors.textMuted} />
                <Text style={styles.gemLocation}>{item.location ?? "Location not provided"}</Text>
              </View>
              <Text style={styles.gemDescription}>
                {item.description ?? "Description not provided in current destination data."}
              </Text>
              <View style={styles.gemBudgetRow}>
                {(item.tags ?? []).map((tag) => (
                  <Text key={`${item.name}-${tag}`} style={styles.gemTag}>
                    {tag}
                  </Text>
                ))}
              </View>
              <View style={styles.gemActions}>
                <Pressable
                  style={[styles.gemActionButton, styles.gemBookButton]}
                  onPress={() => openGemDetails(item)}
                  accessibilityRole="button"
                >
                  <Text style={styles.gemBookText}>Explore Hidden Gem</Text>
                </Pressable>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>

      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.fromLabel}>from</Text>
          <Text style={styles.priceText}>{destination.price}</Text>
        </View>
        <Pressable
          style={styles.bookButton}
          onPress={() => navigation.push("DestinationTrip", { destination: destination.name })}
          accessibilityRole="button"
          accessibilityLabel="Plan this trip"
        >
          <Text style={styles.bookButtonText}>Plan This Trip</Text>
        </Pressable>
      </View>
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

function InfoRow({
  title,
  value,
  values,
}: {
  title: string;
  value?: string;
  values?: string[];
}) {
  if (!value && !values?.length) return null;
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoTitle}>{title}</Text>
      <Text style={styles.infoText}>{value ?? values?.join(", ")}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
  },
  headerIcons: { flexDirection: "row", gap: 16 },
  content: { padding: spacing.lg, paddingBottom: spacing.xl },
  heroImage: {
    width: "100%",
    height: 220,
    borderRadius: radius.lg,
    marginBottom: spacing.md,
  },
  name: { fontSize: 26, fontWeight: "800", color: colors.text },
  locationRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: spacing.xs,
  },
  locationText: { fontSize: 13, color: colors.textMuted },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: spacing.sm,
  },
  ratingValue: { fontSize: 14, fontWeight: "700", color: colors.text, marginRight: 2 },
  reviewsText: { fontSize: 12, color: colors.textMuted, marginLeft: 4 },
  description: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
    marginTop: spacing.md,
  },
  errorText: { color: "#B42318", fontSize: 12, marginTop: spacing.sm },
  infoSection: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    marginTop: spacing.lg,
  },
  infoRow: {
    paddingVertical: spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  infoTitle: { color: colors.text, fontSize: 12, fontWeight: "700" },
  infoText: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: 3 },
  bestTimeRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: spacing.lg,
  },
  bestTimeLabel: { fontSize: 14, fontWeight: "700", color: colors.text },
  bestTimeValue: { fontSize: 13, color: colors.primary, fontWeight: "600" },
  actionsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: spacing.lg,
  },
  actionButton: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surface,
    borderRadius: radius.sm,
    paddingVertical: spacing.md,
    width: "23%",
    gap: 6,
  },
  actionLabel: { fontSize: 11, color: colors.text, fontWeight: "600" },
  nearbyHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: spacing.xl,
    marginBottom: spacing.sm,
  },
  nearbyTitle: { fontSize: 16, fontWeight: "700", color: colors.text },
  seeAll: { fontSize: 13, color: colors.primary, fontWeight: "600" },
  bookingSection: {
    marginTop: spacing.xl,
  },
  bookingGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginTop: spacing.sm,
  },
  bookingButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    minWidth: "46%",
  },
  bookingText: {
    color: colors.text,
    fontSize: 12,
    fontWeight: "700",
  },
  hiddenGemsWrap: {
    marginTop: spacing.sm,
    gap: 12,
  },
  gemCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  gemImage: {
    width: "100%",
    height: 140,
    borderRadius: radius.sm,
    marginBottom: spacing.sm,
  },
  gemImagePlaceholder: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#E8F3F0",
  },
  gemTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: "700",
    marginBottom: 4,
  },
  gemMetaRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  gemLocation: {
    color: colors.textMuted,
    fontSize: 12,
    marginLeft: 4,
  },
  gemDescription: {
    color: colors.text,
    fontSize: 12,
    lineHeight: 18,
    marginBottom: spacing.sm,
  },
  gemActions: {
    flexDirection: "row",
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  gemActionButton: {
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: radius.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  gemActionText: { color: colors.primaryDark, fontSize: 12, fontWeight: "700" },
  gemBookButton: { backgroundColor: colors.primary, marginLeft: "auto" },
  gemBookText: { color: colors.white, fontSize: 12, fontWeight: "700" },
  gemBudgetRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
  },
  gemTag: {
    backgroundColor: "#EEF6FF",
    color: colors.primary,
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 5,
    fontSize: 10,
    fontWeight: "600",
  },
  bottomBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.surface,
    backgroundColor: colors.background,
  },
  fromLabel: { fontSize: 11, color: colors.textMuted },
  priceText: { fontSize: 18, fontWeight: "800", color: colors.text },
  bookButton: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xl,
    minHeight: 52,
    justifyContent: "center",
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 3,
  },
  bookButtonText: { color: "#fff", fontWeight: "700", fontSize: 15 },
});