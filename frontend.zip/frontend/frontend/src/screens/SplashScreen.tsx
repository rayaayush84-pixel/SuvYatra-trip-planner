import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  TouchableOpacity,
  StatusBar as NativeStatusBar,
} from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import { colors, radius } from "../theme";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useAuth } from "../auth/AuthContext";

type Props = NativeStackScreenProps<RootStackParamList, "Splash">;

export default function SplashScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const { isLoggedIn } = useAuth();

  React.useEffect(() => {
    if (isLoggedIn) {
      navigation.replace("MainTabs");
    }
  }, [isLoggedIn, navigation]);

  const handleGetStarted = () => {
    navigation.replace("TermsAndConditions");
  };

  const handleGuestExplore = () => {
    navigation.replace("MainTabs");
  };

  return (
    <ImageBackground
      source={require("../../../assets/WhatsApp Image 2026-09-10 at 11.13.41 PM (1).jpeg")}
      style={styles.background}
      resizeMode="cover"
    >
      <NativeStatusBar translucent backgroundColor="transparent" barStyle="light-content" />
          {/* Dark gradient overlay */}
          <View style={styles.gradientOverlay} />

          {/* Content container */}
          <View
            style={[
              styles.content,
              {
                paddingTop: Math.max(insets.top + 48, 88),
                paddingBottom: Math.max(insets.bottom + 24, 40),
                paddingLeft: Math.max(insets.left + 24, 24),
                paddingRight: Math.max(insets.right + 24, 24),
              },
            ]}
          >
            {/* Logo section - From your PDF */}
            <View style={styles.logoContainer}>
              {/* Logo Text - Based on your PDF */}
              <View style={styles.logoTextContainer}>
                <Text style={styles.logoMainText}>SuvYatra</Text>
              </View>
              
              <Text style={styles.tagline}>Explore Nepal Smarter</Text>
            </View>

            {/* Buttons section */}
            <View style={styles.buttonsSection}>
              <TouchableOpacity
                style={styles.primaryButton}
                onPress={handleGetStarted}
                activeOpacity={0.8}
              >
                <Text style={styles.primaryButtonText}>Get Started</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleGuestExplore}
                activeOpacity={0.7}
              >
                <Text style={styles.secondaryButtonText}>Explore as guest</Text>
              </TouchableOpacity>
            </View>
          </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },

  // Image background
  imageBackground: {
    flex: 1,
    width: "100%",
    height: "100%",
  },

  // Gradient overlay
  gradientOverlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: "rgba(0, 0, 0, 0.38)",
  },

  // Content
  content: {
    flex: 1,
    justifyContent: "space-between",
  },

  // Logo section
  logoContainer: {
    alignItems: "center",
  },
  
  logoTextContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom:5,
  },
  
  logoMainText: {
    fontSize: 52,
    fontWeight: "900",
    color: "#FFFFFF",
    letterSpacing: 1,
    textShadowColor: "rgba(0, 0, 0, 0.4)",
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  
  
  tagline: {
    fontSize: 18,
    fontWeight: "500",
    color: "rgba(255, 255, 255, 0.95)",
    textAlign: "center",
    letterSpacing: 0.5,
    marginTop: 8,
  },

  // Buttons section
  buttonsSection: {
    alignItems: "center",
    width: "100%",
  },
  
  primaryButton: {
    backgroundColor: "#3F53C6",
    borderRadius: radius.md,
    paddingVertical: 18,
    paddingHorizontal: 24,
    width: "100%",
    alignItems: "center",
    marginBottom: 20,
    borderWidth: 2,
    borderColor: "rgba(255, 255, 255, 0.3)",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
  },
  
  primaryButtonText: {
    color: colors.white,
    fontSize: 18,
    fontWeight: "700",
    letterSpacing: 0.8,
  },
  
  secondaryButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: "600",
    letterSpacing: 0.5,
    textDecorationLine: "underline",
    textDecorationColor: colors.white,
    textDecorationStyle: "solid",
  },
});