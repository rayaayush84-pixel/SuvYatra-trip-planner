import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  ActivityIndicator,
  TextInput,
  Modal,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import BSADDatePicker from "../components/BSADDatePicker";
import { todayAdISO } from "../utils/bsDate";
import { normalizeQuantity } from "../utils/quantityValidation";
import { colors, radius, spacing } from "../theme";
import { backendRequest } from "../services/backendApi";
import { useAuth } from "../auth/AuthContext";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "Booking">;
type RoomType = NonNullable<NonNullable<NonNullable<RootStackParamList["Booking"]>["hotel"]>["roomTypes"]>[number];

function amountFromLabel(value: string): number {
  const amount = Number((value.match(/\d[\d,]*/)?.[0] ?? "0").replace(/,/g, ""));
  return Number.isFinite(amount) ? amount : 0;
}

export default function BookingScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const hotel = route.params?.hotel;
  const [adults, setAdults] = useState(() => normalizeQuantity(route.params?.adults ?? 1, "adults"));
  const [children, setChildren] = useState(() => normalizeQuantity(route.params?.children ?? 0, "children"));
  const [rooms, setRooms] = useState(() => normalizeQuantity(route.params?.rooms ?? 1, "rooms"));
  const [submitting, setSubmitting] = useState(false);
  const [requestError, setRequestError] = useState("");
  const [requestNotice, setRequestNotice] = useState("");
  const [checkIn, setCheckIn] = useState(route.params?.checkIn ?? "");
  const [checkOut, setCheckOut] = useState(route.params?.checkOut ?? "");
  const [availableRoomTypes, setAvailableRoomTypes] = useState<RoomType[]>(hotel?.roomTypes ?? []);
  const [selectedRoomTypeId, setSelectedRoomTypeId] = useState("");
  const [availabilityLoading, setAvailabilityLoading] = useState(false);
  const [availabilityError, setAvailabilityError] = useState("");
  const vehicle = route.params?.vehicle;
  const trip = route.params?.trip;
  const activity = route.params?.activity;
  // Standalone transport booking state (hotel/trip state above is untouched).
  const [travelDate, setTravelDate] = useState(route.params?.checkIn ?? "");
  const isActivityBooking = route.params?.activity != null;
  const [contactName, setContactName] = useState(isActivityBooking ? "" : (user?.name ?? ""));
  const [contactPhone, setContactPhone] = useState(user?.phone ?? "");
  const [contactEmail, setContactEmail] = useState(isActivityBooking ? "" : (user?.email ?? ""));

  // Activities bookings always start with empty Name/Email. Never auto-fill
  // from the logged-in profile, auth data, or stored form state so each new
  // Activities booking opens blank (transport/hotel behaviour untouched).
  useEffect(() => {
    if (route.params?.activity != null) {
      setContactName("");
      setContactEmail("");
    }
    // Keyed on the activity id (not the params object) so typing is never
    // wiped by re-renders — only a new activity booking resets the fields.
  }, [activity?.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const [seatsData, setSeatsData] = useState<{
    transportId: string;
    seatSelection: boolean;
    capacity: number;
    booked: number;
    available: number;
    seats?: { label: string; booked: boolean }[];
  } | null>(null);
  const [seatsLoading, setSeatsLoading] = useState(false);
  const [seatsError, setSeatsError] = useState("");
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const bookingTitle = vehicle?.name ?? trip?.name ?? hotel?.name ?? activity?.name ?? "";
  const bookingLocation = vehicle?.location ?? trip?.location ?? hotel?.location ?? activity?.location ?? "";
  const bookingType = hotel ? "hotel" : vehicle ? "transport" : activity ? "activity" : "trip";
  const imageEntityName = bookingType === "trip"
    ? bookingTitle.replace(/^activities near /i, "").trim()
    : bookingTitle;
  const imageEntityType = bookingType === "trip"
    ? /^activities near /i.test(bookingTitle) ? "activity" : "destination"
    : bookingType;

  const dateToUtc = (value: string) => new Date(`${value}T00:00:00Z`);
  const validCheckIn = /^\d{4}-\d{2}-\d{2}$/.test(checkIn) &&
    !Number.isNaN(dateToUtc(checkIn).getTime()) &&
    dateToUtc(checkIn).toISOString().slice(0, 10) === checkIn;
  const validCheckOut = /^\d{4}-\d{2}-\d{2}$/.test(checkOut) &&
    !Number.isNaN(dateToUtc(checkOut).getTime()) &&
    dateToUtc(checkOut).toISOString().slice(0, 10) === checkOut;
  const nights = bookingType === "hotel" && validCheckIn && validCheckOut
    ? Math.round((dateToUtc(checkOut).getTime() - dateToUtc(checkIn).getTime()) / 86400000)
    : 1;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const pastCheckIn = validCheckIn && dateToUtc(checkIn) < new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));
  const invalidHotelDates =
    bookingType === "hotel" &&
    (!validCheckIn || !validCheckOut || nights < 1 || pastCheckIn);

  useEffect(() => {
    if (!hotel?.id || invalidHotelDates || adults < 1 || children < 0 || rooms < 1) {
      setAvailabilityLoading(false);
      setAvailableRoomTypes(hotel?.roomTypes ?? []);
      setAvailabilityError("");
      setSelectedRoomTypeId("");
      return;
    }
    const controller = new AbortController();
    const params = new URLSearchParams({
      checkIn,
      checkOut,
      adults: String(adults),
      children: String(children),
      rooms: String(rooms),
    });
    setAvailabilityLoading(true);
    setAvailabilityError("");
    backendRequest<{ roomTypes: RoomType[] }>(
      `/hotels/${encodeURIComponent(hotel.id)}/availability?${params}`,
      { signal: controller.signal }
    )
      .then((result) => {
        setAvailableRoomTypes(result.roomTypes);
        setSelectedRoomTypeId((current) => {
          const currentAvailable = result.roomTypes.find((roomType) =>
            roomType._id === current &&
            roomType.matchesOccupancy &&
            (roomType.availableRooms ?? 0) >= rooms
          );
          return currentAvailable?._id ??
            result.roomTypes.find((roomType) => roomType.matchesOccupancy && (roomType.availableRooms ?? 0) >= rooms)?._id ??
            "";
        });
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted) {
          setAvailabilityError(error instanceof Error ? error.message : "Could not check room availability.");
          setAvailableRoomTypes([]);
          setSelectedRoomTypeId("");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setAvailabilityLoading(false);
      });
    return () => controller.abort();
  }, [adults, children, checkIn, checkOut, hotel?.id, invalidHotelDates, rooms]);

  const selectedRoomType = availableRoomTypes.find((roomType) => roomType._id === selectedRoomTypeId);
  const nightlyRate = useMemo(() => {
    if (bookingType === "hotel") return selectedRoomType?.nightlyRate ?? hotel?.pricePerNight ?? 0;
    return amountFromLabel(vehicle?.price ?? trip?.price ?? hotel?.price ?? "");
  }, [bookingType, hotel?.price, hotel?.pricePerNight, selectedRoomType?.nightlyRate, trip?.price, vehicle?.price]);

  // ---- Standalone transport validation + pricing (hotel logic above untouched).
  const validTravelDate =
    /^\d{4}-\d{2}-\d{2}$/.test(travelDate) &&
    !Number.isNaN(dateToUtc(travelDate).getTime()) &&
    dateToUtc(travelDate).toISOString().slice(0, 10) === travelDate &&
    !pastCheckInFor(travelDate);
  function pastCheckInFor(value: string) {
    return dateToUtc(value) < new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()));
  }
  const partySize = adults + children;
  const validParty = Number.isInteger(adults) && adults >= 1 && adults <= 20 &&
    Number.isInteger(children) && children >= 0 && children <= 20 && partySize <= 20;
  const transportUnit = vehicle?.unitPrice ?? amountFromLabel(vehicle?.price ?? "");
  const transportPerPerson = ["shared", "scheduled"].includes((vehicle?.serviceMode ?? "").toLowerCase());
  const transportTotal = transportPerPerson ? transportUnit * partySize : transportUnit;
  const contactNameValid = contactName.trim().length >= 2;
  const contactPhoneValid = /^[+]?[\d][\d\s()+-]{5,}$/.test(contactPhone.trim());
  // Activities require a strict mobile number: selectable country calling
  // code (Nepal default) + country-specific national digit count. Scoped to
  // the activity flow only — transport keeps the rule above.
  type CountryPhoneRule = { code: string; name: string; flag: string; min: number; max: number };
  const COUNTRY_PHONE_RULES: CountryPhoneRule[] = [
    { code: "+977", name: "Nepal", flag: "🇳🇵", min: 10, max: 10 },
    { code: "+91", name: "India", flag: "🇮🇳", min: 10, max: 10 },
    { code: "+1", name: "United States", flag: "🇺🇸", min: 10, max: 10 },
    { code: "+44", name: "United Kingdom", flag: "🇬🇧", min: 10, max: 10 },
    { code: "+61", name: "Australia", flag: "🇦🇺", min: 9, max: 9 },
    { code: "+86", name: "China", flag: "🇨🇳", min: 11, max: 11 },
    { code: "+81", name: "Japan", flag: "🇯🇵", min: 10, max: 10 },
    { code: "+49", name: "Germany", flag: "🇩🇪", min: 10, max: 11 },
    { code: "+33", name: "France", flag: "🇫🇷", min: 9, max: 9 },
    { code: "+971", name: "UAE", flag: "🇦🇪", min: 9, max: 9 },
    { code: "+974", name: "Qatar", flag: "🇶🇦", min: 8, max: 8 },
    { code: "+65", name: "Singapore", flag: "🇸🇬", min: 8, max: 8 },
    { code: "+60", name: "Malaysia", flag: "🇲🇾", min: 9, max: 10 },
    { code: "+66", name: "Thailand", flag: "🇹🇭", min: 9, max: 9 },
    { code: "+82", name: "South Korea", flag: "🇰🇷", min: 10, max: 10 },
    { code: "+966", name: "Saudi Arabia", flag: "🇸🇦", min: 9, max: 9 },
  ];
  const NEPAL_PHONE = COUNTRY_PHONE_RULES[0];
  const [phoneCountryCode, setPhoneCountryCode] = useState("+977");
  const [countryPickerOpen, setCountryPickerOpen] = useState(false);
  const [countryQuery, setCountryQuery] = useState("");
  const activityPhoneRule =
    COUNTRY_PHONE_RULES.find((rule) => rule.code === phoneCountryCode) ?? NEPAL_PHONE;
  const NEPAL_PHONE_MESSAGE =
    "Enter a valid Nepali mobile number: +977 followed by exactly 10 digits (e.g. +9779812345678).";
  const activityPhoneMessage =
    activityPhoneRule.code === NEPAL_PHONE.code
      ? NEPAL_PHONE_MESSAGE
      : `Enter a valid ${activityPhoneRule.name} mobile number: ${activityPhoneRule.code} followed by ${
          activityPhoneRule.min === activityPhoneRule.max
            ? `exactly ${activityPhoneRule.min} digits`
            : `${activityPhoneRule.min}–${activityPhoneRule.max} digits`
        }.`;
  const activityPhoneDigits = (() => {
    const trimmed = contactPhone.trim();
    const rest = trimmed.startsWith(phoneCountryCode)
      ? trimmed.slice(phoneCountryCode.length)
      : trimmed.replace(/\D/g, "");
    return rest.replace(/\D/g, "").slice(0, activityPhoneRule.max);
  })();
  const contactPhoneValidActivity = (() => {
    const trimmed = contactPhone.trim();
    if (!trimmed.startsWith(activityPhoneRule.code)) return false;
    const digits = trimmed.slice(activityPhoneRule.code.length);
    return (
      /^\d+$/.test(digits) &&
      digits.length >= activityPhoneRule.min &&
      digits.length <= activityPhoneRule.max
    );
  })();
  const changePhoneCountry = (code: string) => {
    const rule = COUNTRY_PHONE_RULES.find((entry) => entry.code === code) ?? NEPAL_PHONE;
    // Strip only the previously selected code (a greedy prefix regex would
    // eat the national digits too); fall back to digit extraction.
    const trimmed = contactPhone.trim();
    const digits = (trimmed.startsWith(phoneCountryCode)
      ? trimmed.slice(phoneCountryCode.length)
      : trimmed
    )
      .replace(/\D/g, "")
      .slice(0, rule.max);
    setPhoneCountryCode(rule.code);
    setContactPhone(`${rule.code}${digits}`);
    setCountryPickerOpen(false);
    setCountryQuery("");
  };
  const contactEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail.trim());
  const vehicleRoute = (() => {
    const o = vehicle?.origin?.trim() ?? "";
    const d = vehicle?.destination?.trim() ?? "";
    if (o && d && o.toLowerCase() === d.toLowerCase()) return `Local service in ${o}`;
    return [o, d].filter(Boolean).join(" → ") || bookingLocation;
  })();

  useEffect(() => {
    if (bookingType !== "transport" || !vehicle?.id || !validTravelDate) {
      setSeatsData(null);
      setSeatsError("");
      setSeatsLoading(false);
      setSelectedSeats([]);
      return;
    }
    const controller = new AbortController();
    setSeatsLoading(true);
    setSeatsError("");
    backendRequest<{
      transportId: string;
      seatSelection: boolean;
      capacity: number;
      booked: number;
      available: number;
      seats?: { label: string; booked: boolean }[];
    }>(`/transports/${encodeURIComponent(vehicle.id)}/seats?date=${travelDate}`, {
      signal: controller.signal,
    })
      .then((result) => {
        if (controller.signal.aborted) return;
        setSeatsData(result);
        setSelectedSeats([]);
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted) {
          setSeatsError(error instanceof Error ? error.message : "Could not load seat availability.");
          setSeatsData(null);
          setSelectedSeats([]);
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setSeatsLoading(false);
      });
    return () => controller.abort();
  }, [bookingType, travelDate, validTravelDate, vehicle?.id]);

  const seatsRequireSelection = bookingType === "transport" && seatsData?.seatSelection === true;
  const seatsMatchParty = !seatsRequireSelection || selectedSeats.length === partySize;
  const seatsAvailableNote = seatsData && !seatsData.seatSelection
    ? `${seatsData.available} of ${seatsData.capacity} places left for this date.`
    : null;
  const vehicleReady =
    bookingType === "transport" &&
    !!vehicle?.id &&
    validTravelDate &&
    validParty &&
    transportUnit > 0 &&
    contactNameValid &&
    contactPhoneValid &&
    contactEmailValid &&
    !seatsLoading &&
    !seatsError &&
    seatsMatchParty &&
    !submitting;

  // ---- Standalone activity booking state (hotel/transport above untouched).
  const [slotData, setSlotData] = useState<
    { time: string | null; capacity: number; booked: number; available: number }[] | null
  >(null);
  const [slotLoading, setSlotLoading] = useState(false);
  const [slotError, setSlotError] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  // Participant ages for age-restricted activities, entered directly as
  // numbers (no dates of birth collected). Same eligibility chain as before:
  // every participant needs a valid age and the activity's minimum applies.
  const [ageInputs, setAgeInputs] = useState<string[]>([]);
  const activityMinAge =
    Number.isInteger(activity?.minAge) && (activity?.minAge ?? 0) > 0
      ? Math.floor(activity?.minAge ?? 0)
      : 0;
  const activityUnit = activity?.price ?? 0;
  const activityTotal = activityUnit * partySize;

  // Keep one age field per participant; changing party size preserves entries.
  useEffect(() => {
    if (bookingType !== "activity") return;
    setAgeInputs((current) => {
      if (current.length === partySize) return current;
      return Array.from({ length: partySize }, (_, index) => current[index] ?? "");
    });
  }, [bookingType, partySize]);

  useEffect(() => {
    if (bookingType !== "activity" || !activity?.id || !validTravelDate) {
      setSlotData(null);
      setSlotError("");
      setSlotLoading(false);
      setSelectedSlot("");
      return;
    }
    const controller = new AbortController();
    setSlotLoading(true);
    setSlotError("");
    backendRequest<{ slots: { time: string | null; capacity: number; booked: number; available: number }[] }>(
      `/places/${encodeURIComponent(activity.id)}/slots?date=${travelDate}`,
      { signal: controller.signal }
    )
      .then((result) => {
        if (controller.signal.aborted) return;
        setSlotData(result.slots);
        setSelectedSlot("");
      })
      .catch((error: unknown) => {
        if (!controller.signal.aborted) {
          setSlotError(error instanceof Error ? error.message : "Could not load available time slots.");
          setSlotData(null);
          setSelectedSlot("");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setSlotLoading(false);
      });
    return () => controller.abort();
  }, [activity?.id, bookingType, travelDate, validTravelDate]);

  const slotOptions = (slotData ?? []).filter((slot) => slot.time);
  const slotRequired = bookingType === "activity" && slotOptions.length > 0;
  const selectedSlotOk =
    !slotRequired ||
    slotOptions.some((slot) => slot.time === selectedSlot && slot.available >= partySize);
  const ageValues = ageInputs.map((raw) => {
    const text = raw.trim();
    if (!/^\d{1,3}$/.test(text)) return null;
    const value = Number(text);
    return Number.isSafeInteger(value) && value >= 0 && value <= 120 ? value : null;
  });
  const agesValid =
    activityMinAge <= 0 ||
    (ageInputs.length === partySize && ageValues.every((age) => age !== null));
  const ageEligible =
    activityMinAge <= 0 ||
    (agesValid && (ageValues as number[]).every((age) => age >= activityMinAge));
  const activityReady =
    bookingType === "activity" &&
    !!activity?.id &&
    validTravelDate &&
    validParty &&
    activityUnit > 0 &&
    contactNameValid &&
    contactPhoneValidActivity &&
    contactEmailValid &&
    !slotLoading &&
    !slotError &&
    selectedSlotOk &&
    agesValid &&
    ageEligible &&
    !submitting;
  const selectedRoomAvailable = !!selectedRoomType &&
    selectedRoomType.matchesOccupancy === true &&
    (selectedRoomType.availableRooms ?? 0) >= rooms;
  const subtotal = bookingType === "hotel" ? nightlyRate * nights * rooms : nightlyRate;
  const total = subtotal;

  const addHotelToTrip = () => {
    if (!hotel?.id) return;
    navigation.navigate("MainTabs", {
      screen: "Trips",
      params: {
        hotel: {
          id: hotel.id,
          name: hotel.name,
          location: hotel.location,
          latitude: hotel.latitude,
          longitude: hotel.longitude,
          checkIn: checkIn || undefined,
          checkOut: checkOut || undefined,
        },
      },
    });
  };

  const saveBookingRequest = async () => {
    const token = getAccessToken();
    if (!token) {
      setRequestError("Please sign in with a registered account to save a booking request.");
      return;
    }
    if (bookingType === "trip") {
      setRequestError("Transport and activity bookings are handled in the guided destination trip planner with real demo inventory and sandbox payment. Use the trip planner button below to book this service.");
      return;
    }
    if (hotel?.isDemoData) {
      setRequestError("Demo hotel listings cannot be used to create booking requests.");
      return;
    }
    if (bookingType === "hotel" && invalidHotelDates) {
      setRequestError("Enter valid future check-in and check-out dates; check-out must be after check-in.");
      return;
    }
    if (bookingType === "transport") {
      if (!vehicle?.id) {
        setRequestError("This transport option is missing its service reference. Please choose it again from Transportation.");
        return;
      }
      if (!validTravelDate) {
        setRequestError("Select a valid future travel date.");
        return;
      }
      if (!validParty) {
        setRequestError("Enter at least one adult and no more than 12 passengers in total.");
        return;
      }
      if (!(transportUnit > 0)) {
        setRequestError(`“${vehicle?.name ?? "This service"}” does not have a confirmed fare yet. Please choose another transport service.`);
        return;
      }
      if (!contactNameValid) {
        setRequestError("Enter the lead passenger's full name (at least 2 characters).");
        return;
      }
      if (!contactPhoneValid) {
        setRequestError("Enter a valid phone number for the lead passenger.");
        return;
      }
      if (!contactEmailValid) {
        setRequestError("Enter a valid email address for booking updates.");
        return;
      }
      if (seatsLoading) {
        setRequestError("Seat availability is still loading. Please wait a moment.");
        return;
      }
      if (seatsError) {
        setRequestError(seatsError);
        return;
      }
      if (!seatsMatchParty) {
        setRequestError(`Select exactly one seat per passenger (${partySize} seat(s) needed).`);
        return;
      }
    }
    if (bookingType === "hotel" && !selectedRoomAvailable) {
      setRequestError("Choose a room type that is available for the selected dates and occupancy.");
      return;
    }
    if (bookingType === "activity") {
      if (!activity?.id) {
        setRequestError("This activity is missing its service reference. Please choose it again from Activities.");
        return;
      }
      if (!validTravelDate) {
        setRequestError("Select a valid future activity date.");
        return;
      }
      if (!validParty) {
        setRequestError("Enter at least one adult and no more than 20 participants in total.");
        return;
      }
      if (!(activityUnit > 0)) {
        setRequestError(`“${activity?.name ?? "This activity"}” does not have a confirmed price yet. Please choose another activity.`);
        return;
      }
      if (!contactNameValid) {
        setRequestError("Enter the lead participant's full name (at least 2 characters).");
        return;
      }
      if (!contactPhoneValidActivity) {
        setRequestError(activityPhoneMessage);
        return;
      }
      if (!contactEmailValid) {
        setRequestError("Enter a valid email address for booking updates.");
        return;
      }
      if (slotLoading) {
        setRequestError("Available time slots are still loading. Please wait a moment.");
        return;
      }
      if (slotError) {
        setRequestError(slotError);
        return;
      }
      if (!selectedSlotOk) {
        setRequestError("Select an available time slot with enough places for your group.");
        return;
      }
      if (activityMinAge > 0) {
        if (!agesValid) {
          setRequestError("Enter every participant's age (0–120) to check the age requirement.");
          return;
        }
        if (!ageEligible) {
          setRequestError(`This activity is restricted to participants aged ${activityMinAge} and above.`);
          return;
        }
      }
    }
    if (!bookingTitle || (bookingType === "hotel" && (!hotel?.id || nightlyRate <= 0))) {
      setRequestError("This item does not have a valid hotel ID and nightly rate.");
      return;
    }
    setSubmitting(true);
    setRequestError("");
    try {
      const result = await backendRequest<{
        booking: { bookingCode: string };
        message: string;
      }>("/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          itemType: bookingType,
          itemId: bookingType === "hotel" ? hotel?.id : bookingType === "transport" ? vehicle?.id : activity?.id,
          itemName: bookingTitle,
          location: bookingLocation,
          checkIn: bookingType === "hotel" ? checkIn : bookingType === "transport" || bookingType === "activity" ? travelDate : undefined,
          checkOut: bookingType === "hotel" ? checkOut : undefined,
          guests: adults + children,
          adults: bookingType === "hotel" || bookingType === "transport" || bookingType === "activity" ? adults : undefined,
          children: bookingType === "hotel" || bookingType === "transport" || bookingType === "activity" ? children : undefined,
          rooms: bookingType === "hotel" ? rooms : undefined,
          roomTypeId: bookingType === "hotel" ? selectedRoomTypeId : undefined,
          seatNumbers: bookingType === "transport" && seatsRequireSelection ? selectedSeats : undefined,
          serviceTime: bookingType === "activity" && selectedSlot ? selectedSlot : undefined,
          participantAges: bookingType === "activity" && activityMinAge > 0 ? (ageValues as number[]) : undefined,
          amount: bookingType === "transport" ? transportTotal : bookingType === "activity" ? activityTotal : total,
        }),
      });
      setRequestNotice(`${result.message} Reference: ${result.booking.bookingCode}`);
      navigation.navigate("Bookings", undefined);
    } catch (error) {
      setRequestError(
        error instanceof Error ? error.message : "Could not save the booking request."
      );
    } finally {
      setSubmitting(false);
    }
  };

  const confirmDisabled = submitting ||
    (hotel
      ? !hotel || Boolean(hotel.isDemoData) || invalidHotelDates || availabilityLoading || !selectedRoomAvailable
      : vehicle
        ? !vehicleReady
        : activity
          ? !activityReady
          : true);
  const confirmBookingRequest = () => {
    // Mirrors the button's disabled condition so Enter can never submit an
    // invalid, unavailable, or already-submitting booking.
    if (confirmDisabled) {
      return;
    }
    setRequestError("");
    void saveBookingRequest();
  };

  if (!bookingTitle) {
    return (
      <SafeAreaView style={styles.container} edges={["top"]}>
        <BackButton navigation={navigation} style={styles.backButton} iconSize={24} />
        <Text style={styles.header}>Choose a trip or hotel to book</Text>
        <Text style={styles.noticeText}>Open a listed hotel or travel activity before starting a booking request.</Text>
        <Pressable style={styles.confirmButton} onPress={() => navigation.navigate("Hotels")}>
          <Text style={styles.confirmButtonText}>Browse Hotels</Text>
        </Pressable>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <BackButton navigation={navigation} style={styles.backButton} iconSize={24} />

        <Text style={styles.header}>{bookingType === "hotel" ? "Request a Hotel Booking" : "Confirm Your Booking"}</Text>

        <View style={styles.hotelCard}>
          <RelevantImage entity={{
            name: imageEntityName,
            type: imageEntityType,
            location: bookingLocation,
            image: vehicle?.image ?? trip?.image ?? activity?.image ?? hotel?.image,
            images: activity?.images ?? hotel?.images,
            imageSource: vehicle?.imageSource ?? trip?.imageSource ?? activity?.imageSource ?? hotel?.imageSource,
            imageSourcePage: vehicle?.imageSourcePage ?? trip?.imageSourcePage ?? activity?.imageSourcePage ?? hotel?.imageSourcePage,
            imageLicense: vehicle?.imageLicense ?? trip?.imageLicense ?? activity?.imageLicense ?? hotel?.imageLicense,
            imageCredit: vehicle?.imageCredit ?? trip?.imageCredit ?? activity?.imageCredit ?? hotel?.imageCredit,
            imageDescription: vehicle?.imageDescription ?? trip?.imageDescription ?? activity?.imageDescription ?? hotel?.imageDescription,
            imageRelevance: vehicle?.imageRelevance ?? trip?.imageRelevance ?? activity?.imageRelevance ?? hotel?.imageRelevance,
          }} style={styles.hotelImage} />
          <Text style={styles.hotelName}>{bookingTitle}</Text>
          <Text style={styles.hotelLocation}>{bookingLocation}</Text>
          {hotel?.isDemoData ? <Text style={styles.errorText}>Demo listing: booking requests are disabled.</Text> : null}
        </View>

        {bookingType === "hotel" ? (
          <>
            <BSADDatePicker
              label="Check-in date"
              value={checkIn}
              onChange={setCheckIn}
              minDate={todayAdISO()}
              placeholder="Select check-in date"
            />
            <BSADDatePicker
              label="Check-out date"
              value={checkOut}
              onChange={setCheckOut}
              minDate={checkIn || todayAdISO()}
              placeholder="Select check-out date"
            />
            {invalidHotelDates ? <Text style={styles.errorText}>Enter valid future dates; check-out must be after check-in.</Text> : null}
            <Text style={styles.noticeText}>Room inventory is checked for these dates. A booking request still requires provider confirmation.</Text>
          </>
        ) : null}

        {bookingType === "hotel" && (
          <View style={styles.guestControls}>
              <Counter label="Adults" value={adults} minimum={1} maximum={20 - children} onChange={setAdults} />
              <Counter label="Children" value={children} minimum={0} maximum={20 - adults} onChange={setChildren} />
              <Counter label="Rooms" value={rooms} minimum={1} maximum={10} onChange={setRooms} />
          </View>
        )}

        {hotel ? (
          <View style={styles.roomTypes}>
            <Text style={styles.label}>Choose one room type</Text>
            {availabilityLoading ? <ActivityIndicator size="small" color={colors.primary} /> : null}
            {availabilityError ? <Text style={styles.errorText}>{availabilityError}</Text> : null}
            {!availabilityLoading && !availabilityError && !invalidHotelDates && availableRoomTypes.length === 0
              ? <Text style={styles.noticeText}>No room types are available for these dates yet. Check your dates or contact the hotel.</Text>
              : null}
            {availableRoomTypes.map((roomType) => {
              const fits = roomType.matchesOccupancy === true && (roomType.availableRooms ?? 0) >= rooms;
              const selected = selectedRoomTypeId === roomType._id;
              return (
                <Pressable
                  key={roomType._id}
                  disabled={!fits}
                  accessibilityRole="button"
                  accessibilityState={{ selected, disabled: !fits }}
                  onPress={() => setSelectedRoomTypeId(roomType._id)}
                  style={[styles.roomTypeOption, selected && styles.roomTypeOptionSelected, !fits && styles.roomTypeOptionDisabled]}
                >
                  <Ionicons
                    name={selected ? "radio-button-on" : "radio-button-off"}
                    size={19}
                    color={selected ? colors.primary : colors.textMuted}
                  />
                  <View style={styles.roomTypeDescription}>
                    <Text style={styles.roomTypeName}>{roomType.name}</Text>
                    <Text style={styles.noticeText}>
                      Up to {roomType.capacityAdults} adults · {roomType.capacityChildren} children per room
                    </Text>
                    <Text style={styles.noticeText}>
                      {roomType.availableRooms ?? 0} available · NPR {(roomType.nightlyRate ?? hotel.pricePerNight ?? 0).toLocaleString("en-IN")} / night
                    </Text>
                  </View>
                </Pressable>
              );
            })}
          </View>
        ) : null}

        {hotel ? (
          <View style={styles.priceBox}>
            <View style={styles.priceRow}>
              <Text style={styles.priceLabel}>{`${nights} night${nights === 1 ? "" : "s"} × ${rooms} room(s)`}</Text>
              <Text style={styles.priceValue}>NPR {subtotal.toLocaleString("en-IN")}</Text>
            </View>
            <Text style={styles.noticeText}>Price is an estimate from the listed nightly rate, before any provider fees.</Text>
            <View style={[styles.priceRow, styles.totalRow]}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>NPR {total.toLocaleString("en-IN")}</Text>
            </View>
          </View>
        ) : vehicle ? (
          <View>
            <Text style={styles.label}>Route</Text>
            <Text style={styles.routeSummary}>{vehicleRoute}</Text>
            {(vehicle?.departureTime || vehicle?.arrivalTime) ? (
              <Text style={styles.noticeText}>
                {[vehicle?.departureTime && `Departs ${vehicle.departureTime}`, vehicle?.arrivalTime && `arrives ${vehicle.arrivalTime}`].filter(Boolean).join(" · ")}
              </Text>
            ) : null}
            <BSADDatePicker
              label="Travel date"
              value={travelDate}
              onChange={setTravelDate}
              minDate={todayAdISO()}
              placeholder="Select travel date"
            />
            {!validTravelDate && travelDate ? <Text style={styles.errorText}>Select a valid future travel date.</Text> : null}
            <View style={styles.guestControls}>
              <Counter label="Adults" value={adults} minimum={1} maximum={12 - children} onChange={setAdults} />
              <Counter label="Children" value={children} minimum={0} maximum={12 - adults} onChange={setChildren} />
            </View>
            <Text style={styles.label}>Lead passenger full name</Text>
            <TextInput
              value={contactName}
              onChangeText={setContactName}
              placeholder="Full name"
              placeholderTextColor={colors.textMuted}
              autoCapitalize="words"
              style={styles.contactInput}
            />
            <Text style={styles.label}>Phone number</Text>
            <TextInput
              value={contactPhone}
              onChangeText={setContactPhone}
              placeholder="+977 98XXXXXXXX"
              placeholderTextColor={colors.textMuted}
              keyboardType="phone-pad"
              style={styles.contactInput}
            />
            <Text style={styles.label}>Email for booking updates</Text>
            <TextInput
              value={contactEmail}
              onChangeText={setContactEmail}
              placeholder="you@example.com"
              placeholderTextColor={colors.textMuted}
              keyboardType="email-address"
              autoCapitalize="none"
              style={styles.contactInput}
            />
            <Text style={styles.label}>Seats</Text>
            {seatsLoading ? <ActivityIndicator size="small" color={colors.primary} /> : null}
            {seatsError ? <Text style={styles.errorText}>{seatsError}</Text> : null}
            {!seatsLoading && !seatsError && seatsData?.seatSelection && seatsData.seats ? (
              <View>
                <View style={styles.seatLegend}>
                  <Text style={styles.noticeText}>Available</Text>
                  <Text style={styles.noticeText}>Selected: {selectedSeats.length}/{partySize}</Text>
                  <Text style={styles.noticeText}>Greyed out: occupied</Text>
                </View>
                <View style={styles.seatGrid}>
                  {seatsData.seats.map((seat) => {
                    const selected = selectedSeats.includes(seat.label);
                    const canSelect = !seat.booked && (selected || selectedSeats.length < partySize);
                    return (
                      <Pressable
                        key={seat.label}
                        disabled={!canSelect}
                        onPress={() => setSelectedSeats((current) =>
                          current.includes(seat.label)
                            ? current.filter((label) => label !== seat.label)
                            : [...current, seat.label]
                        )}
                        accessibilityRole="button"
                        accessibilityState={{ selected, disabled: !canSelect }}
                        accessibilityLabel={`Seat ${seat.label}${seat.booked ? ", occupied" : selected ? ", selected" : ""}`}
                        style={[
                          styles.seat,
                          selected && styles.seatSelected,
                          seat.booked && styles.seatBooked,
                        ]}
                      >
                        <Text style={[styles.seatText, selected && styles.seatTextSelected]}>{seat.label}</Text>
                      </Pressable>
                    );
                  })}
                </View>
                {!seatsMatchParty ? (
                  <Text style={styles.errorText}>Select exactly one seat per passenger ({partySize} needed).</Text>
                ) : null}
              </View>
            ) : null}
            {!seatsLoading && !seatsError && seatsData && !seatsData.seatSelection ? (
              <Text style={styles.noticeText}>
                No seat map for this service — {seatsAvailableNote ?? "seats are allocated by the operator."}
              </Text>
            ) : null}
            {!seatsLoading && !seatsError && !seatsData && validTravelDate ? (
              <Text style={styles.noticeText}>Select a travel date to load seat availability.</Text>
            ) : null}
            <View style={styles.priceBox}>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>
                  {transportPerPerson
                    ? `NPR ${transportUnit.toLocaleString("en-IN")} × ${partySize} passenger${partySize === 1 ? "" : "s"}`
                    : `${vehicle?.type || "Transport"} hire`}
                </Text>
                <Text style={styles.priceValue}>NPR {transportTotal.toLocaleString("en-IN")}</Text>
              </View>
              <Text style={styles.noticeText}>No additional fees. The server confirms the final payable amount when you book.</Text>
              <View style={[styles.priceRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>NPR {transportTotal.toLocaleString("en-IN")}</Text>
              </View>
            </View>
          </View>
        ) : activity ? (
          <View>
            {activityMinAge >= 18 ? (
              <View style={styles.ageBanner}>
                <Ionicons name="alert-circle" size={20} color="#B91C1C" />
                <Text style={styles.ageBannerText}>18+ Only — all participants must be 18 or older.</Text>
              </View>
            ) : activityMinAge > 0 ? (
              <View style={styles.ageBanner}>
                <Ionicons name="information-circle-outline" size={20} color="#92400E" />
                <Text style={[styles.ageBannerText, { color: "#92400E" }]}>Age {activityMinAge}+ — every participant must qualify.</Text>
              </View>
            ) : null}
            {activity?.durationMinutes !== undefined ? (
              <Text style={styles.noticeText}>Duration: {activity.durationMinutes} minutes</Text>
            ) : null}
            <BSADDatePicker
              label="Activity date"
              value={travelDate}
              onChange={setTravelDate}
              minDate={todayAdISO()}
              placeholder="Select activity date"
            />
            {!validTravelDate && travelDate ? <Text style={styles.errorText}>Select a valid future activity date.</Text> : null}
            <Text style={styles.label}>Time slot</Text>
            {slotLoading ? <ActivityIndicator size="small" color={colors.primary} /> : null}
            {slotError ? <Text style={styles.errorText}>{slotError}</Text> : null}
            {!slotLoading && !slotError && slotRequired ? (
              <View style={styles.roomTypes}>
                {slotOptions.map((slot) => {
                  const fits = slot.available >= partySize;
                  const selected = selectedSlot === slot.time;
                  return (
                    <Pressable
                      key={slot.time}
                      disabled={!fits}
                      accessibilityRole="button"
                      accessibilityState={{ selected, disabled: !fits }}
                      onPress={() => setSelectedSlot(slot.time ?? "")}
                      style={[styles.roomTypeOption, selected && styles.roomTypeOptionSelected, !fits && styles.roomTypeOptionDisabled]}
                    >
                      <Ionicons
                        name={selected ? "radio-button-on" : "radio-button-off"}
                        size={19}
                        color={selected ? colors.primary : colors.textMuted}
                      />
                      <View style={styles.roomTypeDescription}>
                        <Text style={styles.roomTypeName}>{slot.time}</Text>
                        <Text style={styles.noticeText}>
                          {slot.available} of {slot.capacity} places left
                        </Text>
                      </View>
                    </Pressable>
                  );
                })}
                {!selectedSlotOk && selectedSlot ? (
                  <Text style={styles.errorText}>That slot no longer has enough places for your group. Pick another time.</Text>
                ) : null}
              </View>
            ) : null}
            {!slotLoading && !slotError && !slotRequired && slotData ? (
              <Text style={styles.noticeText}>Available all day on the selected date.</Text>
            ) : null}
            {!slotLoading && !slotError && !slotData && validTravelDate ? (
              <Text style={styles.noticeText}>Select an activity date to load available time slots.</Text>
            ) : null}
            <View style={styles.guestControls}>
              <Counter label="Adults" value={adults} minimum={1} maximum={20 - children} onChange={setAdults} />
              <Counter label="Children" value={children} minimum={0} maximum={20 - adults} onChange={setChildren} />
            </View>
            <Text style={styles.label}>Lead participant full name</Text>
            <TextInput
              value={contactName}
              onChangeText={setContactName}
              placeholder="Enter participant name"
              placeholderTextColor={colors.textMuted}
              autoCapitalize="words"
              style={styles.contactInput}
            />
            <Text style={styles.label}>Phone number</Text>
            <View style={styles.phoneRow}>
              <Pressable
                style={styles.phonePrefix}
                accessibilityRole="button"
                accessibilityLabel={`Country calling code, currently ${activityPhoneRule.flag} ${activityPhoneRule.name} ${activityPhoneRule.code}`}
                onPress={() => {
                  setCountryQuery("");
                  setCountryPickerOpen(true);
                }}
              >
                <Text style={styles.phonePrefixText}>{activityPhoneRule.flag} {activityPhoneRule.code}</Text>
                <Ionicons name="chevron-down" size={16} color={colors.textMuted} />
              </Pressable>
              <TextInput
                value={activityPhoneDigits}
                onChangeText={(value) => {
                  setContactPhone(`${phoneCountryCode}${value.replace(/\D/g, "").slice(0, activityPhoneRule.max)}`);
                }}
                placeholder={phoneCountryCode === NEPAL_PHONE.code ? "98XXXXXXXX" : "Enter phone number"}
                placeholderTextColor={colors.textMuted}
                keyboardType="number-pad"
                maxLength={activityPhoneRule.max}
                style={[styles.contactInput, styles.phoneInput]}
              />
            </View>
            <Text style={styles.hintText}>
              {activityPhoneRule.min === activityPhoneRule.max
                ? `Enter exactly ${activityPhoneRule.min} digits after ${activityPhoneRule.code}.`
                : `Enter ${activityPhoneRule.min}–${activityPhoneRule.max} digits after ${activityPhoneRule.code}.`}
            </Text>
            {contactPhone.trim() !== "" && !contactPhoneValidActivity ? (
              <Text style={styles.errorText}>{activityPhoneMessage}</Text>
            ) : null}
            <Modal
              visible={countryPickerOpen}
              transparent
              animationType="fade"
              onRequestClose={() => setCountryPickerOpen(false)}
            >
              <View style={styles.countryBackdrop}>
                <View style={styles.countryCard}>
                  <Text style={styles.countryTitle}>Select country code</Text>
                  <TextInput
                    value={countryQuery}
                    onChangeText={setCountryQuery}
                    placeholder="Search country or code"
                    placeholderTextColor={colors.textMuted}
                    autoCapitalize="none"
                    style={styles.contactInput}
                  />
                  <ScrollView style={styles.countryList} keyboardShouldPersistTaps="handled">
                    {COUNTRY_PHONE_RULES.filter((rule) => {
                      const query = countryQuery.trim().toLowerCase();
                      if (!query) return true;
                      const digits = query.replace(/\D/g, "");
                      return (
                        rule.name.toLowerCase().includes(query) ||
                        rule.code.toLowerCase().includes(query) ||
                        (!!digits && rule.code.replace(/\D/g, "").startsWith(digits))
                      );
                    }).map((rule) => {
                      const selected = rule.code === phoneCountryCode;
                      return (
                        <Pressable
                          key={rule.code}
                          accessibilityRole="button"
                          accessibilityState={{ selected }}
                          accessibilityLabel={`${rule.name} ${rule.code}`}
                          style={[styles.countryRow, selected && styles.countryRowSelected]}
                          onPress={() => changePhoneCountry(rule.code)}
                        >
                          <Text style={styles.countryFlag}>{rule.flag}</Text>
                          <Text style={styles.countryName}>{rule.name}</Text>
                          <Text style={styles.countryCode}>{rule.code}</Text>
                          {selected ? <Ionicons name="checkmark" size={18} color={colors.primaryDark} /> : null}
                        </Pressable>
                      );
                    })}
                  </ScrollView>
                  <Pressable
                    style={styles.secondaryButton}
                    accessibilityRole="button"
                    onPress={() => setCountryPickerOpen(false)}
                  >
                    <Text style={styles.secondaryButtonText}>Cancel</Text>
                  </Pressable>
                </View>
              </View>
            </Modal>
            <Text style={styles.label}>Email for booking updates</Text>
            <TextInput
              value={contactEmail}
              onChangeText={setContactEmail}
              placeholder="Enter email address"
              placeholderTextColor={colors.textMuted}
              keyboardType="email-address"
              autoCapitalize="none"
              style={styles.contactInput}
            />
            {activityMinAge > 0 ? (
              <View>
                <Text style={styles.label}>Participant ages (checked against {activityMinAge}+)</Text>
                {ageInputs.map((rawAge, index) => {
                  const trimmed = rawAge.trim();
                  const age = ageValues[index] ?? null;
                  const ok = age !== null && age >= activityMinAge;
                  return (
                    <View key={`age-${index}`}>
                      <Text style={styles.label}>{`Participant ${index + 1} — age`}</Text>
                      <TextInput
                        value={rawAge}
                        onChangeText={(value) =>
                          setAgeInputs((current) => current.map((entry, i) => (i === index ? value.replace(/\D/g, "").slice(0, 3) : entry)))
                        }
                        placeholder="Age in years"
                        placeholderTextColor={colors.textMuted}
                        keyboardType="number-pad"
                        maxLength={3}
                        style={styles.contactInput}
                      />
                      {!!trimmed && (
                        <Text style={age !== null && ok ? styles.ageOkText : styles.errorText}>
                          {age === null
                            ? "Enter an age between 0 and 120."
                            : ok
                              ? `Age ${age} — eligible.`
                              : `Age ${age} — NOT eligible. This activity is restricted to participants aged ${activityMinAge} and above.`}
                        </Text>
                      )}
                    </View>
                  );
                })}
                {agesValid && !ageEligible ? (
                  <Text style={styles.errorText}>
                    This activity is restricted to participants aged {activityMinAge} and above. Remove or replace ineligible participants to continue.
                  </Text>
                ) : null}
              </View>
            ) : null}
            <View style={styles.priceBox}>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>
                  {`NPR ${activityUnit.toLocaleString("en-IN")} × ${partySize} participant${partySize === 1 ? "" : "s"}`}
                </Text>
                <Text style={styles.priceValue}>NPR {activityTotal.toLocaleString("en-IN")}</Text>
              </View>
              <Text style={styles.noticeText}>No additional fees. The server confirms the final payable amount when you book.</Text>
              <View style={[styles.priceRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>NPR {activityTotal.toLocaleString("en-IN")}</Text>
              </View>
            </View>
          </View>
        ) : (
          <View>
            <Text style={styles.noticeText}>Transport and activity bookings are handled in the guided destination trip planner with real demo inventory and sandbox payment.</Text>
            <Pressable
              style={styles.confirmButton}
              onPress={() => navigation.navigate("DestinationTrip", {})}
              accessibilityRole="button"
              accessibilityLabel="Open guided destination trip planner"
            >
              <Text style={styles.confirmButtonText}>Open trip planner</Text>
            </Pressable>
          </View>
        )}

        {!!requestNotice && <Text style={styles.noticeText}>{requestNotice}</Text>}
        {!!requestError && <Text style={styles.errorText}>{requestError}</Text>}

        <Pressable
          style={[styles.confirmButton, hotel && styles.hotelRequestButton, confirmDisabled && styles.disabledButton]}
          onPress={confirmBookingRequest}
          disabled={confirmDisabled}
        >
          {submitting ? <ActivityIndicator color={colors.white} /> : <Text style={styles.confirmButtonText}>{hotel ? "Send pending booking request" : vehicle || activity ? "Book Now" : "Booking provider unavailable"}</Text>}
        </Pressable>
        {hotel?.id ? (
          <Pressable
            style={styles.tripButton}
            onPress={addHotelToTrip}
            accessibilityRole="button"
          >
            <Ionicons name="airplane-outline" size={18} color={colors.primaryDark} />
            <Text style={styles.tripButtonText}>Add to My Trip</Text>
          </Pressable>
        ) : null}
      </ScrollView>

    </SafeAreaView>
  );
}

function Counter({
  label,
  value,
  minimum,
  maximum,
  onChange,
}: {
  label: string;
  value: number;
  minimum: number;
  maximum: number;
  onChange: (value: number) => void;
}) {
  return (
    <View style={styles.counterField}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.counterRow}>
        <Pressable style={styles.counterBtn} disabled={value <= minimum} onPress={() => onChange(value - 1)}>
          <Ionicons name="remove" size={18} color={value <= minimum ? colors.textMuted : colors.text} />
        </Pressable>
        <Text style={styles.counterValue}>{value}</Text>
        <Pressable style={styles.counterBtn} disabled={value >= maximum} onPress={() => onChange(value + 1)}>
          <Ionicons name="add" size={18} color={value >= maximum ? colors.textMuted : colors.text} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.md,
    paddingTop: spacing.lg,
  },
  backButton: {
    marginBottom: spacing.lg,
  },
  header: {
    fontSize: 20,
    fontWeight: "bold",
    color: colors.text,
    marginBottom: spacing.lg,
  },
  hotelCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  hotelImage: {
    height: 150,
    backgroundColor: colors.border,
    borderRadius: radius.sm,
    marginBottom: spacing.md,
  },
  hotelName: {
    fontSize: 16,
    fontWeight: "bold",
    color: colors.text,
  },
  hotelLocation: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 4,
  },
  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  contactInput: {
    minHeight: 42,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    color: colors.text,
    marginTop: spacing.xs,
    marginBottom: spacing.sm,
  },
  phoneRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  phonePrefix: {
    minHeight: 42,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.background,
    paddingHorizontal: spacing.sm,
    marginTop: spacing.xs,
    marginBottom: spacing.sm,
  },
  phonePrefixText: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  phoneInput: {
    flex: 1,
  },
  hintText: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: -spacing.xs,
    marginBottom: spacing.sm,
  },
  secondaryButton: {
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    marginTop: spacing.sm,
  },
  secondaryButtonText: {
    color: colors.primaryDark,
    fontSize: 14,
    fontWeight: "700",
  },
  countryBackdrop: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: spacing.lg,
    backgroundColor: "rgba(15, 23, 42, 0.45)",
  },
  countryCard: {
    width: "100%",
    maxWidth: 420,
    maxHeight: "80%",
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    padding: spacing.md,
  },
  countryTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: "800",
    marginBottom: spacing.sm,
  },
  countryList: {
    maxHeight: 320,
    marginTop: spacing.sm,
  },
  countryRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    minHeight: 48,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.sm,
  },
  countryRowSelected: {
    backgroundColor: "#E8F3F0",
  },
  countryFlag: {
    fontSize: 20,
  },
  countryName: {
    flex: 1,
    color: colors.text,
    fontSize: 14,
  },
  countryCode: {
    color: colors.textMuted,
    fontSize: 14,
    fontWeight: "700",
  },
  routeSummary: {
    fontSize: 16,
    fontWeight: "800",
    color: colors.text,
    marginBottom: spacing.xs,
  },
  ageBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    backgroundColor: "#FEF2F2",
    borderWidth: 1,
    borderColor: "#FECACA",
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  ageBannerText: {
    flex: 1,
    color: "#B91C1C",
    fontSize: 14,
    fontWeight: "800",
  },
  ageOkText: {
    color: "#047857",
    fontSize: 12,
    fontWeight: "700",
    marginBottom: spacing.sm,
  },
  seatLegend: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: spacing.sm,
  },
  seatGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: spacing.sm,
  },
  seat: {
    minWidth: 46,
    minHeight: 40,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.surface,
    paddingHorizontal: 8,
  },
  seatSelected: {
    borderColor: colors.primary,
    backgroundColor: "#E8F3F0",
  },
  seatBooked: {
    opacity: 0.4,
    backgroundColor: colors.border,
  },
  seatText: {
    color: colors.text,
    fontSize: 12,
    fontWeight: "700",
  },
  seatTextSelected: {
    color: colors.primaryDark,
  },
  dateInput: {
    minHeight: 42,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    color: colors.text,
    marginTop: spacing.xs,
    marginBottom: spacing.sm,
  },
  guestControls: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  roomTypes: { marginTop: spacing.lg, gap: spacing.sm },
  roomTypeOption: { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, padding: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, backgroundColor: colors.surface },
  roomTypeOptionSelected: { borderColor: colors.primary, backgroundColor: "#E8F3F0" },
  roomTypeOptionDisabled: { opacity: 0.5 },
  roomTypeDescription: { flex: 1, gap: 3 },
  roomTypeName: { color: colors.text, fontSize: 13, fontWeight: "800" },
  counterField: {
    minWidth: "30%",
  },
  label: {
    color: colors.textMuted,
    fontSize: 13,
  },
  value: {
    fontWeight: "600",
    fontSize: 13,
    color: colors.text,
  },
  counterRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  counterBtn: {
    width: 30,
    height: 30,
    borderRadius: radius.full,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
  },
  counterValue: {
    fontWeight: "bold",
    fontSize: 14,
    color: colors.text,
  },
  priceBox: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginTop: spacing.lg,
    marginBottom: spacing.lg,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 1,
  },
  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: spacing.sm,
  },
  priceLabel: {
    color: colors.textMuted,
    fontSize: 13,
  },
  priceValue: {
    color: colors.text,
    fontWeight: "600",
    fontSize: 13,
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.sm,
    marginTop: spacing.sm,
  },
  totalLabel: {
    fontWeight: "bold",
    fontSize: 14,
    color: colors.text,
  },
  totalValue: {
    fontWeight: "bold",
    fontSize: 16,
    color: colors.primaryDark,
  },
  confirmButton: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    minHeight: 52,
    justifyContent: "center",
    borderRadius: radius.md,
    alignItems: "center",
    marginBottom: spacing.xl,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 3,
  },
  hotelRequestButton: {
    marginTop: spacing.md,
  },
  tripButton: {
    minHeight: 44,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    marginBottom: spacing.xl,
  },
  tripButtonText: {
    color: colors.primaryDark,
    fontSize: 13,
    fontWeight: "800",
  },
  confirmButtonText: {
    color: colors.white,
    fontWeight: "bold",
    fontSize: 15,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(15, 23, 42, 0.45)",
  },
  paymentSheet: {
    backgroundColor: colors.background,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    paddingBottom: spacing.xl,
  },
  paymentHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.md,
  },
  paymentTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "700",
  },
  paymentNotice: {
    color: colors.textMuted,
    fontSize: 13,
    lineHeight: 19,
    marginBottom: spacing.md,
  },
  paymentOption: {
    minHeight: 58,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  paymentOptionSelected: {
    borderColor: colors.primary,
    backgroundColor: "#EFF8F5",
  },
  paymentOptionCopy: {
    gap: 3,
  },
  paymentOptionName: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "700",
  },
  paymentOptionDetail: {
    color: colors.textMuted,
    fontSize: 12,
  },
  noticeText: {
    color: colors.textMuted,
    fontSize: 12,
    lineHeight: 18,
    marginBottom: spacing.md,
  },
  errorText: {
    color: "#B91C1C",
    fontSize: 12,
    lineHeight: 17,
    marginBottom: spacing.sm,
  },
  disabledButton: {
    opacity: 0.6,
  },
});