import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BottomTabScreenProps } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import { MainTabParamList } from "../navigation/MainTabs";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import BSADDatePicker from "../components/BSADDatePicker";
import { todayAdISO } from "../utils/bsDate";
import { colors, radius, spacing } from "../theme";

type Props = BottomTabScreenProps<MainTabParamList, "Trips">;
type TripRecord = {
  _id: string;
  name: string;
  destination?: string;
  startDate?: string;
  endDate?: string;
  notes?: string;
  status?: string;
  hotelId?: string;
  hotelName?: string;
  hotelLocation?: string;
  hotelLatitude?: number;
  hotelLongitude?: number;
  plannedItems?: Array<{
    itemId: string;
    category: string;
    name: string;
    location?: string;
    latitude?: number;
    longitude?: number;
  }>;
};

type SummaryBooking = {
  _id: string;
  bookingCode: string;
  itemType?: string;
  itemName: string;
  checkIn?: string;
  serviceTime?: string;
  amount?: number;
  currency?: string;
  status?: string;
  paymentStatus?: string;
  payment?: {
    status?: string;
    reference?: string;
  } | null;
};

type TripSummary = {
  bookings: SummaryBooking[];
  totals: {
    subtotal: number;
    taxesAndFees: number;
    total: number;
    currency: string;
    demo: boolean;
  };
};

function summaryItemIcon(itemType?: string): keyof typeof Ionicons.glyphMap {
  const value = (itemType ?? "").toLowerCase();
  if (value === "hotel") return "bed-outline";
  if (value === "transport") return "bus-outline";
  if (value === "restaurant") return "restaurant-outline";
  if (value === "activity") return "walk-outline";
  return "receipt-outline";
}

function summaryBookingDate(booking: SummaryBooking): string {
  const raw = booking.checkIn ?? booking.serviceTime;
  if (!raw) return "Date to be confirmed";
  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return raw;
  return parsed.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

function isDateInputValid(value: string): boolean {
  if (!value) return true;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

export default function TripsScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const selectedGem = route.params?.destination;
  const selectedHotel = route.params?.hotel;
  const [destinationName, setDestinationName] = useState(selectedGem?.name ?? selectedHotel?.location ?? "");
  const [startDate, setStartDate] = useState(selectedHotel?.checkIn ?? "");
  const [endDate, setEndDate] = useState(selectedHotel?.checkOut ?? "");
  const [itineraryNotes, setItineraryNotes] = useState("");
  const [trips, setTrips] = useState<TripRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [expandedTripId, setExpandedTripId] = useState<string | null>(null);
  const [summaries, setSummaries] = useState<Record<string, TripSummary>>({});
  const [summaryLoadingId, setSummaryLoadingId] = useState<string | null>(null);
  const [summaryError, setSummaryError] = useState("");
  // Enter-key focus chain for the create-trip form.
  const destinationRef = useRef<TextInput>(null);

  useEffect(() => {
    if (selectedGem) {
      setDestinationName(selectedGem.name);
      setNotice(`${selectedGem.name} is ready to add to your trip.`);
    } else if (selectedHotel) {
      setDestinationName(selectedHotel.location ?? selectedHotel.name);
      setNotice(`${selectedHotel.name} is ready to add to your trip.`);
    }
  }, [selectedGem, selectedHotel]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId) {
        setTrips([]);
        setLoading(false);
        return;
      }
      const controller = new AbortController();
      setLoading(true);
      setError("");
      backendRequest<TripRecord[]>(`/trips?userId=${encodeURIComponent(userId)}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(setTrips)
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setError(requestError instanceof Error ? requestError.message : "Could not load your trips.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
      return () => controller.abort();
    }, [getAccessToken, userId])
  );

  const createTrip = async () => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.getParent()?.navigate("Login" as never);
      return;
    }
    const cleanDestination = destinationName.trim();
    if (!cleanDestination) {
      setError("Enter a destination to create your trip.");
      return;
    }
    if (!isDateInputValid(startDate) || !isDateInputValid(endDate)) {
      setError("Enter travel dates in YYYY-MM-DD format.");
      return;
    }
    if (startDate && endDate && endDate < startDate) {
      setError("The end date must be on or after the start date.");
      return;
    }

    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      const created = await backendRequest<TripRecord>("/trips", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userId,
          name: `Trip to ${cleanDestination}`,
          destination: cleanDestination,
          startDate: startDate || undefined,
          endDate: endDate || undefined,
          notes: itineraryNotes.trim(),
          status: "planned",
          hotelId: selectedHotel?.id,
          plannedItems: selectedGem?.id ? [{
            itemId: selectedGem.id,
            category: selectedGem.category ?? selectedGem.tags?.[0] ?? "place",
            name: selectedGem.name,
            location: selectedGem.location,
            latitude: selectedGem.latitude,
            longitude: selectedGem.longitude,
          }] : undefined,
        }),
      });
      setTrips((current) => [created, ...current]);
      setNotice(`Your trip to ${cleanDestination} was added to My Trips.`);
      setItineraryNotes("");
      setStartDate("");
      setEndDate("");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not create this trip.");
    } finally {
      setSubmitting(false);
    }
  };

  const removeTrip = async (trip: TripRecord) => {
    const token = getAccessToken();
    if (!token) {
      setError("Sign in again to update your trips.");
      return;
    }
    setError("");
    try {
      await backendRequest(`/trips/${trip._id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      setTrips((current) => current.filter((item) => item._id !== trip._id));
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not remove this trip.");
    }
  };

  const toggleSummary = async (trip: TripRecord) => {
    if (expandedTripId === trip._id) {
      setExpandedTripId(null);
      return;
    }
    setExpandedTripId(trip._id);
    setSummaryError("");
    if (summaries[trip._id]) return;
    const token = getAccessToken();
    if (!token) {
      setSummaryError("Sign in again to view the trip summary.");
      return;
    }
    setSummaryLoadingId(trip._id);
    try {
      const summary = await backendRequest<TripSummary>(`/trips/${trip._id}/summary`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSummaries((current) => ({ ...current, [trip._id]: summary }));
    } catch (requestError) {
      setSummaryError(requestError instanceof Error ? requestError.message : "Could not load the trip summary.");
    } finally {
      setSummaryLoadingId(null);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>YOUR NEXT JOURNEY</Text>
        <Text style={styles.header}>My Trips</Text>
        <Text style={styles.subText}>Build an itinerary around a place you want to explore.</Text>
        <Pressable
          style={styles.planButton}
          onPress={() => navigation.getParent()?.navigate("PlanMyTrip" as never)}
          accessibilityRole="button"
          accessibilityLabel="Open Plan My Trip"
        >
          <Ionicons name="map-outline" size={19} color={colors.white} />
          <Text style={styles.primaryButtonText}>Plan My Trip</Text>
          <Ionicons name="arrow-forward" size={17} color={colors.white} />
        </Pressable>

        {!userId ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Sign in to plan and save trips</Text>
            <Pressable style={styles.primaryButton} onPress={() => navigation.getParent()?.navigate("Login" as never)}>
              <Text style={styles.primaryButtonText}>Sign in</Text>
            </Pressable>
          </View>
        ) : (
          <View style={styles.card}>
            <View style={styles.formHeading}>
              <View style={styles.formIcon}>
                <Ionicons name="map-outline" size={20} color={colors.primary} />
              </View>
              <View style={styles.formHeadingText}>
                <Text style={styles.cardTitle}>Plan an itinerary</Text>
                <Text style={styles.formHint}>Start with your destination; dates and notes are optional.</Text>
              </View>
            </View>
            {selectedGem ? (
              <View style={styles.selectedGem}>
                <Ionicons name="sparkles-outline" size={16} color={colors.primaryDark} />
                <Text style={styles.selectedGemText}>
                  Hidden Gem selected: {selectedGem.name}
                  {selectedGem.location ? ` · ${selectedGem.location}` : ""}
                </Text>
              </View>
            ) : null}
            <Text style={styles.label}>Destination</Text>
            <TextInput
              value={destinationName}
              onChangeText={setDestinationName}
              placeholder="Where do you want to go?"
              placeholderTextColor={colors.textMuted}
              style={styles.input}
              ref={destinationRef}
              returnKeyType="go"
              onSubmitEditing={() => void createTrip()}
            />
            <View style={styles.dateRow}>
              <View style={styles.dateField}>
                <BSADDatePicker
                  label="Start date"
                  value={startDate}
                  onChange={setStartDate}
                  minDate={todayAdISO()}
                  placeholder="Select start date"
                />
              </View>
              <View style={styles.dateField}>
                <BSADDatePicker
                  label="End date"
                  value={endDate}
                  onChange={setEndDate}
                  minDate={startDate || todayAdISO()}
                  placeholder="Select end date"
                />
              </View>
            </View>
            <Text style={styles.label}>Itinerary notes</Text>
            <TextInput
              value={itineraryNotes}
              onChangeText={setItineraryNotes}
              placeholder="Add activities, stops, or reminders for your trip"
              placeholderTextColor={colors.textMuted}
              style={[styles.input, styles.notesInput]}
              multiline
              textAlignVertical="top"
            />
            {error ? <Text style={styles.errorText}>{error}</Text> : null}
            {notice ? <Text style={styles.noticeText}>{notice}</Text> : null}
            <Pressable
              style={[styles.primaryButton, submitting && styles.disabledButton]}
              onPress={() => void createTrip()}
              disabled={submitting}
              accessibilityRole="button"
            >
              {submitting ? (
                <ActivityIndicator color={colors.white} />
              ) : (
                <>
                  <Ionicons name="add-circle-outline" size={19} color={colors.white} />
                  <Text style={styles.primaryButtonText}>Create trip</Text>
                </>
              )}
            </Pressable>
          </View>
        )}

        <View style={styles.tripsHeader}>
          <Text style={styles.sectionTitle}>Your saved trips</Text>
          {loading ? <ActivityIndicator size="small" color={colors.primary} /> : null}
        </View>
        {error && userId ? <Text style={styles.errorText}>{error}</Text> : null}
        {!loading && !error && trips.length === 0 && userId ? (
          <View style={styles.emptyState}>
            <Ionicons name="airplane-outline" size={30} color={colors.primary} />
            <Text style={styles.emptyTitle}>Your trip list is ready</Text>
            <Text style={styles.emptyText}>Create a trip above and add the places and itinerary notes you want to remember.</Text>
          </View>
        ) : null}
        {trips.map((trip) => {
          const summary = summaries[trip._id];
          const isExpanded = expandedTripId === trip._id;
          return (
          <View key={trip._id} style={styles.tripCard}>
            <View style={styles.tripTopRow}>
            <View style={styles.tripIcon}>
              <Ionicons name="airplane-outline" size={19} color={colors.primaryDark} />
            </View>
            <View style={styles.tripText}>
              <Text style={styles.tripTitle}>{trip.name}</Text>
              {trip.destination ? <Text style={styles.tripDetail}>{trip.destination}</Text> : null}
              {trip.hotelName ? <Text style={styles.tripDetail}>Stay: {trip.hotelName}{trip.hotelLocation ? ` · ${trip.hotelLocation}` : ""}</Text> : null}
              {trip.plannedItems?.map((item) => (
                <Text key={`${item.category}-${item.itemId}`} style={styles.tripDetail}>
                  {item.category}: {item.name}{item.location ? ` · ${item.location}` : ""}
                </Text>
              ))}
              {trip.startDate || trip.endDate ? (
                <Text style={styles.tripDetail}>
                  {[trip.startDate, trip.endDate].filter(Boolean).map((date) => new Date(date as string).toLocaleDateString()).join(" – ")}
                </Text>
              ) : null}
              {trip.notes ? <Text style={styles.tripNotes}>{trip.notes}</Text> : null}
            </View>
            <Pressable
              onPress={() => navigation.getParent()?.navigate({ name: "PlanMyTrip", params: { tripId: trip._id } } as never)}
              accessibilityRole="button"
              accessibilityLabel={`Edit ${trip.name}`}
              style={styles.tripAction}
            >
              <Ionicons name="create-outline" size={19} color={colors.primary} />
            </Pressable>
            <Pressable
              onPress={() => void removeTrip(trip)}
              accessibilityRole="button"
              accessibilityLabel={`Remove ${trip.name}`}
              style={styles.tripAction}
            >
              <Ionicons name="trash-outline" size={19} color={colors.textMuted} />
            </Pressable>
            </View>
            <Pressable
              onPress={() => void toggleSummary(trip)}
              accessibilityRole="button"
              accessibilityLabel={`${isExpanded ? "Hide" : "View"} summary for ${trip.name}`}
              style={styles.summaryToggle}
            >
              <Ionicons name={isExpanded ? "chevron-up" : "chevron-down"} size={16} color={colors.primary} />
              <Text style={styles.summaryToggleText}>{isExpanded ? "Hide summary" : "View summary"}</Text>
              {summaryLoadingId === trip._id ? <ActivityIndicator size="small" color={colors.primary} /> : null}
            </Pressable>
            {isExpanded ? (
              <View style={styles.summaryBox}>
                {summaryError && !summary ? <Text style={styles.errorText}>{summaryError}</Text> : null}
                {summary ? (
                  <>
                    {summary.bookings.length ? summary.bookings.map((booking) => (
                      <View key={booking._id} style={styles.summaryRow}>
                        <Ionicons name={summaryItemIcon(booking.itemType)} size={15} color={colors.primaryDark} />
                        <View style={styles.summaryRowText}>
                          <Text style={styles.summaryName}>{booking.itemName}</Text>
                          <Text style={styles.tripDetail}>
                            {summaryBookingDate(booking)} · {booking.currency ?? summary.totals.currency} {(booking.amount ?? 0).toLocaleString("en-IN")} · {booking.status ?? "n/a"}
                          </Text>
                          <Text style={styles.tripDetail}>
                            Payment: {booking.payment?.status ?? booking.paymentStatus ?? "unknown"}
                            {booking.payment?.reference ? ` · Ref ${booking.payment.reference}` : ""}
                            {booking.paymentStatus === "pending" ? " (initiated — not confirmed)" : ""}
                          </Text>
                        </View>
                      </View>
                    )) : <Text style={styles.tripDetail}>No bookings are linked to this trip yet.</Text>}
                    <View style={styles.totalsBox}>
                      <View style={styles.totalsRow}>
                        <Text style={styles.tripDetail}>Subtotal</Text>
                        <Text style={styles.tripDetail}>{summary.totals.currency} {summary.totals.subtotal.toLocaleString("en-IN")}</Text>
                      </View>
                      <View style={styles.totalsRow}>
                        <Text style={styles.tripDetail}>Taxes & fees</Text>
                        <Text style={styles.tripDetail}>{summary.totals.currency} {summary.totals.taxesAndFees.toLocaleString("en-IN")}</Text>
                      </View>
                      <View style={styles.totalsRow}>
                        <Text style={styles.summaryTotalLabel}>Total</Text>
                        <Text style={styles.summaryTotalValue}>{summary.totals.currency} {summary.totals.total.toLocaleString("en-IN")}</Text>
                      </View>
                      <Text style={styles.demoNote}>Totals use demo pricing with no provider fees — not live billing data.</Text>
                    </View>
                    <Pressable
                      onPress={() => navigation.getParent()?.navigate("Bookings" as never)}
                      accessibilityRole="button"
                      accessibilityLabel="Open linked bookings in My Bookings"
                      style={styles.openBookingsButton}
                    >
                      <Text style={styles.openBookingsText}>Open in bookings</Text>
                    </Pressable>
                  </>
                ) : summaryLoadingId === trip._id ? (
                  <Text style={styles.tripDetail}>Loading summary…</Text>
                ) : null}
              </View>
            ) : null}
          </View>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: 110 },
  eyebrow: { color: colors.primaryDark, fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginTop: spacing.md },
  header: { fontSize: 27, fontWeight: "900", color: colors.text, marginTop: 3 },
  subText: { fontSize: 13, lineHeight: 19, color: colors.textMuted, marginTop: 5, marginBottom: spacing.lg },
  planButton: { minHeight: 46, borderRadius: radius.md, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, marginBottom: spacing.md },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md },
  formHeading: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  formIcon: { width: 40, height: 40, alignItems: "center", justifyContent: "center", borderRadius: radius.md, backgroundColor: "#E8F3F0" },
  formHeadingText: { flex: 1 },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: "800" },
  formHint: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 2 },
  selectedGem: { flexDirection: "row", alignItems: "flex-start", gap: 7, backgroundColor: "#E8F3F0", borderRadius: radius.sm, padding: spacing.sm, marginTop: spacing.md },
  selectedGemText: { flex: 1, color: colors.primaryDark, fontSize: 12, fontWeight: "700", lineHeight: 17 },
  label: { color: colors.text, fontSize: 12, fontWeight: "700", marginTop: spacing.md, marginBottom: 5 },
  input: { minHeight: 43, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border, paddingHorizontal: spacing.md, color: colors.text, backgroundColor: "#FFFFFF", fontSize: 13 },
  dateRow: { flexDirection: "row", gap: spacing.sm },
  dateField: { flex: 1 },
  notesInput: { minHeight: 90, paddingTop: spacing.sm },
  primaryButton: { minHeight: 46, borderRadius: radius.md, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, marginTop: spacing.md },
  disabledButton: { opacity: 0.65 },
  primaryButtonText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  errorText: { color: "#B42318", fontSize: 12, lineHeight: 17, marginTop: spacing.sm },
  noticeText: { color: colors.primaryDark, fontSize: 12, lineHeight: 17, marginTop: spacing.sm },
  tripsHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: spacing.xl, marginBottom: spacing.sm },
  sectionTitle: { color: colors.text, fontSize: 17, fontWeight: "800" },
  emptyState: { backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.xl, alignItems: "center", gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 15, fontWeight: "800" },
  emptyText: { color: colors.textMuted, fontSize: 12, textAlign: "center", lineHeight: 18 },
  tripCard: { backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, padding: spacing.md, marginBottom: spacing.sm },
  tripTopRow: { flexDirection: "row", alignItems: "flex-start", gap: spacing.xs },
  tripIcon: { width: 36, height: 36, alignItems: "center", justifyContent: "center", borderRadius: radius.sm, backgroundColor: "#E8F3F0" },
  tripText: { flex: 1 },
  tripAction: { minWidth: 26, minHeight: 30, alignItems: "center", justifyContent: "center" },
  tripTitle: { color: colors.text, fontSize: 14, fontWeight: "800" },
  tripDetail: { color: colors.textMuted, fontSize: 11, marginTop: 4 },
  tripNotes: { color: colors.text, fontSize: 12, lineHeight: 18, marginTop: spacing.sm },
  summaryToggle: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: spacing.sm, paddingVertical: 6 },
  summaryToggleText: { color: colors.primary, fontSize: 12, fontWeight: "800" },
  summaryBox: { marginTop: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm, gap: spacing.sm },
  summaryRow: { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm },
  summaryRowText: { flex: 1 },
  summaryName: { color: colors.text, fontSize: 13, fontWeight: "800" },
  totalsBox: { backgroundColor: colors.background, borderRadius: radius.sm, padding: spacing.sm, gap: 4 },
  totalsRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  summaryTotalLabel: { color: colors.text, fontSize: 13, fontWeight: "800" },
  summaryTotalValue: { color: colors.primary, fontSize: 13, fontWeight: "800" },
  demoNote: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 4 },
  openBookingsButton: { minHeight: 42, borderRadius: radius.md, backgroundColor: colors.primary, alignItems: "center", justifyContent: "center" },
  openBookingsText: { color: colors.white, fontSize: 13, fontWeight: "800" },
});
