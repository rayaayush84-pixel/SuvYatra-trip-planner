import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { HiddenGemDetails, RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "HiddenGemDetail">;
type SavedItem = { _id: string; itemType: string; name: string };
type HotelRecord = {
  _id: string;
  name: string;
  location?: string;
  city?: string;
  image?: string;
};
type RestaurantRecord = {
  _id: string;
  name: string;
  location?: string;
  city?: string;
  image?: string;
};

const NOT_PROVIDED = "Not provided in current destination data.";

export default function HiddenGemDetailScreen({ navigation, route }: Props) {
  const gem = route.params.gem;
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const locationQuery = gem.location?.split(",")[0]?.trim() ?? "";
  const [savedItem, setSavedItem] = useState<SavedItem | null>(null);
  const [savedLoading, setSavedLoading] = useState(false);
  const [savedError, setSavedError] = useState("");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };
  const [hotels, setHotels] = useState<HotelRecord[]>([]);
  const [restaurants, setRestaurants] = useState<RestaurantRecord[]>([]);
  const [hotelError, setHotelError] = useState("");
  const [restaurantError, setRestaurantError] = useState("");
  const [nearbyLoading, setNearbyLoading] = useState(false);
  const [mapsError, setMapsError] = useState("");

  useEffect(() => {
    const token = getAccessToken();
    if (!token || !userId) {
      setSavedItem(null);
      return;
    }
    const controller = new AbortController();
    setSavedLoading(true);
    setSavedError("");
    backendRequest<SavedItem[]>(
      `/saved-items?userId=${encodeURIComponent(userId)}`,
      {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      }
    )
      .then((items) =>
        setSavedItem(
          items.find((item) => item.itemType === "hidden-gem" && item.name === gem.name) ?? null
        )
      )
      .catch((error: unknown) => {
        if (!controller.signal.aborted) {
          setSavedError(error instanceof Error ? error.message : "Could not check Saved Places.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setSavedLoading(false);
      });
    return () => controller.abort();
  }, [gem.name, getAccessToken, userId]);

  useEffect(() => {
    if (!locationQuery) return;
    const controller = new AbortController();
    setNearbyLoading(true);
    setHotelError("");
    setRestaurantError("");
    Promise.allSettled([
      backendRequest<HotelRecord[]>(
        `/hotels?search=${encodeURIComponent(locationQuery)}`,
        { signal: controller.signal }
      ),
      backendRequest<RestaurantRecord[]>(
        `/restaurants?search=${encodeURIComponent(locationQuery)}`,
        { signal: controller.signal }
      ),
    ])
      .then(([hotelResult, restaurantResult]) => {
        if (controller.signal.aborted) return;
        if (hotelResult.status === "fulfilled") {
          setHotels(hotelResult.value);
        } else {
          setHotelError(
            hotelResult.reason instanceof Error
              ? hotelResult.reason.message
              : "Could not load hotel listings."
          );
        }
        if (restaurantResult.status === "fulfilled") {
          setRestaurants(restaurantResult.value);
        } else {
          setRestaurantError(
            restaurantResult.reason instanceof Error
              ? restaurantResult.reason.message
              : "Could not load restaurant listings."
          );
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setNearbyLoading(false);
      });
    return () => controller.abort();
  }, [locationQuery]);

  const toggleSaved = async () => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", {
        notice: "Sign in to save Hidden Gems to your Saved Places.",
      });
      return;
    }
    setSaving(true);
    setSavedError("");
    try {
      if (savedItem) {
        await backendRequest(`/saved-items/${savedItem._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const item = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            userId,
            itemType: "hidden-gem",
            name: gem.name,
            location: gem.location,
            image: gem.image,
            imageSource: gem.imageSource,
            imageSourcePage: gem.imageSourcePage,
            imageLicense: gem.imageLicense,
            imageCredit: gem.imageCredit,
            imageDescription: gem.imageDescription,
            imageRelevance: gem.imageRelevance,
          }),
        });
        setSavedItem(item);
        showToast("Saved to your places");
      }
    } catch (error) {
      setSavedError(error instanceof Error ? error.message : "Could not update Saved Places.");
    } finally {
      setSaving(false);
    }
  };

  const openMaps = async () => {
    const query = [gem.name, gem.location].filter(Boolean).join(", ");
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
    setMapsError("");
    try {
      await Linking.openURL(url);
    } catch (error) {
      setMapsError(error instanceof Error ? error.message : "Could not open Google Maps.");
    }
  };

  const planTrip = () => {
    navigation.navigate("DestinationTrip", { destination: gem.name });
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <BackButton navigation={navigation} />
          <Text style={styles.headerTitle}>Explore the details</Text>
          <Pressable
            onPress={() => void toggleSaved()}
            disabled={saving || savedLoading}
            accessibilityRole="button"
            accessibilityLabel={savedItem ? "Remove from Saved Places" : "Save to Saved Places"}
          >
            {saving || savedLoading ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <Ionicons
                name={savedItem ? "heart" : "heart-outline"}
                size={24}
                color={savedItem ? "#D9435F" : colors.primary}
              />
            )}
          </Pressable>
        </View>

        <RelevantImage entity={{ name: gem.name, type: "destination", location: gem.location, image: gem.image, images: gem.images, imageSource: gem.imageSource, imageSourcePage: gem.imageSourcePage, imageLicense: gem.imageLicense, imageCredit: gem.imageCredit, imageDescription: gem.imageDescription, imageRelevance: gem.imageRelevance }} style={styles.heroPhoto} />

        <Text style={styles.name}>{gem.name}</Text>
        <View style={styles.locationRow}>
          <Ionicons name="location-outline" size={16} color={colors.primary} />
          <Text style={styles.locationText}>{gem.location ?? "Location not provided"}</Text>
        </View>
        {gem.tags?.length ? (
          <View style={styles.tagRow}>
            {gem.tags.map((tag) => <Text key={tag} style={styles.tag}>{tag}</Text>)}
          </View>
        ) : null}

        <InfoSection title="Description" text={gem.description} />
        <InfoSection title="Why is this a hidden gem?" text={gem.whyHiddenGem} />
        <InfoSection title="Why visit?" text={gem.whyVisit ?? gem.description} />
        <InfoSection title="How to reach" text={gem.howToReach ?? gem.transportation} />
        <InfoSection
          title="Transportation options"
          text={gem.transportationOptions?.join(", ") ?? gem.transportation}
        />
        <InfoSection title="Approximate travel time" text={gem.travelTime} />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Estimated budget breakdown</Text>
          <Text style={styles.disclaimer}>All amounts are estimates when supplied by the destination data.</Text>
          <View style={styles.budgetCard}>
            <BudgetRow label="Transportation" value={gem.budgetBreakdown?.transportation} />
            <BudgetRow label="Accommodation" value={gem.budgetBreakdown?.accommodation} />
            <BudgetRow label="Food" value={gem.budgetBreakdown?.food} />
            <BudgetRow label="Activities" value={gem.budgetBreakdown?.activities} />
            <BudgetRow label="Entry fees" value={gem.budgetBreakdown?.entryFees} />
            <BudgetRow label="Estimated total" value={gem.budgetBreakdown?.total} total />
          </View>
        </View>

        <InfoSection title="Accommodation" text={gem.accommodationDetails ?? gem.accommodation} />
        <InfoSection title="Food" text={gem.food} />
        <InfoSection title="Activities" text={gem.thingsToDo?.join(", ")} />
        <InfoSection title="Best season" text={gem.bestTime} />
        <InfoSection title="Recommended duration" text={gem.recommendedDuration} />
        <InfoSection title="Nearby attractions" text={gem.nearbyAttractions?.join(", ")} />
        <InfoSection title="Safety and travel tips" text={gem.safety} />

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Nearby places</Text>
          <Text style={styles.disclaimer}>
            These are backend listings matching the place's location text; distance from the gem is not verified.
          </Text>
          {nearbyLoading ? (
            <ActivityIndicator color={colors.primary} style={styles.nearbyLoader} />
          ) : !locationQuery ? (
            <Text style={styles.missingText}>Location is not available to search existing place listings.</Text>
          ) : (
            <>
              <NearbyList title="Hotels" items={hotels.map((item) => item.name)} error={hotelError} />
              <NearbyList title="Restaurants" items={restaurants.map((item) => item.name)} error={restaurantError} />
            </>
          )}
          <NearbyList title="Attractions" items={gem.nearbyAttractions ?? []} />
          <NearbyList title="Hospitals" items={[]} />
          <NearbyList title="Pharmacies" items={[]} />
          <NearbyList title="ATMs" items={[]} />
          <NearbyList title="Petrol stations" items={[]} />
          <Text style={styles.missingText}>
            The current APIs do not provide location-verified results for hospitals, pharmacies, ATMs, or petrol stations.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Weather</Text>
          <View style={styles.noticeCard}>
            <Ionicons name="partly-sunny-outline" size={22} color={colors.primary} />
            <Text style={styles.noticeText}>
              Live weather and forecasts are unavailable: this project has no configured OpenWeather integration or weather API endpoint.
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Map and location</Text>
          <Text style={styles.bodyText}>
            {gem.latitude != null && gem.longitude != null
              ? `${gem.latitude}, ${gem.longitude}`
              : "Exact coordinates are not provided; Google Maps will search by place name and location."}
          </Text>
          <ActionButton icon="map-outline" label="Open in Maps" onPress={() => void openMaps()} />
          {mapsError ? <Text style={styles.errorText}>{mapsError}</Text> : null}
        </View>

        {savedError ? <Text style={styles.errorText}>{savedError}</Text> : null}

        <View style={styles.ctaCard}>
          <Text style={styles.ctaTitle}>Would you like to plan a complete trip?</Text>
          <Text style={styles.ctaText}>
            Plan your accommodation, transportation, activities, attractions and other travel needs for {gem.name} in one place.
          </Text>
          <Pressable style={styles.planButton} onPress={planTrip} accessibilityRole="button" accessibilityLabel={`Plan a complete trip to ${gem.name}`}>
            <Ionicons name="airplane-outline" size={21} color={colors.white} />
            <Text style={styles.planButtonText}>Plan a Complete Trip</Text>
            <Ionicons name="arrow-forward" size={18} color={colors.white} />
          </Pressable>
        </View>
      </ScrollView>
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

function InfoSection({ title, text }: { title: string; text?: string }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <Text style={[styles.bodyText, !text && styles.missingText]}>{text || NOT_PROVIDED}</Text>
    </View>
  );
}

function BudgetRow({
  label,
  value,
  total = false,
}: {
  label: string;
  value?: string;
  total?: boolean;
}) {
  return (
    <View style={[styles.budgetRow, total && styles.totalRow]}>
      <Text style={[styles.budgetLabel, total && styles.totalText]}>{label}</Text>
      <Text style={[styles.budgetValue, total && styles.totalText]}>{value || "Estimate not provided"}</Text>
    </View>
  );
}

function NearbyList({
  title,
  items,
  error,
}: {
  title: string;
  items: string[];
  error?: string;
}) {
  return (
    <View style={styles.nearbyRow}>
      <Text style={styles.nearbyTitle}>{title}</Text>
      {error ? (
        <Text style={styles.errorText}>{error}</Text>
      ) : (
        <Text style={items.length ? styles.bodyText : styles.missingText}>
          {items.length ? items.join(", ") : "No matching data available."}
        </Text>
      )}
    </View>
  );
}

function ActionButton({
  icon,
  label,
  onPress,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable style={styles.secondaryButton} onPress={onPress} accessibilityRole="button">
      <Ionicons name={icon} size={18} color={colors.primaryDark} />
      <Text style={styles.secondaryButtonText}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: 50 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  headerTitle: { color: colors.text, fontSize: 16, fontWeight: "800" },
  photoStrip: { marginHorizontal: -spacing.lg, marginBottom: spacing.md },
  heroPhoto: { height: 230, width: 330, borderRadius: radius.lg, marginRight: spacing.sm },
  photoPlaceholder: { alignItems: "center", justifyContent: "center", backgroundColor: "#E8F3F0", gap: spacing.sm },
  placeholderText: { color: colors.textMuted, fontSize: 12 },
  name: { color: colors.text, fontSize: 27, fontWeight: "900", marginTop: spacing.sm },
  locationRow: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 5 },
  locationText: { color: colors.textMuted, fontSize: 13 },
  tagRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: spacing.md },
  tag: { color: colors.primaryDark, backgroundColor: "#E8F3F0", borderRadius: radius.full, paddingHorizontal: 10, paddingVertical: 6, fontSize: 11, fontWeight: "700" },
  section: { marginTop: spacing.lg },
  sectionTitle: { color: colors.text, fontSize: 15, fontWeight: "800", marginBottom: spacing.sm },
  bodyText: { color: colors.text, fontSize: 13, lineHeight: 20 },
  missingText: { color: colors.textMuted, fontSize: 12, lineHeight: 18 },
  disclaimer: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginBottom: spacing.sm },
  budgetCard: { backgroundColor: colors.surface, borderRadius: radius.md, paddingHorizontal: spacing.md },
  budgetRow: { flexDirection: "row", justifyContent: "space-between", gap: spacing.md, paddingVertical: spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  budgetLabel: { color: colors.text, fontSize: 12 },
  budgetValue: { color: colors.textMuted, flexShrink: 1, textAlign: "right", fontSize: 12 },
  totalRow: { borderBottomWidth: 0 },
  totalText: { color: colors.primaryDark, fontWeight: "800" },
  nearbyLoader: { marginVertical: spacing.md },
  nearbyRow: { paddingVertical: spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  nearbyTitle: { color: colors.text, fontSize: 12, fontWeight: "800", marginBottom: 3 },
  noticeCard: { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, borderRadius: radius.md, backgroundColor: colors.surface, padding: spacing.md },
  noticeText: { flex: 1, color: colors.textMuted, fontSize: 12, lineHeight: 18 },
  secondaryButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, minHeight: 44, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.primary, borderRadius: radius.md, marginTop: spacing.md },
  secondaryButtonText: { color: colors.primaryDark, fontSize: 13, fontWeight: "800" },
  errorText: { color: "#B42318", fontSize: 12, marginTop: spacing.sm },
  planButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.md, minHeight: 54, backgroundColor: colors.primary, borderRadius: radius.md, marginTop: spacing.md },
  planButtonText: { color: colors.white, fontSize: 15, fontWeight: "900" },
  ctaCard: { marginTop: spacing.xl, backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.lg },
  ctaTitle: { color: colors.text, fontSize: 17, fontWeight: "900" },
  ctaText: { color: colors.textMuted, fontSize: 13, lineHeight: 19, marginTop: spacing.sm },
});
