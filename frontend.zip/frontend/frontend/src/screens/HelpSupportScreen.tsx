import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "Help">;

const FAQS = [
  {
    q: "How do I book a hotel?",
    a: "Open Hotels, choose a listing, and submit a booking request with your dates and guest details. SuvYatra does not process payments; wait for the property to confirm your request.",
  },
  {
    q: "How do refunds work?",
    a: "SuvYatra does not process booking payments or refunds. Check cancellation and refund terms with the property before confirming.",
  },
  {
    q: "Is the AI travel assistant free?",
    a: "Yes! The SuvYatra Assistant is free and always ready to answer questions about destinations, itineraries, and more.",
  },
  {
    q: "How do I save a place I like?",
    a: "Tap the bookmark icon on any destination, hotel, or activity. You'll find everything in Saved Places on your profile.",
  },
  {
    q: "What should I do if I face a payment issue?",
    a: "Contact us through this screen or email support@suvyatra.com — we usually reply within a few hours.",
  },
];

const CONTACTS = [
  { icon: "mail-outline", title: "Email support", value: "support@suvyatra.com", url: "mailto:support@suvyatra.com" },
  { icon: "call-outline", title: "Hotline", value: "+977 1 400 0000", url: "tel:+97714000000" },
  { icon: "logo-whatsapp", title: "WhatsApp", value: "+977 9800 123 456", url: "https://wa.me/9779800123456" },
];

export default function HelpSupportScreen({ navigation }: Props) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [topic, setTopic] = useState("General question");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const topics = ["General question", "Booking help", "Payment", "Bug report", "Feedback"];

  const toggleFaq = (index: number) => {
    setOpenIndex((current) => (current === index ? null : index));
  };

  const openContact = async (title: string, url: string) => {
    try {
      await Linking.openURL(url);
    } catch (error) {
      Alert.alert(title, error instanceof Error ? error.message : "Could not open this contact method.");
    }
  };

  const cycleTopic = () => {
    const index = topics.indexOf(topic);
    setTopic(topics[(index + 1) % topics.length]);
  };

  const canSend = message.trim().length > 0;

  const send = async () => {
    if (!canSend) {
      return;
    }
    setSending(true);
    try {
      await backendRequest("/support", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject: topic, message: message.trim() }),
      });
      setMessage("");
      Alert.alert("Message sent", "Your support request was submitted.");
    } catch (error) {
      Alert.alert(
        "Could not send message",
        error instanceof Error ? error.message : "Please try again."
      );
    } finally {
      setSending(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.header}>
          <BackButton navigation={navigation} style={styles.backButton} />
          <Text style={styles.headerTitle}>Help & Support</Text>
          <View style={styles.headerSpacer} />
        </View>

        <ScrollView
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={styles.sectionLabel}>Frequently asked questions</Text>
          <View style={styles.card}>
            {FAQS.map((faq, index) => {
              const open = openIndex === index;
              return (
                <View key={faq.q}>
                  <Pressable
                    style={({ pressed }) => [
                      styles.faqHeader,
                      pressed && styles.rowPressed,
                    ]}
                    onPress={() => toggleFaq(index)}
                    accessibilityRole="button"
                    accessibilityState={{ expanded: open }}
                  >
                    <Text style={styles.faqQuestion}>{faq.q}</Text>
                    <Ionicons
                      name={open ? "chevron-up" : "chevron-down"}
                      size={17}
                      color={colors.textMuted}
                    />
                  </Pressable>
                  {open && <Text style={styles.faqAnswer}>{faq.a}</Text>}
                </View>
              );
            })}
          </View>

          <Text style={styles.sectionLabel}>Contact us</Text>
          <View style={styles.card}>
            {CONTACTS.map((contactItem) => (
              <Pressable
                key={contactItem.title}
                style={({ pressed }) => [
                  styles.contactRow,
                  pressed && styles.rowPressed,
                ]}
                onPress={() => void openContact(contactItem.title, contactItem.url)}
                accessibilityRole="button"
                accessibilityLabel={`Open ${contactItem.title}`}
              >
                <View style={styles.contactIcon}>
                  <Ionicons
                    name={contactItem.icon as any}
                    size={19}
                    color={colors.primaryDark}
                  />
                </View>
                <View style={styles.contactTextWrap}>
                  <Text style={styles.contactTitle}>{contactItem.title}</Text>
                  <Text style={styles.contactValue}>{contactItem.value}</Text>
                </View>
                <Ionicons name="open-outline" size={17} color="#A0A0A0" />
              </Pressable>
            ))}
          </View>

          <Text style={styles.sectionLabel}>Send us a message</Text>
          <View
            style={[
              styles.messageCard,
              Platform.OS === "web" && styles.messageCardWeb,
            ]}
          >
            <Text style={styles.fieldLabel}>Topic</Text>
            <Pressable
              style={({ pressed }) => [styles.topicRow, pressed && styles.rowPressed]}
              onPress={cycleTopic}
              accessibilityRole="button"
              accessibilityLabel={`Topic, currently ${topic}. Tap to change.`}
            >
              <Text style={styles.topicText}>{topic}</Text>
              <Ionicons name="chevron-down" size={17} color={colors.textMuted} />
            </Pressable>

            <Text style={styles.fieldLabel}>Message</Text>
            <TextInput
              value={message}
              onChangeText={setMessage}
              placeholder="How can we help you?"
              placeholderTextColor="#9CA3AF"
              style={styles.textarea}
              multiline
              maxLength={500}
              textAlignVertical="top"
            />
            <Text style={styles.charHint}>{message.length}/500</Text>

            <Pressable
              style={({ pressed }) => [
                styles.sendButton,
                (!canSend || sending) && styles.sendButtonDisabled,
                pressed && canSend && styles.buttonPressed,
              ]}
              onPress={() => void send()}
              disabled={!canSend || sending}
              accessibilityRole="button"
              accessibilityState={{ disabled: !canSend || sending }}
            >
              {sending ? <ActivityIndicator color="#FFFFFF" /> : <Text style={styles.sendText}>Send Message</Text>}
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  flex: {
    flex: 1,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  backButton: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    textAlign: "center",
    flex: 1,
  },

  headerSpacer: {
    width: 40,
  },

  content: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxxl,
  },

  sectionLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: colors.textMuted,
    textTransform: "uppercase",
    letterSpacing: 0.4,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },

  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    overflow: "hidden",
  },

  faqHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 14,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },

  faqQuestion: {
    flex: 1,
    fontSize: 14.5,
    fontWeight: "600",
    color: colors.text,
    marginRight: spacing.md,
  },

  faqAnswer: {
    fontSize: 13.5,
    lineHeight: 20,
    color: colors.textMuted,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    backgroundColor: "#FAFCFB",
  },

  contactRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 13,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },

  contactIcon: {
    width: 38,
    height: 38,
    borderRadius: radius.md,
    backgroundColor: "#EAF8F2",
    alignItems: "center",
    justifyContent: "center",
  },

  contactTextWrap: {
    flex: 1,
    marginLeft: spacing.md,
  },

  contactTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.text,
  },

  contactValue: {
    fontSize: 12.5,
    color: colors.textMuted,
    marginTop: 2,
  },

  rowPressed: {
    backgroundColor: "#F2F5F4",
  },

  messageCard: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.lg,
  },

  messageCardWeb: {
    boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
  },

  fieldLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: colors.text,
    marginTop: spacing.md,
    marginBottom: 6,
  },

  topicRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#F3F5F4",
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 13,
  },

  topicText: {
    fontSize: 14.5,
    color: colors.text,
  },

  textarea: {
    minHeight: 110,
    backgroundColor: "#F3F5F4",
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    color: colors.text,
    fontSize: 14.5,
    marginTop: 6,
  },

  charHint: {
    alignSelf: "flex-end",
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 4,
    marginBottom: spacing.sm,
  },

  sendButton: {
    backgroundColor: colors.primary,
    minHeight: 50,
    borderRadius: radius.md,
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.xs,
  },

  sendButtonDisabled: {
    backgroundColor: "#BFE6D6",
  },

  sendText: {
    color: colors.white,
    fontSize: 15,
    fontWeight: "700",
  },

  buttonPressed: {
    opacity: 0.85,
  },
});