import React, { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";
import SaveToast from "../components/SaveToast";

type SavedItem = {
  _id: string;
  itemType: string;
  itemId?: string;
  name: string;
  location?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
};

type FilterValue = "all" | "places" | "hotels" | "activities" | "transportation";

const FILTERS: { label: string; value: FilterValue; types: string[] | null }[] = [
  { label: "All", value: "all", types: null },
  { label: "Places", value: "places", types: ["destination", "hidden-gem", "restaurant"] },
  { label: "Hotels", value: "hotels", types: ["hotel"] },
  { label: "Activities", value: "activities", types: ["activity"] },
  { label: "Transportation", value: "transportation", types: ["transport"] },
];

function categoryLabel(itemType: string): string {
  switch (itemType) {
    case "destination":
      return "Place";
    case "hidden-gem":
      return "Hidden Gem";
    case "hotel":
      return "Hotel";
    case "activity":
      return "Activity";
    case "transport":
      return "Transport";
    case "restaurant":
      return "Restaurant";
    default:
      return itemType.replace(/-/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  }
}

function isValidObjectId(value: string | undefined): boolean {
  return typeof value === "string" && /^[0-9a-fA-F]{24}$/.test(value);
}

export default function SavedScreen() {
  const navigation = useNavigation<any>();
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const [items, setItems] = useState<SavedItem[]>([]);
  const [activeFilter, setActiveFilter] = useState<FilterValue>("all");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [removingId, setRemovingId] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId) {
        setItems([]);
        setError("");
        setLoading(false);
        return;
      }

      const controller = new AbortController();
      setLoading(true);
      setError("");
      backendRequest<SavedItem[]>(`/saved-items?userId=${encodeURIComponent(userId)}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then(setItems)
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setError(
              requestError instanceof Error
                ? requestError.message
                : "Could not load your saved places."
            );
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });

      return () => controller.abort();
    }, [getAccessToken, reloadKey, userId])
  );

  const visibleItems = useMemo(() => {
    const filter = FILTERS.find((entry) => entry.value === activeFilter);
    if (!filter?.types) return items;
    return items.filter((item) => filter.types!.includes(item.itemType));
  }, [activeFilter, items]);

  const removeSavedItem = async (item: SavedItem) => {
    const token = getAccessToken();
    if (!token) {
      setError("Sign in again to update your saved places.");
      return;
    }
    setRemovingId(item._id);
    setError("");
    try {
      await backendRequest(`/saved-items/${item._id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems((current) => current.filter((entry) => entry._id !== item._id));
      showToast("Removed from saved");
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Could not remove this saved place."
      );
    } finally {
      setRemovingId("");
    }
  };

  const openSavedItem = (item: SavedItem) => {
    if (item.itemType === "hotel") {
      if (item.itemId) {
        navigation.push("HotelDetails", { hotelId: item.itemId });
      } else {
        navigation.push("Hotels", { location: item.location ?? item.name });
      }
      return;
    }
    if (item.itemType === "hidden-gem") {
      navigation.push("HiddenGemDetail", {
        gem: { name: item.name, location: item.location, image: item.image },
      });
      return;
    }
    if (item.itemType === "restaurant" && item.itemId) {
      navigation.push("Restaurants", { restaurantId: item.itemId });
      return;
    }
    if (item.itemType === "transport" && item.itemId) {
      navigation.push("Transport", { transportId: item.itemId });
      return;
    }
    if (["activity", "shopping", "petrol", "hospital", "atm"].includes(item.itemType) && item.itemId) {
      navigation.push("PlaceDirectory", {
        module: item.itemType as "activity" | "shopping" | "petrol" | "hospital" | "atm",
        placeId: item.itemId,
      });
      return;
    }
    navigation.push("Destination", {
      destination: {
        name: item.name,
        location: item.location ?? "Location not provided",
        rating: "",
        reviews: "",
        description: "",
        bestTime: "",
        price: "",
        image: item.image ?? "",
      },
    });
  };

  const addToTrip = (item: SavedItem) => {
    // Hand the item to the existing Plan a Complete Trip planner. Items with a
    // database reference are preselected by id (the planner loads the real
    // record and ignores duplicates); everything else opens the planner at the
    // matching destination. Nothing is removed from Saved.
    const validId = isValidObjectId(item.itemId) ? (item.itemId as string) : undefined;
    if (item.itemType === "hotel" && validId) {
      navigation.push("DestinationTrip", {
        destination: item.location ?? item.name,
        preselect: { itemType: "hotel", itemId: validId },
      });
    } else if (item.itemType === "transport" && validId) {
      navigation.push("DestinationTrip", {
        preselect: { itemType: "transport", itemId: validId },
      });
    } else if (item.itemType === "activity" && validId) {
      navigation.push("DestinationTrip", {
        preselect: { itemType: "activity", itemId: validId },
      });
    } else if (item.itemType === "restaurant" && validId) {
      navigation.push("DestinationTrip", {
        preselect: { itemType: "restaurant", itemId: validId },
      });
    } else {
      navigation.push("DestinationTrip", { destination: item.name });
    }
    showToast("Added to your trip");
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <Text style={styles.header}>Saved Places</Text>
      <Text style={styles.subtitle}>Your favourites, together in one place.</Text>

      {!userId ? (
        <View style={styles.emptyState}>
          <Ionicons name="heart-outline" size={34} color={colors.primary} />
          <Text style={styles.emptyTitle}>Sign in to see Saved Places</Text>
          <Text style={styles.emptyText}>Your saved places are kept with your SuvYatra account.</Text>
          <Pressable
            style={styles.primaryButton}
            onPress={() => navigation.getParent()?.navigate("Login")}
            accessibilityRole="button"
          >
            <Text style={styles.primaryButtonText}>Sign in</Text>
          </Pressable>
        </View>
      ) : error ? (
        <View style={styles.emptyState}>
          <Text style={styles.errorText}>{error}</Text>
          <Pressable onPress={() => setReloadKey((current) => current + 1)} accessibilityRole="button">
            <Text style={styles.retryText}>Try again</Text>
          </Pressable>
        </View>
      ) : loading ? (
        <View style={styles.emptyState}><ActivityIndicator color={colors.primary} /></View>
      ) : (
        <>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.filterRow}
          >
            {FILTERS.map((filter) => {
              const active = activeFilter === filter.value;
              return (
                <Pressable
                  key={filter.value}
                  onPress={() => setActiveFilter(filter.value)}
                  style={[styles.chip, active && styles.chipActive]}
                  accessibilityRole="button"
                  accessibilityState={{ selected: active }}
                >
                  <Text style={[styles.chipText, active && styles.chipTextActive]}>{filter.label}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
          <FlatList
            data={visibleItems}
            keyExtractor={(item) => item._id}
            contentContainerStyle={visibleItems.length ? styles.list : styles.emptyList}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <Ionicons name="bookmark-outline" size={34} color={colors.primary} />
                <Text style={styles.emptyTitle}>Your saved places are waiting</Text>
                <Text style={styles.emptyText}>
                  Save destinations, hotels, activities and transportation to find them here later.
                </Text>
                <Pressable
                  style={styles.primaryButton}
                  onPress={() => navigation.navigate("Explore")}
                  accessibilityRole="button"
                  accessibilityLabel="Explore Nepal"
                >
                  <Text style={styles.primaryButtonText}>Explore Nepal</Text>
                </Pressable>
              </View>
            }
            renderItem={({ item }) => (
              <View style={styles.card}>
                <View style={styles.cardTop}>
                  <Pressable
                    style={styles.cardMain}
                    onPress={() => openSavedItem(item)}
                    accessibilityRole="button"
                    accessibilityLabel={`Open saved ${item.name}`}
                  >
                    <RelevantImage entity={{ name: item.name, type: item.itemType === "hidden-gem" ? "destination" : item.itemType, location: item.location, image: item.image, images: item.images, imageSource: item.imageSource, imageSourcePage: item.imageSourcePage, imageLicense: item.imageLicense, imageCredit: item.imageCredit, imageDescription: item.imageDescription, imageRelevance: item.imageRelevance }} style={styles.image} />
                    <View style={styles.cardText}>
                      <Text style={styles.category}>{categoryLabel(item.itemType)}</Text>
                      <Text style={styles.name}>{item.name}</Text>
                      <Text style={styles.location}>{item.location ?? "Location not provided"}</Text>
                    </View>
                  </Pressable>
                  <Pressable
                    onPress={() => void removeSavedItem(item)}
                    disabled={removingId === item._id}
                    accessibilityRole="button"
                    accessibilityLabel={`Remove ${item.name} from Saved Places`}
                  >
                    {removingId === item._id ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : (
                      <Ionicons name="heart" size={22} color="#D9435F" />
                    )}
                  </Pressable>
                </View>
                <View style={styles.cardActions}>
                  <Pressable
                    style={styles.detailsButton}
                    onPress={() => openSavedItem(item)}
                    accessibilityRole="button"
                    accessibilityLabel={`View details for ${item.name}`}
                  >
                    <Text style={styles.detailsButtonText}>View Details</Text>
                  </Pressable>
                  <Pressable
                    style={styles.tripButton}
                    onPress={() => addToTrip(item)}
                    accessibilityRole="button"
                    accessibilityLabel={`Add ${item.name} to your trip`}
                  >
                    <Ionicons name="add-circle-outline" size={16} color={colors.primaryDark} />
                    <Text style={styles.tripButtonText}>Add to Trip</Text>
                  </Pressable>
                </View>
              </View>
            )}
          />
        </>
      )}
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.lg, paddingTop: spacing.xl },
  header: { color: colors.text, fontSize: 24, fontWeight: "900" },
  subtitle: { color: colors.textMuted, fontSize: 13, marginTop: 4, marginBottom: spacing.md },
  filterRow: { gap: 7, paddingBottom: spacing.sm },
  chip: {
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { color: colors.textMuted, fontSize: 11, fontWeight: "700" },
  chipTextActive: { color: colors.white },
  list: { paddingBottom: 100 },
  emptyList: { flexGrow: 1, justifyContent: "center", paddingBottom: spacing.xl },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.md, gap: spacing.sm },
  cardTop: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  cardMain: { flex: 1, flexDirection: "row", alignItems: "center", gap: spacing.md },
  image: { width: 84, height: 84, borderRadius: radius.md },
  cardText: { flex: 1, gap: 2 },
  category: { color: colors.primaryDark, fontSize: 10, fontWeight: "800", letterSpacing: 0.6, textTransform: "uppercase" },
  name: { color: colors.text, fontSize: 15, fontWeight: "800" },
  location: { color: colors.textMuted, fontSize: 11, marginTop: 3 },
  cardActions: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.xs },
  detailsButton: { flex: 1, minHeight: 42, alignItems: "center", justifyContent: "center", borderRadius: radius.sm, backgroundColor: colors.primary },
  detailsButtonText: { color: colors.white, fontSize: 12, fontWeight: "800" },
  tripButton: { flex: 1, minHeight: 42, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.primary, backgroundColor: colors.surface },
  tripButtonText: { color: colors.primaryDark, fontSize: 12, fontWeight: "800" },
  emptyState: { alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.xl, gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 15, fontWeight: "800", textAlign: "center" },
  emptyText: { color: colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: "center" },
  primaryButton: { backgroundColor: colors.primary, borderRadius: radius.md, paddingHorizontal: spacing.xl, paddingVertical: spacing.sm, minHeight: 44, justifyContent: "center", marginTop: spacing.sm },
  primaryButtonText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  errorText: { color: "#B42318", fontSize: 12, textAlign: "center" },
  retryText: { color: colors.primaryDark, fontSize: 13, fontWeight: "800", marginTop: spacing.sm },
});
