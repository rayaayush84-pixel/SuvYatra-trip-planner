import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "AdminRegisteredUsers">;

type RegisteredUser = {
  _id: string;
  name: string;
  email: string;
  createdAt: string;
};

type RegisteredUsersResponse = {
  total: number;
  users: RegisteredUser[];
};

export default function AdminRegisteredUsersScreen({ navigation }: Props) {
  const { getAccessToken, user } = useAuth();
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUsersResponse>({
    total: 0,
    users: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const token = getAccessToken();

  const loadRegisteredUsers = useCallback(async (signal: AbortSignal) => {
    if (!token) {
      setError("Sign in with an administrator account to view registered users.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError("");
    try {
      const result = await backendRequest<RegisteredUsersResponse>(
        "/admin/registered-users",
        {
          headers: { Authorization: `Bearer ${token}` },
          signal,
        }
      );
      setRegisteredUsers(result);
    } catch (requestError) {
      if (!signal.aborted) {
        setError(
          requestError instanceof Error
            ? requestError.message
            : "Could not load registered users."
        );
      }
    } finally {
      if (!signal.aborted) setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    const controller = new AbortController();
    void loadRegisteredUsers(controller.signal);
    return () => controller.abort();
  }, [loadRegisteredUsers, reloadKey]);

  const renderUser = ({ item }: { item: RegisteredUser }) => {
    const registeredAt = new Date(item.createdAt);
    return (
      <View style={styles.card}>
        <View style={styles.nameRow}>
          <View style={styles.avatar}>
            <Ionicons name="person-outline" size={18} color={colors.primaryDark} />
          </View>
          <Text style={styles.name}>{item.name}</Text>
        </View>
        <Text style={styles.email}>{item.email || "No email on account"}</Text>
        <View style={styles.registrationDetails}>
          <View style={styles.detail}>
            <Ionicons name="calendar-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>
              {Number.isNaN(registeredAt.getTime())
                ? "Date unavailable"
                : registeredAt.toLocaleDateString()}
            </Text>
          </View>
          <View style={styles.detail}>
            <Ionicons name="time-outline" size={15} color={colors.textMuted} />
            <Text style={styles.detailText}>
              {Number.isNaN(registeredAt.getTime())
                ? "Time unavailable"
                : registeredAt.toLocaleTimeString([], {
                    hour: "numeric",
                    minute: "2-digit",
                  })}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} />
        <Text style={styles.title}>Registered Users</Text>
        <View style={styles.headerSpacer} />
      </View>

      {user?.role !== "admin" ? (
        <View style={styles.empty}>
          <Text style={styles.message}>Administrator access is required.</Text>
        </View>
      ) : loading ? (
        <View style={styles.empty}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : error ? (
        <View style={styles.empty}>
          <Text style={styles.message}>{error}</Text>
          <Pressable
            onPress={() => setReloadKey((key) => key + 1)}
            accessibilityRole="button"
          >
            <Text style={styles.retry}>Try again</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={registeredUsers.users}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.list}
          ListHeaderComponent={
            <View style={styles.totalCard}>
              <Ionicons name="people-outline" size={22} color={colors.primaryDark} />
              <View>
                <Text style={styles.totalNumber}>{registeredUsers.total}</Text>
                <Text style={styles.totalLabel}>Total Registered Users</Text>
              </View>
            </View>
          }
          ListEmptyComponent={
            <Text style={styles.message}>No registered users were found.</Text>
          }
          renderItem={renderUser}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  title: { color: colors.text, fontSize: 17, fontWeight: "700" },
  headerSpacer: { width: 23 },
  list: { padding: spacing.lg, paddingBottom: spacing.xxxl },
  totalCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  totalNumber: { color: colors.text, fontSize: 23, fontWeight: "800" },
  totalLabel: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  nameRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  avatar: {
    width: 34,
    height: 34,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#E6FFFA",
  },
  name: { color: colors.text, fontSize: 15, fontWeight: "700" },
  email: { color: colors.textMuted, fontSize: 13, marginTop: spacing.sm },
  registrationDetails: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.lg,
    marginTop: spacing.md,
  },
  detail: { flexDirection: "row", alignItems: "center", gap: 5 },
  detailText: { color: colors.textMuted, fontSize: 12 },
  empty: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl },
  message: { color: colors.textMuted, textAlign: "center", lineHeight: 20 },
  retry: { color: colors.primaryDark, fontWeight: "700", marginTop: spacing.md },
});
