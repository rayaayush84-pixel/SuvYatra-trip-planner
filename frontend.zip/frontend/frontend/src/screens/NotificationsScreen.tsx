import React from "react";
import { View, Text, StyleSheet, FlatList, Pressable } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import BackButton from "../components/BackButton";
import { useNavigation } from "@react-navigation/native";
import { colors, radius, spacing } from "../theme";

const NOTIFICATIONS = [
  {
    id: "1",
    title: "Booking Confirmed!",
    desc: "Your booking at Fewa Lakeside is confirmed.",
    time: "2h ago",
    icon: "checkmark-circle-outline",
  },
  {
    id: "2",
    title: "Price Drop",
    desc: "Flights to Pokhara 15% cheaper now.",
    time: "1d ago",
    icon: "pricetag-outline",
  },
  {
    id: "3",
    title: "Trip Reminder",
    desc: "Your trip starts in 3 days!",
    time: "2d ago",
    icon: "calendar-outline",
  },
];

export default function NotificationsScreen() {
  const navigation = useNavigation<any>();

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} iconSize={24} />
        <Text style={styles.title}>Notifications</Text>
      </View>

      <FlatList
        data={NOTIFICATIONS}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.notifItem}>
            <View style={styles.iconBox}>
              <Ionicons
                name={item.icon as any}
                size={18}
                color={colors.primary}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.notifTitle}>{item.title}</Text>
              <Text style={styles.notifDesc}>{item.desc}</Text>
              <Text style={styles.notifTime}>{item.time}</Text>
            </View>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.md,
    paddingTop: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: colors.text,
    marginLeft: spacing.md,
  },
  notifItem: {
    flexDirection: "row",
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    alignItems: "flex-start",
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
    marginRight: spacing.md,
  },
  notifTitle: {
    fontWeight: "bold",
    fontSize: 14,
    color: colors.text,
  },
  notifDesc: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 4,
  },
  notifTime: {
    fontSize: 10,
    color: colors.textMuted,
    marginTop: 4,
  },
});