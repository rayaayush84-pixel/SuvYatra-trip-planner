import React, { useState } from "react";
import {
  ActivityIndicator,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "ForgotPassword">;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const AUTH_BG =
  require("../../../assets/WhatsApp Image 2026-09-10 at 11.13.41 PM (1).jpeg");

export default function ForgotPasswordScreen({ navigation, route }: Props) {
  const { requestPasswordReset, verifyPasswordResetOtp } = useAuth();
  // Reused for administrator resets: same endpoints, but navigation returns
  // to the admin login instead of the user login.
  const adminMode = route.params?.admin === true;
  const [email, setEmail] = useState(route.params?.email ?? "");
  const [otp, setOtp] = useState("");
  const [stage, setStage] = useState<"email" | "otp">("email");
  const otpRef = React.useRef<TextInput>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  React.useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [cooldown]);

  const backToLogin = () => {
    if (adminMode) {
      navigation.replace("AdminLogin");
      return;
    }
    if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.replace("Login");
    }
  };

  const normalizedEmail = email.trim().toLowerCase();
  const emailError = submitted
    ? !normalizedEmail
      ? "Please enter your email address."
      : !EMAIL_REGEX.test(normalizedEmail)
        ? "Please enter a valid email address."
        : ""
    : "";
  const otpError = submitted && !/^\d{6}$/.test(otp.trim())
    ? "Please enter the 6-digit reset code from your email."
    : "";

  const sendCode = async () => {
    setSubmitted(true);
    setError("");
    setNotice("");
    if (!normalizedEmail || !EMAIL_REGEX.test(normalizedEmail)) return;
    if (cooldown > 0) return;

    setBusy(true);
    try {
      await requestPasswordReset(normalizedEmail);
      setStage("otp");
      setOtp("");
      setSubmitted(false);
      setCooldown(45);
      setNotice("A reset code has been sent to your email. It expires in 10 minutes.");
    } catch (requestError) {
      const message = requestError instanceof Error ? requestError.message : "Could not send the reset code.";
      if (message.includes("Too many reset requests")) {
        setCooldown(60);
      }
      setError(message);
    } finally {
      setBusy(false);
    }
  };

  const verifyCode = async () => {
    setSubmitted(true);
    setError("");
    if (!/^\d{6}$/.test(otp.trim())) return;

    setBusy(true);
    try {
      await verifyPasswordResetOtp(normalizedEmail, otp.trim());
      navigation.push("ResetPassword", {
        email: normalizedEmail,
        otp: otp.trim(),
        ...(adminMode ? { admin: true as const } : {}),
      });
    } catch (verificationError) {
      setError(
        verificationError instanceof Error
          ? verificationError.message
          : "Could not verify the reset code."
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.hero}>
          <ImageBackground source={AUTH_BG} style={styles.heroImage} resizeMode="cover">
            <View style={styles.heroOverlay} />
            <BackButton
              navigation={navigation}
              style={styles.backButton}
              iconColor="#FFFFFF"
              label="Back to login"
              onFallback={backToLogin}
            />
            <View style={styles.brandBlock}>
              <Text style={styles.brandText}>SuvYatra</Text>
              <Text style={styles.brandTagline}>Your AI Trip Planner</Text>
            </View>
          </ImageBackground>
        </View>

        <ScrollView
          style={styles.formScroll}
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.formPanel}>
            <Text style={styles.title}>
              {stage === "email" ? "Forgot password?" : "Check your email"}
            </Text>
            <Text style={styles.subtitle}>
              {stage === "email"
                ? adminMode
                  ? "Enter your administrator account email and we'll send you a one-time reset code."
                  : "Enter your account email and we'll send you a one-time reset code."
                : `Enter the 6-digit code sent to ${normalizedEmail}.`}
            </Text>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Email</Text>
              <View style={[styles.fieldBox, !!emailError && styles.fieldBoxError]}>
                <Ionicons name="mail-outline" size={18} color="#64748B" />
                <TextInput
                  value={email}
                  onChangeText={(value) => {
                    setEmail(value);
                    setError("");
                  }}
                  placeholder="Email address"
                  placeholderTextColor="#9CA3AF"
                  style={styles.fieldInput}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  autoComplete="email"
                  editable={stage === "email" && !busy}
                  returnKeyType="go"
                  onSubmitEditing={() => {
                    if (stage === "email") {
                      void sendCode();
                    } else {
                      otpRef.current?.focus();
                    }
                  }}
                />
              </View>
              {!!emailError && <Text style={styles.fieldError}>{emailError}</Text>}
            </View>

            {stage === "otp" && (
              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>6-digit reset code</Text>
                <View style={[styles.fieldBox, !!otpError && styles.fieldBoxError]}>
                  <Ionicons name="key-outline" size={18} color="#64748B" />
                  <TextInput
                    value={otp}
                    onChangeText={(value) => {
                      setOtp(value.replace(/\D/g, "").slice(0, 6));
                      setError("");
                    }}
                    placeholder="Enter code"
                    placeholderTextColor="#9CA3AF"
                    style={styles.fieldInput}
                    keyboardType="number-pad"
                    autoCapitalize="none"
                    autoComplete="one-time-code"
                    maxLength={6}
                    editable={!busy}
                    ref={otpRef}
                    returnKeyType="go"
                    onSubmitEditing={() => void verifyCode()}
                  />
                </View>
                {!!otpError && <Text style={styles.fieldError}>{otpError}</Text>}
              </View>
            )}

            {notice ? (
              <View style={styles.notice} accessibilityRole="alert">
                <Text style={styles.noticeText}>{notice}</Text>
              </View>
            ) : null}
            {error ? (
              <View style={styles.errorBox} accessibilityRole="alert">
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : null}

            <Pressable
              style={({ pressed }) => [
                styles.submitButton,
                (busy || cooldown > 0) && styles.submitButtonDisabled,
                pressed && !busy && cooldown <= 0 && styles.submitButtonPressed,
              ]}
              onPress={stage === "email" ? sendCode : verifyCode}
              disabled={busy || (stage === "email" && cooldown > 0)}
              accessibilityRole="button"
              accessibilityState={{ disabled: busy }}
            >
              {busy ? (
                <View style={styles.submitContent}>
                  <ActivityIndicator color="#FFFFFF" />
                  <Text style={styles.submitText}>
                    {stage === "email" ? "Sending..." : "Verifying..."}
                  </Text>
                </View>
              ) : (
                <View style={styles.submitContent}>
                  <Text style={styles.submitText}>
                    {stage === "email"
                      ? cooldown > 0
                        ? `Resend in ${cooldown}s`
                        : "Send OTP"
                      : "Verify Code"}
                  </Text>
                  <Ionicons name="arrow-forward" size={17} color="#FFFFFF" />
                </View>
              )}
            </Pressable>

            {stage === "otp" && cooldown <= 0 && (
              <Pressable
                style={styles.secondaryAction}
                onPress={sendCode}
                disabled={busy}
                accessibilityRole="button"
              >
                <Text style={styles.secondaryText}>Resend code</Text>
              </Pressable>
            )}
            {stage === "otp" && cooldown > 0 && (
              <Text style={[styles.secondaryText, styles.cooldownText]}>
                Resend available in {cooldown}s
              </Text>
            )}

            {stage === "otp" && (
              <Pressable
                style={styles.secondaryAction}
                onPress={() => {
                  setStage("email");
                  setError("");
                  setNotice("");
                  setSubmitted(false);
                }}
                disabled={busy}
                accessibilityRole="button"
              >
                <Text style={styles.secondaryText}>Use a different email</Text>
              </Pressable>
            )}
            <Pressable
              style={styles.footerAction}
              onPress={backToLogin}
              disabled={busy}
              accessibilityRole="link"
            >
              <Text style={styles.footerText}>{adminMode ? "Back to Admin login" : "Back to Login"}</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFFFFF" },
  flex: { flex: 1 },
  hero: { height: 230, width: "100%" },
  heroImage: { flex: 1, justifyContent: "center" },
  heroOverlay: { ...StyleSheet.absoluteFill, backgroundColor: "rgba(10, 28, 49, 0.35)" },
  backButton: {
    position: "absolute",
    top: spacing.md,
    left: spacing.lg,
    zIndex: 2,
    width: 42,
    height: 42,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(15, 23, 42, 0.35)",
  },
  brandBlock: { alignItems: "center", paddingHorizontal: spacing.xl, paddingTop: spacing.lg },
  brandText: { color: "#FFFFFF", fontSize: 38, lineHeight: 46, fontWeight: "900" },
  brandTagline: { color: "#FFFFFF", fontSize: 15, fontWeight: "700", marginTop: spacing.xs },
  formScroll: { flex: 1, marginTop: -24 },
  content: { flexGrow: 1 },
  formPanel: {
    flexGrow: 1,
    width: "100%",
    maxWidth: 520,
    alignSelf: "center",
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.xxxl,
  },
  title: { color: "#102A43", fontSize: 25, fontWeight: "800" },
  subtitle: { color: "#64748B", fontSize: 14, lineHeight: 21, marginTop: spacing.sm, marginBottom: spacing.xl },
  fieldGroup: { marginBottom: spacing.lg },
  fieldLabel: { color: "#26384D", fontSize: 13, fontWeight: "700", marginBottom: spacing.sm },
  fieldBox: {
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    backgroundColor: "#FFFFFF",
  },
  fieldBoxError: { borderColor: "#EF4444" },
  fieldInput: { flex: 1, minHeight: 50, color: "#102A43", fontSize: 15, paddingVertical: 0 },
  fieldError: { color: "#B91C1C", fontSize: 12, marginTop: spacing.xs },
  notice: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#A7F3D0",
    backgroundColor: "#ECFDF5",
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  noticeText: { color: "#047857", fontSize: 13, lineHeight: 19 },
  errorBox: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#FECACA",
    backgroundColor: "#FEF2F2",
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  errorText: { color: "#B91C1C", fontSize: 13, lineHeight: 19 },
  submitButton: {
    minHeight: 54,
    borderRadius: radius.md,
    backgroundColor: "#10B981",
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.sm,
  },
  submitButtonDisabled: { opacity: 0.65 },
  submitButtonPressed: { opacity: 0.85 },
  submitContent: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm },
  submitText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" },
  secondaryAction: { alignSelf: "center", paddingVertical: spacing.md },
  secondaryText: { color: "#0E9488", fontSize: 13, fontWeight: "700" },
  cooldownText: { alignSelf: "center", paddingVertical: spacing.md },
  footerAction: { alignSelf: "center", paddingVertical: spacing.md, marginTop: spacing.xs },
  footerText: { color: "#0E9488", fontSize: 14, fontWeight: "700" },
});
