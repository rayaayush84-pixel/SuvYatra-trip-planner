import React, { useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { AuthenticationError, SocialProvider, useAuth } from "../auth/AuthContext";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "Login">;

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const NAME_REGEX = /^[\p{L}\p{M}]+(?:[ '\u2019-][\p{L}\p{M}]+)*$/u;
const AUTH_BG = require("../../../assets/WhatsApp Image 2026-09-10 at 11.13.41 PM (1).jpeg");

export default function LoginScreen({ navigation, route }: Props) {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [selectedProvider, setSelectedProvider] = useState<SocialProvider>(
    route.params?.provider === "Apple" ? "Apple" : "Email"
  );
  const [name, setName] = useState("");
  const [email, setEmail] = useState(route.params?.identifier ?? "");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showValidationErrors, setShowValidationErrors] = useState(false);
  const [authError, setAuthError] = useState<{ message: string; signUp: boolean } | null>(null);
  const [authNotice, setAuthNotice] = useState("");
  // Focus chain for Enter key: name → email → password → (confirm) → submit.
  const nameRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);
  const confirmRef = useRef<TextInput>(null);

  React.useEffect(() => {
    if (route.params?.provider) {
      setSelectedProvider(route.params.provider === "Apple" ? "Apple" : "Email");
    }
    if (route.params?.identifier) {
      setEmail(route.params.identifier);
    }
    if (route.params?.notice) {
      setAuthNotice(route.params.notice);
    }
  }, [route.params?.provider, route.params?.identifier, route.params?.notice]);

  const errors = useMemo(() => {
    const result: Record<string, string> = {};
    const normalizedName = name.trim().replace(/\s+/g, " ");
    if (mode === "register" && !NAME_REGEX.test(normalizedName)) {
      result.name = "Please enter a valid name.";
    }

    if (!email.trim()) {
      result.email =
        mode === "login" && selectedProvider === "Email"
          ? "Please enter your email address."
          : selectedProvider === "Apple"
          ? "Apple ID is required."
          : "Email is required.";
    } else if (!EMAIL_REGEX.test(email.trim())) {
      result.email = "Please enter a valid email address.";
    }

    if (mode === "register") {
      if (
        password.length < 8 ||
        !/[A-Z]/.test(password) ||
        !/[a-z]/.test(password) ||
        !/\d/.test(password) ||
        !/[^A-Za-z0-9]/.test(password)
      ) {
        result.password =
          "Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character.";
      }
    } else if (!password) {
      result.password = "Please enter your password.";
    }
    if (mode === "register" && confirm !== password) {
      result.confirm = "Passwords do not match.";
    }
    return result;
  }, [mode, name, email, password, confirm, selectedProvider]);

  const canSubmit = Object.keys(errors).length === 0 && !submitting;

  const submit = async () => {
    if (!canSubmit) {
      setShowValidationErrors(true);
      return;
    }
    setSubmitting(true);
    setAuthError(null);
    try {
      let profile;
      if (mode === "login") {
        profile = await login(email.trim(), password, selectedProvider);
      } else {
        profile = await register(name, email.trim(), password, selectedProvider);
      }
      // ONE unified login: role decides the destination. Admin accounts
      // (role === "admin") go to the Admin Dashboard, everyone else to MainTabs.
      navigation.reset({
        index: 0,
        routes: [{ name: profile?.role === "admin" ? "AdminDashboard" : "MainTabs" }],
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Please try again.";
      const code = error instanceof AuthenticationError ? error.code : undefined;
      // Signup now requires Gmail OTP: backend created the pending account
      // and emailed the code → move to the verification screen.
      if (mode === "register" && code === "REGISTER_OTP_SENT") {
        navigation.navigate("VerifyEmail", { email: email.trim().toLowerCase() });
        return;
      }
      // Login before verifying → continue the pending verification.
      if (code === "EMAIL_NOT_VERIFIED") {
        navigation.navigate("VerifyEmail", { email: email.trim().toLowerCase() });
        return;
      }
      if (mode === "register") {
        setAuthError({ message, signUp: false });
      } else if (
        error instanceof AuthenticationError &&
        (error.code === "EMAIL_NOT_FOUND" ||
          error.code === "EMAIL_NOT_REGISTERED" ||
          message === "Email is not registered." ||
          message === "You do not have this account so please create new account.")
      ) {
        setAuthError({
          message: "No account found with this email. Please sign up first.",
          signUp: true,
        });
      } else if (
        error instanceof AuthenticationError &&
        (error.code === "INVALID_PASSWORD" ||
          error.code === "INCORRECT_PASSWORD" ||
          message === "Incorrect password." ||
          message === "Incorrect password. Please try again.")
      ) {
        setAuthError({ message: "Incorrect password. Please try again.", signUp: false });
      } else if (
        error instanceof AuthenticationError &&
        (error.code === "USE_GOOGLE_SIGN_IN" ||
          message.includes("uses Google Sign-In"))
      ) {
        setAuthError({
          message: "This account needs a password to sign in here. Please use Forgot password to set one.",
          signUp: false,
        });
      } else {
        setAuthError({ message, signUp: false });
      }
    } finally {
      setSubmitting(false);
    }
  };

  const forgotPassword = () => {
    navigation.navigate("ForgotPassword", { email: email.trim() });
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.hero}>
          <ImageBackground source={AUTH_BG} style={styles.heroImage} resizeMode="cover">
            <View style={styles.heroOverlay} />
            <BackButton navigation={navigation} style={styles.backButton} iconColor="#FFFFFF" />
            <View style={styles.brandBlock}>
              <Text style={styles.brandText}>SuvYatra</Text>
              <Text style={styles.brandTagline}>Your AI Trip Planner</Text>
              <Text style={styles.brandPromise}>Dream it. Plan it. Explore it.</Text>
            </View>
          </ImageBackground>
        </View>

        <ScrollView
          style={styles.formScroll}
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.formPanel}>
            <Text style={styles.title}>
              {mode === "register"
                ? "Create your account"
                : selectedProvider === "Email"
                  ? "Welcome back"
                  : `Sign in with ${selectedProvider}`}
            </Text>
            <Text style={styles.subtitle}>
              {mode === "register"
                ? "Start planning your next adventure with SuvYatra."
                : selectedProvider === "Email"
                  ? "Log in to continue planning your next adventure."
                  : `Use your ${selectedProvider === "Apple" ? "Apple ID" : `${selectedProvider} account`} to continue.`}
            </Text>

            {mode === "register" && (
              <Field
                label="Full name"
                value={name}
                onChangeText={(value) => {
                  setName(value);
                  setAuthError(null);
                }}
                placeholder="Your full name"
                autoCapitalize="words"
                error={showValidationErrors ? errors.name : undefined}
                leading={<Ionicons name="person-outline" size={18} color="#64748B" />}
                inputRef={nameRef}
                returnKeyType="next"
                onSubmitEditing={() => emailRef.current?.focus()}
              />
            )}

            <Field
              label={
                selectedProvider === "Email"
                  ? "Email"
                  : "Apple ID"
              }
              value={email}
              onChangeText={(value) => {
                setEmail(value);
                setAuthError(null);
              }}
              placeholder={
                selectedProvider === "Apple"
                  ? "Your Apple ID"
                  : "Email address"
              }
              keyboardType={
                selectedProvider === "Email"
                  ? "email-address"
                  : "default"
              }
              autoCapitalize="none"
              autoComplete={
                selectedProvider === "Email"
                  ? "email"
                  : "username"
              }
              error={showValidationErrors ? errors.email : undefined}
              leading={<Ionicons name="mail-outline" size={18} color="#64748B" />}
              inputRef={emailRef}
              returnKeyType="next"
              onSubmitEditing={() => passwordRef.current?.focus()}
            />

            <Field
              label="Password"
              value={password}
              onChangeText={(value) => {
                setPassword(value);
                setAuthError(null);
              }}
              placeholder="Password"
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              error={showValidationErrors ? errors.password : undefined}
              leading={<Ionicons name="lock-closed-outline" size={18} color="#64748B" />}
              inputRef={passwordRef}
              returnKeyType={mode === "login" ? "go" : "next"}
              onSubmitEditing={() => {
                if (mode === "login") {
                  void submit();
                } else {
                  confirmRef.current?.focus();
                }
              }}
              trailing={
                <Pressable
                  onPress={() => setShowPassword((value) => !value)}
                  hitSlop={10}
                  accessibilityRole="button"
                  accessibilityLabel={showPassword ? "Hide password" : "Show password"}
                >
                  <Ionicons
                    name={showPassword ? "eye-off-outline" : "eye-outline"}
                    size={20}
                    color="#64748B"
                  />
                </Pressable>
              }
            />
            {mode === "register" && (
              <Text style={styles.passwordRequirements}>
                At least 8 characters, with uppercase and lowercase letters, a number, and a special character.
              </Text>
            )}

            {mode === "register" && (
              <Field
                label="Confirm password"
                value={confirm}
                onChangeText={(value) => {
                  setConfirm(value);
                  setAuthError(null);
                }}
                placeholder="Repeat your password"
                secureTextEntry={!showConfirm}
                autoCapitalize="none"
                error={showValidationErrors ? errors.confirm : undefined}
                leading={<Ionicons name="lock-closed-outline" size={18} color="#64748B" />}
                inputRef={confirmRef}
                returnKeyType="go"
                onSubmitEditing={() => void submit()}
                trailing={
                  <Pressable
                    onPress={() => setShowConfirm((value) => !value)}
                    hitSlop={10}
                    accessibilityRole="button"
                    accessibilityLabel={showConfirm ? "Hide password" : "Show password"}
                  >
                    <Ionicons
                      name={showConfirm ? "eye-off-outline" : "eye-outline"}
                      size={20}
                      color="#64748B"
                    />
                  </Pressable>
                }
              />
            )}

            {mode === "login" && (
              <Pressable
                style={styles.forgotRow}
                onPress={forgotPassword}
                accessibilityRole="link"
              >
                <Text style={styles.forgotText}>Forgot password?</Text>
              </Pressable>
            )}

            <Pressable
              style={({ pressed }) => [
                styles.submitButton,
                submitting && styles.submitButtonDisabled,
                pressed && !submitting && styles.submitButtonPressed,
              ]}
              onPress={submit}
              disabled={submitting}
              accessibilityRole="button"
              accessibilityState={{ disabled: submitting }}
            >
              {submitting ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <View style={styles.submitContent}>
                  <Text style={styles.submitText}>
                    {mode === "login" ? "Log In" : "Create Account"}
                  </Text>
                  <Ionicons name="arrow-forward" size={17} color="#FFFFFF" />
                </View>
              )}
            </Pressable>

            {authError ? (
              <View style={styles.authError} accessibilityRole="alert">
                <Text style={styles.authErrorText}>{authError.message}</Text>
                {authError.signUp ? (
                  <Pressable
                    onPress={() => {
                      setMode("register");
                      setSelectedProvider("Email");
                      setShowValidationErrors(false);
                      setAuthError(null);
                    }}
                    accessibilityRole="link"
                  >
                    <Text style={styles.authErrorLink}>Go to Sign Up</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : null}
            {authNotice ? (
              <View style={styles.authNotice} accessibilityRole="alert">
                <Text style={styles.authNoticeText}>{authNotice}</Text>
              </View>
            ) : null}

            <View style={styles.footer}>
              <Text style={styles.footerText}>
                {mode === "login" ? "Don't have an account? " : "Already have an account? "}
              </Text>
              <Pressable
                onPress={() => {
                  setMode(mode === "login" ? "register" : "login");
                  setShowValidationErrors(false);
                  setAuthError(null);
                }}
                accessibilityRole="link"
              >
                <Text style={styles.footerLink}>{mode === "login" ? "Sign Up" : "Log In"}</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  error,
  secureTextEntry,
  keyboardType,
  autoCapitalize,
  autoComplete,
  leading,
  trailing,
  inputRef,
  returnKeyType,
  onSubmitEditing,
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder: string;
  error?: string;
  secureTextEntry?: boolean;
  keyboardType?: "email-address" | "default";
  autoCapitalize?: "none" | "words";
  autoComplete?: "email" | "password" | "username";
  leading?: React.ReactNode;
  trailing?: React.ReactNode;
  inputRef?: React.RefObject<TextInput | null>;
  returnKeyType?: "next" | "go" | "done" | "send" | "default";
  onSubmitEditing?: () => void;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <View style={styles.fieldGroup}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View
        style={[
          styles.fieldBox,
          focused && styles.fieldBoxFocused,
          !!error && styles.fieldBoxError,
        ]}
      >
        {leading}
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#9CA3AF"
          style={styles.fieldInput}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          autoCorrect={false}
          autoComplete={autoComplete}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          underlineColorAndroid="transparent"
          ref={inputRef}
          returnKeyType={returnKeyType}
          onSubmitEditing={onSubmitEditing ? () => onSubmitEditing() : undefined}
        />
        {trailing}
      </View>
      {!!error && <Text style={styles.fieldError}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  flex: {
    flex: 1,
  },
  hero: {
    height: 268,
    width: "100%",
  },
  heroImage: {
    flex: 1,
    justifyContent: "center",
  },
  heroOverlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: "rgba(10, 28, 49, 0.28)",
  },
  backButton: {
    position: "absolute",
    top: spacing.md,
    left: spacing.lg,
    zIndex: 2,
    width: 42,
    height: 42,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(15, 23, 42, 0.28)",
  },
  brandBlock: {
    alignItems: "center",
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.lg,
  },
  brandText: {
    color: "#FFFFFF",
    fontSize: 42,
    lineHeight: 48,
    fontWeight: "900",
    textShadowColor: "rgba(0,0,0,0.24)",
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  brandTagline: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "700",
    marginTop: spacing.xs,
  },
  brandPromise: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 13,
    marginTop: spacing.sm,
  },
  formScroll: {
    flex: 1,
    marginTop: -24,
    backgroundColor: "transparent",
  },
  content: {
    flexGrow: 1,
  },
  formPanel: {
    flexGrow: 1,
    width: "100%",
    maxWidth: 520,
    alignSelf: "center",
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: spacing.xl,
  },
  title: {
    fontSize: 24,
    lineHeight: 30,
    fontWeight: "800",
    color: "#102A43",
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 19,
    color: "#64748B",
    marginTop: 4,
    marginBottom: spacing.lg,
  },
  fieldGroup: {
    marginBottom: spacing.md,
  },
  fieldLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#52657A",
    marginBottom: 6,
  },
  fieldBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#D8E2EE",
    borderRadius: 12,
    paddingHorizontal: spacing.md,
    minHeight: 48,
    gap: spacing.sm,
  },
  fieldBoxFocused: {
    borderColor: "#2878E8",
  },
  fieldBoxError: {
    borderColor: "#EF4444",
  },
  fieldInput: {
    flex: 1,
    color: colors.text,
    fontSize: 14,
    paddingVertical: spacing.sm,
  },
  fieldError: {
    color: "#DC2626",
    fontSize: 12,
    marginTop: 4,
  },
  passwordRequirements: {
    color: "#64748B",
    fontSize: 11,
    lineHeight: 16,
    marginTop: -spacing.sm,
    marginBottom: spacing.md,
  },
  forgotRow: {
    alignSelf: "flex-end",
    marginTop: -2,
    marginBottom: spacing.md,
  },
  forgotText: {
    color: "#2878E8",
    fontSize: 12,
    fontWeight: "700",
  },
  submitButton: {
    backgroundColor: "#2878E8",
    minHeight: 50,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
    marginTop: spacing.xs,
    shadowColor: "#2878E8",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 3,
  },
  submitButtonDisabled: {
    backgroundColor: "#AFCBF1",
  },
  submitButtonPressed: {
    opacity: 0.82,
  },
  submitText: {
    color: colors.white,
    fontSize: 15,
    fontWeight: "800",
  },
  submitContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  authError: {
    borderWidth: 1,
    borderColor: "#FECACA",
    backgroundColor: "#FEF2F2",
    borderRadius: 12,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  authErrorText: {
    color: "#B91C1C",
    fontSize: 13,
    lineHeight: 19,
  },
  authNotice: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#A7F3D0",
    backgroundColor: "#ECFDF5",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginTop: spacing.md,
  },
  authNoticeText: {
    color: "#047857",
    fontSize: 13,
    lineHeight: 19,
    textAlign: "center",
  },
  authErrorLink: {
    color: "#1D4ED8",
    fontSize: 13,
    fontWeight: "800",
    marginTop: spacing.xs,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: spacing.lg,
  },
  footerText: {
    color: "#718096",
    fontSize: 12,
  },
  footerLink: {
    color: "#2878E8",
    fontSize: 13,
    fontWeight: "800",
  },
  adminLink: {
    alignSelf: "center",
    paddingVertical: spacing.md,
  },
  adminLinkText: {
    color: "#64748B",
    fontSize: 12,
    fontWeight: "700",
    textDecorationLine: "underline",
  },
});