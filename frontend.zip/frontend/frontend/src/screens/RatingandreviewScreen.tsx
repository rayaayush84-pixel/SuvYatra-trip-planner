import React, { useState } from "react";
import {
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "Rating">;

// ======================================================
// RATING BREAKDOWN
// ======================================================

const BREAKDOWN = [
  { star: 5, count: "1,000", width: "88%" },
  { star: 4, count: "180", width: "32%" },
  { star: 3, count: "40", width: "14%" },
  { star: 2, count: "10", width: "7%" },
  { star: 1, count: "4", width: "4%" },
];

// ======================================================
// REVIEWS
// ======================================================

const REVIEWS = [
  {
    id: "1",
    name: "Ramesh Thapa",
    date: "2 days ago",
    rating: 5,
    comment:
      "Amazing place! The view is breathtaking and the service was excellent.",
    likes: "12",
    placeName: "",
  },
  {
    id: "2",
    name: "Anita Gurung",
    date: "1 week ago",
    rating: 5,
    comment:
      "Pokhara is a beautiful place with stunning views, fresh air, and amazing natural scenery. A perfect place to relax and explore!",
    likes: "8",
    placeName: "Pokhara",
  },
];

// ======================================================
// RATING SCREEN
// ======================================================

export default function RatingScreen({ navigation }: Props) {
  const [activeTab, setActiveTab] = useState("All");

  const tabs = ["All", "Photos", "Videos", "Helpful"];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.page}
      >
        {/* =================================================
            BACK BUTTON
        ================================================= */}

        <View style={styles.topHeader}>
          <BackButton navigation={navigation} style={styles.backButton} iconColor="#111111" iconSize={30} />
        </View>

        {/* =================================================
            PAGE HEADING
        ================================================= */}

        <Text style={styles.pageHeading}>Reviews & Ratings</Text>

        {/* =================================================
            MAIN WHITE CARD
        ================================================= */}

        <View style={styles.mainCard}>
          {/* =================================================
              RATING SUMMARY
          ================================================= */}

          <View style={styles.summary}>
            {/* LEFT SIDE */}

            <View style={styles.ratingLeft}>
              <Text style={styles.ratingNumber}>4.8</Text>

              <View style={styles.mainStars}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <Ionicons
                    key={star}
                    name="star"
                    size={17}
                    color="#FFB800"
                  />
                ))}
              </View>

              <Text style={styles.reviewCount}>
                (1,234 reviews)
              </Text>
            </View>

            {/* RIGHT SIDE - BREAKDOWN */}

            <View style={styles.breakdown}>
              {BREAKDOWN.map((item) => (
                <View
                  key={item.star}
                  style={styles.breakdownRow}
                >
                  <Text style={styles.starNumber}>
                    {item.star}
                  </Text>

                  <Ionicons
                    name="star"
                    size={14}
                    color="#FFB800"
                  />

                  <View style={styles.barBackground}>
                    <View
                      style={[
                        styles.barFill,
                        { width: item.width as any },
                      ]}
                    />
                  </View>

                  <Text style={styles.countText}>
                    {item.count}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* =================================================
              FILTER TABS
          ================================================= */}

          <View style={styles.tabsContainer}>
            {tabs.map((tab) => {
              const active = activeTab === tab;

              return (
                <Pressable
                  key={tab}
                  onPress={() => setActiveTab(tab)}
                  style={[
                    styles.tab,
                    active && styles.activeTab,
                  ]}
                >
                  <Text
                    style={[
                      styles.tabText,
                      active && styles.activeTabText,
                    ]}
                  >
                    {tab}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* =================================================
              REVIEWS
          ================================================= */}

          <View style={styles.reviewsContainer}>
            {REVIEWS.map((review) => (
              <View
                key={review.id}
                style={styles.reviewCard}
              >
                {/* USER INFORMATION */}

                <View style={styles.userRow}>
                  <View style={styles.avatar}>
                    <Text style={styles.avatarText}>
                      {review.name.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toLocaleUpperCase()}
                    </Text>
                  </View>

                  <View style={styles.userInfo}>
                    <Text style={styles.userName}>
                      {review.name}
                    </Text>

                    <Text style={styles.date}>
                      {review.date}
                    </Text>
                  </View>
                </View>

                {/* STARS */}

                <View style={styles.reviewStars}>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Ionicons
                      key={star}
                      name={
                        star <= review.rating
                          ? "star"
                          : "star-outline"
                      }
                      size={14}
                      color="#FFB800"
                    />
                  ))}
                </View>

                {/* COMMENT */}

                <Text style={styles.comment}>
                  {review.comment}
                </Text>

                {/* REVIEW PHOTOS */}

                <View style={styles.photoRow}>
                  {review.placeName ? (
                    <RelevantImage
                      entity={{ name: review.placeName, type: "destination", location: "Nepal" }}
                      style={styles.reviewPhoto}
                    />
                  ) : null}
                </View>

                {/* BOTTOM ACTIONS */}

                <View style={styles.actionRow}>
                  <View style={styles.leftActions}>
                    <Pressable style={styles.action}>
                      <Ionicons
                        name="thumbs-up-outline"
                        size={17}
                        color="#555"
                      />

                      <Text style={styles.actionText}>
                        {review.likes}
                      </Text>
                    </Pressable>

                    <Pressable style={styles.action}>
                      <Ionicons
                        name="chatbox-outline"
                        size={17}
                        color="#555"
                      />

                      <Text style={styles.actionText}>
                        Reply
                      </Text>
                    </Pressable>
                  </View>

                  <Pressable>
                    <Text style={styles.replyText}>
                      Reply
                    </Text>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ======================================================
// STYLES
// ======================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F5F5",
  },

  // ====================================================
  // TOP HEADER / BACK BUTTON
  // ====================================================

  topHeader: {
    width: "100%",
    maxWidth: 700,
    height: 55,
    justifyContent: "center",
    alignItems: "flex-start",
    marginBottom: 5,
  },

  backButton: {
    width: 42,
    height: 42,
    justifyContent: "center",
    alignItems: "center",
  },

  // ====================================================
  // PAGE
  // ====================================================

  page: {
    paddingHorizontal: 8,
    paddingTop: 0,
    paddingBottom: 25,
    alignItems: "center",
  },

  // ====================================================
  // PAGE HEADING
  // ====================================================

  pageHeading: {
    width: "100%",
    maxWidth: 700,
    fontSize: 17,
    color: "#A0A0A0",
    fontWeight: "400",
    marginBottom: 10,
  },

  // ====================================================
  // MAIN WHITE CARD
  // ====================================================

  mainCard: {
    width: "100%",
    maxWidth: 700,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    paddingTop: 30,
    paddingHorizontal: 8,
    paddingBottom: 30,

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.04,
    shadowRadius: 5,
    elevation: 2,
  },

  // ====================================================
  // RATING SUMMARY
  // ====================================================

  summary: {
    flexDirection: "row",
    paddingHorizontal: 30,
    minHeight: 165,
  },

  ratingLeft: {
    width: "46%",
    paddingTop: 15,
  },

  ratingNumber: {
    fontSize: 32,
    fontWeight: "500",
    color: "#111111",
  },

  mainStars: {
    flexDirection: "row",
    marginTop: 3,
    gap: 1,
  },

  reviewCount: {
    fontSize: 13,
    color: "#888888",
    marginTop: 8,
  },

  // ====================================================
  // RATING BREAKDOWN
  // ====================================================

  breakdown: {
    flex: 1,
    justifyContent: "center",
    paddingTop: 5,
  },

  breakdownRow: {
    flexDirection: "row",
    alignItems: "center",
    height: 20,
  },

  starNumber: {
    width: 13,
    fontSize: 12,
    color: "#222222",
    textAlign: "right",
    marginRight: 3,
  },

  barBackground: {
    height: 7,
    flex: 1,
    backgroundColor: "#E9E9E9",
    borderRadius: 5,
    marginLeft: 10,
    marginRight: 10,
    overflow: "hidden",
  },

  barFill: {
    height: "100%",
    backgroundColor: "#FFB800",
    borderRadius: 5,
  },

  countText: {
    width: 28,
    fontSize: 10,
    color: "#222222",
  },

  // ====================================================
  // TABS
  // ====================================================

  tabsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 24,
    marginTop: 7,
    marginBottom: 30,
  },

  tab: {
    minWidth: 70,
    height: 34,
    paddingHorizontal: 15,
    borderRadius: 9,
    borderWidth: 1,
    borderColor: "#EEEEEE",
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
  },

  activeTab: {
    backgroundColor: "#5856D6",
    borderColor: "#5856D6",
  },

  tabText: {
    fontSize: 12,
    color: "#111111",
    fontWeight: "500",
  },

  activeTabText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  // ====================================================
  // REVIEWS
  // ====================================================

  reviewsContainer: {
    paddingHorizontal: 7,
  },

  reviewCard: {
    borderWidth: 1,
    borderColor: "#E5E5E5",
    borderRadius: 9,
    padding: 14,
    marginBottom: 14,
    backgroundColor: "#FFFFFF",
  },

  // ====================================================
  // USER ROW
  // ====================================================

  userRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#E8F3F0",
  },
  avatarText: {
    color: colors.primaryDark,
    fontSize: 13,
    fontWeight: "800",
  },

  userInfo: {
    marginLeft: 11,
  },

  userName: {
    fontSize: 13,
    fontWeight: "700",
    color: "#111111",
  },

  date: {
    fontSize: 11,
    color: "#777777",
    marginTop: 3,
  },

  // ====================================================
  // REVIEW STARS
  // ====================================================

  reviewStars: {
    flexDirection: "row",
    gap: 1,
    marginTop: 10,
  },

  // ====================================================
  // COMMENT
  // ====================================================

  comment: {
    fontSize: 12.5,
    lineHeight: 16,
    color: "#555555",
    marginTop: 9,
    marginBottom: 12,
  },

  // ====================================================
  // REVIEW PHOTOS
  // ====================================================

  photoRow: {
    flexDirection: "row",
    gap: 5,
  },

  reviewPhoto: {
    flex: 1,
    height: 57,
    borderRadius: 9,
    backgroundColor: "#EEEEEE",
  },

  // ====================================================
  // BOTTOM ACTIONS
  // ====================================================

  actionRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 17,
  },

  leftActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 24,
  },

  action: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
  },

  actionText: {
    fontSize: 12,
    color: "#777777",
  },

  replyText: {
    fontSize: 12,
    color: "#777777",
  },
});