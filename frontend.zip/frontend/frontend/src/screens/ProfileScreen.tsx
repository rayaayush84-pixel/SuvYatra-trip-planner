import React from "react";
import {
  Alert,
  Image,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { navigateToScreen } from "../../App";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type MenuItem = {
  id: string;
  title: string;
  icon: string;
  route: string;
  tab?: boolean;
};

const MENU_ITEMS: MenuItem[] = [
  { id: "1", title: "Edit Profile", icon: "person-outline", route: "EditProfile" },
  { id: "2", title: "My Bookings", icon: "document-text-outline", route: "Bookings" },
  { id: "3", title: "Saved Places", icon: "heart-outline", route: "Saved", tab: true },
  { id: "4", title: "Notifications", icon: "notifications-outline", route: "Notifications" },
  { id: "5", title: "Help & Support", icon: "help-circle-outline", route: "Help" },
  { id: "6", title: "Settings", icon: "settings-outline", route: "Settings" },
];

export default function ProfileScreen() {
  const navigation = useNavigation<any>();
  const { user, logout, termsAccepted, getAccessToken } = useAuth();
  const userId = user?._id ?? user?.id;
  const [stats, setStats] = useState({ trips: 0, reviews: 0, saved: 0 });
  const [statsError, setStatsError] = useState("");

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!userId || !token) {
        setStats({ trips: 0, reviews: 0, saved: 0 });
        setStatsError("");
        return;
      }

      const controller = new AbortController();
      const headers = { Authorization: `Bearer ${token}` };
      const query = `?userId=${encodeURIComponent(userId)}`;
      setStatsError("");
      Promise.all([
        backendRequest<unknown[]>(`/trips${query}`, {
          signal: controller.signal,
          headers,
        }),
        backendRequest<unknown[]>(`/reviews${query}`, {
          signal: controller.signal,
          headers,
        }),
        backendRequest<unknown[]>("/saved-items", {
          signal: controller.signal,
          headers,
        }),
      ])
        .then(([trips, reviews, saved]) => {
          setStats({ trips: trips.length, reviews: reviews.length, saved: saved.length });
        })
        .catch((error: unknown) => {
          if (!controller.signal.aborted) {
            setStatsError(
              error instanceof Error ? error.message : "Could not load profile activity."
            );
          }
        });

      return () => controller.abort();
    }, [getAccessToken, userId])
  );

  const openMenu = (item: MenuItem) => {
    if (item.tab) {
      navigation.navigate(item.route);
      return;
    }

    navigateToScreen(item.route as any);
  };

  const performLogout = async () => {
    await logout();
    navigation.getParent()?.reset({
      index: 0,
      routes: termsAccepted
        ? [{ name: "Login", params: { provider: "Email" } }]
        : [{ name: "TermsAndConditions" }],
    });
  };

  const confirmLogout = () => {
    const message = "Are you sure you want to log out of your SuvYatra account?";
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(message)) {
        void performLogout();
      }
      return;
    }

    Alert.alert("Log out", message, [
      { text: "Cancel", style: "cancel" },
      { text: "Log Out", style: "destructive", onPress: () => void performLogout() },
    ]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.pageTitle}>Profile</Text>

        {!user ? (
          <View style={styles.signedOutCard}>
            <View style={styles.signedOutAvatar}>
              <Ionicons name="person" size={40} color="#FFFFFF" />
            </View>
            <Text style={styles.signedOutTitle}>You're not signed in</Text>
            <Text style={styles.signedOutText}>
              Sign in to manage your trips, bookings, saved places and settings.
            </Text>
            <Pressable
              style={({ pressed }) => [
                styles.signInButton,
                pressed && styles.buttonPressed,
              ]}
              onPress={() =>
                navigateToScreen(termsAccepted ? "Login" : "TermsAndConditions")
              }
              accessibilityRole="button"
            >
              <Ionicons name="log-in-outline" size={18} color="#FFFFFF" />
              <Text style={styles.signInText}>Sign In / Create Account</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <View style={styles.headerCard}>
              <Image source={{ uri: user.avatar }} style={styles.profileImage} />
              <Text style={styles.name}>{user.name}</Text>
              <Text style={styles.email}>{user.email}</Text>
              {user.location ? (
                <View style={styles.locationRow}>
                  <Ionicons name="location-outline" size={13} color={colors.textMuted} />
                  <Text style={styles.location}>{user.location}</Text>
                </View>
              ) : null}
              {user.memberSince ? (
                <Text style={styles.memberSince}>Member since {user.memberSince}</Text>
              ) : null}

              <Pressable
                style={({ pressed }) => [
                  styles.editButton,
                  pressed && styles.buttonPressed,
                ]}
                onPress={() => navigateToScreen("EditProfile")}
                accessibilityRole="button"
              >
                <Ionicons name="create-outline" size={16} color="#FFFFFF" />
                <Text style={styles.editText}>Edit Profile</Text>
              </Pressable>
            </View>

            <View style={styles.statsRow}>
              {[
                { label: "Trips", value: stats.trips },
                { label: "Reviews", value: stats.reviews },
                { label: "Saved", value: stats.saved },
              ].map((stat) => (
                <View key={stat.label} style={styles.statBox}>
                  <Text style={styles.statNumber}>{stat.value}</Text>
                  <Text style={styles.statLabel}>{stat.label}</Text>
                </View>
              ))}
            </View>
            {statsError ? <Text style={styles.statsError}>{statsError}</Text> : null}

            <View style={styles.menuCard}>
              {MENU_ITEMS.map((item, index) => (
                <Pressable
                  key={item.id}
                  style={({ pressed }) => [
                    styles.menuItem,
                    pressed && styles.menuItemPressed,
                  ]}
                  onPress={() => openMenu(item)}
                  accessibilityRole="button"
                >
                  <View style={styles.menuLeft}>
                    <View style={styles.menuIcon}>
                      <Ionicons name={item.icon as any} size={20} color={colors.primaryDark} />
                    </View>
                    <Text style={styles.menuText}>{item.title}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color="#A0A0A0" />
                </Pressable>
              ))}
              {user.role === "admin" && (
                <>
                  <Pressable
                    style={styles.menuItem}
                    onPress={() => navigateToScreen("AdminRegisteredUsers")}
                    accessibilityRole="button"
                  >
                    <View style={styles.menuLeft}>
                      <View style={styles.menuIcon}>
                        <Ionicons name="people-outline" size={20} color={colors.primaryDark} />
                      </View>
                      <Text style={styles.menuText}>Registered Users</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={18} color="#A0A0A0" />
                  </Pressable>
                  <Pressable
                    style={styles.menuItem}
                    onPress={() => navigateToScreen("AdminLoginActivity")}
                    accessibilityRole="button"
                  >
                    <View style={styles.menuLeft}>
                      <View style={styles.menuIcon}>
                        <Ionicons name="time-outline" size={20} color={colors.primaryDark} />
                      </View>
                      <Text style={styles.menuText}>User Login Activity</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={18} color="#A0A0A0" />
                  </Pressable>
                </>
              )}
              <Pressable
                style={({ pressed }) => [
                  styles.menuItem,
                  styles.logoutMenuItem,
                  pressed && styles.menuItemPressed,
                ]}
                onPress={confirmLogout}
                accessibilityRole="button"
                accessibilityLabel="Log out of SuvYatra"
              >
                <View style={styles.menuLeft}>
                  <View style={[styles.menuIcon, styles.logoutMenuIcon]}>
                    <Ionicons name="log-out-outline" size={20} color="#DC2626" />
                  </View>
                  <Text style={[styles.menuText, styles.logoutText]}>Log Out</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color="#DC2626" />
              </Pressable>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  content: {
    padding: spacing.xl,
    paddingBottom: 120,
  },

  pageTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: colors.text,
    marginBottom: spacing.lg,
  },

  signedOutCard: {
    backgroundColor: colors.white,
    borderRadius: radius.xl,
    padding: spacing.xxl,
    alignItems: "center",
    marginTop: spacing.md,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },

  signedOutAvatar: {
    width: 88,
    height: 88,
    borderRadius: radius.full,
    backgroundColor: colors.primary,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.lg,
  },

  signedOutTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
  },

  signedOutText: {
    fontSize: 13.5,
    color: colors.textMuted,
    textAlign: "center",
    lineHeight: 19,
    marginTop: spacing.sm,
    marginBottom: spacing.xl,
  },

  signInButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    paddingHorizontal: spacing.xl,
    width: "100%",
  },

  signInText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
    marginLeft: 8,
  },

  headerCard: {
    backgroundColor: colors.white,
    borderRadius: radius.xl,
    padding: spacing.xl,
    alignItems: "center",
    marginBottom: spacing.lg,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },

  profileImage: {
    width: 96,
    height: 96,
    borderRadius: radius.full,
    borderWidth: 3,
    borderColor: "#B4E6D1",
    marginBottom: spacing.md,
  },

  name: {
    fontSize: 21,
    fontWeight: "700",
    color: colors.text,
  },

  email: {
    fontSize: 13.5,
    color: colors.textMuted,
    marginTop: 4,
  },

  locationRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: spacing.sm,
  },

  location: {
    fontSize: 13,
    color: colors.textMuted,
    marginLeft: 4,
  },

  memberSince: {
    fontSize: 12,
    color: colors.textMuted,
    marginTop: 2,
    marginBottom: spacing.md,
  },

  editButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.lg,
    paddingVertical: 9,
    borderRadius: radius.full,
  },

  editText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "700",
    marginLeft: 6,
  },

  statsRow: {
    flexDirection: "row",
    marginBottom: spacing.lg,
  },
  statsError: {
    color: colors.textMuted,
    fontSize: 12,
    marginTop: -spacing.md,
    marginBottom: spacing.lg,
    textAlign: "center",
  },

  statBox: {
    flex: 1,
    backgroundColor: colors.white,
    marginHorizontal: 5,
    borderRadius: radius.lg,
    paddingVertical: spacing.lg,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.04,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
  },

  statNumber: {
    fontSize: 20,
    fontWeight: "700",
    color: colors.primaryDark,
  },

  statLabel: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 4,
  },

  menuCard: {
    backgroundColor: colors.white,
    borderRadius: radius.xl,
    overflow: "hidden",
    marginBottom: spacing.lg,
    shadowColor: "#000",
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
  },

  menuItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 14,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },

  menuItemPressed: {
    backgroundColor: "#F2F5F4",
  },

  menuLeft: {
    flexDirection: "row",
    alignItems: "center",
  },

  menuIcon: {
    width: 38,
    height: 38,
    borderRadius: radius.md,
    backgroundColor: "#EAF8F2",
    alignItems: "center",
    justifyContent: "center",
  },

  menuText: {
    fontSize: 15,
    color: colors.text,
    marginLeft: spacing.md,
    fontWeight: "500",
  },

  logoutMenuItem: {
    borderBottomWidth: 0,
    backgroundColor: "#FFFAFA",
  },

  logoutMenuIcon: {
    backgroundColor: "#FEF2F2",
  },

  logoutText: {
    color: "#DC2626",
    fontSize: 15,
    fontWeight: "700",
  },

  buttonPressed: {
    opacity: 0.8,
  },
});