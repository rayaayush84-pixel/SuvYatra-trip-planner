import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import { validateQuantityText } from "../utils/quantityValidation";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "Hotels">;
type HotelRecord = {
  _id: string;
  name: string;
  location?: string;
  city?: string;
  district?: string;
  province?: string;
  destination?: string;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  roomTypes?: {
    _id: string;
    name: string;
    capacityAdults: number;
    capacityChildren: number;
    totalRooms: number;
    nightlyRate?: number;
    availableRooms?: number;
    matchesOccupancy?: boolean;
  }[];
  availableForSearch?: boolean;
  pricePerNight?: number;
  rating?: number;
  amenities?: string[];
  propertyTypes?: string[];
  travelerTypes?: string[];
  specialFeatures?: string[];
  latitude?: number;
  longitude?: number;
  isDemoData?: boolean;
  createdAt?: string;
};
type FilterOptions = {
  cities: string[];
  districts: string[];
  provinces: string[];
  destinations: string[];
  propertyTypes: string[];
  facilities: string[];
  travelerTypes: string[];
  specialFeatures: string[];
};
type SavedItem = { _id: string; itemType: string; itemId?: string; name: string };
type SortOption = "recommended" | "relevance" | "price-asc" | "price-desc" | "newest";

const EMPTY_FILTERS: FilterOptions = {
  cities: [],
  districts: [],
  provinces: [],
  destinations: [],
  propertyTypes: [],
  facilities: [],
  travelerTypes: [],
  specialFeatures: [],
};

const PRICE_RANGES = [
  { label: "Any price", min: undefined, max: undefined },
  { label: "Under NPR 2,000", min: undefined, max: 1999 },
  { label: "NPR 2,000–5,000", min: 2000, max: 5000 },
  { label: "NPR 5,000–10,000", min: 5001, max: 10000 },
  { label: "NPR 10,000+", min: 10000, max: undefined },
];
function isFutureDateOnly(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) &&
    date.toISOString().slice(0, 10) === value &&
    value >= new Date().toISOString().slice(0, 10);
}

const SORT_OPTIONS: { label: string; value: SortOption }[] = [
  { label: "Recommended (name order)", value: "recommended" },
  { label: "Most relevant", value: "relevance" },
  { label: "Price: Low → High", value: "price-asc" },
  { label: "Price: High → Low", value: "price-desc" },
  { label: "Newest", value: "newest" },
];

export default function HotelListScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const [hotels, setHotels] = useState<HotelRecord[]>([]);
  const [filters, setFilters] = useState<FilterOptions>(EMPTY_FILTERS);
  const [savedItems, setSavedItems] = useState<SavedItem[]>([]);
  const [query, setQuery] = useState(route.params?.location ?? "");
  const [submittedSearch, setSubmittedSearch] = useState(route.params?.location?.trim() ?? "");
  const [selectedPrice, setSelectedPrice] = useState(0);
  const [minPriceText, setMinPriceText] = useState("");
  const [maxPriceText, setMaxPriceText] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [adults, setAdults] = useState("");
  const [children, setChildren] = useState("");
  const [rooms, setRooms] = useState("");
  const [availabilityApplied, setAvailabilityApplied] = useState(false);
  const [availabilityError, setAvailabilityError] = useState("");
  const [selectedCities, setSelectedCities] = useState<string[]>([]);
  const [selectedDistricts, setSelectedDistricts] = useState<string[]>([]);
  const [selectedProvinces, setSelectedProvinces] = useState<string[]>([]);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>([]);
  const [selectedProperties, setSelectedProperties] = useState<string[]>([]);
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([]);
  const [selectedTravelers, setSelectedTravelers] = useState<string[]>([]);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [sort, setSort] = useState<SortOption>("recommended");
  const [loading, setLoading] = useState(true);
  const [filterLoading, setFilterLoading] = useState(true);
  const [error, setError] = useState("");
  const [filterError, setFilterError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [savingId, setSavingId] = useState("");
  const [savedError, setSavedError] = useState("");
  const [mapsError, setMapsError] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };

  useEffect(() => {
    if (route.params?.location !== undefined) {
      const value = route.params.location.trim();
      setQuery(value);
      setSubmittedSearch(value);
    }
  }, [route.params?.location]);

  const activePrice = PRICE_RANGES[selectedPrice];
  const params = useMemo(() => {
    const search = new URLSearchParams();
    if (submittedSearch) search.set("search", submittedSearch);
    if (selectedCities.length) search.set("city", selectedCities.join(","));
    if (selectedDistricts.length) search.set("district", selectedDistricts.join(","));
    if (selectedProvinces.length) search.set("province", selectedProvinces.join(","));
    if (selectedDestinations.length) search.set("destination", selectedDestinations.join(","));
    if (selectedProperties.length) search.set("propertyType", selectedProperties.join(","));
    if (selectedFacilities.length) search.set("facility", selectedFacilities.join(","));
    if (selectedTravelers.length) search.set("travelerType", selectedTravelers.join(","));
    if (selectedFeatures.length) search.set("specialFeature", selectedFeatures.join(","));
    if (availabilityApplied) {
      search.set("checkIn", checkIn);
      search.set("checkOut", checkOut);
      search.set("adults", adults);
      search.set("children", children);
      search.set("rooms", rooms);
    }
    const customMin = minPriceText.trim() ? Number(minPriceText) : undefined;
    const customMax = maxPriceText.trim() ? Number(maxPriceText) : undefined;
    if (minPriceText && (!Number.isFinite(customMin) || (customMin as number) < 0)) return null;
    if (maxPriceText && (!Number.isFinite(customMax) || (customMax as number) < 0)) return null;
    if (minPriceText || maxPriceText) {
      if (customMin !== undefined) search.set("minPrice", String(customMin));
      if (customMax !== undefined) search.set("maxPrice", String(customMax));
    } else {
      if (activePrice.min !== undefined) search.set("minPrice", String(activePrice.min));
      if (activePrice.max !== undefined) search.set("maxPrice", String(activePrice.max));
    }
    if (sort !== "recommended") search.set("sort", sort);
    return search.toString();
  }, [
    activePrice.max,
    activePrice.min,
    maxPriceText,
    minPriceText,
    checkIn,
    checkOut,
    adults,
    children,
    rooms,
    availabilityApplied,
    selectedCities,
    selectedDistricts,
    selectedFacilities,
    selectedFeatures,
    selectedProperties,
    selectedDestinations,
    selectedTravelers,
    selectedProvinces,
    sort,
    submittedSearch,
  ]);

  useEffect(() => {
    const controller = new AbortController();
    setFilterLoading(true);
    setFilterError("");
    backendRequest<FilterOptions>("/hotels/filters", { signal: controller.signal })
      .then(setFilters)
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setFilterError(requestError instanceof Error ? requestError.message : "Could not load hotel filters.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setFilterLoading(false);
      });
    return () => controller.abort();
  }, [reloadKey]);

  useEffect(() => {
    if (params === null) {
      setError("Enter valid minimum and maximum nightly prices.");
      setLoading(false);
      setHotels([]);
      return;
    }
    const controller = new AbortController();
    setLoading(true);
    setError("");
    backendRequest<HotelRecord[]>(`/hotels${params ? `?${params}` : ""}`, {
      signal: controller.signal,
    })
      .then(setHotels)
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load hotels.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [params, reloadKey]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId) {
        setSavedItems([]);
        return;
      }
      const controller = new AbortController();
      backendRequest<SavedItem[]>(`/saved-items?userId=${encodeURIComponent(userId)}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((items) => setSavedItems(items.filter((item) => item.itemType === "hotel")))
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setSavedError(requestError instanceof Error ? requestError.message : "Could not load saved hotels.");
          }
        });
      return () => controller.abort();
    }, [getAccessToken, userId])
  );

  const toggleSelection = (
    value: string,
    values: string[],
    setValues: React.Dispatch<React.SetStateAction<string[]>>
  ) => setValues(values.includes(value) ? values.filter((item) => item !== value) : [...values, value]);

  const resetFilters = () => {
    setQuery("");
    setSubmittedSearch("");
    setSelectedPrice(0);
    setMinPriceText("");
    setMaxPriceText("");
    setSelectedCities([]);
    setSelectedDistricts([]);
    setSelectedProvinces([]);
    setSelectedDestinations([]);
    setSelectedProperties([]);
    setSelectedFacilities([]);
    setSelectedTravelers([]);
    setSelectedFeatures([]);
    setSort("recommended");
    setCheckIn("");
    setCheckOut("");
    setAdults("");
    setChildren("");
    setRooms("");
    setAvailabilityApplied(false);
    setAvailabilityError("");
  };

  const toggleFavorite = async (hotel: HotelRecord) => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", { notice: "Sign in to save hotels to Saved Places." });
      return;
    }
    setSavingId(hotel._id);
    setSavedError("");
    try {
      const saved = savedItems.find(
        (item) => item.itemType === "hotel" && (item.itemId === hotel._id || item.name === hotel.name)
      );
      if (saved) {
        await backendRequest(`/saved-items/${saved._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItems((current) => current.filter((item) => item._id !== saved._id));
        showToast("Removed from saved");
      } else {
        const item = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            userId,
            itemType: "hotel",
            itemId: hotel._id,
            name: hotel.name,
            location: hotel.location ?? hotel.city,
            image: hotel.image,
            imageSource: hotel.imageSource,
            imageSourcePage: hotel.imageSourcePage,
            imageLicense: hotel.imageLicense,
            imageCredit: hotel.imageCredit,
            imageDescription: hotel.imageDescription,
            imageRelevance: hotel.imageRelevance,
          }),
        });
        setSavedItems((current) => [...current, item]);
        showToast("Saved to your places");
      }
    } catch (requestError) {
      setSavedError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSavingId("");
    }
  };

  const openMap = async (hotel: HotelRecord) => {
    const query = hotel.latitude != null && hotel.longitude != null
      ? `${hotel.latitude},${hotel.longitude}`
      : [hotel.name, hotel.location, hotel.city].filter(Boolean).join(", ");
    if (!query) {
      setMapsError("This listing does not include a usable location.");
      return;
    }
    setMapsError("");
    try {
      await Linking.openURL(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`
      );
    } catch (requestError) {
      setMapsError(requestError instanceof Error ? requestError.message : "Could not open Maps.");
    }
  };

  const openHotelDetails = (hotelId: string) => {
    const availabilitySearch = availabilityApplied
      ? {
        checkIn,
        checkOut,
        adults: Number(adults),
        children: Number(children),
        rooms: Number(rooms),
      }
      : undefined;
    navigation.push("HotelDetails", { hotelId, availabilitySearch });
  };

  const applyAvailabilitySearch = () => {
    const adultsError = validateQuantityText(adults, "adults");
    if (adultsError) {
      setAvailabilityError(adultsError);
      return;
    }
    const childrenError = validateQuantityText(children, "children");
    if (childrenError) {
      setAvailabilityError(childrenError);
      return;
    }
    const roomsError = validateQuantityText(rooms, "rooms");
    if (roomsError) {
      setAvailabilityError(roomsError);
      return;
    }
    const adultCount = Number(adults);
    const childCount = Number(children);
    const roomCount = Number(rooms);
    if (
      !isFutureDateOnly(checkIn) ||
      !isFutureDateOnly(checkOut) ||
      checkOut <= checkIn ||
      adultCount + childCount > 20
    ) {
      setAvailabilityError("Choose valid future dates, 1–20 adults, 0–20 children, and 1–10 rooms (20 guests maximum).");
      return;
    }
    setAvailabilityError("");
    setAvailabilityApplied(true);
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <BackButton navigation={navigation} />
          <Text style={styles.title}>Find a stay</Text>
          <Pressable onPress={resetFilters} accessibilityRole="button">
            <Text style={styles.resetText}>Reset</Text>
          </Pressable>
        </View>
        <Text style={styles.subtitle}>Search real hotel records and filter on data each property provides.</Text>

        {filterError ? <Text style={styles.errorText}>{filterError}</Text> : null}
        {filterLoading ? <ActivityIndicator size="small" color={colors.primary} /> : null}
        {filters.travelerTypes.length > 0 ? (
          <FilterGroup
            title="Traveler type"
            values={filters.travelerTypes}
            selected={selectedTravelers}
            onToggle={(value) => toggleSelection(value, selectedTravelers, setSelectedTravelers)}
          />
        ) : null}
        {filters.specialFeatures.length > 0 ? (
          <FilterGroup
            title="Special features"
            values={filters.specialFeatures}
            selected={selectedFeatures}
            onToggle={(value) => toggleSelection(value, selectedFeatures, setSelectedFeatures)}
          />
        ) : null}
        {!filterLoading &&
          !filters.propertyTypes.length &&
          !filters.facilities.length &&
          !filters.travelerTypes.length &&
          !filters.specialFeatures.length ? (
            <Text style={styles.missingData}>
              Property types, facilities, traveler types, and special features are not supplied by current hotel records.
            </Text>
          ) : null}

        <View style={styles.resultsHeading}>
          <View>
            <Text style={styles.resultCount}>{loading ? "Searching…" : `${hotels.length} matching records`}</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {SORT_OPTIONS.map((option) => (
              <Chip
                key={option.value}
                label={option.label}
                active={sort === option.value}
                onPress={() => setSort(option.value)}
              />
            ))}
          </ScrollView>
        </View>
        <Text style={styles.sortNote}>
          Recommended uses alphabetical name order; distance sorting is unavailable without hotel coordinates.
        </Text>

        {savedError || mapsError ? <Text style={styles.errorText}>{savedError || mapsError}</Text> : null}
        {error ? (
          <View style={styles.emptyState}>
            <Text style={styles.errorText}>{error}</Text>
            <Pressable onPress={() => setReloadKey((value) => value + 1)}>
              <Text style={styles.retryText}>Try again</Text>
            </Pressable>
          </View>
        ) : loading ? (
          <ActivityIndicator style={styles.loader} size="large" color={colors.primary} />
        ) : hotels.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="bed-outline" size={32} color={colors.primary} />
            <Text style={styles.emptyTitle}>{submittedSearch ? "No matching hotels found" : "No hotel records found"}</Text>
            <Text style={styles.emptyText}>Try a different search or reset filters. Results come from the hotel database.</Text>
          </View>
        ) : (
          hotels.map((hotel) => {
            const saved = savedItems.some(
              (item) => item.itemType === "hotel" && (item.itemId === hotel._id || item.name === hotel.name)
            );
            return (
              <View key={hotel._id} style={styles.hotelCard}>
                <Pressable onPress={() => openHotelDetails(hotel._id)}>
                  <RelevantImage entity={{ name: hotel.name, type: "hotel", location: [hotel.location, hotel.city, hotel.district].filter(Boolean).join(", "), image: hotel.image, images: hotel.images, imageSource: hotel.imageSource, imageSourcePage: hotel.imageSourcePage, imageLicense: hotel.imageLicense, imageCredit: hotel.imageCredit, imageDescription: hotel.imageDescription, imageRelevance: hotel.imageRelevance }} style={styles.hotelImage} />
                </Pressable>
                <View style={styles.hotelBody}>
                  <View style={styles.cardTitleRow}>
                    <Text style={styles.hotelName}>{hotel.name}</Text>
                    <Pressable
                      onPress={() => void toggleFavorite(hotel)}
                      disabled={savingId === hotel._id}
                      accessibilityRole="button"
                      accessibilityLabel={saved ? `Unsave ${hotel.name}` : `Save ${hotel.name}`}
                    >
                      {savingId === hotel._id ? <ActivityIndicator size="small" color={colors.primary} /> : (
                        <Ionicons name={saved ? "heart" : "heart-outline"} size={22} color={saved ? "#D9435F" : colors.primary} />
                      )}
                    </Pressable>
                  </View>
                  <Text style={styles.locationText}>
                    {[hotel.location, hotel.city, hotel.district, hotel.province, hotel.destination].filter(Boolean).join(", ") || "Location not provided"}
                  </Text>
                  {hotel.isDemoData ? <Text style={styles.demoLabel}>DEMO LISTING · NOT BOOKABLE</Text> : null}
                  {!!hotel.description ? <Text style={styles.description} numberOfLines={2}>{hotel.description}</Text> : null}
                  {hotel.propertyTypes?.length ? <Text style={styles.metaText}>{hotel.propertyTypes.join(" · ")}</Text> : null}
                  {hotel.amenities?.length ? <Text style={styles.metaText}>{hotel.amenities.join(" · ")}</Text> : null}
                  {availabilityApplied ? (
                    <Text style={styles.availabilityHint}>
                      {hotel.roomTypes?.filter((roomType) => roomType.matchesOccupancy && (roomType.availableRooms ?? 0) >= Number(rooms))
                        .map((roomType) => `${roomType.name}: ${roomType.availableRooms} available`)
                        .join(" · ") || "Availability changed; run the search again."}
                    </Text>
                  ) : null}
                  <View style={styles.cardFooter}>
                    {typeof hotel.rating === "number" ? (
                      <Text style={styles.rating}>★ {hotel.rating.toFixed(1)}</Text>
                    ) : <Text style={styles.metaText}>No verified rating</Text>}
                    {typeof hotel.pricePerNight === "number" ? (
                      <Text style={styles.price}>NPR {hotel.pricePerNight.toLocaleString("en-IN")} / night</Text>
                    ) : <Text style={styles.metaText}>Nightly rate unavailable</Text>}
                  </View>
                  <View style={styles.actionRow}>
                    <Pressable
                      style={styles.secondaryButton}
                      onPress={() => openHotelDetails(hotel._id)}
                      accessibilityRole="button"
                    >
                      <Text style={styles.secondaryButtonText}>View details</Text>
                    </Pressable>
                    <Pressable style={styles.mapButton} onPress={() => void openMap(hotel)} accessibilityRole="button">
                      <Ionicons name="map-outline" size={16} color={colors.primaryDark} />
                      <Text style={styles.mapButtonText}>Maps</Text>
                    </Pressable>
                  </View>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

function FilterGroup({
  title,
  values,
  selected,
  onToggle,
}: {
  title: string;
  values: string[];
  selected: string[];
  onToggle: (value: string) => void;
}) {
  return (
    <View style={styles.filterGroup}>
      <Text style={styles.filterTitle}>{title}</Text>
      <View style={styles.chipWrap}>
        {values.map((value) => (
          <Chip key={value} label={value} active={selected.includes(value)} onPress={() => onToggle(value)} />
        ))}
      </View>
    </View>
  );
}

function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && styles.activeChip]} accessibilityRole="button" accessibilityState={{ selected: active }}>
      <Text style={[styles.chipText, active && styles.activeChipText]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: 110 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.md },
  title: { flex: 1, textAlign: "center", color: colors.text, fontSize: 23, fontWeight: "900" },
  resetText: { color: colors.primaryDark, fontSize: 12, fontWeight: "800" },
  subtitle: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: spacing.xs, marginBottom: spacing.md },
  availabilityPanel: { marginTop: spacing.md, padding: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, backgroundColor: colors.surface },
  availabilityRow: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.sm },
  availabilityInput: { flex: 1, minWidth: 0, minHeight: 40, paddingHorizontal: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, color: colors.text, backgroundColor: colors.background, fontSize: 11 },
  availabilityActions: { flexDirection: "row", alignItems: "center", gap: spacing.md, marginTop: spacing.md },
  availabilityButton: { minHeight: 38, paddingHorizontal: spacing.md, alignItems: "center", justifyContent: "center", borderRadius: radius.sm, backgroundColor: "#E8F3F0" },
  clearAvailabilityButton: { minHeight: 38, justifyContent: "center" },
  availabilityHint: { color: colors.primaryDark, fontSize: 11, lineHeight: 16, marginTop: spacing.sm },
  filterGroup: { marginTop: spacing.sm },
  filterTitle: { color: colors.text, fontSize: 13, fontWeight: "800", marginTop: spacing.md, marginBottom: spacing.sm },
  chipWrap: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  horizontalChips: { gap: 7 },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.full, paddingHorizontal: 10, paddingVertical: 7, backgroundColor: colors.surface },
  activeChip: { borderColor: colors.primary, backgroundColor: "#E8F3F0" },
  chipText: { color: colors.textMuted, fontSize: 10, fontWeight: "700" },
  activeChipText: { color: colors.primaryDark },
  priceInputRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginTop: spacing.sm },
  priceInput: { flex: 1, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, backgroundColor: colors.surface, minHeight: 38, paddingHorizontal: spacing.sm, color: colors.text, fontSize: 12 },
  rangeDash: { color: colors.textMuted, fontSize: 11 },
  missingData: { color: colors.textMuted, fontSize: 11, lineHeight: 17, marginTop: spacing.md },
  resultsHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.sm, marginTop: spacing.xl },
  resultsTitle: { color: colors.text, fontSize: 17, fontWeight: "900" },
  resultCount: { color: colors.textMuted, fontSize: 11, marginTop: 3 },
  sortNote: { color: colors.textMuted, fontSize: 10, lineHeight: 15, marginTop: spacing.sm, marginBottom: spacing.md },
  hotelCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, overflow: "hidden", marginBottom: spacing.md, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.08, shadowRadius: 16, elevation: 3 },
  hotelImage: { width: "100%", height: 200, backgroundColor: colors.border },
  imagePlaceholder: { alignItems: "center", justifyContent: "center", gap: spacing.sm },
  placeholderText: { color: colors.textMuted, fontSize: 11 },
  hotelBody: { padding: spacing.md },
  cardTitleRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  hotelName: { flex: 1, color: colors.text, fontSize: 16, fontWeight: "800" },
  locationText: { color: colors.textMuted, fontSize: 11, marginTop: 4, lineHeight: 16 },
  demoLabel: { color: "#9A3412", fontSize: 10, fontWeight: "900", marginTop: spacing.sm },
  description: { color: colors.text, fontSize: 12, lineHeight: 18, marginTop: spacing.sm },
  metaText: { color: colors.textMuted, fontSize: 10, lineHeight: 15, marginTop: 5 },
  cardFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.sm, marginTop: spacing.md },
  rating: { color: colors.text, fontSize: 11, fontWeight: "800" },
  price: { color: colors.primaryDark, fontSize: 14, fontWeight: "900" },
  actionRow: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.md },
  secondaryButton: { flex: 1, minHeight: 46, alignItems: "center", justifyContent: "center", borderRadius: radius.sm, backgroundColor: colors.primary, shadowColor: colors.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 8, elevation: 2 },
  secondaryButtonText: { color: colors.white, fontSize: 12, fontWeight: "800" },
  mapButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingHorizontal: spacing.md, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.primary },
  mapButtonText: { color: colors.primaryDark, fontSize: 11, fontWeight: "800" },
  emptyState: { alignItems: "center", padding: spacing.xl, backgroundColor: colors.surface, borderRadius: radius.md, gap: spacing.sm },
  emptyTitle: { color: colors.text, fontSize: 15, fontWeight: "800" },
  emptyText: { color: colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: "center" },
  retryText: { color: colors.primaryDark, fontSize: 13, fontWeight: "800" },
  errorText: { color: "#B42318", fontSize: 12, lineHeight: 17, marginVertical: spacing.sm },
  loader: { marginTop: spacing.xl },
});
