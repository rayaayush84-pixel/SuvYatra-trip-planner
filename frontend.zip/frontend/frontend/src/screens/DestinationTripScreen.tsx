import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import RelevantImage from "../components/RelevantImage";
import BSADDatePicker from "../components/BSADDatePicker";
import DestinationAutocomplete, { type DestinationSummary } from "../components/DestinationAutocomplete";
import LocationAutocomplete, { type LocationResult } from "../components/LocationAutocomplete";
import { todayAdISO, isStrictAdISO } from "../utils/bsDate";
import {
  confirmDestinationWithServer,
  confirmOriginWithServer,
  validateCompleteTripInput,
  type TripValidationError,
} from "../utils/tripValidation";
import {
  handleQuantityTextChange,
  quantityMaxMessage,
  validateQuantityText,
  type QuantityField,
} from "../utils/quantityValidation";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import {
  curatedFor,
  pickLesserKnown,
  resolveDestination,
  type CuratedActivity,
  type CuratedHotel,
  type CuratedPlace,
  type CuratedService,
} from "../data/completeTripFallbacks";

type Props = NativeStackScreenProps<RootStackParamList, "DestinationTrip">;

type DestinationRecord = {
  _id: string;
  name: string;
  description?: string;
  province?: string;
  highlights?: string[];
  tags?: string[];
  latitude?: number;
  longitude?: number;
  openingHours?: string;
  entryFee?: string | number;
  estimatedDuration?: string;
  bestTimeToVisit?: string;
  approximateCost?: string | number;
  whyVisit?: string;
  safetyInfo?: string;
  nearbyFacilities?: string[];
  /** True for curated fallback suggestions (not database inventory). */
  isCurated?: boolean;
};

type SeatInfo = { label: string; booked: boolean };
type SeatsResponse = {
  seatSelection?: boolean;
  capacity?: number;
  booked?: number;
  available?: number;
  seats?: SeatInfo[];
};

type TransportRecord = {
  _id: string;
  name: string;
  type?: string;
  provider?: string;
  origin?: string;
  destination?: string;
  departureTime?: string;
  arrivalTime?: string;
  durationMinutes?: number;
  price?: number;
  capacity?: number;
  serviceMode?: string;
  seatMap?: unknown;
  amenities?: string[];
  cancellationPolicy?: string;
  latitude?: number;
  longitude?: number;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
};

type RoomType = {
  _id: string;
  name: string;
  capacityAdults: number;
  capacityChildren: number;
  totalRooms: number;
  nightlyRate?: number;
  bedConfiguration?: string;
  breakfastIncluded?: boolean;
  amenities?: string[];
  availableRooms?: number;
  matchesOccupancy?: boolean;
};

type HotelRecord = {
  _id: string;
  name: string;
  location?: string;
  description?: string;
  latitude?: number;
  longitude?: number;
  roomTypes?: RoomType[];
  pricePerNight?: number;
  rating?: number;
  reviewCount?: number;
  amenities?: string[];
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  /** Shown instead of room rows when live availability is unavailable. */
  fallbackNote?: string;
};

type ActivityRecord = {
  _id: string;
  name: string;
  location?: string;
  description?: string;
  price?: number;
  durationMinutes?: number;
  slots?: string[];
  capacityPerSlot?: number;
  meetingPoint?: string;
  includedServices?: string[];
  requirements?: string[];
  latitude?: number;
  longitude?: number;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  /** True for curated fallback suggestions (not bookable inventory). */
  isCurated?: boolean;
};

/** Display-only local service (ATM, hospital, petrol, emergency, …). */
type LocalService = {
  _id: string;
  name: string;
  category: string;
  location?: string;
  description?: string;
  latitude?: number;
  longitude?: number;
};

type RestaurantRecord = {
  _id: string;
  name: string;
  category?: string;
  location?: string;
  address?: string;
  city?: string;
  cuisine?: string[];
  description?: string;
  priceRange?: string;
  rating?: number;
  latitude?: number;
  longitude?: number;
  image?: string;
  images?: string[];
};

type SlotsResponse = { slots: { time: string; capacity: number; booked: number; available: number }[] };

type TripRecord = { _id: string; name?: string; destination?: string };

/** The single trip booking created when the traveller submits the plan. */
type SubmittedTripBooking = {
  _id: string;
  bookingCode: string;
  itemName: string;
  amount: number;
  currency: string;
  status: string;
  paymentStatus: string;
};

const STEPS = [
  { key: "destination", title: "Destination", subtitle: "Search and pick a destination" },
  { key: "overview", title: "Overview", subtitle: "Facts, origin, dates and travelers" },
  { key: "outbound", title: "Outbound transport", subtitle: "Origin to destination with seats" },
  { key: "hotel", title: "Hotel", subtitle: "Live availability, never book sold out" },
  { key: "restaurants", title: "Restaurants", subtitle: "Reserve tables, pay at venue" },
  { key: "attractions", title: "Attractions & heritage", subtitle: "Free stops for the plan" },
  { key: "activities", title: "Activities", subtitle: "Slots with remaining capacity" },
  { key: "gems", title: "Hidden gems", subtitle: "Quieter places to add" },
  { key: "local", title: "Local transport", subtitle: "Getting around at the destination" },
  { key: "return", title: "Return transport", subtitle: "Destination to origin" },
  { key: "review", title: "Review trip", subtitle: "Full review of your selections" },
  { key: "complete", title: "Complete trip", subtitle: "Submit for admin confirmation" },
  { key: "confirmation", title: "Confirmation", subtitle: "Booking receipt" },
  { key: "done", title: "Summary", subtitle: "Pending admin confirmation" },
] as const;

type StepKey = (typeof STEPS)[number]["key"];

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Per-leg transport price, mirroring backend/services/bookingService:
 * shared/scheduled services charge per person, others charge per vehicle.
 */
function transportLegPrice(
  t: { price?: number; serviceMode?: string } | null,
  party: number
): number {
  if (!t) return 0;
  const unit = Number(t.price) || 0;
  const perPerson = ["shared", "scheduled"].includes(t.serviceMode ?? "");
  return perPerson ? Math.round(unit * party) : Math.round(unit);
}

/**
 * Mirrors the backend booking rule: a transport option without a confirmed
 * fare computes to NPR 0 and can never be booked. Flagged in the UI so the
 * user finds out before checkout instead of via a server error.
 */
function transportFareOk(
  t: { price?: number; serviceMode?: string } | null,
  party: number
): boolean {
  return transportLegPrice(t, party) > 0;
}

/**
 * Per-service seat check for the planner: only services that publish a
 * reservable seat map require seat picks, and only for the passengers
 * assigned to that service. Returns a single service-specific message or
 * null when nothing blocks booking.
 */
function legSeatError(
  selected: { name: string } | null,
  seats: SeatsResponse | null,
  picked: string[],
  assigned: number
): string | null {
  if (!selected || assigned <= 0) return null;
  if (seats?.seats?.length && seats.seatSelection !== false && picked.length !== assigned) {
    return `${selected.name}: Select seats for the ${assigned} passenger(s) assigned to this service.`;
  }
  return null;
}

function toDestinationSummary(record: DestinationRecord): DestinationSummary {
  return {
    _id: record._id,
    name: record.name,
    province: record.province,
    country: "Nepal",
    latitude: record.latitude,
    longitude: record.longitude,
    description: record.description,
  };
}

function formatDuration(minutes?: number): string | undefined {
  if (minutes === undefined || minutes === null) return undefined;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  const out = `${h ? `${h}h ` : ""}${m ? `${m}m` : ""}`.trim();
  return out || "0m";
}

function mapsDirectionsUrl(destination: string, origin?: string): string {
  const base = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`;
  return origin ? `${base}&origin=${encodeURIComponent(origin)}` : base;
}

function placeQuery(name: string, location?: string, lat?: number, lng?: number): string {
  if (lat !== undefined && lng !== undefined) return `${lat},${lng}`;
  return [name, location].filter(Boolean).join(", ");
}

function unwrap<T>(data: unknown): T {
  if (data && typeof data === "object") {
    const o = data as Record<string, unknown>;
    for (const k of ["transport", "hotel", "restaurant", "place", "activity", "item", "data"]) {
      if (o[k] && typeof o[k] === "object") return o[k] as T;
    }
  }
  return data as T;
}

function asArray<T>(data: unknown): T[] {
  if (Array.isArray(data)) return data as T[];
  if (data && typeof data === "object") {
    const o = data as Record<string, unknown>;
    if (Array.isArray(o.items)) return o.items as T[];
    if (Array.isArray(o.data)) return o.data as T[];
    if (Array.isArray(o.results)) return o.results as T[];
  }
  return [];
}

/**
 * Best-effort single query used by the Complete Trip fallback chain.
 * API failure and zero-result cases are both handled by the caller broadening
 * the search, so a failure here resolves to [] instead of surfacing a
 * technical error in the trip flow UI.
 */
async function tryQuery<T>(path: string): Promise<T[]> {
  try {
    const data = await backendRequest<unknown>(path);
    return asArray<T>(data);
  } catch {
    return [];
  }
}

function hasHiddenTag(tags?: string[]): boolean {
  return (tags ?? []).map((t) => t.toLowerCase()).includes("hidden");
}

type LocalPlaceRecord = {
  _id: string;
  name: string;
  category?: string;
  serviceType?: string;
  city?: string;
  location?: string;
  address?: string;
  description?: string;
  latitude?: number;
  longitude?: number;
};

const LOCAL_SERVICE_MODULES = ["atm", "hospital", "petrol", "shopping"] as const;

async function queryLocalServices(term: string): Promise<LocalService[]> {
  if (!term.trim()) return [];
  const found: LocalService[] = [];
  const seen = new Set<string>();
  const results = await Promise.all(
    LOCAL_SERVICE_MODULES.map((module) =>
      tryQuery<LocalPlaceRecord>(`/places?module=${module}&search=${encodeURIComponent(term.trim())}`)
        .then((items) => ({ module, items }))
    )
  );
  for (const { module, items } of results) {
    for (const item of items.slice(0, 6)) {
      if (!item?._id || seen.has(item._id)) continue;
      seen.add(item._id);
      found.push({
        _id: item._id,
        name: item.name,
        category: item.category || item.serviceType || module,
        location: item.location || item.address || item.city,
        description: item.description,
        latitude: item.latitude,
        longitude: item.longitude,
      });
    }
  }
  return found;
}

export default function DestinationTripScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const routeDestination = route.params?.destination ?? "";
  const routeOrigin = route.params?.origin ?? "";
  const preselect = route.params?.preselect;

  const [stepIndex, setStepIndex] = useState(routeDestination ? 1 : 0);
  const step = STEPS[stepIndex].key as StepKey;

  // Destination + trip inputs
  const [destination, setDestination] = useState(routeDestination);
  const [destinationDetail, setDestinationDetail] = useState<DestinationRecord | null>(null);
  // The validated (recognized) destination record. Free typing never counts —
  // a suggestion must be picked and server-confirmed before planning starts.
  const [selectedDestination, setSelectedDestination] = useState<DestinationSummary | null>(null);
  const [gateError, setGateError] = useState<TripValidationError | null>(null);
  const [gateBusy, setGateBusy] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [popularDests, setPopularDests] = useState<DestinationRecord[]>([]);
  const [destLoading, setDestLoading] = useState(false);

  const [origin, setOrigin] = useState(routeOrigin);
  // The validated (recognized) origin record. Free typing never counts —
  // a suggestion must be picked and server-confirmed before planning starts.
  const [selectedOrigin, setSelectedOrigin] = useState<LocationResult | null>(null);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [adults, setAdults] = useState("");
  const [children, setChildren] = useState("");
  const [rooms, setRooms] = useState("");

  // Outbound
  const [outbound, setOutbound] = useState<TransportRecord[]>([]);
  const [outboundLoading, setOutboundLoading] = useState(false);
  const [selectedOutboundId, setSelectedOutboundId] = useState("");
  const [outboundDate, setOutboundDate] = useState("");
  const [seatsData, setSeatsData] = useState<SeatsResponse | null>(null);
  const [seatsLoading, setSeatsLoading] = useState(false);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);

  // Hotel
  const [hotels, setHotels] = useState<HotelRecord[]>([]);
  const [hotelsLoading, setHotelsLoading] = useState(false);
  const [hotelsNote, setHotelsNote] = useState("");
  const [selectedHotelId, setSelectedHotelId] = useState("");
  const [selectedRoomTypeId, setSelectedRoomTypeId] = useState("");
  const [addedHotelId, setAddedHotelId] = useState("");

  // Attractions (free stops)
  const [attractions, setAttractions] = useState<DestinationRecord[]>([]);
  const [attractionsLoading, setAttractionsLoading] = useState(false);
  const [attractionsNote, setAttractionsNote] = useState("");
  const [plannedItems, setPlannedItems] = useState<string[]>([]);

  // Activities
  const [activities, setActivities] = useState<ActivityRecord[]>([]);
  const [activitiesLoading, setActivitiesLoading] = useState(false);
  const [activitiesNote, setActivitiesNote] = useState("");
  const [selectedActivityId, setSelectedActivityId] = useState("");
  const [activityDate, setActivityDate] = useState("");
  const [activitySlots, setActivitySlots] = useState<SlotsResponse["slots"]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState("");
  const [participants, setParticipants] = useState("");

  // Hidden gems
  const [gems, setGems] = useState<DestinationRecord[]>([]);
  const [gemsLoading, setGemsLoading] = useState(false);
  const [gemsNote, setGemsNote] = useState("");
  const [selectedGemIds, setSelectedGemIds] = useState<string[]>([]);

  // Restaurants (table reservation, pay at venue — NPR 0 in the checkout)
  const [restaurants, setRestaurants] = useState<RestaurantRecord[]>([]);
  const [restaurantsLoading, setRestaurantsLoading] = useState(false);
  const [restaurantsNote, setRestaurantsNote] = useState("");
  const [selectedRestaurantId, setSelectedRestaurantId] = useState("");
  const [restaurantDate, setRestaurantDate] = useState("");

  // Local transport + local services
  const [localTransports, setLocalTransports] = useState<TransportRecord[]>([]);
  const [localServices, setLocalServices] = useState<LocalService[]>([]);
  const [localLoading, setLocalLoading] = useState(false);
  const [localNote, setLocalNote] = useState("");
  const [selectedLocalId, setSelectedLocalId] = useState("");
  const [localDate, setLocalDate] = useState("");

  // Trip + the single submitted trip booking (pending admin confirmation).
  const [tripId, setTripId] = useState("");
  const [submittedBooking, setSubmittedBooking] = useState<SubmittedTripBooking | null>(null);
  const [creating, setCreating] = useState(false);
  const [bookingError, setBookingError] = useState("");
  const [bookingNotice, setBookingNotice] = useState("");
  const [loadError, setLoadError] = useState("");

  // Return
  const [returnOptions, setReturnOptions] = useState<TransportRecord[]>([]);
  const [returnLoading, setReturnLoading] = useState(false);
  const [selectedReturnId, setSelectedReturnId] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [returnSeats, setReturnSeats] = useState<SeatsResponse | null>(null);
  const [returnSeatsLoading, setReturnSeatsLoading] = useState(false);
  const [selectedReturnSeats, setSelectedReturnSeats] = useState<string[]>([]);
  // Passengers assigned to each booked leg. Empty text = the whole party;
  // the remainder travels by own vehicle or stays unassigned and is never
  // booked or charged.
  const [outboundAdults, setOutboundAdults] = useState("");
  const [outboundChildren, setOutboundChildren] = useState("");
  const [returnAdults, setReturnAdults] = useState("");
  const [returnChildren, setReturnChildren] = useState("");
  const [localAdults, setLocalAdults] = useState("");
  const [localChildren, setLocalChildren] = useState("");

  const authHeaders = useCallback(() => {
    const token = getAccessToken();
    return {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    };
  }, [getAccessToken]);

  const requireToken = useCallback((): string | null => {
    const token = getAccessToken();
    if (!token) {
      navigation.navigate("Login", { notice: "Sign in to create bookings for this trip." });
      return null;
    }
    return token;
  }, [getAccessToken, navigation]);

  // ---------- Destination fetchers ----------
  // Validate-first gate: no search/planning API may run until the user has
  // picked a recognized destination (free typing never counts).
  const isDestinationLocked =
    !!selectedDestination &&
    !!destination.trim() &&
    selectedDestination.name.trim().toLowerCase() === destination.trim().toLowerCase();

  const requireLockedDestination = useCallback((): boolean => {
    if (isDestinationLocked) return true;
    setLoadError("Please select a valid Nepal destination.");
    return false;
  }, [isDestinationLocked]);

  // Origin follows the exact same rule: valid only after a recognized
  // suggestion has been selected (typing alone never counts).
  const isOriginLocked =
    !!selectedOrigin &&
    !!(selectedOrigin.refId ?? selectedOrigin._id) &&
    !!origin.trim() &&
    selectedOrigin.name.trim().toLowerCase() === origin.trim().toLowerCase();

  const requireLockedOrigin = useCallback((): boolean => {
    if (isOriginLocked) return true;
    setLoadError("Please select a valid origin from the suggestions.");
    return false;
  }, [isOriginLocked]);

  // Verified coordinates for maps/directions/distance whenever a real
  // origin is selected — never derived from arbitrary text.
  const originPoint: string | undefined =
    isOriginLocked && typeof selectedOrigin?.latitude === "number" && typeof selectedOrigin?.longitude === "number"
      ? `${selectedOrigin.latitude},${selectedOrigin.longitude}`
      : origin.trim() || undefined;
  const fetchPopular = useCallback(async () => {
    setDestLoading(true);
    try {
      const data = await backendRequest<unknown>("/destinations?featured=popular");
      setPopularDests(asArray<DestinationRecord>(data).slice(0, 12));
    } catch {
      setPopularDests([]);
    } finally {
      setDestLoading(false);
    }
  }, []);

  const fetchDestinationDetail = useCallback(async (name: string) => {
    if (!name.trim()) {
      setDestinationDetail(null);
      return;
    }
    setDetailLoading(true);
    try {
      const data = await backendRequest<unknown>(`/destinations?search=${encodeURIComponent(name.trim())}`);
      const list = asArray<DestinationRecord>(data);
      const exact = list.find((d) => d.name.toLowerCase() === name.trim().toLowerCase()) ?? list[0] ?? null;
      setDestinationDetail(exact);
    } catch {
      setDestinationDetail(null);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchPopular();
  }, [fetchPopular]);

  useEffect(() => {
    if (destination.trim()) void fetchDestinationDetail(destination);
  }, [destination, fetchDestinationDetail]);

  // Incoming handoffs (e.g. "Book this trip end-to-end" from the AI planner)
  // skip the destination step — validate the provided name immediately so
  // only a recognized destination can proceed.
  useEffect(() => {
    if (!routeDestination.trim()) return;
    let active = true;
    void (async () => {
      const result = await confirmDestinationWithServer(routeDestination);
      if (!active) return;
      if (result.ok) {
        setSelectedDestination(result.destination);
        setDestination(result.destination.name);
      } else {
        setSelectedDestination(null);
        setGateError({ field: "destination", message: result.message });
      }
    })();
    return () => {
      active = false;
    };
  }, [routeDestination]);

  // A fresh Hidden Gem handoff always lands on the planning step so the
  // incoming destination context is never hidden behind step 0.
  useEffect(() => {
    if (routeDestination.trim()) setStepIndex(1);
  }, [routeDestination]);

  // Same for an incoming origin: only a recognized location may proceed.
  // Validated by name against the server (handoffs carry text, not a pick).
  useEffect(() => {
    if (!routeOrigin.trim()) return;
    let active = true;
    void (async () => {
      try {
        const response = await backendRequest<{ success: boolean; location?: LocationResult; message?: string }>(
          `/locations/validate?name=${encodeURIComponent(routeOrigin.trim())}`
        );
        if (!active) return;
        if (response?.success && response.location) {
          setSelectedOrigin(response.location);
          setOrigin(response.location.name);
        } else {
          setSelectedOrigin(null);
          setGateError({
            field: "origin",
            message: typeof response?.message === "string" ? response.message : "Please select a valid origin from the suggestions.",
          });
        }
      } catch (requestError) {
        if (!active) return;
        setSelectedOrigin(null);
        setGateError({
          field: "origin",
          message: requestError instanceof Error ? requestError.message : "Please select a valid origin from the suggestions.",
        });
      }
    })();
    return () => {
      active = false;
    };
  }, [routeOrigin]);

  // Date fields stay empty until the user picks them in the calendar.
  // Dependency is enforced via minDate constraints on each picker
  // (e.g. return after departure), never by auto-filling values.

  // ---------- Preselect support ----------
  useEffect(() => {
    if (!preselect) return;
    let active = true;
    (async () => {
      try {
        if (preselect.itemType === "transport") {
          const raw = await backendRequest<unknown>(`/transports/${preselect.itemId}`);
          const t = unwrap<TransportRecord>(raw);
          if (active && t && typeof t === "object" && "_id" in t) {
            setOutbound((cur) => (cur.some((x) => x._id === t._id) ? cur : [...cur, t]));
            setSelectedOutboundId(t._id);
          }
        } else if (preselect.itemType === "hotel") {
          const raw = await backendRequest<unknown>(`/hotels/${preselect.itemId}`);
          const h = unwrap<HotelRecord>(raw);
          if (active && h && typeof h === "object" && "_id" in h) {
            setHotels((cur) => (cur.some((x) => x._id === h._id) ? cur : [...cur, h]));
            setSelectedHotelId(h._id);
          }
        } else if (preselect.itemType === "activity") {
          const raw = await backendRequest<unknown>(`/places/${preselect.itemId}`);
          const a = unwrap<ActivityRecord>(raw);
          if (active && a && typeof a === "object" && "_id" in a) {
            setActivities((cur) => (cur.some((x) => x._id === a._id) ? cur : [...cur, a]));
            setSelectedActivityId(a._id);
          }
        }
      } catch {
        // Keep the flow usable when the preselected item cannot be loaded.
      }
    })();
    return () => {
      active = false;
    };
  }, [preselect]);

  // ---------- Transport / hotel / activity fetchers ----------
  const fetchOutbound = useCallback(async () => {
    if (!requireLockedDestination()) return;
    if (!requireLockedOrigin()) return;
    if (!isStrictAdISO(outboundDate) || outboundDate < todayAdISO()) {
      setLoadError("Please select a future travel date.");
      return;
    }
    setOutboundLoading(true);
    setLoadError("");
    try {
      const params = new URLSearchParams();
      if (origin.trim()) params.set("origin", origin.trim());
      params.set("destination", destination.trim());
      let data = await backendRequest<unknown>(`/transports?${params}`);
      let list = asArray<TransportRecord>(data);
      if (list.length === 0 && origin.trim()) {
        const fallback = await backendRequest<unknown>(`/transports?destination=${encodeURIComponent(destination.trim())}`);
        list = asArray<TransportRecord>(fallback);
      }
      if (list.length === 0) {
        // Broadened text search across routes and operators for the city.
        const scope = resolveDestination(destination);
        for (const term of [scope.city, scope.province]) {
          if (!term.trim()) continue;
          const broad = await tryQuery<TransportRecord>(`/transports?search=${encodeURIComponent(term.trim())}`);
          if (broad.length) {
            list = broad;
            break;
          }
        }
      }
      setOutbound(list);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : "Could not load outbound transport.");
    } finally {
      setOutboundLoading(false);
    }
  }, [requireLockedDestination, requireLockedOrigin, destination, origin, outboundDate]);

  const fetchSeats = useCallback(async (transportId: string, date: string): Promise<SeatsResponse | null> => {
    if (!transportId || !DATE_RE.test(date)) return null;
    const data = await backendRequest<SeatsResponse>(`/transports/${transportId}/seats?date=${date}`);
    return data;
  }, []);

  useEffect(() => {
    if (!selectedOutboundId || !DATE_RE.test(outboundDate)) {
      setSeatsData(null);
      return;
    }
    let active = true;
    setSeatsLoading(true);
    void fetchSeats(selectedOutboundId, outboundDate)
      .then((d) => {
        if (active) {
          setSeatsData(d);
          setSelectedSeats([]);
        }
      })
      .catch(() => {
        if (active) setSeatsData(null);
      })
      .finally(() => {
        if (active) setSeatsLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedOutboundId, outboundDate, fetchSeats]);

  useEffect(() => {
    if (!selectedReturnId || !DATE_RE.test(returnDate)) {
      setReturnSeats(null);
      return;
    }
    let active = true;
    setReturnSeatsLoading(true);
    void fetchSeats(selectedReturnId, returnDate)
      .then((d) => {
        if (active) {
          setReturnSeats(d);
          setSelectedReturnSeats([]);
        }
      })
      .catch(() => {
        if (active) setReturnSeats(null);
      })
      .finally(() => {
        if (active) setReturnSeatsLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedReturnId, returnDate, fetchSeats]);

  const fetchHotels = useCallback(async () => {
    if (!requireLockedDestination()) return;
    const guestsError =
      validateQuantityText(adults, "adults") ??
      validateQuantityText(children, "children") ??
      validateQuantityText(rooms, "rooms");
    if (guestsError) {
      setLoadError(guestsError);
      return;
    }
    if (Number(adults) + Number(children) > 20) {
      setLoadError("Guests must total no more than 20.");
      return;
    }
    setHotelsLoading(true);
    setLoadError("");
    setAddedHotelId("");
    try {
      const scope = resolveDestination(destination);
      const withDates =
        DATE_RE.test(startDate) && DATE_RE.test(endDate)
          ? `&checkIn=${startDate}&checkOut=${endDate}&adults=${adults || "1"}&children=${children || "0"}&rooms=${rooms || "1"}`
          : "";
      // LEVEL 1–3: exact destination → city → province, with live availability.
      const datedTerms = [scope.primary, scope.city, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      for (const term of datedTerms) {
        if (!withDates) break;
        const list = await tryQuery<HotelRecord>(`/hotels?search=${encodeURIComponent(term.trim())}${withDates}`);
        if (list.length) {
          setHotels(list);
          setHotelsNote(
            term.toLowerCase() === scope.primary.toLowerCase()
              ? ""
              : `Showing bookable stays matching “${term}” for ${scope.primary}.`
          );
          return;
        }
      }
      // LEVEL 4: same search without dates — shown as accommodation options
      // with availability explicitly unconfirmed (never faked as available).
      const plainTerms = [scope.city || scope.primary, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      for (const term of plainTerms) {
        const list = await tryQuery<HotelRecord>(`/hotels?search=${encodeURIComponent(term.trim())}`);
        if (list.length) {
          setHotels(list.map((hotel) => ({
            ...hotel,
            fallbackNote: "Availability is not confirmed for your dates — verify directly with the property.",
          })));
          setHotelsNote(`Live availability could not be confirmed — showing stays matching “${term}”.`);
          return;
        }
      }
      // LEVEL 5: curated destination-aware suggestions (display only).
      const curated = curatedFor(scope.key);
      setHotels(curated.hotels.map((hotel: CuratedHotel) => ({
        _id: hotel._id,
        name: hotel.name,
        location: hotel.location,
        description: hotel.description,
        fallbackNote: "Suggested stay — itinerary only, not booked. Verify availability directly.",
      })));
      setHotelsNote(`Suggested stays for ${scope.primary} — availability not confirmed.`);
    } finally {
      setHotelsLoading(false);
    }
  }, [requireLockedDestination, destination, startDate, endDate, adults, children, rooms]);

  const fetchAttractions = useCallback(async () => {
    if (!requireLockedDestination()) return;
    setAttractionsLoading(true);
    try {
      const scope = resolveDestination(destination);
      // LEVEL 1–3: exact destination → city → province (hidden-tagged excluded).
      const terms = [scope.primary, scope.city, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      for (const term of terms) {
        const list = (await tryQuery<DestinationRecord>(`/destinations?search=${encodeURIComponent(term.trim())}`))
          .filter((d) => !hasHiddenTag(d.tags));
        if (list.length) {
          setAttractions(list);
          setAttractionsNote(
            term.toLowerCase() === scope.primary.toLowerCase()
              ? ""
              : `Showing attractions matching “${term}” for ${scope.primary}.`
          );
          return;
        }
      }
      // LEVEL 4: curated destination-aware attractions (free stops, no booking).
      const curated = curatedFor(scope.key);
      setAttractions(curated.attractions.map((place: CuratedPlace) => ({
        _id: place._id,
        name: place.name,
        description: place.description,
        province: place.province,
        highlights: place.highlights,
        whyVisit: place.whyVisit,
        bestTimeToVisit: place.bestTimeToVisit,
        isCurated: true,
      })));
      setAttractionsNote(`Suggested attractions for ${scope.primary}.`);
    } finally {
      setAttractionsLoading(false);
    }
  }, [requireLockedDestination, destination]);

  const fetchActivities = useCallback(async () => {
    if (!requireLockedDestination()) return;
    setActivitiesLoading(true);
    try {
      const scope = resolveDestination(destination);
      // LEVEL 1–3: exact destination → city → province.
      const terms = [scope.primary, scope.city, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      for (const term of terms) {
        const list = await tryQuery<ActivityRecord>(
          `/places?module=activity&search=${encodeURIComponent(term.trim())}`
        );
        if (list.length) {
          setActivities(list);
          setActivitiesNote(
            term.toLowerCase() === scope.primary.toLowerCase()
              ? ""
              : `Showing activities matching “${term}” for ${scope.primary}.`
          );
          return;
        }
      }
      // LEVEL 4: curated destination-aware activities (suggestions, not bookable).
      const curated = curatedFor(scope.key);
      setActivities(curated.activities.map((activity: CuratedActivity) => ({
        _id: activity._id,
        name: activity.name,
        location: activity.location,
        description: activity.description,
        meetingPoint: activity.meetingPoint,
        isCurated: true,
      })));
      setActivitiesNote(`Suggested activities for ${scope.primary} — itinerary only, not booked. Verify locally.`);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : "Could not load activities.");
    } finally {
      setActivitiesLoading(false);
    }
  }, [requireLockedDestination, destination]);

  const fetchSlots = useCallback(async () => {
    if (!selectedActivityId || selectedActivityId.startsWith("curated-") || !DATE_RE.test(activityDate)) {
      setActivitySlots([]);
      return;
    }
    setSlotsLoading(true);
    try {
      const data = await backendRequest<SlotsResponse>(`/places/${selectedActivityId}/slots?date=${activityDate}`);
      setActivitySlots(data.slots ?? []);
    } catch {
      setActivitySlots([]);
    } finally {
      setSlotsLoading(false);
    }
  }, [selectedActivityId, activityDate]);

  useEffect(() => {
    void fetchSlots();
  }, [fetchSlots]);

  const fetchGems = useCallback(async () => {
    if (!requireLockedDestination()) return;
    setGemsLoading(true);
    try {
      const scope = resolveDestination(destination);
      const terms = [scope.primary, scope.city, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      for (const term of terms) {
        const results = await tryQuery<DestinationRecord>(`/destinations?search=${encodeURIComponent(term.trim())}`);
        // LEVEL 1: places literally tagged hidden.
        const hidden = results.filter((d) => hasHiddenTag(d.tags));
        if (hidden.length) {
          setGems(hidden);
          setGemsNote(
            term.toLowerCase() === scope.primary.toLowerCase()
              ? ""
              : `Showing hidden spots matching “${term}” for ${scope.primary}.`
          );
          return;
        }
        // LEVEL 2–3: lesser-known places in the same results — everything
        // except the exact destination match, so a famous landmark is never
        // labelled "hidden" just to fill the section.
        const lesserKnown = pickLesserKnown(results, term);
        if (lesserKnown.length) {
          setGems(lesserKnown);
          setGemsNote(`Lesser-known spots near ${scope.primary} — add the ones you like to the plan.`);
          return;
        }
      }
      // LEVEL 4: curated destination-aware hidden gems (free stops, no booking).
      const curated = curatedFor(scope.key);
      setGems(curated.gems.map((place: CuratedPlace) => ({
        _id: place._id,
        name: place.name,
        description: place.description,
        province: place.province,
        highlights: place.highlights,
        whyVisit: place.whyVisit,
        bestTimeToVisit: place.bestTimeToVisit,
        isCurated: true,
      })));
      setGemsNote(`Suggested hidden gems for ${scope.primary}.`);
    } finally {
      setGemsLoading(false);
    }
  }, [requireLockedDestination, destination]);

  const fetchLocal = useCallback(async () => {
    if (!requireLockedDestination()) return;
    setLocalLoading(true);
    try {
      const scope = resolveDestination(destination);
      const notes: string[] = [];
      // Bookable local transport: exact destination → city.
      const transportTerms = [scope.primary, scope.city].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      let transports: TransportRecord[] = [];
      for (const [index, term] of transportTerms.entries()) {
        const list = await tryQuery<TransportRecord>(`/transports?origin=${encodeURIComponent(term.trim())}`);
        if (list.length) {
          transports = list;
          if (index > 0) notes.push(`Local transport in ${term}.`);
          break;
        }
      }
      // Useful local services (ATM, hospital, petrol, shopping) from the
      // existing places catalog: city → province.
      const serviceTerms = [scope.city || scope.primary, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      let services: LocalService[] = [];
      for (const [index, term] of serviceTerms.entries()) {
        const list = await queryLocalServices(term);
        if (list.length) {
          services = list;
          if (index > 0 || !transports.length) notes.push(`Services matching “${term}”.`);
          break;
        }
      }
      // Final level: curated destination-aware services (display only).
      if (!transports.length && !services.length) {
        const curated = curatedFor(scope.key);
        services = curated.services.map((service: CuratedService) => ({ ...service }));
        notes.push(`Key services for ${scope.primary} — verify locally.`);
      }
      setLocalTransports(transports);
      setLocalServices(services);
      setLocalNote(notes.join(" "));
    } finally {
      setLocalLoading(false);
    }
  }, [requireLockedDestination, destination]);

  const fetchRestaurants = useCallback(async () => {
    if (!requireLockedDestination()) return;
    setRestaurantsLoading(true);
    setLoadError("");
    try {
      const scope = resolveDestination(destination);
      const terms = [scope.primary, scope.city, scope.province].filter(
        (term, index, all) => term.trim() && all.findIndex((t) => t.toLowerCase() === term.toLowerCase()) === index
      );
      for (const [index, term] of terms.entries()) {
        const list = await tryQuery<RestaurantRecord>(`/restaurants?search=${encodeURIComponent(term.trim())}`);
        const bookable = list.filter((r) => r && !String(r._id).startsWith("curated-"));
        if (bookable.length) {
          setRestaurants(bookable.slice(0, 20));
          setRestaurantsNote(
            index > 0 ? `Showing restaurants matching “${term}” for ${scope.primary}.` : ""
          );
          return;
        }
      }
      setRestaurants([]);
      setRestaurantsNote(`No reservable restaurants found for ${scope.primary} yet.`);
    } catch (e) {
      setRestaurants([]);
      setLoadError(e instanceof Error ? e.message : "Could not load restaurants.");
    } finally {
      setRestaurantsLoading(false);
    }
  }, [requireLockedDestination, destination]);

  const fetchReturn = useCallback(async () => {    if (!requireLockedDestination()) return;
    if (!requireLockedOrigin()) return;
    if (!isStrictAdISO(returnDate) || returnDate < todayAdISO()) {
      setLoadError("Please select a future travel date.");
      return;
    }
    if (returnDate <= startDate) {
      setLoadError("Return date must be after the departure date.");
      return;
    }
    setReturnLoading(true);
    try {
      const params = new URLSearchParams({ origin: destination.trim() });
      if (origin.trim()) params.set("destination", origin.trim());
      const data = await backendRequest<unknown>(`/transports?${params}`);
      let list = asArray<TransportRecord>(data);
      if (list.length === 0) {
        // Broadened text search across routes and operators for the city.
        const scope = resolveDestination(destination);
        for (const term of [scope.primary, scope.city, scope.province]) {
          if (!term.trim()) continue;
          const broad = await tryQuery<TransportRecord>(`/transports?search=${encodeURIComponent(term.trim())}`);
          if (broad.length) {
            list = broad;
            break;
          }
        }
      }
      setReturnOptions(list);
    } catch {
      setReturnOptions([]);
    } finally {
      setReturnLoading(false);
    }
  }, [requireLockedDestination, requireLockedOrigin, destination, origin, returnDate, startDate]);

  const refreshStepData = useCallback(() => {
    if (!requireLockedDestination()) return;
    if (!requireLockedOrigin()) return;
    void fetchOutbound();
    void fetchHotels();
    void fetchAttractions();
    void fetchActivities();
    void fetchGems();
    void fetchRestaurants();
    void fetchLocal();
    void fetchReturn();
  }, [requireLockedDestination, requireLockedOrigin, fetchOutbound, fetchHotels, fetchAttractions, fetchActivities, fetchGems, fetchRestaurants, fetchLocal, fetchReturn]);

  // Auto-load the current step's data on step visit so jumping ahead via the
  // progress dots (before any fetch ran) can never leave a category blank.
  // Only fires when the list is still empty and no load is in progress.
  // Keep the active step dot visible: the 15-dot bar overflows on narrow
  // screens and never scrolled with the step, so on later steps the active
  // dot sat off-screen and the stepper looked like it had disappeared.
  const stepBarRef = useRef<ScrollView>(null);
  useEffect(() => {
    // 28px dot + 6px gap per step; keep one step of leading context.
    stepBarRef.current?.scrollTo({ x: Math.max(0, stepIndex * 34 - 34), animated: true });
  }, [stepIndex]);
  const stepFetchersRef = useRef({ fetchOutbound, fetchHotels, fetchAttractions, fetchActivities, fetchGems, fetchRestaurants, fetchLocal, fetchReturn });
  stepFetchersRef.current = { fetchOutbound, fetchHotels, fetchAttractions, fetchActivities, fetchGems, fetchRestaurants, fetchLocal, fetchReturn };
  useEffect(() => {
    if (!isDestinationLocked || !isOriginLocked) return;
    const fetchers = stepFetchersRef.current;
    if (step === "hotel" && hotels.length === 0 && !hotelsLoading) void fetchers.fetchHotels();
    else if (step === "attractions" && attractions.length === 0 && !attractionsLoading) void fetchers.fetchAttractions();
    else if (step === "activities" && activities.length === 0 && !activitiesLoading) void fetchers.fetchActivities();
    else if (step === "gems" && gems.length === 0 && !gemsLoading) void fetchers.fetchGems();
    else if (step === "restaurants" && restaurants.length === 0 && !restaurantsLoading) void fetchers.fetchRestaurants();
    else if (step === "local" && localTransports.length === 0 && localServices.length === 0 && !localLoading) void fetchers.fetchLocal();
    else if (step === "outbound" && outbound.length === 0 && !outboundLoading) void fetchers.fetchOutbound();
    else if (step === "return" && returnOptions.length === 0 && !returnLoading) void fetchers.fetchReturn();
    // Runs on step change only; fetchers/lists are read via ref + snapshot.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stepIndex]);

  // ---------- Derived ----------
  const selectedOutbound = outbound.find((t) => t._id === selectedOutboundId) ?? null;
  const selectedHotel = hotels.find((h) => h._id === selectedHotelId) ?? null;
  const selectedRoom = selectedHotel?.roomTypes?.find((r) => r._id === selectedRoomTypeId) ?? null;
  const selectedActivity = activities.find((a) => a._id === selectedActivityId) ?? null;
  const selectedLocal = localTransports.find((t) => t._id === selectedLocalId) ?? null;
  const selectedReturn = returnOptions.find((t) => t._id === selectedReturnId) ?? null;
  const selectedRestaurant = restaurants.find((r) => r._id === selectedRestaurantId) ?? null;

  const roomNeeded = Math.max(1, Number(rooms) || 1);
  const roomSoldOut = (room: RoomType): boolean =>
    room.matchesOccupancy === false || (room.availableRooms ?? 0) < roomNeeded;
  const roomSelectable = (room: RoomType): boolean =>
    room.matchesOccupancy !== false && (room.availableRooms ?? 0) >= roomNeeded;

  // Explains WHY a hotel cannot take the party, distinguishing the two
  // independent checks every flow shares (backend occupancy flags, then
  // date-based inventory). Occupancy uses each room type's real capacities
  // (capacityAdults × rooms ≥ adults, capacityChildren × rooms ≥ children);
  // inventory is the free-room count for the selected dates.
  const roomShortfallMessage = (hotel: HotelRecord): string => {
    const needed = Math.max(1, Number(rooms) || 1);
    const roomsWithData = (hotel.roomTypes ?? []).filter((room) => room.availableRooms !== undefined);
    const matching = roomsWithData.filter((room) => room.matchesOccupancy === true);
    if (matching.length) {
      const maxAvailable = Math.max(...matching.map((room) => room.availableRooms ?? 0));
      if (maxAvailable <= 0) {
        return "No suitable rooms are available for your selected dates and occupancy.";
      }
      return `Only ${maxAvailable} room(s) are available for your selected dates.`;
    }
    if (roomsWithData.length) {
      return "These room types cannot accommodate your selected guests.";
    }
    return "No suitable rooms are available for your selected dates and occupancy.";
  };

  // Hotel-level availability status from confirmed data only: total free
  // rooms across occupancy-matching room types. Returns null when availability
  // is unconfirmed (the fallback note covers that case) or nothing is free.
  // Never claims availability without evidence.
  const hotelAvailabilityStatus = (hotel: HotelRecord) => {
    const withData = (hotel.roomTypes ?? []).filter((room) => room.availableRooms !== undefined);
    if (!withData.length) return null;
    const totalFree = withData
      .filter((room) => room.matchesOccupancy === true)
      .reduce((total, room) => total + (room.availableRooms ?? 0), 0);
    if (totalFree <= 0) return null;
    return (
      <Text style={styles.inStock}>
        Rooms Available · {totalFree} room(s) available
      </Text>
    );
  };

  const goTo = (key: StepKey) => {
    const idx = STEPS.findIndex((s) => s.key === key);
    if (idx >= 0) setStepIndex(idx);
  };
  const next = () => setStepIndex((i) => Math.min(i + 1, STEPS.length - 1));
  const prev = () => setStepIndex((i) => Math.max(i - 1, 0));

  // Single confirm path for the Overview step: the primary button and the
  // Enter key on its fields both use this. Validation order is strict:
  // destination → origin → departure → return → travelers → budget →
  // (server confirm) → ONLY THEN any search/planning calls.
  // Quantity keystroke gates: digits only, capped at each field's maximum.
  // Overview inputs share the gate-error channel; step inputs reuse loadError.
  const handleOverviewQuantity = (
    field: "adults" | "children" | "rooms",
    nextText: string,
    currentText: string,
    apply: (text: string) => void
  ) => {
    const result = handleQuantityTextChange(field, nextText, currentText);
    apply(result.text);
    if (result.capped) setGateError({ field, message: quantityMaxMessage(field) });
    else setGateError(null);
  };

  const handleStepQuantity = (
    field: QuantityField,
    nextText: string,
    currentText: string,
    apply: (text: string) => void
  ) => {
    const result = handleQuantityTextChange(field, nextText, currentText);
    apply(result.text);
    if (result.capped) setLoadError(quantityMaxMessage(field));
  };

  const confirmOverview = () => {    const failure = validateCompleteTripInput({
      destinationText: destination,
      selectedDestination,
      originText: origin,
      selectedOrigin,
      startDate,
      endDate,
      adults,
      children,
    });
    if (failure) {
      setGateError(failure);
      return;
    }
    setGateError(null);
    setGateBusy(true);
    void (async () => {
      try {
        const confirmed = await confirmDestinationWithServer(destination);
        if (!confirmed.ok) {
          setGateError({ field: "destination", message: confirmed.message });
          return;
        }
        setSelectedDestination(confirmed.destination);
        setDestination(confirmed.destination.name);
        const confirmedOrigin = await confirmOriginWithServer(selectedOrigin, origin);
        if (!confirmedOrigin.ok) {
          setGateError({ field: "origin", message: confirmedOrigin.message });
          return;
        }
        setSelectedOrigin(confirmedOrigin.location);
        setOrigin(confirmedOrigin.location.name);
        await fetchDestinationDetail(confirmed.destination.name);
        refreshStepData();
        next();
      } finally {
        setGateBusy(false);
      }
    })();
  };

  const toggleId = (id: string, list: string[], set: (v: string[]) => void) =>
    set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

  // ---------- Select-to-trip helpers (hotel / activity cards) ----------
  // Once the trip is submitted for admin confirmation, selections lock so the
  // plan can never drift out of sync with the submitted booking. Payment
  // happens later in My Bookings — never inside this flow.
  const tripLocked = submittedBooking !== null;

  const stayNights = useMemo(() => {    if (!DATE_RE.test(startDate) || !DATE_RE.test(endDate)) return 0;
    return Math.max(0, Math.round((new Date(`${endDate}T00:00:00Z`).getTime() - new Date(`${startDate}T00:00:00Z`).getTime()) / 86400000));
  }, [startDate, endDate]);

  const hotelBestRate = useCallback((hotel: HotelRecord): number | undefined => {
    const roomRates = (hotel.roomTypes ?? [])
      .map((room) => room.nightlyRate)
      .filter((rate): rate is number => typeof rate === "number" && Number.isFinite(rate));
    if (roomRates.length) return Math.min(...roomRates);
    return typeof hotel.pricePerNight === "number" ? hotel.pricePerNight : undefined;
  }, []);

  /** Explicit per-room selection: tapping Select Room again deselects it.
   *  Only rooms the current party fits (backend occupancy flags) with free
   *  inventory for the dates can be selected. */
  const selectRoom = (hotel: HotelRecord, room: RoomType) => {
    if (tripLocked) return;
    if (selectedHotelId === hotel._id && selectedRoomTypeId === room._id) {
      setSelectedHotelId("");
      setSelectedRoomTypeId("");
    } else {
      setSelectedHotelId(hotel._id);
      setSelectedRoomTypeId(room._id);
    }
    setAddedHotelId("");
    setLoadError("");
  };

  /** Card-level Add to Trip for hotels: adds the explicitly selected room.
   *  The user always chooses a suitable room first — nothing is silently
   *  substituted. Selection only — payment happens once for the whole trip. */
  const addHotelToTrip = useCallback((hotel: HotelRecord) => {
    if (tripLocked) return;
    if (hotel._id.startsWith("curated-")) return;
    let room: RoomType | undefined;
    if (hotel._id === selectedHotelId && selectedRoomTypeId) {
      const chosen = hotel.roomTypes?.find((r) => r._id === selectedRoomTypeId);
      room = chosen && roomSelectable(chosen) ? chosen : undefined;
    }
    if (!room) {
      setAddedHotelId("");
      setLoadError(
        hotel._id === selectedHotelId && selectedRoomTypeId
          ? roomShortfallMessage(hotel)
          : "Please select a room type above first."
      );
      return;
    }
    setLoadError("");
    setSelectedHotelId(hotel._id);
    setSelectedRoomTypeId(room._id);
    setAddedHotelId(hotel._id);
  }, [rooms, selectedHotelId, selectedRoomTypeId, tripLocked]);

  /** Card-level Add to Trip for activities: select and jump to Review. */
  const addActivityToTrip = useCallback((activity: ActivityRecord) => {
    if (tripLocked) return;
    if (activity._id.startsWith("curated-") || activity.isCurated) return;
    const participantsError = validateQuantityText(participants, "participants");
    if (participantsError) {
      setLoadError(participantsError);
      return;
    }
    setLoadError("");
    setSelectedActivityId(activity._id);
    setSelectedSlot("");
    goTo("review");
  }, [goTo, participants, tripLocked]);

  const openMap = (name: string, location?: string, lat?: number, lng?: number) => {
    navigation.navigate("Map", {
      query: [name, location].filter(Boolean).join(", "),
      latitude: lat,
      longitude: lng,
    });
  };

  const openExternalDirections = (dest: string, orig?: string) =>
    void Linking.openURL(mapsDirectionsUrl(dest, orig));

  // ---------- Review cart intents ----------
  type CartIntent = { key: string; label: string; detail: string; payload: Record<string, unknown> };

  // ---------- Per-service passenger allocation ----------
  // Each booked leg carries only its assigned passengers (default: the whole
  // party). Anyone not assigned travels by own vehicle or stays unassigned —
  // they are never booked, charged, or seat-validated.
  const partyAdults = Number(adults) || 1;
  const partyChildren = Number(children) || 0;
  const partyTotal = partyAdults + partyChildren;
  const clampLegCount = (text: string, cap: number): number => {
    const parsed = Math.floor(Number(text));
    if (!Number.isFinite(parsed) || parsed < 0) return 0;
    return Math.min(cap, parsed);
  };
  const resolveLegParty = (adultsText: string, childrenText: string) => {
    const legAdults = adultsText === "" ? partyAdults : clampLegCount(adultsText, partyAdults);
    const legChildren = childrenText === "" ? partyChildren : clampLegCount(childrenText, partyChildren);
    return { adults: legAdults, children: legChildren, total: legAdults + legChildren };
  };
  const outboundParty = resolveLegParty(outboundAdults, outboundChildren);
  const returnParty = resolveLegParty(returnAdults, returnChildren);
  const localParty = resolveLegParty(localAdults, localChildren);

  const cartIntents: CartIntent[] = useMemo(() => {
    const intents: CartIntent[] = [];
    const adultsNum = Number(adults) || 1;
    const childrenNum = Number(children) || 0;
    if (selectedOutbound && outboundParty.total > 0) {
      intents.push({
        key: `transport-out-${selectedOutbound._id}`,
        label: `Outbound · ${selectedOutbound.name}`,
        detail: `${outboundDate} · ${selectedSeats.length ? `${selectedSeats.join(", ")}` : `${outboundParty.total} traveler(s)`} · NPR ${selectedOutbound.price ?? "?"}`,
        payload: {
          itemType: "transport",
          itemId: selectedOutbound._id,
          checkIn: outboundDate,
          adults: outboundParty.adults,
          children: outboundParty.children,
          guests: outboundParty.total,
          ...(selectedSeats.length ? { seatNumbers: selectedSeats } : {}),
        },
      });
    }
    if (selectedHotel && selectedRoom) {
      intents.push({
        key: `hotel-${selectedHotel._id}-${selectedRoom._id}`,
        label: `Hotel · ${selectedHotel.name} · ${selectedRoom.name}`,
        detail: `${startDate} → ${endDate} · ${roomNeeded} room(s) · NPR ${selectedRoom.nightlyRate ?? selectedHotel.pricePerNight ?? "?"}/night`,
        payload: {
          itemType: "hotel",
          itemId: selectedHotel._id,
          checkIn: startDate,
          checkOut: endDate,
          adults: adultsNum,
          children: childrenNum,
          guests: adultsNum + childrenNum,
          rooms: roomNeeded,
          roomTypeId: selectedRoom._id,
        },
      });
    }
    if (selectedActivity) {
      intents.push({
        key: `activity-${selectedActivity._id}`,
        label: `Activity · ${selectedActivity.name}`,
        detail: `${activityDate}${selectedSlot ? ` @ ${selectedSlot}` : ""} · ${participants} participant(s) · NPR ${selectedActivity.price ?? "?"}`,
        payload: {
          itemType: "activity",
          itemId: selectedActivity._id,
          checkIn: activityDate,
          ...(selectedSlot ? { serviceTime: selectedSlot } : {}),
          adults: Number(participants) || adultsNum,
          children: 0,
          guests: Number(participants) || adultsNum,
        },
      });
    }
    if (selectedLocal && localParty.total > 0) {
      intents.push({
        key: `local-${selectedLocal._id}`,
        label: `Local transport · ${selectedLocal.name}`,
        detail: `${localDate} · ${localParty.total} traveler(s) · NPR ${selectedLocal.price ?? "?"}`,
        payload: {
          itemType: "transport",
          itemId: selectedLocal._id,
          checkIn: DATE_RE.test(localDate) ? localDate : startDate,
          adults: localParty.adults,
          children: localParty.children,
          guests: localParty.total,
        },
      });
    }
    if (selectedReturn && returnParty.total > 0) {
      intents.push({
        key: `transport-return-${selectedReturn._id}`,
        label: `Return · ${selectedReturn.name}`,
        detail: `${returnDate} · ${selectedReturnSeats.length ? `${selectedReturnSeats.join(", ")}` : `${returnParty.total} traveler(s)`} · NPR ${selectedReturn.price ?? "?"}`,
        payload: {
          itemType: "transport",
          itemId: selectedReturn._id,
          checkIn: returnDate,
          adults: returnParty.adults,
          children: returnParty.children,
          guests: returnParty.total,
          ...(selectedReturnSeats.length ? { seatNumbers: selectedReturnSeats } : {}),
        },
      });
    }
    if (selectedRestaurant) {
      intents.push({
        key: `restaurant-${selectedRestaurant._id}`,
        label: `Restaurant · ${selectedRestaurant.name}`,
        detail: `${restaurantDate} · ${adultsNum + childrenNum} guest(s) · pay at venue`,
        payload: {
          itemType: "restaurant",
          itemId: selectedRestaurant._id,
          checkIn: restaurantDate,
          adults: adultsNum,
          children: childrenNum,
          guests: adultsNum + childrenNum,
        },
      });
    }
    return intents;
  }, [
    adults,
    children,
    selectedOutbound,
    outboundDate,
    selectedSeats,
    outboundAdults,
    outboundChildren,
    selectedHotel,
    selectedRoom,
    startDate,
    endDate,
    roomNeeded,
    selectedActivity,
    activityDate,
    selectedSlot,
    participants,
    selectedLocal,
    localDate,
    localAdults,
    localChildren,
    selectedReturn,
    returnDate,
    selectedReturnSeats,
    returnAdults,
    returnChildren,
    selectedRestaurant,
    restaurantDate,
  ]);

  /**
   * Submit the planned trip for admin confirmation. Creates the trip plan
   * (once — reused on retry) and saves ONE trip booking with status Pending
   * Admin Confirmation. No payment happens here: after the admin confirms,
   * the traveller pays in My Bookings.
   */
  const submitTripForApproval = async () => {
    const token = requireToken();
    if (!token) return;
    if (tripLocked) {
      setBookingError("This trip is already submitted. Selections are locked.");
      return;
    }
    if (!isDestinationLocked) {
      setBookingError("Please select a valid Nepal destination.");
      return;
    }
    if (!isOriginLocked || !selectedOrigin) {
      setBookingError("Please select a valid origin from the suggestions.");
      return;
    }
    if (!isStrictAdISO(startDate) || !isStrictAdISO(endDate) || startDate < todayAdISO() || endDate < startDate) {
      setBookingError(
        !isStrictAdISO(startDate) || !isStrictAdISO(endDate)
          ? "Please select valid travel dates."
          : startDate < todayAdISO()
            ? "Please select a future travel date."
            : "Return date must be after the departure date."
      );
      return;
    }
    if (!cartIntents.length) {
      setBookingError("Add at least one bookable item (outbound or return transport, hotel room, restaurant, activity, or local transport) before submitting.");
      return;
    }
    // Scheduled activities must carry their slot — the backend rejects
    // dateless-slot bookings, so stop here with a field-specific message.
    if (selectedActivity && selectedActivity.slots && selectedActivity.slots.length > 0 && !selectedSlot) {
      setBookingError(`Select one of the scheduled slots (${selectedActivity.slots.join(", ")}) for ${selectedActivity.name} before checkout.`);
      return;
    }
    // Seat picks are validated per booked service, only against the passengers
    // assigned to that service — never against the whole trip party. Unassigned
    // travelers (own vehicle) and seat-map-free services need no seats.
    const transportSeatError =
      legSeatError(selectedOutbound, seatsData, selectedSeats, outboundParty.total) ??
      legSeatError(selectedReturn, returnSeats, selectedReturnSeats, returnParty.total);
    if (transportSeatError) {
      setBookingError(transportSeatError);
      return;
    }
    setCreating(true);
    setBookingError("");
    setBookingNotice("");
    try {
      // Snapshot of everything chosen, stored on the trip for admin review,
      // My Bookings, and the completed-trip PDF. Every selected service is
      // recorded with its identifying details, dates, party, and priced
      // amounts (unit price + basis where applicable) — never estimates
      // reconstructed later.
      const legSnapshot = (
        leg: TransportRecord | null,
        label: string,
        date: string,
        party: { adults: number; children: number; total: number },
        seats: string[]
      ) => leg ? {
        label: `${label} · ${leg.name}`,
        name: leg.name,
        vehicleType: leg.type || undefined,
        provider: leg.provider || undefined,
        origin: leg.origin || undefined,
        destination: leg.destination || undefined,
        date,
        departureTime: leg.departureTime || undefined,
        arrivalTime: leg.arrivalTime || undefined,
        durationMinutes: leg.durationMinutes ?? undefined,
        serviceMode: leg.serviceMode || undefined,
        unitPrice: leg.price ?? undefined,
        priceBasis: ["shared", "scheduled"].includes(leg.serviceMode ?? "")
          ? `per person × ${party.total}`
          : "per vehicle",
        adults: party.adults,
        children: party.children,
        detail: `${seats.length ? `Seats ${seats.join(", ")}` : `${party.total} traveler(s)`}`,
        seats: seats.length ? seats : undefined,
        amount: transportLegPrice(leg, party.total),
      } : null;
      // Itinerary-only picks (curated stays/activities without bookable
      // inventory) resolve from their own lists; ids from lists that no
      // longer contain them are dropped, same as attractions/gems.
      const hotelPlanRecords = plannedItems
        .map((id) => hotels.find((record) => record._id === id))
        .filter((record): record is HotelRecord => !!record);
      const activityPlanRecords = plannedItems
        .map((id) => activities.find((record) => record._id === id))
        .filter((record): record is ActivityRecord => !!record);
      const selectionsSnapshot = {
        startDate,
        endDate,
        destination: destination.trim(),
        destinationProvince: selectedDestination?.province || destinationDetail?.province || undefined,
        destinationCountry: selectedDestination?.country || undefined,
        origin: origin.trim(),
        party: {
          adults: Number(adults) || 1,
          children: Number(children) || 0,
          rooms: roomNeeded,
          participants: participants.trim() === "" ? undefined : Number(participants),
        },
        hotel: selectedHotel && selectedRoom ? {
          name: selectedHotel.name,
          location: selectedHotel.location || undefined,
          room: selectedRoom.name,
          roomTypeId: selectedRoom._id,
          bedConfiguration: selectedRoom.bedConfiguration || undefined,
          breakfastIncluded: selectedRoom.breakfastIncluded ?? undefined,
          capacityAdults: selectedRoom.capacityAdults,
          capacityChildren: selectedRoom.capacityChildren,
          rating: selectedHotel.rating ?? undefined,
          checkIn: startDate,
          checkOut: endDate,
          nights: stayNights,
          rooms: roomNeeded,
          nightlyRate: selectedRoom.nightlyRate ?? selectedHotel.pricePerNight ?? undefined,
          amount: estimate.hotel,
        } : null,
        outbound: legSnapshot(selectedOutbound, "Outbound", outboundDate, outboundParty, selectedSeats),
        return: legSnapshot(selectedReturn, "Return", returnDate, returnParty, selectedReturnSeats),
        local: selectedLocal ? {
          ...legSnapshot(selectedLocal, "Local transport", DATE_RE.test(localDate) ? localDate : startDate, localParty, []),
          detail: `${localParty.total} traveler(s)`,
        } : null,
        activity: selectedActivity ? {
          name: selectedActivity.name,
          location: selectedActivity.location || undefined,
          date: activityDate,
          slot: selectedSlot || undefined,
          durationMinutes: selectedActivity.durationMinutes ?? undefined,
          meetingPoint: selectedActivity.meetingPoint || undefined,
          unitPrice: selectedActivity.price ?? undefined,
          participants: Number(participants) || (Number(adults) || 1) + (Number(children) || 0),
          amount: estimate.activities,
        } : null,
        restaurant: selectedRestaurant ? {
          name: selectedRestaurant.name,
          location: selectedRestaurant.address || selectedRestaurant.location || undefined,
          category: selectedRestaurant.category || undefined,
          cuisine: selectedRestaurant.cuisine?.length ? selectedRestaurant.cuisine : undefined,
          priceRange: selectedRestaurant.priceRange || undefined,
          date: restaurantDate,
          guests: (Number(adults) || 1) + (Number(children) || 0),
        } : null,
        stops: [
          ...plannedItems
            .map((id) => attractions.find((record) => record._id === id))
            .filter((record): record is DestinationRecord => !!record)
            .map((record) => ({ kind: "attraction", name: record.name, location: record.province || undefined })),
          ...selectedGemIds
            .map((id) => gems.find((record) => record._id === id))
            .filter((record): record is DestinationRecord => !!record)
            .map((record) => ({ kind: "hidden gem", name: record.name, location: record.province || undefined })),
          ...hotelPlanRecords
            .map((record) => ({ kind: "hotel stay", name: record.name, location: record.location || undefined })),
          ...activityPlanRecords
            .map((record) => ({ kind: "activity", name: record.name, location: record.location || undefined })),
        ],
        totals: {
          hotel: estimate.hotel,
          transportation: estimate.transportation,
          activities: estimate.activities,
          total: estimate.total,
          currency: "NPR",
        },
      };
      // POST /trips returns the trip document directly (201 + trip JSON).
      // Reuse the already-created trip on retry so re-pressing never
      // duplicates the plan; the booking endpoint is idempotent too.
      let newTripId = tripId;
      if (!newTripId) {
        const toPlannedItem = (record: DestinationRecord, category: string) => ({
          itemId: record._id,
          category,
          name: record.name,
          location: record.province ?? destination.trim(),
          latitude: record.latitude,
          longitude: record.longitude,
        });
        const plannedRecords = plannedItems
          .map((id) => attractions.find((record) => record._id === id))
          .filter((record): record is DestinationRecord => !!record)
          .map((record) => toPlannedItem(record, "destination"));
        const gemRecords = selectedGemIds
          .map((id) => gems.find((record) => record._id === id))
          .filter((record): record is DestinationRecord => !!record)
          .map((record) => toPlannedItem(record, "destination"));
        const itineraryHotelRecords = hotelPlanRecords.map((record) => ({
          itemId: record._id,
          category: "hotel",
          name: record.name,
          location: record.location,
          latitude: record.latitude,
          longitude: record.longitude,
        }));
        const itineraryActivityRecords = activityPlanRecords.map((record) => ({
          itemId: record._id,
          category: "activity",
          name: record.name,
          location: record.location,
          latitude: record.latitude,
          longitude: record.longitude,
        }));
        const tripRes = await backendRequest<TripRecord>(
          "/trips",
          {
            method: "POST",
            headers: authHeaders(),
            body: JSON.stringify({
              name: `Trip to ${destination.trim()}`,
              destination: destination.trim(),
              origin: origin.trim(),
              originDetails: {
                refId: selectedOrigin.refId ?? selectedOrigin._id,
                kind: selectedOrigin.kind,
                source: selectedOrigin.source,
                latitude: selectedOrigin.latitude,
                longitude: selectedOrigin.longitude,
                city: selectedOrigin.city,
                province: selectedOrigin.province,
                country: selectedOrigin.country,
              },
              startDate,
              endDate,
              adults: Number(adults) || 1,
              children: Number(children) || 0,
              plannedItems: [...plannedRecords, ...gemRecords, ...itineraryHotelRecords, ...itineraryActivityRecords],
              selections: selectionsSnapshot,
              totalAmount: estimate.total,
            }),
          }
        );
        newTripId = (tripRes as TripRecord)._id || (tripRes as unknown as { trip: TripRecord }).trip?._id;
        if (!newTripId) {
          throw new Error("Trip was not created. Please try again.");
        }
        setTripId(newTripId);
      }
      // ONE trip booking, saved as Pending Admin Confirmation. The server
      // returns the existing record if this trip was already submitted.
      const bookingRes = await backendRequest<{ booking: SubmittedTripBooking }>(
        "/bookings",
        {
          method: "POST",
          headers: authHeaders(),
          body: JSON.stringify({
            itemType: "trip",
            tripId: newTripId,
            checkIn: startDate,
            checkOut: endDate,
            adults: Number(adults) || 1,
            children: Number(children) || 0,
            rooms: roomNeeded,
            amount: estimate.total,
          }),
        }
      );
      setSubmittedBooking(bookingRes.booking);
      setBookingNotice(
        `Trip submitted for admin confirmation: ${bookingRes.booking.bookingCode}. Find it in My Bookings — payment unlocks after the admin confirms it.`
      );
      setStepIndex(STEPS.findIndex((s) => s.key === "confirmation"));
    } catch (e) {
      setBookingError(e instanceof Error ? e.message : "Could not create trip.");
    } finally {
      setCreating(false);
    }
  };

  // Return transport is selected like everything else and saved with the trip
  // submission — there is intentionally no separate return booking or return
  // payment inside the complete-trip flow.

  // Selections inside the complete-trip flow are edited with the Select /
  // Remove toggles. Individual booking cancellation lives in My Bookings,
  // not here.

  // Client-side price estimate from the CURRENT selection (updates instantly
  // as items change). It becomes the submitted trip total at submit time.
  const estimate = useMemo(() => {
    const party = (Number(adults) || 1) + (Number(children) || 0);
    const transportAmount = (t: TransportRecord | null, dateOk: boolean, assigned: number): number => {
      if (!t || !dateOk || assigned <= 0) return 0;
      return transportLegPrice(t, assigned);
    };
    let hotel = 0;
    if (selectedHotel && selectedRoom) {
      const rate = Number(selectedRoom.nightlyRate ?? selectedHotel.pricePerNight) || 0;
      hotel = Math.round(rate * stayNights * roomNeeded);
    }
    const transportation =
      transportAmount(selectedOutbound, DATE_RE.test(outboundDate), outboundParty.total) +
      transportAmount(selectedReturn, DATE_RE.test(returnDate), returnParty.total) +
      transportAmount(selectedLocal, true, localParty.total);
    const activities =
      selectedActivity && DATE_RE.test(activityDate)
        ? Math.round((Number(selectedActivity.price) || 0) * (Number(participants) || party))
        : 0;
    return {
      hotel,
      transportation,
      activities,
      other: 0,
      total: hotel + transportation + activities,
    };
  }, [
    adults,
    children,
    selectedOutbound,
    outboundDate,
    outboundAdults,
    outboundChildren,
    selectedReturn,
    returnDate,
    returnAdults,
    returnChildren,
    selectedLocal,
    localAdults,
    localChildren,
    selectedHotel,
    selectedRoom,
    stayNights,
    roomNeeded,
    selectedActivity,
    activityDate,
    participants,
  ]);

  // ---------- Step bodies ----------
  const renderBody = () => {
    switch (step) {
      case "destination":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Choose your destination</Text>
              <Text style={styles.muted}>Search the live catalog and pick a recognized destination. Everything downstream follows this choice.</Text>
            </View>
            {destLoading ? <ActivityIndicator color={colors.primary} /> : null}
            <Text style={styles.sectionTitle}>Popular right now</Text>
            {popularDests.map((d) => (
              <View key={d._id} style={[styles.card, destination === d.name && styles.cardActive]}>
                <Text style={styles.cardTitle}>{d.name}</Text>
                {!!d.province && <Text style={styles.muted}>{d.province}</Text>}
                <View style={styles.btnRow}>
                  <Pressable
                    style={styles.secondaryBtn}
                    onPress={() => {
                      setGateError(null);
                      setSelectedDestination(toDestinationSummary(d));
                      setDestination(d.name);
                      setDestinationDetail(d);
                      // NOTE: no refreshStepData() here — same stale-closure
                      // reason as above; the step-visit auto-fetch loads data
                      // with fresh state after next().
                      next();
                    }}
                  >
                    <Text style={styles.secondaryBtnText}>Select & continue</Text>
                  </Pressable>
                  <Pressable style={styles.ghostBtn} onPress={() => openMap(d.name, d.province, d.latitude, d.longitude)}>
                    <Text style={styles.ghostBtnText}>Map</Text>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        );
      case "overview":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>{destination ? `Trip to ${destination}` : "Trip overview"}</Text>
              {detailLoading ? <ActivityIndicator color={colors.primary} /> : null}
              {destinationDetail ? (
                <View style={{ gap: 4 }}>
                  <RelevantImage
                    entity={{ name: destinationDetail.name, type: "destination", location: destinationDetail.province }}
                    style={styles.bannerImage}
                  />
                  {!!destinationDetail.description && <Text style={styles.body}>{destinationDetail.description}</Text>}
                  {!!destinationDetail.whyVisit && <Text style={styles.body}>Why visit: {destinationDetail.whyVisit}</Text>}
                  {!!destinationDetail.bestTimeToVisit && <Text style={styles.muted}>Best time: {destinationDetail.bestTimeToVisit}</Text>}
                  {!!destinationDetail.approximateCost && <Text style={styles.muted}>Approx cost: {String(destinationDetail.approximateCost)}</Text>}
                  {!!destinationDetail.entryFee && <Text style={styles.muted}>Entry fee: {String(destinationDetail.entryFee)}</Text>}
                  {!!destinationDetail.openingHours && <Text style={styles.muted}>Hours: {destinationDetail.openingHours}</Text>}
                  {!!destinationDetail.estimatedDuration && <Text style={styles.muted}>Suggested duration: {destinationDetail.estimatedDuration}</Text>}
                  {!!destinationDetail.safetyInfo && <Text style={styles.muted}>Safety: {destinationDetail.safetyInfo}</Text>}
                  {!!destinationDetail.highlights?.length && <Text style={styles.muted}>Highlights: {destinationDetail.highlights.slice(0, 5).join(" · ")}</Text>}
                  {!!destinationDetail.nearbyFacilities?.length && <Text style={styles.muted}>Nearby: {destinationDetail.nearbyFacilities.slice(0, 5).join(" · ")}</Text>}
                  <View style={styles.btnRow}>
                    <Pressable
                      style={styles.ghostBtn}
                      onPress={() => openMap(destinationDetail.name, destinationDetail.province, destinationDetail.latitude, destinationDetail.longitude)}
                    >
                      <Text style={styles.ghostBtnText}>Open in Map screen</Text>
                    </Pressable>
                    <Pressable
                      style={styles.ghostBtn}
                      onPress={() => openExternalDirections(placeQuery(destinationDetail.name, destinationDetail.province, destinationDetail.latitude, destinationDetail.longitude), originPoint)}
                    >
                      <Text style={styles.ghostBtnText}>Directions</Text>
                    </Pressable>
                  </View>
                </View>
              ) : (
                <Text style={styles.muted}>Destination facts load from GET /destinations once you pick a destination.</Text>
              )}
            </View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Origin, dates, travelers</Text>
              <DestinationAutocomplete
                label="Destination"
                selected={selectedDestination}
                error={gateError?.field === "destination" ? gateError.message : undefined}
                onSelect={(item) => {
                  setGateError(null);
                  setSelectedDestination(item);
                  setDestination(item.name);
                  setDestinationDetail(item as unknown as DestinationRecord);
                }}
                onClear={() => {
                  setSelectedDestination(null);
                  setDestinationDetail(null);
                }}
              />
              <LocationAutocomplete
                label="Origin (editable)"
                placeholder="Search origin, e.g. Thamel…"
                endpoint="/locations/search"
                selected={selectedOrigin}
                error={gateError?.field === "origin" ? gateError.message : undefined}
                onSelect={(item) => {
                  setGateError(null);
                  setSelectedOrigin(item);
                  setOrigin(item.name);
                }}
                onClear={() => {
                  setSelectedOrigin(null);
                }}
              />
              <View style={styles.twoCol}>
                <View style={styles.col}>
                  <BSADDatePicker
                    label="Departure date"
                    value={startDate}
                    onChange={(iso) => {
                      setGateError(null);
                      setStartDate(iso);
                    }}
                    minDate={todayAdISO()}
                    error={gateError?.field === "startDate" ? gateError.message : undefined}
                  />
                </View>
                <View style={styles.col}>
                  <BSADDatePicker
                    label="Return date"
                    value={endDate}
                    onChange={(iso) => {
                      setGateError(null);
                      setEndDate(iso);
                    }}
                    minDate={startDate}
                    // Same-day return is allowed (matches the submit
                    // validation); only a return before departure flags here.
                    error={gateError?.field === "endDate" ? gateError.message : isStrictAdISO(endDate) && endDate < startDate ? "Return date must be after the departure date." : undefined}
                  />
                </View>
              </View>
              <View style={styles.threeCol}>
                <View style={styles.col}>
                  <Text style={styles.label}>Adults</Text>
                  <TextInput value={adults} onChangeText={(value) => handleOverviewQuantity("adults", value, adults, setAdults)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={confirmOverview} />
                </View>
                <View style={styles.col}>
                  <Text style={styles.label}>Children</Text>
                  <TextInput value={children} onChangeText={(value) => handleOverviewQuantity("children", value, children, setChildren)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={confirmOverview} />
                </View>
                <View style={styles.col}>
                  <Text style={styles.label}>Rooms</Text>
                  <TextInput value={rooms} onChangeText={(value) => handleOverviewQuantity("rooms", value, rooms, setRooms)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={confirmOverview} />
                </View>
              </View>
              {(gateError?.field === "adults" || gateError?.field === "children" || gateError?.field === "rooms") && (
                <Text style={styles.error}>{gateError.message}</Text>
              )}
              <Pressable style={styles.primaryBtn} onPress={confirmOverview} disabled={gateBusy}>
                <Text style={styles.primaryBtnText}>{gateBusy ? "Validating…" : `Load ${destination ? "trip options" : "options"}`}</Text>
              </Pressable>
            </View>
          </View>
        );
      case "outbound":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Origin → destination</Text>
              <Text style={styles.muted}>Live query with fallback to destination-only when the route has no direct service.</Text>
              <LocationAutocomplete
                label="Origin"
                placeholder="Search origin…"
                endpoint="/locations/search"
                selected={selectedOrigin}
                error={gateError?.field === "origin" ? gateError.message : undefined}
                onSelect={(item) => {
                  setGateError(null);
                  setSelectedOrigin(item);
                  setOrigin(item.name);
                }}
                onClear={() => {
                  setSelectedOrigin(null);
                }}
              />
              <BSADDatePicker
                label="Travel date"
                value={outboundDate}
                onChange={setOutboundDate}
                minDate={todayAdISO()}
              />
              <Text style={styles.label}>Passengers</Text>
              <Text style={styles.body}>{(Number(adults) || 0) + (Number(children) || 0)} traveler(s) ({adults} adult(s), {children} child(ren)) — edit in Overview</Text>
              <Pressable style={styles.primaryBtn} onPress={() => void fetchOutbound()}>
                <Text style={styles.primaryBtnText}>Search outbound</Text>
              </Pressable>
            </View>
            <View style={styles.rowBetween}>
              <Text style={styles.sectionTitle}>Options{[origin.trim(), destination.trim()].filter(Boolean).length ? `: ${[origin.trim(), destination.trim()].filter(Boolean).join(" → ")}` : ""}</Text>
              <Pressable onPress={() => void fetchOutbound()}><Text style={styles.link}>Reload</Text></Pressable>
            </View>
            {outboundLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!outboundLoading && outbound.length === 0 ? (
              <View style={styles.card}><Text style={styles.muted}>No verified services for this route yet. Try clearing the origin for destination-only results.</Text></View>
            ) : null}
            {outbound.map((t) => {
              const active = t._id === selectedOutboundId;
              return (
                <View key={t._id} style={[styles.card, active && styles.cardActive]}>
                  <RelevantImage
                    entity={{
                      name: t.name,
                      type: "transport",
                      location: [t.origin, t.destination].filter(Boolean).join(" "),
                      image: t.image,
                      images: t.images,
                      imageSource: t.imageSource,
                      imageSourcePage: t.imageSourcePage,
                      imageLicense: t.imageLicense,
                      imageCredit: t.imageCredit,
                      imageDescription: t.imageDescription,
                      imageRelevance: t.imageRelevance,
                    }}
                    style={styles.thumb}
                  />
                  <Text style={styles.cardTitle}>{t.name}</Text>
                  {!!t.type && <Text style={styles.muted}>Type: {t.type}{t.provider ? ` · ${t.provider}` : ""}</Text>}
                  {(t.origin || t.destination) ? <Text style={styles.muted}>{[t.origin, t.destination].filter(Boolean).join(" → ")}</Text> : null}
                  {t.departureTime ? <Text style={styles.muted}>Departs: {t.departureTime}</Text> : null}
                  {t.arrivalTime ? <Text style={styles.muted}>Arrives: {t.arrivalTime}</Text> : null}
                  {formatDuration(t.durationMinutes) ? <Text style={styles.muted}>Duration: {formatDuration(t.durationMinutes)}</Text> : null}
                  {t.price !== undefined ? <Text style={styles.price}>NPR {t.price}</Text> : <Text style={styles.muted}>Price on request</Text>}
                  {!transportFareOk(t, (Number(adults) || 1) + (Number(children) || 0)) ? (
                    <Text style={styles.error}>Fare not confirmed — this service cannot be booked yet.</Text>
                  ) : null}
                  {t.capacity !== undefined ? <Text style={styles.muted}>Capacity: {t.capacity}</Text> : null}
                  {!!t.amenities?.length && <Text style={styles.muted}>Amenities: {t.amenities.join(", ")}</Text>}
                  {active ? (
                    <View style={styles.qrBox}>
                      <Text style={styles.roomName}>Seats for {outboundDate}</Text>
                      {seatsLoading ? <ActivityIndicator color={colors.primary} /> : null}
                      {!seatsLoading && !seatsData ? <Text style={styles.muted}>Seat map unavailable — booking will be for passenger count only.</Text> : null}
                      {seatsData && seatsData.seatSelection === false ? (
                        <Text style={styles.muted}>Whole-vehicle service: no per-seat selection. Booking reserves the vehicle for your group.</Text>
                      ) : null}
                      {seatsData?.seats?.length ? (
                        <View>
                          <Text style={styles.muted}>Available {seatsData.available ?? 0} / {seatsData.capacity ?? 0} · Booked {seatsData.booked ?? 0}</Text>
                          <View style={styles.chipWrap}>
                            {seatsData.seats.map((s) => {
                              const chosen = selectedSeats.includes(s.label);
                              return (
                                <Pressable
                                  key={s.label}
                                  disabled={s.booked}
                                  onPress={() => setSelectedSeats((cur) => (cur.includes(s.label) ? cur.filter((x) => x !== s.label) : [...cur, s.label]))}
                                  style={[styles.chip, s.booked && styles.chipDisabled, chosen && styles.chipActive]}
                                >
                                  <Text style={[styles.chipText, chosen && styles.chipTextActive]}>{s.label}{s.booked ? " (Booked)" : ""}</Text>
                                </Pressable>
                              );
                            })}
                          </View>
                          <Text style={styles.muted}>Selected: {selectedSeats.length ? selectedSeats.join(", ") : "none"}</Text>
                        </View>
                      ) : null}
                      <Text style={styles.label}>Passengers on this service</Text>
                      <View style={styles.threeCol}>
                        <View style={styles.col}><Text style={styles.label}>Adults</Text><TextInput value={outboundAdults} onChangeText={setOutboundAdults} placeholder={String(partyAdults)} placeholderTextColor={colors.textMuted} keyboardType="number-pad" maxLength={3} style={styles.input} /></View>
                        <View style={styles.col}><Text style={styles.label}>Children</Text><TextInput value={outboundChildren} onChangeText={setOutboundChildren} placeholder={String(partyChildren)} placeholderTextColor={colors.textMuted} keyboardType="number-pad" maxLength={3} style={styles.input} /></View>
                      </View>
                      <Text style={styles.muted}>{outboundParty.total} of {partyTotal} traveler(s) on this service · rest by own vehicle or unassigned.</Text>
                    </View>
                  ) : null}
                  <View style={styles.btnRow}>
                    <Pressable style={[styles.secondaryBtn, active && styles.primaryBtn]} disabled={tripLocked || !transportFareOk(t, (Number(adults) || 1) + (Number(children) || 0))} onPress={() => { setSelectedOutboundId(active ? "" : t._id); setSelectedSeats([]); }}>
                      <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "Added ✓" : "Add to Trip"}</Text>
                    </Pressable>
                    <Pressable style={styles.ghostBtn} onPress={() => openMap(t.name, [t.origin, t.destination].filter(Boolean).join(" "), t.latitude, t.longitude)}>
                      <Text style={styles.ghostBtnText}>Map</Text>
                    </Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        );
      case "hotel":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Dates & occupancy</Text>
              <View style={styles.twoCol}>
                <View style={styles.col}><Text style={styles.label}>Check-in</Text><TextInput value={startDate} onChangeText={setStartDate} style={styles.input} returnKeyType="go" onSubmitEditing={() => void fetchHotels()} /></View>
                <View style={styles.col}><Text style={styles.label}>Check-out</Text><TextInput value={endDate} onChangeText={setEndDate} style={styles.input} returnKeyType="go" onSubmitEditing={() => void fetchHotels()} /></View>
              </View>
              <View style={styles.threeCol}>
                <View style={styles.col}><Text style={styles.label}>Adults</Text><TextInput value={adults} onChangeText={(value) => handleStepQuantity("adults", value, adults, setAdults)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={() => void fetchHotels()} /></View>
                <View style={styles.col}><Text style={styles.label}>Children</Text><TextInput value={children} onChangeText={(value) => handleStepQuantity("children", value, children, setChildren)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={() => void fetchHotels()} /></View>
                <View style={styles.col}><Text style={styles.label}>Rooms</Text><TextInput value={rooms} onChangeText={(value) => handleStepQuantity("rooms", value, rooms, setRooms)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={() => void fetchHotels()} /></View>
              </View>
              <Pressable style={styles.primaryBtn} onPress={() => void fetchHotels()}><Text style={styles.primaryBtnText}>Check availability</Text></Pressable>
            </View>
            {hotelsLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!!hotelsNote && !hotelsLoading ? <Text style={styles.muted}>{hotelsNote}</Text> : null}
            {!hotelsLoading && hotels.length === 0 && !destination.trim() ? <View style={styles.card}><Text style={styles.muted}>Select a destination to load stays.</Text></View> : null}
            {hotels.map((h) => (
              <View key={h._id} style={[styles.card, h._id === selectedHotelId && styles.cardActive]}>
                <RelevantImage
                  entity={{
                    name: h.name,
                    type: "hotel",
                    location: h.location,
                    image: h.image,
                    images: h.images,
                    imageSource: h.imageSource,
                    imageSourcePage: h.imageSourcePage,
                    imageLicense: h.imageLicense,
                    imageCredit: h.imageCredit,
                    imageDescription: h.imageDescription,
                    imageRelevance: h.imageRelevance,
                  }}
                  style={styles.thumb}
                />
                <Text style={styles.cardTitle}>{h.name}</Text>
                {!!h.location && <Text style={styles.muted}>{h.location}</Text>}
                {!!h.description && <Text style={styles.body} numberOfLines={2}>{h.description}</Text>}
                {typeof h.rating === "number" ? (
                  <Text style={styles.muted}>★ {h.rating}{typeof h.reviewCount === "number" ? ` (${h.reviewCount} reviews)` : ""}</Text>
                ) : null}
                {hotelBestRate(h) !== undefined ? (
                  <Text style={styles.price}>NPR {hotelBestRate(h)} / night{stayNights > 0 ? ` · ${stayNights} night(s) ≈ NPR ${((hotelBestRate(h) ?? 0) * stayNights * roomNeeded).toLocaleString("en-IN")} for ${roomNeeded} room(s)` : ""}</Text>
                ) : <Text style={styles.muted}>Nightly rate not listed</Text>}
                {!!h.amenities?.length && <Text style={styles.muted}>Amenities: {h.amenities.slice(0, 6).join(" · ")}</Text>}
                {hotelAvailabilityStatus(h)}
                {(h.roomTypes ?? []).some((r) => r.availableRooms !== undefined) ? (
                (h.roomTypes ?? []).map((r) => {
                  const soldOut = roomSoldOut(r);
                  const selectable = roomSelectable(r);
                  const chosen = selectedHotelId === h._id && selectedRoomTypeId === r._id;
                  const maxOccupancy =
                    Number.isFinite(r.capacityAdults) && Number.isFinite(r.capacityChildren)
                      ? r.capacityAdults + r.capacityChildren
                      : undefined;
                  return (
                    <View
                      key={r._id}
                      style={[styles.roomRow, chosen && styles.cardActive, !selectable && styles.roomDisabled]}
                    >
                      <Pressable
                        disabled={!selectable || tripLocked}
                        onPress={() => { setSelectedHotelId(h._id); setSelectedRoomTypeId(r._id); }}
                        style={styles.roomMain}
                        accessibilityRole="button"
                        accessibilityLabel={`Select ${r.name} at ${h.name}`}
                        accessibilityState={{ selected: chosen, disabled: !selectable }}
                      >
                      <View style={styles.roomInfo}>
                        <Text style={styles.roomName}>{r.name}</Text>
                        <Text style={styles.muted}>Up to {r.capacityAdults} adult(s) · {r.capacityChildren} child(ren)</Text>
                        {maxOccupancy !== undefined ? (
                          <Text style={styles.muted}>Maximum occupancy: {maxOccupancy} guest(s)</Text>
                        ) : null}
                        <Text style={styles.muted}>{r.availableRooms ?? 0} room(s) left{r.nightlyRate !== undefined ? ` · NPR ${r.nightlyRate}/night` : ""}</Text>
                        {!!r.bedConfiguration && <Text style={styles.muted}>{r.bedConfiguration}{r.breakfastIncluded ? " · breakfast included" : ""}</Text>}
                        {!!r.amenities?.length && <Text style={styles.muted}>Room facilities: {r.amenities.slice(0, 6).join(" · ")}</Text>}
                      </View>
                      <Text style={soldOut ? styles.soldOut : styles.inStock}>{soldOut ? "SOLD OUT" : "AVAILABLE"}</Text>
                      </Pressable>
                      {selectable && !tripLocked ? (
                        <Pressable
                          style={[styles.selectRoomBtn, chosen && styles.selectRoomBtnChosen]}
                          onPress={() => selectRoom(h, r)}
                          accessibilityRole="button"
                          accessibilityState={{ selected: chosen }}
                          accessibilityLabel={chosen ? `${r.name} selected` : `Select ${r.name}`}
                        >
                          <Text style={[styles.selectRoomBtnText, chosen && styles.selectRoomBtnTextChosen]}>
                            {chosen ? "✓ Room Selected" : "Select Room"}
                          </Text>
                        </Pressable>
                      ) : null}
                    </View>
                  );
                })
                ) : (
                  !!h.fallbackNote ? <Text style={styles.muted}>{h.fallbackNote}</Text> : null
                )}
                <View style={styles.btnRow}>
                  {h._id.startsWith("curated-") ? (
                    <Pressable
                      style={[styles.secondaryBtn, plannedItems.includes(h._id) && styles.primaryBtn]}
                      disabled={tripLocked}
                      onPress={() => toggleId(h._id, plannedItems, setPlannedItems)}
                      accessibilityRole="button"
                      accessibilityState={{ selected: plannedItems.includes(h._id) }}
                      accessibilityLabel={plannedItems.includes(h._id) ? `Remove ${h.name} from itinerary` : `Add ${h.name} to itinerary`}
                    >
                      <Text style={[styles.secondaryBtnText, plannedItems.includes(h._id) && styles.primaryBtnText]}>{plannedItems.includes(h._id) ? "In itinerary ✓" : "Add to itinerary"}</Text>
                    </Pressable>
                  ) : (h.roomTypes ?? []).some((r) => roomSelectable(r)) ? (
                    <Pressable
                      style={styles.primaryBtn}
                      onPress={() => addHotelToTrip(h)}
                      disabled={tripLocked}
                      accessibilityRole="button"
                      accessibilityLabel={`Add ${h.name} to trip`}
                    >
                      <Text style={styles.primaryBtnText}>
                        {selectedHotelId === h._id && selectedRoomTypeId ? "Added — review trip ✓" : "Add to Trip"}
                      </Text>
                    </Pressable>
                  ) : (h.roomTypes ?? []).some((r) => r.availableRooms !== undefined) ? (
                    <Text style={styles.soldOut}>{roomShortfallMessage(h)}</Text>
                  ) : null}
                  <Pressable style={styles.ghostBtn} onPress={() => openMap(h.name, h.location, h.latitude, h.longitude)}><Text style={styles.ghostBtnText}>Map</Text></Pressable>
                  <Pressable style={styles.ghostBtn} onPress={() => openExternalDirections(placeQuery(h.name, h.location, h.latitude, h.longitude))}><Text style={styles.ghostBtnText}>Directions</Text></Pressable>
                </View>
                {addedHotelId === h._id ? (
                  <Text style={styles.notice}>Hotel added to your trip ✓</Text>
                ) : null}
              </View>
            ))}
          </View>
        );
      case "restaurants":
        return (
          <View>
            <View style={styles.rowBetween}>
              <Text style={styles.sectionTitle}>Restaurants</Text>
              <Pressable onPress={() => void fetchRestaurants()}><Text style={styles.link}>Reload</Text></Pressable>
            </View>
            <View style={styles.card}>
              <Text style={styles.muted}>Table reservation for {(Number(adults) || 1) + (Number(children) || 0)} guest(s) — pay at the venue, NPR 0 in the trip total.</Text>
              <BSADDatePicker
                label="Reservation date"
                value={restaurantDate}
                onChange={setRestaurantDate}
                minDate={todayAdISO()}
              />
            </View>
            {restaurantsLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!!restaurantsNote && !restaurantsLoading ? <Text style={styles.muted}>{restaurantsNote}</Text> : null}
            {!restaurantsLoading && restaurants.length === 0 ? (
              <View style={styles.card}><Text style={styles.muted}>No reservable restaurants found for this destination yet.</Text></View>
            ) : null}
            {restaurants.map((r) => {
              const active = r._id === selectedRestaurantId;
              return (
                <View key={r._id} style={[styles.card, active && styles.cardActive]}>
                  <Text style={styles.cardTitle}>{r.name}</Text>
                  {!!r.cuisine?.length && <Text style={styles.muted}>{r.cuisine.slice(0, 4).join(" · ")}</Text>}
                  {!!(r.city || r.location) && <Text style={styles.muted}>{[r.location, r.city].filter(Boolean).join(" · ")}</Text>}
                  {!!r.description && <Text style={styles.body} numberOfLines={2}>{r.description}</Text>}
                  {r.rating !== undefined ? <Text style={styles.muted}>Rating: {r.rating} / 5</Text> : null}
                  <View style={styles.btnRow}>
                    <Pressable
                      style={[styles.secondaryBtn, active && styles.primaryBtn]}
                      disabled={tripLocked}
                      onPress={() => setSelectedRestaurantId(active ? "" : r._id)}
                    >
                      <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "Reserved ✓" : "Reserve table"}</Text>
                    </Pressable>
                    <Pressable style={styles.ghostBtn} onPress={() => openMap(r.name, r.location || r.city, r.latitude, r.longitude)}><Text style={styles.ghostBtnText}>Map</Text></Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        );
      case "attractions":
        return (
          <View>
            <View style={styles.rowBetween}>
              <Text style={styles.sectionTitle}>Attractions & heritage</Text>
              <Pressable onPress={() => void fetchAttractions()}><Text style={styles.link}>Reload</Text></Pressable>
            </View>
            <View style={styles.card}><Text style={styles.muted}>Free stops from the destinations catalog (hidden-tagged places excluded). Multi-select — they join the trip plan, no booking needed.</Text></View>
            {attractionsLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!!attractionsNote && !attractionsLoading ? <Text style={styles.muted}>{attractionsNote}</Text> : null}
            {!attractionsLoading && attractions.length === 0 && !destination.trim() ? <View style={styles.card}><Text style={styles.muted}>Select a destination to load attractions.</Text></View> : null}
            {attractions.map((d) => {
              const active = plannedItems.includes(d._id);
              return (
                <View key={d._id} style={[styles.card, active && styles.cardActive]}>
                  <Text style={styles.cardTitle}>{d.name}</Text>
                  {d.isCurated ? <Text style={styles.muted}>Suggested stop — verify locally.</Text> : null}
                  {!!d.description && <Text style={styles.body} numberOfLines={3}>{d.description}</Text>}
                  {!!d.highlights?.length && <Text style={styles.muted}>Highlights: {d.highlights.slice(0, 4).join(" · ")}</Text>}
                  {!!d.openingHours && <Text style={styles.muted}>Hours: {d.openingHours}</Text>}
                  {d.entryFee !== undefined && <Text style={styles.muted}>Entry: {String(d.entryFee)}</Text>}
                  <View style={styles.btnRow}>
                    <Pressable style={[styles.secondaryBtn, active && styles.primaryBtn]} disabled={tripLocked} onPress={() => toggleId(d._id, plannedItems, setPlannedItems)}>
                      <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "In plan ✓" : "Add to Trip"}</Text>
                    </Pressable>
                    <Pressable style={styles.ghostBtn} onPress={() => openMap(d.name, d.province, d.latitude, d.longitude)}><Text style={styles.ghostBtnText}>Map</Text></Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        );
      case "activities":
        return (
          <View>
            <View style={styles.rowBetween}>
              <Text style={styles.sectionTitle}>Activities</Text>
              <Pressable onPress={() => void fetchActivities()}><Text style={styles.link}>Reload</Text></Pressable>
            </View>
            <View style={styles.card}>
              <View style={styles.twoCol}>
                <View style={styles.col}>
                  <BSADDatePicker
                    label="Activity date"
                    value={activityDate}
                    onChange={setActivityDate}
                    minDate={todayAdISO()}
                  />
                </View>
                <View style={styles.col}><Text style={styles.label}>Participants</Text><TextInput value={participants} onChangeText={(value) => handleStepQuantity("participants", value, participants, setParticipants)} keyboardType="number-pad" maxLength={3} style={styles.input} returnKeyType="go" onSubmitEditing={() => void fetchActivities()} /></View>
              </View>
            </View>
            {activitiesLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!!activitiesNote && !activitiesLoading ? <Text style={styles.muted}>{activitiesNote}</Text> : null}
            {!activitiesLoading && activities.length === 0 && !destination.trim() ? <View style={styles.card}><Text style={styles.muted}>Select a destination to load activities.</Text></View> : null}
            {activities.map((a) => {
              const active = a._id === selectedActivityId;
              const participantCount = Math.max(1, Number(participants) || 1);
              const activityTotal = typeof a.price === "number" ? a.price * participantCount : undefined;
              return (
                <View key={a._id} style={[styles.card, active && styles.cardActive]}>
                  <RelevantImage
                    entity={{
                      name: a.name,
                      type: "activity",
                      location: a.location,
                      image: a.image,
                      images: a.images,
                      imageSource: a.imageSource,
                      imageSourcePage: a.imageSourcePage,
                      imageLicense: a.imageLicense,
                      imageCredit: a.imageCredit,
                      imageDescription: a.imageDescription,
                      imageRelevance: a.imageRelevance,
                    }}
                    style={styles.thumb}
                  />
                  <Text style={styles.cardTitle}>{a.name}</Text>
                  {a.isCurated ? <Text style={styles.muted}>Suggested activity — itinerary only, not booked.</Text> : null}
                  {!!a.location && <Text style={styles.muted}>{a.location}</Text>}
                  {!!a.description && <Text style={styles.body} numberOfLines={2}>{a.description}</Text>}
                  {a.price !== undefined ? (
                    <Text style={styles.price}>
                      NPR {a.price.toLocaleString("en-IN")} / person{activityTotal !== undefined ? ` · ${participantCount} participant(s) ≈ NPR ${activityTotal.toLocaleString("en-IN")} total` : ""}
                    </Text>
                  ) : <Text style={styles.muted}>Price not listed — verify with the operator</Text>}
                  {a.durationMinutes !== undefined ? <Text style={styles.muted}>Duration: {Math.floor(a.durationMinutes / 60) > 0 ? `${Math.floor(a.durationMinutes / 60)}h ` : ""}{a.durationMinutes % 60 ? `${a.durationMinutes % 60}m` : a.durationMinutes < 60 ? `${a.durationMinutes} min` : ""}</Text> : null}
                  {!!a.meetingPoint && <Text style={styles.muted}>Meet: {a.meetingPoint}</Text>}
                  {!!a.requirements?.length && <Text style={styles.muted}>Needs: {a.requirements.join(", ")}</Text>}
                  {active ? (
                    <View style={styles.qrBox}>
                      <Text style={styles.roomName}>Slots for {activityDate}</Text>
                      {slotsLoading ? <ActivityIndicator color={colors.primary} /> : null}
                      {!slotsLoading && activitySlots.length === 0 ? (
                        <Text style={styles.muted}>
                          {selectedActivity?.slots && selectedActivity.slots.length > 0
                            ? `This activity runs on scheduled slots (${selectedActivity.slots.join(", ")}) — pick one above or checkout will be rejected.`
                            : "No slot inventory for this date — booking will use the date only."}
                        </Text>
                      ) : null}
                      <View style={styles.chipWrap}>
                        {activitySlots.map((s) => {
                          const full = s.available <= 0;
                          const chosen = selectedSlot === s.time;
                          return (
                            <Pressable
                              key={s.time}
                              disabled={full}
                              onPress={() => setSelectedSlot(chosen ? "" : s.time)}
                              style={[styles.chip, full && styles.chipDisabled, chosen && styles.chipActive]}
                            >
                              <Text style={[styles.chipText, chosen && styles.chipTextActive]}>{s.time} ({s.available} left){full ? " Full" : ""}</Text>
                            </Pressable>
                          );
                        })}
                      </View>
                    </View>
                  ) : null}
                  <View style={styles.btnRow}>
                    {a.isCurated ? (
                      <>
                        <Pressable
                          style={[styles.secondaryBtn, plannedItems.includes(a._id) && styles.primaryBtn]}
                          disabled={tripLocked}
                          onPress={() => toggleId(a._id, plannedItems, setPlannedItems)}
                          accessibilityRole="button"
                          accessibilityState={{ selected: plannedItems.includes(a._id) }}
                          accessibilityLabel={plannedItems.includes(a._id) ? `Remove ${a.name} from itinerary` : `Add ${a.name} to itinerary`}
                        >
                          <Text style={[styles.secondaryBtnText, plannedItems.includes(a._id) && styles.primaryBtnText]}>{plannedItems.includes(a._id) ? "In itinerary ✓" : "Add to itinerary"}</Text>
                        </Pressable>
                        <Pressable style={styles.ghostBtn} onPress={() => openExternalDirections(placeQuery(a.name, a.location, a.latitude, a.longitude))}><Text style={styles.ghostBtnText}>Directions</Text></Pressable>
                      </>
                    ) : (
                      <>
                        <Pressable
                          style={[styles.secondaryBtn, active && styles.primaryBtn]}
                          disabled={tripLocked}
                          onPress={() => {
                            if (!active) {
                              const participantsError = validateQuantityText(participants, "participants");
                              if (participantsError) {
                                setLoadError(participantsError);
                                return;
                              }
                              setLoadError("");
                            }
                            setSelectedActivityId(active ? "" : a._id); setSelectedSlot("");
                          }}
                        >
                          <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "Added ✓" : "Add to Trip"}</Text>
                        </Pressable>
                        <Pressable
                          style={styles.primaryBtn}
                          onPress={() => addActivityToTrip(a)}
                          disabled={tripLocked}
                          accessibilityRole="button"
                          accessibilityLabel={`Add ${a.name} to trip`}
                        >
                          <Text style={styles.primaryBtnText}>{active ? "Added — review trip ✓" : "Add to Trip & Review"}</Text>
                        </Pressable>
                      </>
                    )}
                    <Pressable style={styles.ghostBtn} onPress={() => openMap(a.name, a.location, a.latitude, a.longitude)}><Text style={styles.ghostBtnText}>Map</Text></Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        );
      case "gems":
        return (
          <View>
            <View style={styles.rowBetween}>
              <Text style={styles.sectionTitle}>Hidden gems</Text>
              <Pressable onPress={() => void fetchGems()}><Text style={styles.link}>Reload</Text></Pressable>
            </View>
            <View style={styles.card}><Text style={styles.muted}>Quieter and lesser-known spots for this destination — catalog hidden places first, then nearby off-beat stops. Added to the trip plan with map info.</Text></View>
            {gemsLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!!gemsNote && !gemsLoading ? <Text style={styles.muted}>{gemsNote}</Text> : null}
            {!gemsLoading && gems.length === 0 && !destination.trim() ? <View style={styles.card}><Text style={styles.muted}>Select a destination to load hidden gems.</Text></View> : null}
            {gems.map((g) => {
              const active = selectedGemIds.includes(g._id);
              return (
                <View key={g._id} style={[styles.card, active && styles.cardActive]}>
                  <Text style={styles.cardTitle}>{g.name}</Text>
                  {g.isCurated ? <Text style={styles.muted}>Suggested hidden gem — verify locally.</Text> : null}
                  {!!g.description && <Text style={styles.body} numberOfLines={2}>{g.description}</Text>}
                  {!!g.whyVisit && <Text style={styles.body}>Why visit: {g.whyVisit}</Text>}
                  {!!g.bestTimeToVisit && <Text style={styles.muted}>Best time: {g.bestTimeToVisit}</Text>}
                  {g.approximateCost !== undefined && <Text style={styles.muted}>Approx cost: {String(g.approximateCost)}</Text>}
                  {!!g.safetyInfo && <Text style={styles.muted}>Safety: {g.safetyInfo}</Text>}
                  {(g.latitude !== undefined && g.longitude !== undefined) ? <Text style={styles.muted}>Map: {g.latitude}, {g.longitude}</Text> : null}
                  <View style={styles.btnRow}>
                    <Pressable style={[styles.secondaryBtn, active && styles.primaryBtn]} disabled={tripLocked} onPress={() => toggleId(g._id, selectedGemIds, setSelectedGemIds)}>
                      <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "In trip ✓" : "Add to trip"}</Text>
                    </Pressable>
                    <Pressable style={styles.ghostBtn} onPress={() => openMap(g.name, g.province, g.latitude, g.longitude)}><Text style={styles.ghostBtnText}>Map</Text></Pressable>
                  </View>
                </View>
              );
            })}
          </View>
        );
      case "local":
        return (
          <View>
            <View style={styles.rowBetween}>
              <Text style={styles.sectionTitle}>Getting around{destination ? ` · ${destination}` : ""}</Text>
              <Pressable onPress={() => void fetchLocal()}><Text style={styles.link}>Reload</Text></Pressable>
            </View>
            <View style={styles.card}>
              <BSADDatePicker
                label="Travel date"
                value={localDate}
                onChange={setLocalDate}
                minDate={todayAdISO()}
              />
            </View>
            {localLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!!localNote && !localLoading ? <Text style={styles.muted}>{localNote}</Text> : null}
            {!localLoading && localTransports.length === 0 && localServices.length === 0 && !destination.trim() ? <View style={styles.card}><Text style={styles.muted}>Select a destination to load local services.</Text></View> : null}
            {localTransports.slice(0, 20).map((t) => {
              const active = t._id === selectedLocalId;
              return (
                <View key={t._id} style={[styles.card, active && styles.cardActive]}>
                  <Text style={styles.cardTitle}>{t.name}</Text>
                  <Text style={styles.muted}>{[t.origin, t.destination].filter(Boolean).join(" → ") || "Local service"}</Text>
                  {t.price !== undefined ? <Text style={styles.price}>NPR {t.price}</Text> : null}
                  {!transportFareOk(t, (Number(adults) || 1) + (Number(children) || 0)) ? (
                    <Text style={styles.error}>Fare not confirmed — this service cannot be booked yet.</Text>
                  ) : null}
                  {!!t.cancellationPolicy && <Text style={styles.muted}>Cancellation: {t.cancellationPolicy}</Text>}
                  {active ? (
                    <View>
                      <Text style={styles.label}>Passengers on this service</Text>
                      <View style={styles.threeCol}>
                        <View style={styles.col}><Text style={styles.label}>Adults</Text><TextInput value={localAdults} onChangeText={setLocalAdults} placeholder={String(partyAdults)} placeholderTextColor={colors.textMuted} keyboardType="number-pad" maxLength={3} style={styles.input} /></View>
                        <View style={styles.col}><Text style={styles.label}>Children</Text><TextInput value={localChildren} onChangeText={setLocalChildren} placeholder={String(partyChildren)} placeholderTextColor={colors.textMuted} keyboardType="number-pad" maxLength={3} style={styles.input} /></View>
                      </View>
                      <Text style={styles.muted}>{localParty.total} of {partyTotal} traveler(s) on this service · rest by own vehicle or unassigned.</Text>
                    </View>
                  ) : null}
                  <View style={styles.btnRow}>
                    <Pressable style={[styles.secondaryBtn, active && styles.primaryBtn]} disabled={tripLocked || !transportFareOk(t, (Number(adults) || 1) + (Number(children) || 0))} onPress={() => setSelectedLocalId(active ? "" : t._id)}>
                      <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "Added ✓" : "Add to Trip"}</Text>
                    </Pressable>
                    <Pressable style={styles.ghostBtn} onPress={() => openExternalDirections([t.origin, t.destination].filter(Boolean).join(" to ") || t.name)}><Text style={styles.ghostBtnText}>Directions</Text></Pressable>
                  </View>
                </View>
              );
            })}
            {localServices.length ? <Text style={styles.sectionTitle}>Useful services nearby</Text> : null}
            {localServices.map((s) => (
              <View key={s._id} style={styles.card}>
                <Text style={styles.cardTitle}>{s.name}</Text>
                <Text style={styles.muted}>{s.category}{s.location ? ` · ${s.location}` : ""}</Text>
                {!!s.description && <Text style={styles.body} numberOfLines={2}>{s.description}</Text>}
                <View style={styles.btnRow}>
                  <Pressable style={styles.ghostBtn} onPress={() => openMap(s.name, s.location)}><Text style={styles.ghostBtnText}>Map</Text></Pressable>
                  <Pressable style={styles.ghostBtn} onPress={() => openExternalDirections(placeQuery(s.name, s.location))}><Text style={styles.ghostBtnText}>Directions</Text></Pressable>
                </View>
              </View>
            ))}
          </View>
        );
      case "review":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Complete Trip Review</Text>
              <Text style={styles.muted}>Submit for admin confirmation — payment happens later in My Bookings, after the admin confirms.</Text>
              <Text style={styles.body}>Destination: {destination || "—"}</Text>
              <Text style={styles.body}>Origin: {origin || "—"}</Text>
              <Text style={styles.body}>Dates: {startDate || "—"} → {returnDate || endDate || "—"}</Text>
              <Text style={styles.body}>
                Duration: {stayNights} night{stayNights === 1 ? "" : "s"} ({stayNights + 1} day{stayNights + 1 === 1 ? "" : "s"})
              </Text>
              <Text style={styles.body}>Travellers: {(Number(adults) || 1) + (Number(children) || 0)} ({adults} adult(s), {children} child(ren))</Text>
              {tripLocked ? <Text style={styles.notice}>Submitted ✓ — selections are locked.</Text> : null}
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Hotel</Text>
              {selectedHotel && selectedRoom ? (
                <View>
                  <RelevantImage
                    entity={{ name: selectedHotel.name, type: "hotel", location: selectedHotel.location, image: selectedHotel.image, images: selectedHotel.images, imageSource: selectedHotel.imageSource, imageSourcePage: selectedHotel.imageSourcePage, imageLicense: selectedHotel.imageLicense, imageCredit: selectedHotel.imageCredit, imageDescription: selectedHotel.imageDescription, imageRelevance: selectedHotel.imageRelevance }}
                    style={styles.thumb}
                  />
                  <Text style={styles.body}>{selectedHotel.name} · {selectedRoom.name}</Text>
                  {!!selectedHotel.location && (
                    <Text style={styles.muted}>{selectedHotel.location}</Text>
                  )}
                  {!!selectedRoom.bedConfiguration && (
                    <Text style={styles.muted}>
                      {selectedRoom.bedConfiguration}{selectedRoom.breakfastIncluded ? " · breakfast included" : ""}
                    </Text>
                  )}
                  {Number.isFinite(selectedRoom.capacityAdults) && Number.isFinite(selectedRoom.capacityChildren) ? (
                    <Text style={styles.muted}>
                      Maximum occupancy: {selectedRoom.capacityAdults + selectedRoom.capacityChildren} guest(s)
                    </Text>
                  ) : null}
                  {!!selectedRoom.amenities?.length && (
                    <Text style={styles.muted}>Room facilities: {selectedRoom.amenities.slice(0, 6).join(" · ")}</Text>
                  )}
                  <Text style={styles.muted}>{startDate} → {endDate} · {roomNeeded} room(s) · {(Number(adults) || 1) + (Number(children) || 0)} guest(s)</Text>
                  {(selectedRoom.nightlyRate ?? selectedHotel.pricePerNight) !== undefined ? (
                    <Text style={styles.muted}>
                      NPR {(selectedRoom.nightlyRate ?? selectedHotel.pricePerNight ?? 0).toLocaleString("en-IN")}/night
                    </Text>
                  ) : null}
                  <Text style={styles.price}>NPR {estimate.hotel.toLocaleString("en-IN")}</Text>
                </View>
              ) : (
                <Text style={styles.muted}>No hotel selected.</Text>
              )}
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Transportation</Text>
              {selectedOutbound ? (
                <View>
                  <Text style={styles.body}>Outbound: {selectedOutbound.name}</Text>
                  <Text style={styles.muted}>{outboundDate}{selectedSeats.length ? ` · Seats ${selectedSeats.join(", ")}` : ""} · {outboundParty.total} of {partyTotal} traveler(s) on this service</Text>
                  <Text style={styles.price}>NPR {transportLegPrice(selectedOutbound, outboundParty.total).toLocaleString("en-IN")}</Text>
                </View>
              ) : (
                <Text style={styles.muted}>No outbound transport selected.</Text>
              )}
              {selectedReturn ? (
                <View>
                  <Text style={styles.body}>Return: {selectedReturn.name}</Text>
                  <Text style={styles.muted}>{returnDate}{selectedReturnSeats.length ? ` · Seats ${selectedReturnSeats.join(", ")}` : ""} · {returnParty.total} of {partyTotal} traveler(s) on this service</Text>
                  <Text style={styles.price}>NPR {transportLegPrice(selectedReturn, returnParty.total).toLocaleString("en-IN")}</Text>
                </View>
              ) : (
                <Text style={styles.muted}>No return transport selected.</Text>
              )}
              {selectedLocal ? (
                <View>
                  <Text style={styles.body}>Local: {selectedLocal.name}</Text>
                  <Text style={styles.muted}>{localDate} · {localParty.total} of {partyTotal} traveler(s) on this service</Text>
                  <Text style={styles.price}>NPR {transportLegPrice(selectedLocal, localParty.total).toLocaleString("en-IN")}</Text>
                </View>
              ) : null}
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Restaurants</Text>
              {selectedRestaurant ? (
                <View>
                  <Text style={styles.body}>{selectedRestaurant.name}</Text>
                  <Text style={styles.muted}>
                    {restaurantDate} · {(Number(adults) || 1) + (Number(children) || 0)} guest(s)
                    {selectedRestaurant.cuisine?.length ? ` · ${selectedRestaurant.cuisine.slice(0, 3).join(", ")}` : ""}
                  </Text>
                  <Text style={styles.price}>Pay at venue · NPR 0 in trip total</Text>
                </View>
              ) : (
                <Text style={styles.muted}>No restaurant selected.</Text>
              )}
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Activities</Text>
              {selectedActivity ? (
                <View>
                  <RelevantImage
                    entity={{ name: selectedActivity.name, type: "activity", location: selectedActivity.location, image: selectedActivity.image, images: selectedActivity.images, imageSource: selectedActivity.imageSource, imageSourcePage: selectedActivity.imageSourcePage, imageLicense: selectedActivity.imageLicense, imageCredit: selectedActivity.imageCredit, imageDescription: selectedActivity.imageDescription, imageRelevance: selectedActivity.imageRelevance }}
                    style={styles.thumb}
                  />
                  <Text style={styles.body}>{selectedActivity.name}</Text>
                  <Text style={styles.muted}>{activityDate}{selectedSlot ? ` @ ${selectedSlot}` : ""} · {participants} participant(s)</Text>
                  {selectedActivity.slots && selectedActivity.slots.length > 0 && !selectedSlot ? (
                    <Text style={styles.error}>Scheduled slots ({selectedActivity.slots.join(", ")}) — pick one on the Activities step or checkout will be rejected.</Text>
                  ) : null}
                  <Text style={styles.price}>
                    NPR {Math.round((Number(selectedActivity.price) || 0) * (Number(participants) || (Number(adults) || 1) + (Number(children) || 0))).toLocaleString("en-IN")}
                  </Text>
                </View>
              ) : (
                <Text style={styles.muted}>No activity selected.</Text>
              )}
              {plannedItems.length > 0 ? <Text style={styles.body}>Free stops in plan: {plannedItems.length}</Text> : null}
              {selectedGemIds.length > 0 ? <Text style={styles.body}>Hidden gems in plan: {selectedGemIds.length}</Text> : null}
            </View>

            <View style={styles.card}>
              <Text style={styles.cardTitle}>Price summary</Text>
              <Text style={styles.body}>Hotel: NPR {estimate.hotel.toLocaleString("en-IN")}</Text>
              <Text style={styles.body}>Transportation: NPR {estimate.transportation.toLocaleString("en-IN")}</Text>
              <Text style={styles.body}>Activities: NPR {estimate.activities.toLocaleString("en-IN")}</Text>
              <Text style={styles.body}>Other services: NPR {estimate.other.toLocaleString("en-IN")}</Text>
              <Text style={styles.body}>Service charges & taxes: NPR 0 (demo — none applied)</Text>
              <Text style={styles.price}>Grand Total: NPR {estimate.total.toLocaleString("en-IN")}</Text>
              <Text style={styles.muted}>Live estimate from your selection — it becomes the submitted trip total.</Text>
            </View>

            {!!bookingError && <Text style={styles.error}>{bookingError}</Text>}
            {!!bookingNotice && <Text style={styles.notice}>{bookingNotice}</Text>}
            {cartIntents.length === 0 ? <Text style={styles.muted}>Nothing bookable selected yet. Go back and add transport, a hotel room, a restaurant, an activity, or local transport.</Text> : null}
            <Pressable
              style={[styles.primaryBtn, (!cartIntents.length || tripLocked) && styles.disabledBtn]}
              disabled={!cartIntents.length || tripLocked}
              onPress={() => goTo("complete")}
            >
              <Text style={styles.primaryBtnText}>
                {tripLocked ? "Submitted ✓ — continue" : `Continue to Complete Trip (${cartIntents.length})`}
              </Text>
            </Pressable>
          </View>
        );
      case "complete":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Complete Trip</Text>
              <Text style={styles.muted}>
                This validates everything and submits the trip for admin confirmation.
                Nothing is charged here — after the admin confirms, you pay in My Bookings.
              </Text>
              <Text style={styles.body}>Destination: {destination || "—"} {isDestinationLocked ? "✓" : "✗"}</Text>
              <Text style={styles.body}>Origin: {origin || "—"} {isOriginLocked ? "✓" : "✗"}</Text>
              <Text style={styles.body}>Dates: {startDate || "—"} → {returnDate || endDate || "—"}</Text>
              <Text style={styles.body}>Travellers: {(Number(adults) || 1) + (Number(children) || 0)}</Text>
              <Text style={styles.body}>Bookable services: {cartIntents.length}</Text>
              <Text style={styles.price}>Total: NPR {estimate.total.toLocaleString("en-IN")}</Text>
              {tripLocked ? <Text style={styles.notice}>Submitted ✓ — selections are locked.</Text> : null}
            </View>
            {!!bookingError && <Text style={styles.error}>{bookingError}</Text>}
            {!!bookingNotice && <Text style={styles.notice}>{bookingNotice}</Text>}
            {submittedBooking ? (
              <View style={styles.card}>
                <Text style={styles.cardTitle}>Booking submitted</Text>
                <Text style={styles.body}>· {submittedBooking.bookingCode} — {submittedBooking.itemName}</Text>
                <Text style={styles.muted}>Status: Pending Admin Confirmation</Text>
                <Pressable style={styles.primaryBtn} onPress={() => goTo("confirmation")}>
                  <Text style={styles.primaryBtnText}>Continue →</Text>
                </Pressable>
              </View>
            ) : null}
            <Pressable
              style={[styles.primaryBtn, (creating || !cartIntents.length || tripLocked) && styles.disabledBtn]}
              disabled={creating || !cartIntents.length || tripLocked}
              onPress={() => void submitTripForApproval()}
            >
              {creating ? <ActivityIndicator color={colors.white} /> : <Text style={styles.primaryBtnText}>SUBMIT FOR APPROVAL</Text>}
            </Pressable>
          </View>
        );
      case "confirmation":
        return (
          <View>
            {submittedBooking ? (
              <View style={styles.card}>
                <View style={styles.successBox}>
                  <Text style={styles.successTitle}>Booking Submitted ✓</Text>
                  <Text style={styles.body}>Trip: {destination ? `${destination} Trip` : "Complete Trip"}</Text>
                  <Text style={styles.body}>Booking reference: {submittedBooking.bookingCode}</Text>
                  <Text style={styles.body}>Total: {submittedBooking.currency ?? "NPR"} {Number(submittedBooking.amount).toLocaleString("en-IN")}</Text>
                  <Text style={styles.price}>STATUS: Pending Admin Confirmation</Text>
                  <Text style={styles.muted}>Nothing is charged yet. After the admin confirms, pay in My Bookings.</Text>
                </View>
              </View>
            ) : (
              <View style={styles.card}><Text style={styles.muted}>No submitted booking yet — complete the trip first.</Text></View>
            )}
            <View style={styles.card}>
              <Text style={styles.cardTitle}>{destination ? `${destination} Trip` : "Complete Trip"} ✓</Text>
              <Text style={styles.body}>Customer: {user?.name ?? "—"} ({user?.email ?? "—"})</Text>
              <Text style={styles.body}>Route: {origin || "—"} → {destination || "—"}</Text>
              <Text style={styles.body}>When: {startDate || "—"}{endDate ? ` → ${endDate}` : ""}</Text>
              <Text style={styles.body}>Travellers: {(Number(adults) || 1) + (Number(children) || 0)} ({adults} adult(s), {children} child(ren))</Text>
              <View style={styles.btnRow}>
                <Pressable style={styles.ghostBtn} onPress={() => openMap(destination, destination)}><Text style={styles.ghostBtnText}>Map link</Text></Pressable>
                <Pressable style={styles.ghostBtn} onPress={() => openExternalDirections([destination].filter(Boolean).join(", "))}><Text style={styles.ghostBtnText}>Directions</Text></Pressable>
              </View>
            </View>
            <Pressable style={styles.secondaryBtn} onPress={() => navigation.navigate("Bookings")}><Text style={styles.secondaryBtnText}>Manage in My Bookings</Text></Pressable>
            <Pressable style={styles.primaryBtn} onPress={next}>
              <Text style={styles.primaryBtnText}>Continue →</Text>
            </Pressable>
          </View>
        );
      case "return":
        return (
          <View>
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Return journey</Text>
              <Text style={styles.muted}>Services leaving {destination || "the destination"}{origin ? ` toward ${origin}` : ""}. Select one — it is saved with the trip submission, with no separate charge.</Text>
              <BSADDatePicker
                label="Return date"
                value={returnDate}
                onChange={setReturnDate}
                minDate={startDate}
                minExclusive
                error={isStrictAdISO(returnDate) && returnDate <= startDate ? "Return date must be after the departure date." : undefined}
              />
              <View style={styles.btnRow}>
                <Pressable onPress={() => void fetchReturn()}><Text style={styles.link}>Reload</Text></Pressable>
              </View>
            </View>
            {returnLoading ? <ActivityIndicator color={colors.primary} /> : null}
            {!returnLoading && returnOptions.length === 0 ? <View style={styles.card}><Text style={styles.muted}>No return services listed. Use Maps directions for the return leg.</Text></View> : null}
            {returnOptions.slice(0, 15).map((t) => {
              const active = t._id === selectedReturnId;
              return (
                <View key={t._id} style={[styles.card, active && styles.cardActive]}>
                  <Text style={styles.cardTitle}>{t.name}</Text>
                  <Text style={styles.muted}>{[t.origin, t.destination].filter(Boolean).join(" → ")}</Text>
                  {t.price !== undefined ? <Text style={styles.price}>NPR {t.price}</Text> : null}
                  {!transportFareOk(t, (Number(adults) || 1) + (Number(children) || 0)) ? (
                    <Text style={styles.error}>Fare not confirmed — this service cannot be booked yet.</Text>
                  ) : null}
                  {active ? (
                    <View style={styles.qrBox}>
                      <Text style={styles.roomName}>Seats for {returnDate}</Text>
                      {returnSeatsLoading ? <ActivityIndicator color={colors.primary} /> : null}
                      {!returnSeatsLoading && !returnSeats ? <Text style={styles.muted}>Seat map unavailable — booking for passenger count only.</Text> : null}
                      {returnSeats && returnSeats.seatSelection === false ? (
                        <Text style={styles.muted}>Whole-vehicle service: no per-seat selection.</Text>
                      ) : null}
                      {returnSeats?.seats?.length ? (
                        <View style={styles.chipWrap}>
                          {returnSeats.seats.map((s) => {
                            const chosen = selectedReturnSeats.includes(s.label);
                            return (
                              <Pressable
                                key={s.label}
                                disabled={s.booked}
                                onPress={() => setSelectedReturnSeats((cur) => (cur.includes(s.label) ? cur.filter((x) => x !== s.label) : [...cur, s.label]))}
                                style={[styles.chip, s.booked && styles.chipDisabled, chosen && styles.chipActive]}
                              >
                                <Text style={[styles.chipText, chosen && styles.chipTextActive]}>{s.label}{s.booked ? " (Booked)" : ""}</Text>
                              </Pressable>
                            );
                          })}
                        </View>
                      ) : null}
                      <Text style={styles.label}>Passengers on this service</Text>
                      <View style={styles.threeCol}>
                        <View style={styles.col}><Text style={styles.label}>Adults</Text><TextInput value={returnAdults} onChangeText={setReturnAdults} placeholder={String(partyAdults)} placeholderTextColor={colors.textMuted} keyboardType="number-pad" maxLength={3} style={styles.input} /></View>
                        <View style={styles.col}><Text style={styles.label}>Children</Text><TextInput value={returnChildren} onChangeText={setReturnChildren} placeholder={String(partyChildren)} placeholderTextColor={colors.textMuted} keyboardType="number-pad" maxLength={3} style={styles.input} /></View>
                      </View>
                      <Text style={styles.muted}>{returnParty.total} of {partyTotal} traveler(s) on this service · rest by own vehicle or unassigned.</Text>
                    </View>
                  ) : null}
                  <Pressable style={[styles.secondaryBtn, active && styles.primaryBtn]} disabled={tripLocked || !transportFareOk(t, (Number(adults) || 1) + (Number(children) || 0))} onPress={() => { setSelectedReturnId(active ? "" : t._id); setSelectedReturnSeats([]); }}>
                    <Text style={[styles.secondaryBtnText, active && styles.primaryBtnText]}>{active ? "Selected ✓" : "Select return"}</Text>
                  </Pressable>
                </View>
              );
            })}
            {!!bookingError && <Text style={styles.error}>{bookingError}</Text>}
            {!!bookingNotice && <Text style={styles.notice}>{bookingNotice}</Text>}
            <View style={styles.card}>
              <Text style={styles.muted}>Return travel is saved with the trip submission — there is no separate return charge. Continue to Review to see it in the total.</Text>
            </View>
            <View style={styles.btnRow}>
              <Pressable style={styles.primaryBtn} onPress={() => goTo("review")}>
                <Text style={styles.primaryBtnText}>Review Complete Trip</Text>
              </Pressable>
            </View>
          </View>
        );
      case "done":
        return (
          <View style={styles.card}>
            <Ionicons name="checkmark-circle" size={44} color={colors.primary} />
            <Text style={styles.cardTitle}>
              {submittedBooking ? "Trip submitted" : "Almost ready — one step left"}
            </Text>
            <Text style={styles.body}>{origin || "Origin"} → {destination || "destination"} → {origin || "origin"} · {startDate} → {returnDate || endDate}</Text>
            {submittedBooking ? (
              <Text style={styles.body}>Booking: {submittedBooking.bookingCode} · Total: {submittedBooking.currency ?? "NPR"} {Number(submittedBooking.amount).toLocaleString("en-IN")}</Text>
            ) : null}
            <Text style={styles.price}>STATUS: Pending Admin Confirmation</Text>
            {!!bookingNotice && <Text style={styles.notice}>{bookingNotice}</Text>}
            <Text style={styles.muted}>Track this trip in My Bookings. Payment unlocks after the admin confirms it.</Text>
            <Pressable style={styles.primaryBtn} onPress={() => navigation.navigate("Bookings")}>
              <Text style={styles.primaryBtnText}>Go to Bookings</Text>
            </Pressable>
            <Pressable style={styles.secondaryBtn} onPress={() => navigation.navigate("MainTabs", { screen: "Trips" } as never)}>
              <Text style={styles.secondaryBtnText}>Go to Trips tab</Text>
            </Pressable>
          </View>
        );
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        stickyHeaderIndices={[0]}
      >
        <View style={styles.stickyStepper}>
          <View style={styles.header}>
            <BackButton navigation={navigation} />
            <View style={styles.headerText}>
              <Text style={styles.eyebrow}>DESTINATION TRIP{destination ? ` · ${destination.toUpperCase()}` : ""}</Text>
              <Text style={styles.title}>{STEPS[stepIndex].title}</Text>
              <Text style={styles.stepCount}>Step {stepIndex + 1} of {STEPS.length} · {STEPS[stepIndex].subtitle}</Text>
            </View>
            <View style={styles.headerSpacer} />
          </View>
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${((stepIndex + 1) / STEPS.length) * 100}%` }]} />
          </View>
          <ScrollView ref={stepBarRef} horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.stepBar}>
            {STEPS.map((s, i) => (
              <Pressable key={s.key} onPress={() => setStepIndex(i)} style={[styles.stepDot, i === stepIndex && styles.stepDotActive, i < stepIndex && styles.stepDotDone]}>
                <Text style={[styles.stepDotText, i === stepIndex && styles.stepDotTextActive]}>{i + 1}</Text>
              </Pressable>
            ))}
          </ScrollView>
          {!!loadError && <Text style={styles.error}>{loadError}</Text>}
        </View>
        {renderBody()}
        <View style={styles.navRow}>
          <Pressable style={[styles.navBtn, stepIndex === 0 && styles.disabledBtn]} disabled={stepIndex === 0} onPress={prev}>
            <Text style={styles.navBtnText}>← Back</Text>
          </Pressable>
          <Pressable style={styles.navBtn} onPress={() => goTo("review")}>
            <Text style={styles.navBtnText}>Review</Text>
          </Pressable>
          {stepIndex < STEPS.length - 1 ? (
            <Pressable style={[styles.navBtn, styles.navNext]} onPress={next}>
              <Text style={[styles.navBtnText, styles.navNextText]}>Next →</Text>
            </Pressable>
          ) : null}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  // Pinned stepper (stickyHeaderIndices={[0]}): stays at the top on every
  // step while content scrolls underneath. Full-bleed to cancel the content
  // padding so inner insets match the previous outside-scroll layout exactly.
  // Opaque background + stacking so cards/images/dropdowns never paint over it.
  stickyStepper: {
    marginHorizontal: -spacing.md,
    backgroundColor: colors.background,
    zIndex: 20,
    elevation: 8,
  },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  headerText: { flex: 1 },
  headerSpacer: { width: 32 },
  eyebrow: { color: colors.primary, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  title: { color: colors.text, fontSize: 22, fontWeight: "900" },
  stepCount: { color: colors.textMuted, fontSize: 11, marginTop: 2 },
  progressTrack: { height: 6, backgroundColor: colors.border, borderRadius: 3, marginHorizontal: spacing.md, marginTop: spacing.sm },
  progressFill: { height: 6, backgroundColor: colors.primary, borderRadius: 3 },
  stepBar: { gap: 6, paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  stepDot: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center" },
  stepDotActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  stepDotDone: { borderColor: colors.primary },
  stepDotText: { color: colors.textMuted, fontSize: 11, fontWeight: "800" },
  stepDotTextActive: { color: colors.white },
  content: { padding: spacing.md, paddingBottom: 120, gap: spacing.sm },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.sm, gap: 6 },
  cardActive: { borderColor: colors.primary, backgroundColor: "#E8F3F0" },
  cardTitle: { color: colors.text, fontSize: 15, fontWeight: "800" },
  sectionTitle: { color: colors.text, fontSize: 15, fontWeight: "800", flex: 1 },
  body: { color: colors.text, fontSize: 12, lineHeight: 18 },
  muted: { color: colors.textMuted, fontSize: 11, lineHeight: 16 },
  price: { color: colors.primaryDark, fontSize: 13, fontWeight: "900" },
  label: { color: colors.textMuted, fontSize: 11, fontWeight: "700", marginTop: spacing.sm },
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, backgroundColor: colors.background, minHeight: 42, paddingHorizontal: spacing.sm, color: colors.text, fontSize: 13, marginTop: 4 },
  searchRow: { flexDirection: "row", gap: spacing.sm, alignItems: "center" },
  twoCol: { flexDirection: "row", gap: spacing.sm },
  threeCol: { flexDirection: "row", gap: spacing.sm },
  col: { flex: 1 },
  rowBetween: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginBottom: spacing.sm },
  link: { color: colors.primary, fontWeight: "700", fontSize: 12 },
  btnRow: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.sm, flexWrap: "wrap" },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: radius.sm, minHeight: 44, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md, marginTop: spacing.sm },
  primaryBtnText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  secondaryBtn: { borderWidth: 1, borderColor: colors.primary, borderRadius: radius.sm, minHeight: 40, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md, marginTop: spacing.sm, flex: 1 },
  secondaryBtnText: { color: colors.primaryDark, fontSize: 12, fontWeight: "800" },
  ghostBtn: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, minHeight: 40, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md, marginTop: spacing.sm },
  ghostBtnText: { color: colors.textMuted, fontSize: 12, fontWeight: "700" },
  disabledBtn: { opacity: 0.5 },
  roomRow: { gap: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm, marginTop: spacing.sm },
  roomMain: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  selectRoomBtn: { minHeight: 40, alignItems: "center", justifyContent: "center", borderRadius: radius.sm, borderWidth: 1, borderColor: colors.primary, backgroundColor: colors.surface },
  selectRoomBtnChosen: { backgroundColor: colors.primary, borderColor: colors.primary },
  selectRoomBtnText: { color: colors.primaryDark, fontSize: 12, fontWeight: "800" },
  selectRoomBtnTextChosen: { color: colors.white },
  roomDisabled: { opacity: 0.55 },
  roomInfo: { flex: 1, gap: 2 },
  roomName: { color: colors.text, fontSize: 13, fontWeight: "800" },
  soldOut: { color: "#B42318", fontSize: 11, fontWeight: "900" },
  inStock: { color: colors.primaryDark, fontSize: 11, fontWeight: "900" },
  chipWrap: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: spacing.sm },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: 16, paddingHorizontal: 10, paddingVertical: 6 },
  chipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipDisabled: { opacity: 0.45 },
  chipText: { color: colors.text, fontSize: 11 },
  chipTextActive: { color: colors.white, fontWeight: "700" },
  qrBox: { backgroundColor: "#F8FAFC", borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, padding: spacing.sm, marginTop: spacing.sm },
  qrFrame: { backgroundColor: "#FFFFFF", borderRadius: radius.sm, padding: spacing.md, borderWidth: 1, borderColor: colors.border },
  successBox: { backgroundColor: "#EAF8F2", borderWidth: 1, borderColor: "#047857", borderRadius: radius.sm, padding: spacing.md, marginTop: spacing.sm, gap: 4 },
  successTitle: { color: "#047857", fontSize: 16, fontWeight: "900" },
  qrPayload: { color: colors.text, fontSize: 11, fontWeight: "700", marginBottom: 4 },
  error: { color: "#B42318", fontSize: 12, lineHeight: 17, marginVertical: spacing.sm, paddingHorizontal: spacing.md },
  notice: { color: "#065F46", fontSize: 12, lineHeight: 17, marginTop: spacing.sm },
  navRow: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.md },
  navBtn: { flex: 1, minHeight: 44, alignItems: "center", justifyContent: "center", borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  navBtnText: { color: colors.text, fontSize: 12, fontWeight: "800" },
  navNext: { backgroundColor: colors.text },
  navNextText: { color: colors.white },
  thumb: { height: 120, borderRadius: radius.sm },
  bannerImage: { height: 150, borderRadius: radius.sm },
});
