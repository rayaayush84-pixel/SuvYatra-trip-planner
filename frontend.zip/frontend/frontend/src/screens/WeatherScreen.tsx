import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "Weather">;

export default function WeatherScreen({ navigation }: Props) {
  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <BackButton navigation={navigation} iconSize={24} />
          <Text style={styles.title}>Weather</Text>
          <View style={styles.headerSpacer} />
        </View>

        <View style={styles.weatherCard}>
          <View style={styles.iconWrap}>
            <Ionicons name="partly-sunny-outline" size={34} color={colors.primary} />
          </View>
          <Text style={styles.cardTitle}>Live weather is unavailable</Text>
          <Text style={styles.body}>
            SuvYatra does not currently have a configured OpenWeather integration or weather API endpoint. No current conditions or forecast can be shown until a live data source is connected.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: spacing.xl },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.xl },
  title: { color: colors.text, fontSize: 20, fontWeight: "800" },
  headerSpacer: { width: 24 },
  weatherCard: { alignItems: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, padding: spacing.xl, marginTop: spacing.xl },
  iconWrap: { width: 64, height: 64, borderRadius: 32, backgroundColor: "#E8F3F0", alignItems: "center", justifyContent: "center" },
  cardTitle: { color: colors.text, fontSize: 17, fontWeight: "800", marginTop: spacing.md, textAlign: "center" },
  body: { color: colors.textMuted, fontSize: 13, lineHeight: 20, textAlign: "center", marginTop: spacing.sm },
});
