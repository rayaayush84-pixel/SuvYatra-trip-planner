import React, { useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";

type Props = NativeStackScreenProps<RootStackParamList, "TermsAndConditions">;

const termsSections = [
  {
    title: "Plan your Nepal trip",
    body: "SuvYatra helps you discover destinations, stays, restaurants, activities, and transport, then organize the details of your journey.",
  },
  {
    title: "Check details before you book",
    body: "Prices, availability, routes, and travel information can change. Confirm important details with the service provider before booking or traveling.",
  },
  {
    title: "Use your account responsibly",
    body: "Provide accurate account information, keep your password private, and use SuvYatra lawfully and respectfully.",
  },
  {
    title: "Your information",
    body: "Account information is used to sign you in and provide app features such as profile, saved places, and bookings. Do not share passwords or sensitive payment details in chat or reviews.",
  },
];

export default function TermsAndConditionsScreen({ navigation }: Props) {
  const { acceptTerms } = useAuth();
  const [agreed, setAgreed] = useState(false);
  const [saving, setSaving] = useState(false);

  const continueToLogin = async () => {
    if (!agreed || saving) {
      return;
    }

    setSaving(true);
    await acceptTerms();
    navigation.replace("Login", { provider: "Email" });
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "bottom"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} style={styles.backButton} iconColor="#17324D" iconSize={22} />
        <Text style={styles.headerLabel}>SUVYATRA</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.eyebrow}>BEFORE YOU CONTINUE</Text>
        <Text style={styles.title}>Terms & Conditions</Text>
        <Text style={styles.description}>
          SuvYatra is your Nepal trip planner. Discover places, compare travel options, and keep your plans together in one place.
        </Text>

        <View style={styles.sectionList}>
          {termsSections.map((section, index) => (
            <View
              key={section.title}
              style={[styles.section, index === termsSections.length - 1 && styles.lastSection]}
            >
              <Text style={styles.sectionTitle}>{section.title}</Text>
              <Text style={styles.sectionBody}>{section.body}</Text>
            </View>
          ))}
        </View>

        <Pressable
          style={styles.agreementRow}
          onPress={() => setAgreed((value) => !value)}
          accessibilityRole="checkbox"
          accessibilityState={{ checked: agreed }}
        >
          <View style={[styles.checkbox, agreed && styles.checkboxChecked]}>
            {agreed && <Ionicons name="checkmark" size={16} color="#FFFFFF" />}
          </View>
          <Text style={styles.agreementText}>
            I have read and agree to the Terms & Conditions.
          </Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.continueButton,
            !agreed && styles.continueButtonDisabled,
            pressed && agreed && styles.continueButtonPressed,
          ]}
          onPress={continueToLogin}
          disabled={!agreed || saving}
          accessibilityRole="button"
          accessibilityState={{ disabled: !agreed || saving }}
        >
          <Text style={styles.continueButtonText}>Accept & Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F8FA",
  },
  header: {
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: "flex-start",
    justifyContent: "center",
  },
  headerLabel: {
    color: "#0F766E",
    fontSize: 11,
    fontWeight: "800",
  },
  headerSpacer: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    width: "100%",
    maxWidth: 680,
    alignSelf: "center",
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 36,
  },
  eyebrow: {
    color: "#0F766E",
    fontSize: 11,
    fontWeight: "800",
    marginBottom: 8,
  },
  title: {
    color: "#17324D",
    fontSize: 30,
    lineHeight: 36,
    fontWeight: "800",
  },
  description: {
    color: "#53677B",
    fontSize: 15,
    lineHeight: 23,
    marginTop: 10,
    marginBottom: 24,
  },
  sectionList: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E0E8EE",
    borderRadius: 12,
    paddingHorizontal: 18,
  },
  section: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#E7EDF1",
  },
  lastSection: {
    borderBottomWidth: 0,
  },
  sectionTitle: {
    color: "#17324D",
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "700",
  },
  sectionBody: {
    color: "#5C6F82",
    fontSize: 13,
    lineHeight: 20,
    marginTop: 5,
  },
  agreementRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 20,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderWidth: 1.5,
    borderColor: "#8FA1B1",
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },
  checkboxChecked: {
    backgroundColor: "#0F9F94",
    borderColor: "#0F9F94",
  },
  agreementText: {
    flex: 1,
    color: "#344A5E",
    fontSize: 13,
    lineHeight: 19,
  },
  continueButton: {
    minHeight: 52,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    borderRadius: 10,
    backgroundColor: "#0F9F94",
  },
  continueButtonDisabled: {
    backgroundColor: "#9BCAC6",
  },
  continueButtonPressed: {
    opacity: 0.82,
  },
  continueButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "800",
  },
});