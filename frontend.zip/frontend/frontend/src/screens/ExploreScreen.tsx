import React, { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { DestinationDetails, HiddenGemDetails, RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import RelevantImage from "../components/RelevantImage";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { DEFAULT_HIDDEN_GEMS } from "../data/hiddenGems";
import { colors, radius, spacing } from "../theme";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

type SavedItem = { _id: string; itemType: string; itemId?: string; name: string };

type DestinationRecord = {
  _id: string;
  name: string;
  province?: string;
  country?: string;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  highlights?: string[];
  tags?: string[];
  bestTimeToVisit?: string;
  approximateCost?: string;
  whyVisit?: string;
  latitude?: number;
  longitude?: number;
};

type DiscoverableDestination = {
  details: DestinationDetails;
  province?: string;
};

type Experience = {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  keywords: string[];
};

const EXPERIENCES: Experience[] = [
  { label: "Adventure", icon: "rocket-outline", keywords: ["adventure", "rafting", "paragliding", "bungee", "safari", "jungle", "climb", "raft", "zipline", "canyoning"] },
  { label: "Nature", icon: "leaf-outline", keywords: ["nature", "lake", "forest", "waterfall", "valley", "wildlife", "national park", "river"] },
  { label: "Culture & Heritage", icon: "library-outline", keywords: ["culture", "heritage", "temple", "durbar", "unesco", "monastery", "palace", "history", "historic", "shrine"] },
  { label: "Mountains", icon: "snow-outline", keywords: ["mountain", "himalaya", "himalayan", "annapurna", "everest", "peak", "base camp", "range"] },
  { label: "Relaxation", icon: "sunny-outline", keywords: ["relax", "peaceful", "tranquil", "serene", "retreat", "spa", "boating", "lakeside"] },
  { label: "Trekking", icon: "trail-sign-outline", keywords: ["trek", "trekking", "trail", "hiking", "base camp", "annapurna", "everest", "langtang", "manaslu"] },
  { label: "Religious", icon: "moon-outline", keywords: ["temple", "monastery", "pagoda", "buddha", "shiva", "pilgrim", "religious", "sacred", "stupa", "lumbini", "pashupati", "muktinath"] },
  { label: "Food & Local Life", icon: "restaurant-outline", keywords: ["food", "cuisine", "restaurant", "market", "thamel", "local", "village", "dining", "cafe", "cuisine", "handicraft"] },
];

function normalized(value: string | undefined): string {
  return value?.trim().toLocaleLowerCase() ?? "";
}

function toDiscoverable(record: DestinationRecord): DiscoverableDestination {
  return {
    province: record.province,
    details: {
      id: record._id,
      name: record.name,
      location: [record.province, record.country].filter(Boolean).join(", ") || "Location not listed",
      rating: "",
      reviews: "",
      description: record.description || "Destination information is not available yet.",
      bestTime: record.bestTimeToVisit || "Not specified",
      price: record.approximateCost || "Not listed",
      image: record.image || "",
      images: record.images,
      imageSource: record.imageSource,
      imageSourcePage: record.imageSourcePage,
      imageLicense: record.imageLicense,
      imageCredit: record.imageCredit,
      imageDescription: record.imageDescription,
      imageRelevance: record.imageRelevance,
      hiddenGems: record.highlights || [],
      thingsToDo: record.highlights || [],
      categories: ["Book Hotel", "Book Jeep", "Book Bike", "Book Bus", "Book Activities"],
      latitude: record.latitude,
      longitude: record.longitude,
    },
  };
}

function destinationSearchText(item: DiscoverableDestination, tags: string[]): string {
  return [
    item.details.name,
    item.details.location,
    item.province,
    item.details.description,
    ...(item.details.thingsToDo ?? []),
    ...tags,
  ]
    .filter(Boolean)
    .join(" ")
    .toLocaleLowerCase();
}

export default function ExploreScreen() {
  const navigation = useNavigation<NavigationProp>();
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const [destinations, setDestinations] = useState<DiscoverableDestination[]>([]);
  const [destinationsLoading, setDestinationsLoading] = useState(true);
  const [destinationsError, setDestinationsError] = useState("");
  const [destinationTags, setDestinationTags] = useState<Record<string, string[]>>({});
  const [gems, setGems] = useState<HiddenGemDetails[]>(DEFAULT_HIDDEN_GEMS);
  const [gemsLoading, setGemsLoading] = useState(true);
  const [selectedProvince, setSelectedProvince] = useState("");
  const [selectedExperience, setSelectedExperience] = useState("");
  const [savedMap, setSavedMap] = useState<Record<string, SavedItem>>({});
  const [savingId, setSavingId] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };

  const savedKeyFor = (details: DestinationDetails) =>
    details.id != null ? String(details.id) : `name:${details.name.trim().toLocaleLowerCase()}`;

  useFocusEffect(
    useCallback(() => {
      let active = true;
      setDestinationsLoading(true);
      setDestinationsError("");
      backendRequest<DestinationRecord[]>("/destinations?featured=popular")
        .then((records) => {
          if (!active) return;
          setDestinations(records.map(toDiscoverable));
          const tags: Record<string, string[]> = {};
          for (const record of records) {
            tags[record._id] = record.tags ?? [];
          }
          setDestinationTags(tags);
        })
        .catch((error: unknown) => {
          if (active) {
            setDestinationsError(error instanceof Error ? error.message : "Could not load destinations.");
          }
        })
        .finally(() => {
          if (active) setDestinationsLoading(false);
        });
      return () => {
        active = false;
      };
    }, [])
  );

  useFocusEffect(
    useCallback(() => {
      let active = true;
      setGemsLoading(true);
      backendRequest<DestinationRecord[]>("/destinations?featured=hidden")
        .then((records) => {
          if (!active) return;
          const unique = new Map<string, HiddenGemDetails>();
          for (const gem of DEFAULT_HIDDEN_GEMS) {
            unique.set(normalized(gem.name), gem);
          }
          for (const record of records) {
            const key = normalized(record.name);
            if (unique.has(key)) continue;
            unique.set(key, {
              id: record._id,
              name: record.name,
              location: [record.province, record.country].filter(Boolean).join(", ") || undefined,
              province: record.province,
              description: record.description,
              whyHiddenGem: record.description,
              thingsToDo: record.highlights || [],
              tags: (record.tags || []).filter((tag) => normalized(tag) !== "hidden"),
              image: record.image,
              images: record.images,
              imageSource: record.imageSource,
              imageSourcePage: record.imageSourcePage,
              imageLicense: record.imageLicense,
              imageCredit: record.imageCredit,
              imageDescription: record.imageDescription,
              imageRelevance: record.imageRelevance,
            });
          }
          setGems(Array.from(unique.values()).slice(0, 4));
        })
        .catch(() => {
          if (active) setGems(DEFAULT_HIDDEN_GEMS.slice(0, 4));
        })
        .finally(() => {
          if (active) setGemsLoading(false);
        });
      return () => {
        active = false;
      };
    }, [])
  );

  const provinces = useMemo(
    () =>
      Array.from(
        new Set(
          destinations
            .map((item) => item.province?.trim())
            .filter((value): value is string => Boolean(value))
        )
      ),
    [destinations]
  );

  const visibleDestinations = useMemo(() => {
    const experience = EXPERIENCES.find((item) => item.label === selectedExperience);
    return destinations.filter((item) => {
      if (selectedProvince && item.province?.trim() !== selectedProvince) return false;
      if (!experience) return true;
      const haystack = destinationSearchText(item, destinationTags[item.details.id ?? ""] ?? []);
      return experience.keywords.some((keyword) => haystack.includes(keyword));
    });
  }, [destinationTags, destinations, selectedExperience, selectedProvince]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId) {
        if (!token) setSavedMap({});
        return;
      }
      const controller = new AbortController();
      backendRequest<SavedItem[]>(`/saved-items?userId=${encodeURIComponent(userId)}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((items) => {
          if (!controller.signal.aborted) {
            const map: Record<string, SavedItem> = {};
            for (const item of items) {
              if (item.itemType !== "destination") continue;
              map[item.itemId ?? `name:${item.name.trim().toLocaleLowerCase()}`] = item;
            }
            setSavedMap(map);
          }
        })
        .catch(() => {});
      return () => controller.abort();
    }, [getAccessToken, userId])
  );

  const toggleSavedDestination = async (details: DestinationDetails) => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", { notice: "Sign in to save destinations to Saved Places." });
      return;
    }
    const key = savedKeyFor(details);
    setSavingId(key);
    try {
      const existing = savedMap[key];
      if (existing) {
        await backendRequest(`/saved-items/${existing._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedMap((current) => {
          const next = { ...current };
          delete next[key];
          return next;
        });
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            userId,
            itemType: "destination",
            itemId: details.id,
            name: details.name,
            location: details.location,
            image: details.image,
            imageSource: details.imageSource,
            imageSourcePage: details.imageSourcePage,
            imageLicense: details.imageLicense,
            imageCredit: details.imageCredit,
            imageDescription: details.imageDescription,
            imageRelevance: details.imageRelevance,
          }),
        });
        setSavedMap((current) => ({ ...current, [key]: saved }));
        showToast("Saved to your places");
      }
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSavingId("");
    }
  };

  const openDestination = (details: DestinationDetails) =>
    navigation.push("Destination", { destination: details });

  const planTrip = (name: string) =>
    navigation.push("DestinationTrip", { destination: name });

  const openGem = (gem: HiddenGemDetails) =>
    navigation.push("HiddenGemDetail", { gem });

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topBar}>
          <BackButton navigation={navigation} />
          <View style={styles.topBarSpacer} />
        </View>

        <View style={styles.hero}>
          <Image
            source={require("../../../assets/1.jpeg")}
            style={StyleSheet.absoluteFill}
            resizeMode="cover"
            accessibilityLabel="Himalayan mountain valley in Nepal"
          />
          <View style={styles.heroOverlay}>
            <Text style={styles.heroEyebrow}>DISCOVER NEPAL</Text>
            <Text style={styles.heroTitle}>Explore Nepal</Text>
            <Text style={styles.heroSubtitle}>
              Discover destinations, experiences, culture and hidden places across Nepal.
            </Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Explore by Experience</Text>
        </View>
        <Text style={styles.sectionHint}>
          Pick an experience to filter destinations using their tags, highlights and descriptions.
        </Text>
        <View style={styles.experienceGrid}>
          {EXPERIENCES.map((experience) => {
            const active = selectedExperience === experience.label;
            return (
              <Pressable
                key={experience.label}
                onPress={() => setSelectedExperience(active ? "" : experience.label)}
                style={[styles.experienceCard, active && styles.experienceCardActive]}
                accessibilityRole="button"
                accessibilityState={{ selected: active }}
                accessibilityLabel={`Filter by ${experience.label}`}
              >
                <View style={[styles.experienceIcon, active && styles.experienceIconActive]}>
                  <Ionicons
                    name={experience.icon}
                    size={22}
                    color={active ? colors.white : "#0F766E"}
                  />
                </View>
                <Text style={[styles.experienceText, active && styles.experienceTextActive]}>
                  {experience.label}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {provinces.length > 0 ? (
          <View style={styles.filterSection}>
            <Text style={styles.filterLabel}>Filter by region</Text>
            <View style={styles.chipWrap}>
              <Pressable
                onPress={() => setSelectedProvince("")}
                style={[styles.chip, !selectedProvince && styles.chipActive]}
                accessibilityRole="button"
                accessibilityState={{ selected: !selectedProvince }}
              >
                <Text style={[styles.chipText, !selectedProvince && styles.chipTextActive]}>All regions</Text>
              </Pressable>
              {provinces.map((province) => (
                <Pressable
                  key={province}
                  onPress={() => setSelectedProvince(selectedProvince === province ? "" : province)}
                  style={[styles.chip, selectedProvince === province && styles.chipActive]}
                  accessibilityRole="button"
                  accessibilityState={{ selected: selectedProvince === province }}
                >
                  <Text style={[styles.chipText, selectedProvince === province && styles.chipTextActive]}>
                    {province}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : null}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Popular Destinations</Text>
          {destinations.length > 0 ? (
            <Text style={styles.sectionCount}>{visibleDestinations.length}</Text>
          ) : null}
        </View>

        {destinationsLoading ? (
          <View style={styles.centerRow}>
            <ActivityIndicator color="#0F766E" />
            <Text style={styles.mutedText}>Loading destinations…</Text>
          </View>
        ) : null}
        {destinationsError ? <Text style={styles.errorText}>{destinationsError}</Text> : null}
        {!destinationsLoading && !destinationsError && destinations.length === 0 ? (
          <Text style={styles.mutedText}>No destinations are listed yet.</Text>
        ) : null}

        {visibleDestinations.map((item) => {
          const key = savedKeyFor(item.details);
          const listSaved = savedMap[key];
          return (
          <View key={item.details.id ?? item.details.name} style={styles.card}>
            <Pressable onPress={() => openDestination(item.details)} accessibilityRole="button">
              <RelevantImage
                entity={{
                  name: item.details.name,
                  type: "destination",
                  location: item.details.location,
                  image: item.details.image,
                  images: item.details.images,
                  imageSource: item.details.imageSource,
                  imageSourcePage: item.details.imageSourcePage,
                  imageLicense: item.details.imageLicense,
                  imageCredit: item.details.imageCredit,
                  imageDescription: item.details.imageDescription,
                  imageRelevance: item.details.imageRelevance,
                }}
                style={styles.cardImage}
              />
            </Pressable>
            <View style={styles.cardBody}>
              <View style={styles.cardTitleRow}>
                <Text style={styles.cardName}>{item.details.name}</Text>
                <Pressable
                  onPress={() => void toggleSavedDestination(item.details)}
                  disabled={savingId === key}
                  accessibilityRole="button"
                  accessibilityLabel={listSaved ? `Remove ${item.details.name} from Saved` : `Save ${item.details.name}`}
                >
                  {savingId === key ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : (
                    <Ionicons
                      name={listSaved ? "heart" : "heart-outline"}
                      size={23}
                      color={listSaved ? "#D9435F" : colors.primary}
                    />
                  )}
                </Pressable>
              </View>
              <View style={styles.locationRow}>
                <Ionicons name="location-outline" size={14} color={colors.textMuted} />
                <Text style={styles.locationText} numberOfLines={1}>
                  {item.details.location}
                </Text>
              </View>
              <Text style={styles.cardDescription} numberOfLines={3}>
                {item.details.description}
              </Text>
              <View style={styles.cardActions}>
                <Pressable
                  style={styles.primaryButton}
                  onPress={() => openDestination(item.details)}
                  accessibilityRole="button"
                  accessibilityLabel={`View destination ${item.details.name}`}
                >
                  <Text style={styles.primaryButtonText}>View Destination</Text>
                </Pressable>
                <Pressable
                  style={styles.secondaryButton}
                  onPress={() => planTrip(item.details.name)}
                  accessibilityRole="button"
                  accessibilityLabel={`Plan a trip to ${item.details.name}`}
                >
                  <Text style={styles.secondaryButtonText}>Plan a Trip</Text>
                </Pressable>
              </View>
            </View>
          </View>
          );
        })}
        {!destinationsLoading && !destinationsError && destinations.length > 0 && visibleDestinations.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="compass-outline" size={30} color="#0F766E" />
            <Text style={styles.emptyTitle}>No matching destinations</Text>
            <Text style={styles.emptyText}>
              No destinations in the current data match these filters yet. Try another region or experience.
            </Text>
          </View>
        ) : null}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Hidden Gems</Text>
          <Pressable onPress={() => navigation.navigate("HiddenGems", {})} accessibilityRole="button">
            <Text style={styles.seeAll}>See all</Text>
          </Pressable>
        </View>

        {gemsLoading ? (
          <View style={styles.centerRow}>
            <ActivityIndicator size="small" color="#0F766E" />
            <Text style={styles.mutedText}>Loading hidden gems…</Text>
          </View>
        ) : null}
        {!gemsLoading && gems.length === 0 ? (
          <Text style={styles.mutedText}>No hidden gems are listed yet.</Text>
        ) : null}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.gemsRow}
        >
          {gems.map((gem) => (
            <View key={gem.id ?? gem.name} style={styles.gemCard}>
              <Pressable onPress={() => openGem(gem)} accessibilityRole="button">
                <RelevantImage
                  entity={{
                    name: gem.name,
                    type: "destination",
                    location: gem.location,
                    image: gem.image,
                    images: gem.images,
                    imageSource: gem.imageSource,
                    imageSourcePage: gem.imageSourcePage,
                    imageLicense: gem.imageLicense,
                    imageCredit: gem.imageCredit,
                    imageDescription: gem.imageDescription,
                    imageRelevance: gem.imageRelevance,
                  }}
                  style={styles.gemImage}
                />
              </Pressable>
              <View style={styles.gemBody}>
                <Text style={styles.gemName} numberOfLines={1}>
                  {gem.name}
                </Text>
                <View style={styles.locationRow}>
                  <Ionicons name="location-outline" size={12} color={colors.textMuted} />
                  <Text style={styles.gemLocation} numberOfLines={1}>
                    {gem.location ?? "Location not provided"}
                  </Text>
                </View>
                <Text style={styles.gemDescription} numberOfLines={2}>
                  {gem.description ?? "A description is not included in the current destination data."}
                </Text>
                <Pressable
                  style={styles.gemButton}
                  onPress={() => openGem(gem)}
                  accessibilityRole="button"
                  accessibilityLabel={`Explore ${gem.name}`}
                >
                  <Text style={styles.gemButtonText}>Explore</Text>
                  <Ionicons name="arrow-forward" size={14} color={colors.white} />
                </Pressable>
              </View>
            </View>
          ))}
        </ScrollView>
      </ScrollView>
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F5F7FB" },
  content: { paddingHorizontal: spacing.lg, paddingBottom: 110 },
  topBar: { flexDirection: "row", alignItems: "center", marginTop: spacing.md },
  topBarSpacer: { flex: 1 },
  hero: {
    height: 230,
    borderRadius: 12,
    overflow: "hidden",
    marginTop: spacing.md,
    marginBottom: spacing.lg,
  },
  heroOverlay: {
    flex: 1,
    padding: spacing.xl,
    justifyContent: "flex-end",
    backgroundColor: "rgba(8, 15, 28, 0.42)",
  },
  heroEyebrow: { color: "#D1FAE5", fontSize: 10, fontWeight: "800", letterSpacing: 1.2 },
  heroTitle: { color: colors.white, fontSize: 32, fontWeight: "900", marginTop: 2 },
  heroSubtitle: { color: colors.white, fontSize: 13, lineHeight: 19, marginTop: 4, maxWidth: 320 },
  filterSection: { marginBottom: spacing.md },
  filterLabel: { color: colors.textMuted, fontSize: 12, fontWeight: "700", marginBottom: 6 },
  chipWrap: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  chip: {
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  chipActive: { backgroundColor: "#0F766E", borderColor: "#0F766E" },
  chipText: { color: colors.textMuted, fontSize: 11, fontWeight: "700" },
  chipTextActive: { color: colors.white },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: spacing.xl,
    marginBottom: spacing.md,
  },
  sectionTitle: { fontSize: 21, fontWeight: "800", color: "#102A43" },
  sectionCount: { fontSize: 13, fontWeight: "800", color: "#0F766E" },
  sectionHint: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: -spacing.sm, marginBottom: spacing.md },
  seeAll: { fontSize: 13, color: "#0F766E", fontWeight: "700" },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    overflow: "hidden",
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 3,
  },
  cardImage: { width: "100%", height: 200 },
  cardBody: { padding: spacing.md },
  cardTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.md },
  cardName: { flex: 1, color: colors.text, fontSize: 19, fontWeight: "800" },
  locationRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 5 },
  locationText: { color: colors.textMuted, fontSize: 12, flex: 1 },
  cardDescription: { color: colors.text, fontSize: 13, lineHeight: 19, marginTop: spacing.sm },
  cardActions: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.md },
  primaryButton: {
    flex: 1,
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.md,
    backgroundColor: "#0F766E",
  },
  primaryButtonText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  secondaryButton: {
    flex: 1,
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#0F766E",
    backgroundColor: colors.surface,
  },
  secondaryButtonText: { color: "#0F766E", fontSize: 13, fontWeight: "800" },
  experienceGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  experienceCard: {
    width: "48%",
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 16,
    padding: spacing.md,
    alignItems: "center",
    marginBottom: spacing.md,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  experienceCardActive: { backgroundColor: "#0F766E", borderColor: "#0F766E" },
  experienceIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#E6FFFB",
    marginBottom: spacing.sm,
  },
  experienceIconActive: { backgroundColor: "rgba(255,255,255,0.18)" },
  experienceText: { fontSize: 12, fontWeight: "700", color: "#334155", textAlign: "center" },
  experienceTextActive: { color: colors.white },
  gemsRow: { gap: spacing.md, paddingRight: spacing.md },
  gemCard: {
    width: 230,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 3,
  },
  gemImage: { width: "100%", height: 124 },
  gemBody: { padding: spacing.md },
  gemName: { color: colors.text, fontSize: 15, fontWeight: "800" },
  gemLocation: { color: colors.textMuted, fontSize: 11, flex: 1 },
  gemDescription: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 5 },
  gemButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    backgroundColor: "#0F766E",
    borderRadius: radius.sm,
    minHeight: 38,
    marginTop: spacing.sm,
  },
  gemButtonText: { color: colors.white, fontSize: 12, fontWeight: "800" },
  centerRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.md },
  mutedText: { color: "#64748B", fontSize: 13, lineHeight: 19, paddingVertical: spacing.sm },
  errorText: { color: "#B42318", fontSize: 12, marginBottom: spacing.sm },
  emptyState: {
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.xl,
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  emptyTitle: { color: colors.text, fontSize: 15, fontWeight: "800" },
  emptyText: { color: colors.textMuted, fontSize: 12, textAlign: "center", lineHeight: 18 },
});
