import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "HotelDetails">;
type HotelRecord = {
  _id: string;
  name: string;
  location?: string;
  city?: string;
  district?: string;
  province?: string;
  destination?: string;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  roomTypes?: {
    _id: string;
    name: string;
    capacityAdults: number;
    capacityChildren: number;
    totalRooms: number;
    nightlyRate?: number;
    availableRooms?: number;
    matchesOccupancy?: boolean;
  }[];
  pricePerNight?: number;
  rating?: number;
  reviewCount?: number;
  amenities?: string[];
  propertyTypes?: string[];
  latitude?: number;
  longitude?: number;
  policies?: string[];
  checkInTime?: string;
  checkOutTime?: string;
  cancellationPolicy?: string;
  contact?: { phone?: string; email?: string; website?: string };
  nearbyAttractions?: string[];
  availabilityProvider?: string;
  available?: boolean;
  isDemoData?: boolean;
};
type SavedItem = { _id: string; itemType: string; itemId?: string; name: string };
type RestaurantRecord = {
  _id: string;
  name: string;
  location?: string;
  city?: string;
  isDemoData?: boolean;
};

export default function HotelDetailsScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const [hotel, setHotel] = useState<HotelRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [retryKey, setRetryKey] = useState(0);
  const [savedItem, setSavedItem] = useState<SavedItem | null>(null);
  const [savedLoading, setSavedLoading] = useState(false);
  const [savedError, setSavedError] = useState("");
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };
  const [mapsError, setMapsError] = useState("");
  const [availability, setAvailability] = useState<{
    roomTypes: NonNullable<HotelRecord["roomTypes"]>;
    availableForSearch: boolean;
  } | null>(null);
  const [availabilityError, setAvailabilityError] = useState("");
  const [nearbyRestaurants, setNearbyRestaurants] = useState<RestaurantRecord[]>([]);
  const [nearbyError, setNearbyError] = useState("");

  React.useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    backendRequest<HotelRecord>(`/hotels/${encodeURIComponent(route.params.hotelId)}`, {
      signal: controller.signal,
    })
      .then(setHotel)
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load hotel details.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [retryKey, route.params.hotelId]);

  React.useEffect(() => {
    const search = route.params.availabilitySearch;
    if (!search) {
      setAvailability(null);
      setAvailabilityError("");
      return;
    }
    const controller = new AbortController();
    const params = new URLSearchParams({
      checkIn: search.checkIn,
      checkOut: search.checkOut,
      adults: String(search.adults),
      children: String(search.children),
      rooms: String(search.rooms),
    });
    backendRequest<{
      roomTypes: NonNullable<HotelRecord["roomTypes"]>;
      availableForSearch: boolean;
    }>(`/hotels/${encodeURIComponent(route.params.hotelId)}/availability?${params}`, { signal: controller.signal })
      .then((result) => {
        setAvailability(result);
        setAvailabilityError("");
      })
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setAvailabilityError(requestError instanceof Error ? requestError.message : "Could not refresh room availability.");
        }
      });
    return () => controller.abort();
  }, [route.params.availabilitySearch, route.params.hotelId]);

  React.useEffect(() => {
    const city = hotel?.city?.trim() || hotel?.location?.split(",").at(-1)?.trim();
    if (!city) {
      setNearbyRestaurants([]);
      return;
    }
    const controller = new AbortController();
    setNearbyError("");
    backendRequest<RestaurantRecord[]>(`/restaurants?search=${encodeURIComponent(city)}`, {
      signal: controller.signal,
    })
      .then((records) => setNearbyRestaurants(records.filter((record) => record.isDemoData === false)))
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setNearbyError(requestError instanceof Error ? requestError.message : "Could not search restaurant listings.");
        }
      });
    return () => controller.abort();
  }, [hotel?.city, hotel?.location]);

  useFocusEffect(
    useCallback(() => {
      const token = getAccessToken();
      if (!token || !userId || !hotel) {
        setSavedItem(null);
        return;
      }
      const controller = new AbortController();
      setSavedLoading(true);
      setSavedError("");
      backendRequest<SavedItem[]>(`/saved-items?userId=${encodeURIComponent(userId)}`, {
        signal: controller.signal,
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((items) => setSavedItem(
          items.find((item) => item.itemType === "hotel" && (
            item.itemId === hotel._id || item.name === hotel.name
          )) ?? null
        ))
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setSavedError(requestError instanceof Error ? requestError.message : "Could not check Saved Places.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setSavedLoading(false);
        });
      return () => controller.abort();
    }, [getAccessToken, hotel, userId])
  );

  const toggleSaved = async () => {
    if (!hotel) return;
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", { notice: "Sign in to save hotels to Saved Places." });
      return;
    }
    setSaving(true);
    setSavedError("");
    try {
      if (savedItem) {
        await backendRequest(`/saved-items/${savedItem._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItem(null);
        showToast("Removed from saved");
      } else {
        const item = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            userId,
            itemType: "hotel",
            itemId: hotel._id,
            name: hotel.name,
            location: hotel.location ?? hotel.city,
            image: hotel.image,
            imageSource: hotel.imageSource,
            imageSourcePage: hotel.imageSourcePage,
            imageLicense: hotel.imageLicense,
            imageCredit: hotel.imageCredit,
            imageDescription: hotel.imageDescription,
            imageRelevance: hotel.imageRelevance,
          }),
        });
        setSavedItem(item);
        showToast("Saved to your places");
      }
    } catch (requestError) {
      setSavedError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSaving(false);
    }
  };

  const openMaps = async () => {
    if (!hotel) return;
    const query = hotel.latitude != null && hotel.longitude != null
      ? `${hotel.latitude},${hotel.longitude}`
      : [hotel.name, hotel.location, hotel.city, hotel.district, hotel.province, hotel.destination]
          .filter(Boolean)
          .join(", ");
    if (!query) {
      setMapsError("This hotel record has no usable location.");
      return;
    }
    setMapsError("");
    try {
      await Linking.openURL(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`
      );
    } catch (requestError) {
      setMapsError(requestError instanceof Error ? requestError.message : "Could not open Maps.");
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.center} edges={["top"]}>
        <ActivityIndicator color={colors.primary} size="large" />
        <Text style={styles.muted}>Loading hotel details…</Text>
      </SafeAreaView>
    );
  }
  if (error || !hotel) {
    return (
      <SafeAreaView style={styles.center} edges={["top"]}>
        <Text style={styles.errorText}>{error || "Hotel details are unavailable."}</Text>
        <Pressable style={styles.primaryButton} onPress={() => setRetryKey((value) => value + 1)}>
          <Text style={styles.primaryButtonText}>Try again</Text>
        </Pressable>
        <BackButton navigation={navigation} />
      </SafeAreaView>
    );
  }

  const location = [hotel.location, hotel.city, hotel.district, hotel.province, hotel.destination].filter(Boolean).join(", ");
  const mapsQuery = hotel.latitude != null && hotel.longitude != null
    ? `${hotel.latitude}, ${hotel.longitude}`
    : "Coordinates not provided";

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <BackButton navigation={navigation} />
          <Text style={styles.headerTitle}>Hotel details</Text>
          <Pressable onPress={() => void toggleSaved()} disabled={saving || savedLoading} accessibilityRole="button">
            {saving || savedLoading ? <ActivityIndicator color={colors.primary} /> : (
              <Ionicons name={savedItem ? "heart" : "heart-outline"} size={23} color={savedItem ? "#D9435F" : colors.primary} />
            )}
          </Pressable>
        </View>

        <RelevantImage entity={{ name: hotel.name, type: "hotel", location, image: hotel.image, images: hotel.images, imageSource: hotel.imageSource, imageSourcePage: hotel.imageSourcePage, imageLicense: hotel.imageLicense, imageCredit: hotel.imageCredit, imageDescription: hotel.imageDescription, imageRelevance: hotel.imageRelevance }} style={styles.heroImage} />

        <Text style={styles.name}>{hotel.name}</Text>
        <Text style={styles.location}>{location || "Location not provided"}</Text>
        {hotel.isDemoData ? <Text style={styles.demoLabel}>DEMO DATA · THIS PROPERTY CANNOT BE BOOKED</Text> : null}
        {hotel.description ? <Text style={styles.description}>{hotel.description}</Text> : <InfoMissing text="Description not provided." />}
        {hotel.propertyTypes?.length ? <Text style={styles.meta}>{hotel.propertyTypes.join(" · ")}</Text> : <InfoMissing text="Property type is not provided." />}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Price</Text>
          {typeof hotel.pricePerNight === "number" ? (
            <>
              <Text style={styles.price}>NPR {hotel.pricePerNight.toLocaleString("en-IN")} / night</Text>
              <Text style={styles.muted}>Final booking amount is recalculated by the backend using selected dates and rooms.</Text>
            </>
          ) : <InfoMissing text="Nightly price is not available." />}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Facilities</Text>
          {hotel.amenities?.length ? <Text style={styles.body}>{hotel.amenities.join(" · ")}</Text> : <InfoMissing text="Facilities are not listed in this hotel record." />}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Policies and contact</Text>
          <DetailRow label="Check-in" value={hotel.checkInTime} />
          <DetailRow label="Check-out" value={hotel.checkOutTime} />
          <DetailRow label="Cancellation" value={hotel.cancellationPolicy} />
          <DetailRow label="Policies" value={hotel.policies?.join(" · ")} />
          <DetailRow label="Phone" value={hotel.contact?.phone} />
          <DetailRow label="Email" value={hotel.contact?.email} />
          <DetailRow label="Website" value={hotel.contact?.website} />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rooms and availability</Text>
          {availabilityError ? <Text style={styles.errorText}>{availabilityError}</Text> : null}
          {availability && !availability.availableForSearch
            ? <Text style={styles.body}>No room type is currently available for these dates and occupancy.</Text>
            : null}
          {(availability?.roomTypes ?? hotel.roomTypes ?? []).map((roomType) => (
            <View key={roomType._id} style={styles.roomTypeCard}>
              <Text style={styles.roomTypeName}>{roomType.name}</Text>
              <Text style={styles.body}>
                Up to {roomType.capacityAdults} adults · {roomType.capacityChildren} children per room
              </Text>
              <Text style={styles.muted}>
                {availability
                  ? `${roomType.availableRooms ?? 0} available for selected dates`
                  : `${roomType.totalRooms} rooms in inventory; choose dates to check availability`}
              </Text>
              <Text style={styles.muted}>
                NPR {(roomType.nightlyRate ?? hotel.pricePerNight ?? 0).toLocaleString("en-IN")} / room / night
              </Text>
            </View>
          ))}
          {!hotel.roomTypes?.length ? <Text style={styles.body}>No room inventory has been configured for this hotel yet.</Text> : null}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Map and nearby</Text>
          <Text style={styles.muted}>Hotel location: {mapsQuery}</Text>
          <Pressable style={styles.secondaryButton} onPress={() => void openMaps()}>
            <Ionicons name="map-outline" size={17} color={colors.primaryDark} />
            <Text style={styles.secondaryText}>Open in Maps</Text>
          </Pressable>
          {mapsError ? <Text style={styles.errorText}>{mapsError}</Text> : null}
          <Text style={styles.nearbyTitle}>Nearby attractions</Text>
          {hotel.nearbyAttractions?.length ? (
            <Text style={styles.body}>{hotel.nearbyAttractions.join(", ")}</Text>
          ) : <InfoMissing text="No attraction records are linked to this hotel." />}
          <Text style={styles.nearbyTitle}>Restaurants matching this city/location</Text>
          {nearbyError ? (
            <Text style={styles.errorText}>{nearbyError}</Text>
          ) : nearbyRestaurants.length ? (
            <Text style={styles.body}>
              {nearbyRestaurants.map((restaurant) => restaurant.name).join(", ")}
            </Text>
          ) : <InfoMissing text="No non-demo restaurant records matched this hotel location." />}
          <InfoMissing text="Restaurant distances cannot be verified without coordinates. Hospitals, pharmacies, ATMs, petrol stations, and transit stops are not available through the current location-based APIs." />
        </View>

        {savedError ? <Text style={styles.errorText}>{savedError}</Text> : null}
        <Pressable
        style={[styles.primaryButton, (hotel.isDemoData || hotel.available === false) && styles.disabledButton]}
        disabled={hotel.isDemoData || hotel.available === false}
          onPress={() => navigation.push("Booking", {
            hotel: {
              id: hotel._id,
              name: hotel.name,
              location,
              pricePerNight: hotel.pricePerNight,
              image: hotel.image,
              images: hotel.images,
              description: hotel.description,
              propertyTypes: hotel.propertyTypes,
              amenities: hotel.amenities,
              roomTypes: hotel.roomTypes,
              latitude: hotel.latitude,
              longitude: hotel.longitude,
              isDemoData: hotel.isDemoData,
            },
            checkIn: route.params.availabilitySearch?.checkIn,
            checkOut: route.params.availabilitySearch?.checkOut,
            adults: route.params.availabilitySearch?.adults,
            children: route.params.availabilitySearch?.children,
            rooms: route.params.availabilitySearch?.rooms,
          })}
        >
          <Text style={styles.primaryButtonText}>
            {hotel.isDemoData
              ? "Demo listing — booking unavailable"
              : hotel.available === false
                ? "Hotel unavailable"
                : "Request booking"}
          </Text>
        </Pressable>
        <Pressable
          style={styles.secondaryButton}
          onPress={() => navigation.navigate("MainTabs", {
            screen: "Trips",
            params: {
              hotel: {
                id: hotel._id,
                name: hotel.name,
                location,
                latitude: hotel.latitude,
                longitude: hotel.longitude,
              },
            },
          })}
        >
          <Ionicons name="airplane-outline" size={17} color={colors.primaryDark} />
          <Text style={styles.secondaryText}>Add to My Trip</Text>
        </Pressable>
      </ScrollView>
      <SaveToast message={toast} toastKey={toastKey} />
    </SafeAreaView>
  );
}

function DetailRow({ label, value }: { label: string; value?: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={value ? styles.body : styles.muted}>{value || "Not provided"}</Text>
    </View>
  );
}

function InfoMissing({ text }: { text: string }) {
  return <Text style={styles.muted}>{text}</Text>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: 55 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background, padding: spacing.xl, gap: spacing.md },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  headerTitle: { color: colors.text, fontSize: 16, fontWeight: "800" },
  imageStrip: { marginHorizontal: -spacing.lg },
  heroImage: { width: 320, height: 230, borderRadius: radius.lg, marginRight: spacing.sm, backgroundColor: colors.border },
  imagePlaceholder: { alignItems: "center", justifyContent: "center", gap: spacing.sm },
  name: { color: colors.text, fontSize: 25, fontWeight: "900", marginTop: spacing.md },
  location: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
  demoLabel: { color: "#9A3412", fontSize: 11, fontWeight: "900", marginTop: spacing.sm },
  description: { color: colors.text, fontSize: 13, lineHeight: 20, marginTop: spacing.md },
  meta: { color: colors.primaryDark, fontSize: 12, fontWeight: "700", marginTop: spacing.sm },
  section: { marginTop: spacing.lg },
  sectionTitle: { color: colors.text, fontSize: 15, fontWeight: "800", marginBottom: spacing.sm },
  roomTypeCard: { padding: spacing.md, marginBottom: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.lg, backgroundColor: colors.surface, gap: 4, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.05, shadowRadius: 10, elevation: 1 },
  roomTypeName: { color: colors.text, fontSize: 13, fontWeight: "800" },
  body: { color: colors.text, fontSize: 12, lineHeight: 19 },
  muted: { color: colors.textMuted, fontSize: 11, lineHeight: 17 },
  price: { color: colors.primaryDark, fontSize: 18, fontWeight: "900", marginBottom: 4 },
  detailRow: { paddingVertical: spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  detailLabel: { color: colors.text, fontSize: 11, fontWeight: "800", marginBottom: 3 },
  nearbyTitle: { color: colors.text, fontSize: 12, fontWeight: "800", marginTop: spacing.md, marginBottom: 4 },
  secondaryButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, minHeight: 43, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.primary, borderRadius: radius.md, marginTop: spacing.md },
  secondaryText: { color: colors.primaryDark, fontSize: 12, fontWeight: "800" },
  primaryButton: { minHeight: 50, alignItems: "center", justifyContent: "center", backgroundColor: colors.primary, borderRadius: radius.md, marginTop: spacing.xl, paddingHorizontal: spacing.md, shadowColor: colors.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 10, elevation: 3 },
  primaryButtonText: { color: colors.white, fontSize: 13, fontWeight: "900", textAlign: "center" },
  disabledButton: { backgroundColor: colors.textMuted },
  errorText: { color: "#B42318", fontSize: 12, lineHeight: 18, textAlign: "center" },
  linkText: { color: colors.primaryDark, fontSize: 13, fontWeight: "800" },
});
