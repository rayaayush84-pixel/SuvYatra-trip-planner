import React, { useState } from "react";
import { Linking, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { WebView } from "react-native-webview";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "Map">;

export default function MapScreen({ navigation, route }: Props) {
  const coordinates = route.params?.latitude !== undefined && route.params?.longitude !== undefined
    ? `${route.params.latitude},${route.params.longitude}`
    : "";
  const initialQuery = route.params?.query?.trim()
    || coordinates
    || route.params?.category
    || "";
  const [query, setQuery] = useState(initialQuery);
  const mapQuery = query.trim() || "Nepal";
  const encoded = encodeURIComponent(mapQuery);
  const openGoogleMaps = () => Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encoded}`);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <BackButton navigation={navigation} iconSize={24} />
        <Text style={styles.title}>Map search</Text>
        <View style={styles.spacer} />
      </View>
      <View style={styles.searchRow}>
        <TextInput value={query} onChangeText={setQuery} placeholder="Search a place or service" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="search" onSubmitEditing={() => void openGoogleMaps()} />
        <Pressable onPress={() => void openGoogleMaps()} style={styles.openButton} accessibilityRole="button">
          <Text style={styles.openText}>Open Maps</Text>
        </Pressable>
      </View>
      <Text style={styles.note}>Map results are provided by Google Maps. SuvYatra does not currently have a configured Places API, so this screen does not claim business details, opening hours, services, availability, or distance.</Text>
      <View style={styles.mapContainer}>
        <WebView source={{ uri: `https://www.google.com/maps?q=${encoded}&output=embed` }} style={styles.map} javaScriptEnabled domStorageEnabled />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.lg, paddingTop: spacing.md },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  title: { color: colors.text, fontSize: 20, fontWeight: "800" },
  spacer: { width: 24 },
  searchRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  input: { flex: 1, backgroundColor: colors.surface, color: colors.text, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 12 },
  openButton: { backgroundColor: colors.primary, borderRadius: radius.md, padding: spacing.md },
  openText: { color: colors.white, fontWeight: "800", fontSize: 12 },
  note: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginVertical: spacing.md },
  mapContainer: { flex: 1, overflow: "hidden", borderRadius: radius.md, marginBottom: spacing.md },
  map: { flex: 1 },
});
