import React, {
  ReactNode,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  View,
  ViewStyle,
  useWindowDimensions,
} from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { Ionicons } from "@expo/vector-icons";
import Markdown from "react-native-markdown-display";
import {
  CHAT_TEMPORARY_MESSAGE,
  ChatSource,
  HistoryItem,
  ReadyStatus,
  checkReady,
  streamChat,
  userFacingChatError,
} from "../services/chatApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";
import { ImageEntity } from "../imageResolver";
import { backendRequest } from "../services/backendApi";

type Props = NativeStackScreenProps<RootStackParamList, "Chat">;

type MessageStatus = "done" | "streaming" | "error";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources: ChatSource[];
  status: MessageStatus;
  errorText?: string;
  question?: string;
  timestamp?: string;
};

type ChatSession = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
};

const STORAGE_KEY = "suvyatra_chat_v1";
const HISTORY_KEY = "suvyatra_chat_sessions_v1";
const MAX_QUESTION_LENGTH = 1000;

const QUICK_ACTIONS = [
  { label: "Plan My Trip", question: "Help me plan a Nepal trip. Ask me only for the key details you need." },
  { label: "Find Destinations", question: "Recommend Nepal destinations for my interests and explain why they fit." },
  { label: "Hidden Gems", question: "Suggest lesser-known places in Nepal and distinguish verified information from general suggestions." },
  { label: "Budget Trip", question: "Help me plan an affordable Nepal trip and label all cost figures as estimates." },
  { label: "Hotels", question: "Find hotels in Nepal using available live listings. Do not invent prices or availability." },
  { label: "Restaurants", question: "Find restaurants in Nepal using available live listings. Do not invent ratings or details." },
  { label: "Transport", question: "Compare practical transport options for my Nepal route without claiming live schedules." },
  { label: "Weather", question: "Tell me whether live weather data is available for my destination, and suggest a weather-aware plan." },
  { label: "Trekking", question: "Help me plan a Nepal trek, noting altitude considerations and verifying current permit rules." },
  { label: "Emergency Help", question: "I need travel safety or emergency guidance in Nepal. Give practical steps and direct me to local authorities when appropriate." },
];

const WELCOME_LINES = [
  "Hi! I'm your SuvYatra AI travel assistant.",
  "Ask me anything about Nepal — destinations, itineraries, trekking, food and transport.",
];

type ListedImageEntity = ImageEntity & { isDemoData?: boolean };

const CHAT_IMAGE_ENTITIES: ImageEntity[] = [
  { name: "Phewa Lake", type: "destination", location: "Pokhara, Nepal" },
  { name: "Everest Base Camp", type: "destination", location: "Khumbu, Nepal" },
  { name: "Sarangkot", type: "destination", location: "Pokhara, Nepal" },
  { name: "Thamel", type: "destination", location: "Kathmandu, Nepal" },
  { name: "Bhaktapur Durbar Square", type: "destination", location: "Bhaktapur, Nepal" },
  { name: "Paragliding", type: "activity", location: "Sarangkot, Pokhara, Nepal" },
  { name: "Rafting", type: "activity", location: "Nepal" },
  { name: "Trekking", type: "activity", location: "Nepal" },
  { name: "Jeep", type: "transport", location: "Nepal" },
  { name: "Tourist Bus", type: "transport", location: "Nepal" },
  { name: "Motorbike", type: "transport", location: "Nepal" },
];

let chatImageCatalog: Promise<ImageEntity[]> | null = null;

async function loadChatImageCatalog(): Promise<ImageEntity[]> {
  if (!chatImageCatalog) {
    chatImageCatalog = (async () => {
      const requests: Array<Promise<ListedImageEntity[]>> = [
        backendRequest<ListedImageEntity[]>("/destinations"),
        backendRequest<ListedImageEntity[]>("/hotels"),
        backendRequest<ListedImageEntity[]>("/restaurants"),
        backendRequest<ListedImageEntity[]>("/transports"),
      ];
      const results = await Promise.allSettled(requests);
      const listed: ImageEntity[] = [];
      for (const [index, result] of results.entries()) {
        if (result.status === "rejected") {
          console.warn("Could not load verified chatbot image recommendations.", result.reason);
          continue;
        }
        const records = index === 0
          ? result.value
          : result.value.filter((record) => record.isDemoData !== true);
        const type = ["destination", "hotel", "restaurant", "transport"][index];
        listed.push(...records.map((record) => ({ ...record, type })));
      }
      return [...CHAT_IMAGE_ENTITIES, ...listed];
    })();
  }
  return chatImageCatalog;
}

function ChatRecommendationImages({ content }: { content: string }) {
  const [entities, setEntities] = useState<ImageEntity[]>([]);
  useEffect(() => {
    let active = true;
    loadChatImageCatalog()
      .then((catalog) => {
        if (!active) return;
        const mentioned = catalog.filter((entity) =>
          content.toLocaleLowerCase().includes(entity.name.toLocaleLowerCase())
        );
        const seen = new Set<string>();
        setEntities(mentioned.filter((entity) => {
          const key = `${entity.type}:${entity.name.toLocaleLowerCase()}`;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        }));
      })
      .catch((error: unknown) => {
        console.warn("Could not prepare chatbot image recommendations.", error);
      });
    return () => {
      active = false;
    };
  }, [content]);

  if (!entities.length) return null;
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.recommendationImages}>
      {entities.map((entity) => (
        <View key={`${entity.type}:${entity.name}`} style={styles.recommendationCard}>
          <RelevantImage entity={entity} style={styles.recommendationImage} />
          <Text numberOfLines={1} style={styles.recommendationName}>{entity.name}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

function getStorage(): Storage | null {
  try {
    return typeof localStorage !== "undefined" ? localStorage : null;
  } catch {
    return null;
  }
}

const memoryStorage = new Map<string, string>();

function readStored(): ChatMessage[] {
  const store = getStorage();
  const raw = store ? store.getItem(STORAGE_KEY) : memoryStorage.get(STORAGE_KEY);
  if (!raw) {
    return [];
  }
  try {
    return JSON.parse(raw) as ChatMessage[];
  } catch {
    return [];
  }
}

function writeStored(messages: ChatMessage[]) {
  const store = getStorage();
  const raw = JSON.stringify(messages);
  if (store) {
    try {
      store.setItem(STORAGE_KEY, raw);
    } catch {
      // storage full or blocked
    }
  } else {
    memoryStorage.set(STORAGE_KEY, raw);
  }
}

function readStoredSessions(): ChatSession[] {
  const store = getStorage();
  const raw = store ? store.getItem(HISTORY_KEY) : memoryStorage.get(HISTORY_KEY);
  if (!raw) {
    const legacy = readStored();
    if (!legacy.length) {
      return [];
    }
    const session: ChatSession = {
      id: `session-${Date.now()}`,
      title: legacy[0]?.content ? "New chat" : "Untitled chat",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: legacy.map((message) => ({
        ...message,
        timestamp: message.timestamp ?? new Date().toISOString(),
      })),
    };
    writeStoredSessions([session]);
    return [session];
  }

  try {
    const parsed = JSON.parse(raw) as ChatSession[];
    return parsed.map((session) => ({
      ...session,
      createdAt: session.createdAt ?? new Date().toISOString(),
      updatedAt: session.updatedAt ?? new Date().toISOString(),
      messages: (session.messages ?? []).map((message) => ({
        ...message,
        timestamp: message.timestamp ?? new Date().toISOString(),
      })),
    }));
  } catch {
    return [];
  }
}

function writeStoredSessions(sessions: ChatSession[]) {
  const store = getStorage();
  const raw = JSON.stringify(sessions);
  if (store) {
    try {
      store.setItem(HISTORY_KEY, raw);
    } catch {
      // storage full or blocked
    }
  } else {
    memoryStorage.set(HISTORY_KEY, raw);
  }
}

function formatHistoryDate(value?: string) {
  if (!value) return "Today";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Today";
  return date.toLocaleString([], {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function getConversationTitle(messages: ChatMessage[]) {
  const latestUser = [...messages].reverse().find((message) => message.role === "user");
  if (latestUser?.content) {
    return latestUser.content.trim().slice(0, 40) || "New chat";
  }
  return "New chat";
}

function clearStored() {
  const store = getStorage();
  if (store) {
    try {
      store.removeItem(STORAGE_KEY);
      store.removeItem(HISTORY_KEY);
    } catch {
      // ignore
    }
  } else {
    memoryStorage.delete(STORAGE_KEY);
    memoryStorage.delete(HISTORY_KEY);
  }
}

function MessageItem({
  children,
  style,
}: {
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(progress, {
      toValue: 1,
      duration: 240,
      useNativeDriver: true,
    }).start();
  }, [progress]);

  return (
    <Animated.View
      style={[
        style,
        {
          opacity: progress,
          transform: [
            {
              translateY: progress.interpolate({
                inputRange: [0, 1],
                outputRange: [10, 0],
              }),
            },
          ],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}

function TypingDots() {
  const dots = useRef([
    new Animated.Value(0),
    new Animated.Value(0),
    new Animated.Value(0),
  ]).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.stagger(
        160,
        dots.map((value) =>
          Animated.sequence([
            Animated.timing(value, {
              toValue: 1,
              duration: 320,
              useNativeDriver: true,
            }),
            Animated.timing(value, {
              toValue: 0,
              duration: 320,
              useNativeDriver: true,
            }),
          ])
        )
      )
    );
    animation.start();
    return () => animation.stop();
  }, [dots]);

  return (
    <View style={styles.typingRow}>
      {dots.map((value, index) => (
        <Animated.View
          key={index}
          style={[
            styles.typingDot,
            {
              opacity: value.interpolate({
                inputRange: [0, 1],
                outputRange: [0.25, 1],
              }),
            },
          ]}
        />
      ))}
    </View>
  );
}

let idCounter = 0;
function nextId(): string {
  idCounter += 1;
  return `msg-${Date.now()}-${idCounter}`;
}

const STATUS_META: Record<ReadyStatus, { color: string; label: string }> = {
  checking: { color: colors.textMuted, label: "Connecting…" },
  ready: { color: "#34D399", label: "Online" },
  empty: { color: "#F59E0B", label: "Updating travel data" },
  unreachable: { color: "#EF4444", label: "Server unreachable" },
};

export default function ChatScreen({ navigation, route }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [kbStatus, setKbStatus] = useState<ReadyStatus>("checking");
  const [expandedSources, setExpandedSources] = useState<Record<string, boolean>>({});

  const scrollRef = useRef<ScrollView>(null);
  const abortRef = useRef<AbortController | null>(null);
  const historyRef = useRef<HistoryItem[]>([]);
  const nearBottomRef = useRef(true);
  const handledPromptRef = useRef<string | null>(null);
  // Mirrors the composer text so send handlers always read the latest value,
  // even when they fire before a re-render. Kept separate from `messages`
  // and `isSending` so generating answers can never overwrite typed text.
  const inputRef = useRef("");
  const isSendingRef = useRef(false);
  const generationRef = useRef(0);
  const lastSentRef = useRef<{ text: string; time: number }>({ text: "", time: 0 });

  // Single writer for the composer box: state (render) + ref (send logic).
  const setComposerText = useCallback((value: string) => {
    inputRef.current = value;
    setInput(value);
  }, []);

  useEffect(() => {
    const storedSessions = readStoredSessions();
    if (storedSessions.length) {
      setSessions(storedSessions);
      setSelectedSessionId(storedSessions[0].id);
      setMessages(storedSessions[0].messages);
      historyRef.current = storedSessions[0].messages
        .filter((m) => m.content && m.status !== "error")
        .map((m): HistoryItem => ({ role: m.role as HistoryItem["role"], content: m.content }))
        .slice(-8);
    } else {
      const legacy = readStored();
      if (legacy.length) {
        const restored: ChatMessage[] = legacy.map((message) => ({
          ...message,
          timestamp: message.timestamp ?? new Date().toISOString(),
          sources: message.sources ?? [],
          status: message.status === "error" ? ("error" as const) : ("done" as const),
        }));
        const sessionId = `session-${Date.now()}`;
        const session: ChatSession = {
          id: sessionId,
          title: getConversationTitle(restored),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messages: restored,
        };
        setSessions([session]);
        setSelectedSessionId(sessionId);
        setMessages(restored);
        writeStoredSessions([session]);
        historyRef.current = restored
          .filter((m) => m.content && m.status !== "error")
          .map((m): HistoryItem => ({ role: m.role as HistoryItem["role"], content: m.content }))
          .slice(-8);
      } else {
        const fallbackSession: ChatSession = {
          id: `session-${Date.now()}`,
          title: "New chat",
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messages: [],
        };
        setSessions([fallbackSession]);
        setSelectedSessionId(fallbackSession.id);
        setMessages([]);
        writeStoredSessions([fallbackSession]);
      }
    }
    if (route.params?.prompt?.trim()) {
      // Pre-fill only when the user has not already typed something.
      if (!inputRef.current.trim()) {
        setComposerText(route.params.prompt.trim());
      }
    }
    setKbStatus("checking");
    checkReady().then(setKbStatus);
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (!selectedSessionId) return;
    setSessions((current) => {
      const next = current.map((session) =>
        session.id === selectedSessionId
          ? {
              ...session,
              messages,
              title: getConversationTitle(messages),
              updatedAt: new Date().toISOString(),
            }
          : session
      );
      writeStoredSessions(next);
      return next;
    });
  }, [messages, selectedSessionId]);

  useEffect(() => {
    const timer = setTimeout(() => {
      const shouldScroll = isSending || nearBottomRef.current;
      if (shouldScroll) {
        scrollRef.current?.scrollToEnd({ animated: true });
      }
    }, 60);
    return () => clearTimeout(timer);
  }, [messages, isSending, kbStatus]);

  const updateMessage = useCallback(
    (id: string, updater: (m: ChatMessage) => ChatMessage) => {
      setMessages((current) =>
        current.map((m) => (m.id === id ? updater(m) : m))
      );
    },
    []
  );

  const runStream = useCallback(
    async (assistantId: string, question: string, history: HistoryItem[]) => {
      const controller = new AbortController();
      const generation = (generationRef.current += 1);
      abortRef.current = controller;
      isSendingRef.current = true;
      setIsSending(true);
      let answer = "";

      try {
        await streamChat({
          question,
          history,
          signal: controller.signal,
          onToken: (token) => {
            answer += token;
            updateMessage(assistantId, (m) => ({ ...m, content: answer }));
          },
          onDone: (sources) => {
            updateMessage(assistantId, (m) => ({
              ...m,
              content: answer,
              sources,
              status: "done",
            }));
            const updatedHistory: HistoryItem[] = [
              ...historyRef.current,
              { role: "user", content: question },
              { role: "assistant", content: answer },
            ];
            historyRef.current = updatedHistory.slice(-8);
          },
        });
      } catch (err) {
        if (controller.signal.aborted) {
          updateMessage(assistantId, (m) => ({
            ...m,
            status: "done",
          }));
        } else {
          // Never show raw backend details — the helper maps everything to
          // a clean user-facing message.
          updateMessage(assistantId, (m) => ({
            ...m,
            status: "error",
            errorText: userFacingChatError(err),
          }));
        }
      } finally {
        // Only the latest generation may reset shared stream state: an
        // older stream aborted by a newer question must not clear it.
        if (abortRef.current === controller) {
          abortRef.current = null;
        }
        if (generationRef.current === generation) {
          isSendingRef.current = false;
          setIsSending(false);
        }
      }
    },
    [updateMessage]
  );

  const sendMessage = useCallback(
    async (text?: string, retryAssistantId?: string) => {
      // Read the live composer value (not a stale closure) so Enter always
      // sends exactly what is on screen.
      const question = (text ?? inputRef.current).trim();
      if (!question) {
        return;
      }
      if (question.length > MAX_QUESTION_LENGTH) {
        return;
      }
      // Ignore accidental double-Enter / key-repeat for identical text while
      // still allowing a genuine repeat send afterwards.
      const now = Date.now();
      if (
        lastSentRef.current.text === question &&
        now - lastSentRef.current.time < 1500
      ) {
        return;
      }
      lastSentRef.current = { text: question, time: now };
      // A new question sent while the previous answer is still generating
      // stops that stream first (ChatGPT-style). Typing is never blocked:
      // `isSending` only swaps the send/stop button, never the input.
      if (isSendingRef.current) {
        abortRef.current?.abort();
      }
      if (
        !retryAssistantId &&
        /\b(?:plan|create|build|make)\b.*\b(?:trip|itinerary|travel)\b|\b\d{1,2}\s*[- ]?\s*days?\b.*\btrip\b/i.test(question)
      ) {
        navigation.push("PlanMyTrip", { prompt: question });
        return;
      }

      let activeSessionId = selectedSessionId;
      if (!activeSessionId) {
        activeSessionId = `session-${Date.now()}`;
        setSelectedSessionId(activeSessionId);
        setSessions((current) => {
          const next = [{
            id: activeSessionId!,
            title: "New chat",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            messages: [],
          }, ...current];
          writeStoredSessions(next);
          return next;
        });
      }

      const history = historyRef.current.slice(-8);
      const assistantId = retryAssistantId ?? nextId();
      nearBottomRef.current = true;

      if (retryAssistantId) {
        setMessages((current) =>
          current.map((m) =>
            m.id === retryAssistantId
              ? {
                  id: retryAssistantId,
                  role: "assistant",
                  content: "",
                  sources: [],
                  status: "streaming",
                  question,
                  timestamp: new Date().toISOString(),
                }
              : m
          )
        );
      } else {
        const userMessage: ChatMessage = {
          id: nextId(),
          role: "user",
          content: question,
          sources: [],
          status: "done",
          timestamp: new Date().toISOString(),
        };
        const assistantMessage: ChatMessage = {
          id: assistantId,
          role: "assistant",
          content: "",
          sources: [],
          status: "streaming",
          question,
          timestamp: new Date().toISOString(),
        };
        setMessages((current) => [...current, userMessage, assistantMessage]);
      }

      // Clear the composer only when it still holds the exact text that was
      // just submitted. Programmatic sends (suggestion chips, retries,
      // route prompts) and stream completions must never wipe text the user
      // typed afterwards (e.g. question 2 typed while answer 1 streams).
      if (text === undefined && inputRef.current.trim() === question) {
        setComposerText("");
      }
      await runStream(assistantId, question, history);
    },
    [navigation, runStream, selectedSessionId, setComposerText]
  );

  useEffect(() => {
    const prompt = route.params?.prompt?.trim();
    if (!isInitialized || !prompt || handledPromptRef.current === prompt) {
      return;
    }
    handledPromptRef.current = prompt;
    void sendMessage(prompt);
  }, [isInitialized, route.params?.prompt, sendMessage]);

  const stopStream = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const newChat = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    const newSessionId = `session-${Date.now()}`;
    const newSession: ChatSession = {
      id: newSessionId,
      title: "New chat",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    setSelectedSessionId(newSessionId);
    setMessages([]);
    setSessions((current) => {
      const ordered = [newSession, ...current.filter((session) => session.id !== newSessionId)];
      writeStoredSessions(ordered);
      return ordered;
    });
    historyRef.current = [];
    setExpandedSources({});
    setShowHistory(false);
  }, []);

  const refreshReady = useCallback(() => {
    setKbStatus("checking");
    checkReady().then(setKbStatus);
  }, []);

  const toggleSources = useCallback((id: string) => {
    setExpandedSources((current) => ({ ...current, [id]: !current[id] }));
  }, []);

  const showWelcome = messages.length === 0;
  const isWeb = Platform.OS === "web";
  // Mobile-shaped layout on wide web screens: the chat renders inside a
  // centered phone-sized frame; on real mobile devices (or narrow windows)
  // it fills the available screen with no frame styling.
  const { width: windowWidth, height: windowHeight } = useWindowDimensions();
  const isPhoneFrame = isWeb && windowWidth >= 520;
  const phoneFrameHeight = Math.min(850, Math.round(windowHeight * 0.9));
  const canSend = input.trim().length > 0 && !isSending;
  const status = STATUS_META[kbStatus];

  const inputProps = isWeb
    ? {
        blurOnSubmit: false as const,
        onKeyPress: (e: any) => {
          const key = e?.key ?? e?.nativeEvent?.key;
          if (key === "Enter" && !e?.shiftKey) {
            e.preventDefault?.();
            sendMessage();
          }
        },
      }
    : {
        submitBehavior: "submit" as const,
        blurOnSubmit: false as const,
        onSubmitEditing: () => sendMessage(),
      };

  const onMessagesScroll = useCallback((e: any) => {
    const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
    nearBottomRef.current =
      layoutMeasurement.height + contentOffset.y >= contentSize.height - 40;
  }, []);

  return (
    <View style={[styles.page, isPhoneFrame && styles.pageDesktop]}>
      <View
        style={[
          styles.phoneFrame,
          isPhoneFrame && [styles.phoneFrameDesktop, { height: phoneFrameHeight }],
        ]}
      >
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.header}>
          <View style={styles.headerRow}>
            <BackButton
              navigation={navigation}
              style={styles.headerButton}
              iconColor="#FFFFFF"
            />

            <View style={styles.avatar}>
              <Ionicons name="sparkles" size={19} color={colors.primaryDark} />
            </View>

            <View style={styles.headerTextWrap}>
              <Text style={styles.headerTitle}>SuvYatra Assistant</Text>
              <View style={styles.statusRow}>
                <View style={[styles.statusDot, { backgroundColor: status.color }]} />
                <Text style={styles.statusText}>{status.label}</Text>
              </View>
            </View>

            <Pressable
              style={styles.headerButton}
              onPress={() => setShowHistory((current) => !current)}
              hitSlop={10}
              accessibilityRole="button"
              accessibilityLabel="Open chat history"
            >
              <Ionicons name="time-outline" size={22} color="#FFFFFF" />
            </Pressable>

            <Pressable
              style={styles.headerButton}
              onPress={newChat}
              hitSlop={10}
              accessibilityRole="button"
              accessibilityLabel="Start a new chat"
            >
              <Ionicons name="create-outline" size={22} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>

        {showHistory && (
          <View style={styles.historyPanel}>
            <Text style={styles.historyTitle}>Chat history</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.historyRow}>
              {sessions.map((session) => (
                <Pressable
                  key={session.id}
                  style={({ pressed }) => [
                    styles.historyCard,
                    selectedSessionId === session.id && styles.historyCardActive,
                    pressed && styles.historyCardPressed,
                  ]}
                  onPress={() => {
                    setSelectedSessionId(session.id);
                    setMessages(session.messages);
                    historyRef.current = session.messages
                      .filter((m) => m.content && m.status !== "error")
                      .map((m): HistoryItem => ({ role: m.role as HistoryItem["role"], content: m.content }))
                      .slice(-8);
                    setShowHistory(false);
                    setExpandedSources({});
                  }}
                >
                  <Text style={styles.historyCardTitle} numberOfLines={1}>{session.title}</Text>
                  <Text style={styles.historyCardText} numberOfLines={2}>
                    {session.messages.length
                      ? session.messages[session.messages.length - 1]?.content ?? "No message yet"
                      : "No message yet"}
                  </Text>
                  <Text style={styles.historyCardDate}>{formatHistoryDate(session.updatedAt)}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}

        {kbStatus === "empty" && (
          <View style={styles.banner}>
            <Ionicons name="alert-circle" size={17} color="#B45309" />
            <Text style={styles.bannerText}>
              Travel data is updating — answers may be general until it finishes loading.
            </Text>
            <Pressable
              onPress={refreshReady}
              style={styles.bannerAction}
              accessibilityRole="button"
              accessibilityLabel="Refresh server status"
            >
              <Ionicons name="refresh" size={17} color="#B45309" />
            </Pressable>
          </View>
        )}
        {kbStatus === "unreachable" && (
          <View style={styles.bannerDanger}>
            <Ionicons name="warning" size={17} color="#B91C1C" />
            <Text style={styles.bannerTextDanger}>
              I'm having trouble connecting right now. Please check your connection and retry.
            </Text>
            <Pressable
              onPress={refreshReady}
              style={styles.bannerAction}
              accessibilityRole="button"
              accessibilityLabel="Refresh server status"
            >
              <Ionicons name="refresh" size={17} color="#B91C1C" />
            </Pressable>
          </View>
        )}

        <View style={styles.chatArea}>
          <ScrollView
            ref={scrollRef}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.messagesContent}
            keyboardShouldPersistTaps="handled"
            onScroll={onMessagesScroll}
            scrollEventThrottle={16}
          >
            {showWelcome ? (
              <View style={styles.welcomeSection}>
                <View style={styles.welcomeAvatar}>
                  <Ionicons name="sparkles" size={34} color={colors.primaryDark} />
                </View>

                <View style={styles.welcomeBubble}>
                  {WELCOME_LINES.map((line, index) => (
                    <Text
                      key={index}
                      style={[styles.welcomeText, !index && styles.welcomeTextBold]}
                    >
                      {line}
                    </Text>
                  ))}
                </View>

                <Text style={styles.chipLabel}>Try asking</Text>

                <View style={styles.chips}>
                  {QUICK_ACTIONS.map(({ label, question }) => (
                    <Pressable
                      key={label}
                      style={({ pressed }) => [
                        styles.chip,
                        pressed && styles.chipPressed,
                      ]}
                      onPress={() => {
                        if (label === "Plan My Trip") {
                          navigation.push("PlanMyTrip");
                          return;
                        }
                        void sendMessage(question);
                      }}
                      accessibilityRole="button"
                      accessibilityLabel={`${label}: ${question}`}
                    >
                      <Ionicons name="sparkles" size={15} color={colors.primaryDark} />
                      <Text style={styles.chipText}>{label}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            ) : (
              messages.map((message) => (
                <MessageItem
                  key={message.id}
                  style={
                    message.role === "user"
                      ? styles.userMessageContainer
                      : styles.botMessageContainer
                  }
                >
                  {message.role !== "user" && (
                    <View style={styles.smallBotIcon}>
                      <Ionicons name="happy-outline" size={24} color={colors.primaryDark} />
                    </View>
                  )}

                  <View
                    style={
                      message.role === "user" ? styles.userBubble : styles.botBubble
                    }
                  >
                    {message.role === "user" ? (
                      <Text style={styles.userText}>{message.content}</Text>
                    ) : (
                      <>
                        {message.status === "streaming" && !message.content ? (
                          <TypingDots />
                        ) : message.content ? (
                          <Markdown style={mdStyles}>{message.content}</Markdown>
                        ) : null}

                        {message.status === "done" && message.content ? (
                          <ChatRecommendationImages content={message.content} />
                        ) : null}

                        {message.status === "error" && (
                          <View style={styles.errorBox}>
                            <Text style={styles.errorText}>
                              {message.errorText ?? CHAT_TEMPORARY_MESSAGE}
                            </Text>
                            {message.question && (
                              <Pressable
                                style={({ pressed }) => [
                                  styles.retryButton,
                                  pressed && styles.buttonPressed,
                                ]}
                                onPress={() =>
                                  sendMessage(message.question, message.id)
                                }
                                accessibilityRole="button"
                                accessibilityLabel="Retry sending question"
                              >
                                <Ionicons name="refresh" size={15} color={colors.primaryDark} />
                                <Text style={styles.retryText}>Retry</Text>
                              </Pressable>
                            )}
                          </View>
                        )}

                        {message.role === "assistant" &&
                          message.status === "done" &&
                          message.sources.length > 0 && (
                            <View style={styles.sourcesBox}>
                              <Pressable
                                style={({ pressed }) => [
                                  styles.sourcesToggle,
                                  pressed && styles.buttonPressed,
                                ]}
                                onPress={() => toggleSources(message.id)}
                                accessibilityRole="button"
                                accessibilityState={{
                                  expanded: !!expandedSources[message.id],
                                }}
                              >
                                <Ionicons
                                  name="document-text-outline"
                                  size={14}
                                  color={colors.textMuted}
                                />
                                <Text style={styles.sourcesToggleText}>
                                  Sources ({message.sources.length})
                                </Text>
                                <Ionicons
                                  name={
                                    expandedSources[message.id]
                                      ? "chevron-up"
                                      : "chevron-down"
                                  }
                                  size={15}
                                  color={colors.textMuted}
                                />
                              </Pressable>

                              {expandedSources[message.id] &&
                                message.sources.map((source, index) => (
                                  <View key={index} style={styles.sourceItem}>
                                    <Text style={styles.sourceName}>
                                      {source.source}
                                    </Text>
                                    <Text style={styles.sourceSnippet}>
                                      {source.snippet}
                                    </Text>
                                  </View>
                                ))}
                            </View>
                          )}
                      </>
                    )}
                  </View>
                </MessageItem>
              ))
            )}
          </ScrollView>
        </View>

        <View style={styles.composerWrap}>
          <View
            style={[
              styles.composerRow,
              isSending && styles.composerRowStreaming,
            ]}
          >
            <TextInput
              value={input}
              onChangeText={setComposerText}
              placeholder="Ask about Nepal travel…"
              placeholderTextColor="#9CA3AF"
              style={styles.input}
              multiline
              maxLength={MAX_QUESTION_LENGTH}
              {...inputProps}
            />

            {isSending ? (
              <Pressable
                style={({ pressed }) => [
                  styles.stopButton,
                  pressed && styles.stopButtonPressed,
                ]}
                onPress={stopStream}
                accessibilityRole="button"
                accessibilityLabel="Stop generating"
              >
                <Ionicons name="stop" size={20} color="#FFFFFF" />
              </Pressable>
            ) : (
              <Pressable
                style={({ pressed }) => [
                  styles.sendButton,
                  !canSend && styles.sendButtonDisabled,
                  pressed && canSend && styles.sendButtonPressed,
                ]}
                onPress={() => canSend && sendMessage()}
                disabled={!canSend}
                accessibilityRole="button"
                accessibilityLabel="Send message"
                accessibilityState={{ disabled: !canSend }}
              >
                <Ionicons
                  name="arrow-up"
                  size={22}
                  color={canSend ? "#FFFFFF" : "#9CA3AF"}
                />
              </Pressable>
            )}
          </View>

          {input.length >= 850 && (
            <Text
              style={[
                styles.charLimit,
                input.length >= MAX_QUESTION_LENGTH && styles.charLimitWarn,
              ]}
            >
              {input.length}/{MAX_QUESTION_LENGTH}
            </Text>
          )}
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
      </View>
    </View>
  );
}

const mdStyles = StyleSheet.create({
  body: { color: colors.text, fontSize: 14, lineHeight: 20 },
  paragraph: { marginTop: 2, marginBottom: 5 },
  heading1: {
    fontSize: 17,
    fontWeight: "700",
    marginTop: 6,
    marginBottom: 3,
    color: colors.text,
  },
  heading2: {
    fontSize: 15.5,
    fontWeight: "700",
    marginTop: 5,
    marginBottom: 2,
    color: colors.text,
  },
  heading3: { fontSize: 14.5, fontWeight: "700", marginTop: 4, marginBottom: 2 },
  strong: { fontWeight: "700", color: colors.text },
  em: { fontStyle: "italic" },
  link: { color: colors.primaryDark, textDecorationLine: "underline" },
  bullet_list: { marginVertical: 2 },
  ordered_list: { marginVertical: 2 },
  list_item: { marginVertical: 2 },
  code_inline: {
    backgroundColor: "#E7F8F1",
    color: colors.primaryDark,
    paddingHorizontal: 4,
    borderRadius: radius.sm,
  },
  fence: {
    backgroundColor: "#F3F5F4",
    padding: 10,
    borderRadius: radius.md,
    marginVertical: 4,
  },
  code_block: {
    backgroundColor: "#F3F5F4",
    padding: 10,
    borderRadius: radius.md,
    marginVertical: 4,
  },
  blockquote: {
    borderLeftWidth: 3,
    borderLeftColor: colors.primary,
    paddingLeft: spacing.md,
    marginVertical: 4,
  },
  hr: { marginVertical: 6, backgroundColor: colors.border, height: StyleSheet.hairlineWidth },
});

const styles = StyleSheet.create({
  // Outer page: fills the screen on mobile; on wide desktop browsers it
  // becomes a clean backdrop that centers the phone-sized chat frame.
  page: {
    flex: 1,
    backgroundColor: colors.background,
  },
  pageDesktop: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#D9E4E0",
    padding: 16,
  },
  // Inner frame: full-screen on mobile, phone-shaped on desktop.
  phoneFrame: {
    flex: 1,
    width: "100%",
    backgroundColor: colors.background,
  },
  phoneFrameDesktop: {
    flex: undefined,
    maxWidth: 420,
    borderRadius: 28,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.12,
    shadowRadius: 24,
  },
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  flex: {
    flex: 1,
  },

  header: {
    backgroundColor: colors.primary,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
    paddingHorizontal: spacing.lg,
  },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  headerButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.full,
    marginLeft: 6,
  },

  avatar: {
    width: 36,
    height: 36,
    borderRadius: radius.full,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: spacing.xs,
  },

  headerTextWrap: {
    flex: 1,
    marginLeft: spacing.md,
  },

  headerTitle: {
    color: "#FFFFFF",
    fontSize: 17,
    fontWeight: "700",
  },

  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 2,
  },

  statusDot: {
    width: 7,
    height: 7,
    borderRadius: radius.full,
    marginRight: 5,
  },

  statusText: {
    color: "rgba(255,255,255,0.9)",
    fontSize: 12,
  },

  historyPanel: {
    backgroundColor: colors.cardBackground,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: colors.text,
    marginBottom: spacing.sm,
  },
  historyRow: {
    paddingBottom: spacing.xs,
  },
  historyCard: {
    width: 180,
    backgroundColor: colors.background,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginRight: spacing.sm,
  },
  historyCardActive: {
    borderColor: colors.primary,
    backgroundColor: "#E7F8F1",
  },
  historyCardPressed: {
    opacity: 0.8,
  },
  historyCardTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 6,
  },
  historyCardText: {
    color: colors.textMuted,
    fontSize: 11.5,
    lineHeight: 16,
    minHeight: 32,
  },
  historyCardDate: {
    marginTop: 8,
    color: colors.primaryDark,
    fontSize: 10.5,
    fontWeight: "600",
  },
  banner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FEF3C7",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },

  bannerText: {
    flex: 1,
    color: "#B45309",
    fontSize: 12.5,
    lineHeight: 17,
    marginLeft: spacing.sm,
  },

  bannerAction: {
    padding: spacing.xs,
  },

  bannerDanger: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FEE2E2",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },

  bannerTextDanger: {
    flex: 1,
    color: "#B91C1C",
    fontSize: 12.5,
    lineHeight: 17,
    marginLeft: spacing.sm,
  },

  chatArea: {
    flex: 1,
    backgroundColor: colors.background,
  },

  messagesContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl + spacing.sm,
    paddingBottom: spacing.lg,
  },

  welcomeSection: {
    alignItems: "center",
  },

  welcomeAvatar: {
    width: 72,
    height: 72,
    borderRadius: radius.full,
    backgroundColor: "#E7F8F1",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.lg,
  },

  welcomeBubble: {
    backgroundColor: colors.cardBackground,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
    alignItems: "center",
    maxWidth: "100%",
  },

  welcomeText: {
    color: colors.textMuted,
    fontSize: 13.5,
    lineHeight: 19,
    textAlign: "center",
  },

  welcomeTextBold: {
    color: colors.text,
    fontWeight: "600",
    marginBottom: 4,
  },

  chipLabel: {
    color: colors.textMuted,
    fontSize: 13,
    fontWeight: "600",
    marginTop: spacing.xl,
    alignSelf: "flex-start",
  },

  chips: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: spacing.md,
    alignSelf: "flex-start",
  },

  chip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.cardBackground,
    borderWidth: 1,
    borderColor: "#B4E6D1",
    borderRadius: radius.full,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
    marginRight: spacing.sm,
    marginBottom: spacing.sm,
  },

  chipPressed: {
    opacity: 0.6,
    transform: [{ scale: 0.97 }],
  },

  chipText: {
    color: colors.primaryDark,
    fontSize: 13,
    fontWeight: "600",
    marginLeft: 6,
  },

  userMessageContainer: {
    alignItems: "flex-end",
    marginTop: spacing.lg,
  },

  userBubble: {
    backgroundColor: colors.primary,
    borderRadius: radius.lg,
    borderTopRightRadius: radius.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    maxWidth: "82%",
  },

  userText: {
    color: "#FFFFFF",
    fontSize: 14,
    lineHeight: 19,
  },

  botMessageContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginTop: spacing.lg,
  },

  smallBotIcon: {
    width: 34,
    alignItems: "center",
    justifyContent: "center",
    marginRight: spacing.sm,
    paddingTop: 8,
  },

  botBubble: {
    backgroundColor: colors.cardBackground,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    borderTopLeftRadius: radius.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    maxWidth: "82%",
    flexShrink: 1,
  },

  typingRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 6,
  },

  typingDot: {
    width: 8,
    height: 8,
    borderRadius: radius.full,
    backgroundColor: colors.primary,
    marginHorizontal: 3,
  },

  errorBox: {
    marginTop: spacing.xs,
  },

  errorText: {
    color: "#B91C1C",
    fontSize: 13,
    lineHeight: 18,
  },

  retryButton: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    marginTop: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: "#B4E6D1",
    backgroundColor: "#E7F8F1",
  },

  retryText: {
    color: colors.primaryDark,
    fontSize: 13,
    fontWeight: "700",
    marginLeft: 5,
  },

  sourcesBox: {
    marginTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.sm + 2,
  },
  recommendationImages: {
    gap: spacing.sm,
    paddingTop: spacing.sm,
  },
  recommendationCard: {
    width: 116,
    overflow: "hidden",
    borderRadius: radius.sm,
    backgroundColor: colors.background,
  },
  recommendationImage: {
    width: 116,
    height: 76,
  },
  recommendationName: {
    paddingHorizontal: spacing.xs,
    paddingVertical: 5,
    color: colors.text,
    fontSize: 11,
    fontWeight: "700",
  },

  sourcesToggle: {
    flexDirection: "row",
    alignItems: "center",
  },

  sourcesToggleText: {
    color: colors.textMuted,
    fontSize: 12.5,
    fontWeight: "600",
    marginLeft: 5,
    marginRight: 4,
  },

  sourceItem: {
    marginTop: spacing.sm,
    backgroundColor: "#F3F5F4",
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  sourceName: {
    color: colors.text,
    fontSize: 12.5,
    fontWeight: "700",
  },

  sourceSnippet: {
    color: colors.textMuted,
    fontSize: 12,
    lineHeight: 16,
    marginTop: 2,
  },

  buttonPressed: {
    opacity: 0.6,
  },

  composerWrap: {
    backgroundColor: colors.cardBackground,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },

  composerRow: {
    minHeight: 52,
    borderWidth: 1.5,
    borderColor: "#D3DDE3",
    borderRadius: radius.lg,
    flexDirection: "row",
    alignItems: "flex-end",
    backgroundColor: colors.cardBackground,
  },

  composerRowStreaming: {
    borderColor: "#FCA5A5",
    backgroundColor: "#FFF7F7",
  },

  input: {
    flex: 1,
    maxHeight: 130,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.md - 2,
    paddingBottom: spacing.md - 2,
    color: colors.text,
    fontSize: 14.5,
  },

  sendButton: {
    width: 38,
    height: 38,
    borderRadius: radius.full,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 6,
    marginBottom: 6,
    backgroundColor: colors.primary,
  },

  sendButtonDisabled: {
    backgroundColor: "#E5EEE9",
  },

  sendButtonPressed: {
    transform: [{ scale: 0.92 }],
  },

  stopButton: {
    width: 38,
    height: 38,
    borderRadius: radius.full,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 6,
    marginBottom: 6,
    backgroundColor: "#EF4444",
  },

  stopButtonPressed: {
    transform: [{ scale: 0.92 }],
  },

  charLimit: {
    alignSelf: "flex-end",
    color: colors.textMuted,
    fontSize: 11,
    marginTop: 5,
    marginRight: 6,
  },

  charLimitWarn: {
    color: "#EF4444",
    fontWeight: "700",
  },
});