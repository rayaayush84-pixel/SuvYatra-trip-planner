import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import BSADDatePicker from "../components/BSADDatePicker";
import { todayAdISO } from "../utils/bsDate";
import { sanitizeQuantityText } from "../utils/quantityValidation";
import { useAuth } from "../auth/AuthContext";
import RelevantImage from "../components/RelevantImage";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "PlanMyTrip">;

type ItineraryItem = {
  entityType: string;
  entityId: string;
  name: string;
  description?: string;
  category?: string;
  location?: string;
  address?: string;
  latitude?: number;
  longitude?: number;
  durationMinutes?: number;
  estimatedCost?: number;
  distanceFromPreviousKm?: number;
  currency?: string;
  openingHours?: Record<string, unknown> | string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  source?: string;
  sourceUrl?: string;
  suggestedTimeOfDay?: string;
  isDemoData?: boolean;
  price?: number;
  cuisine?: string[];
  rating?: number;
  reviewCount?: number;
  amenities?: string[];
};

type TripDay = {
  day: number;
  date?: string;
  focus?: string;
  guidance?: Partial<Record<"Morning" | "Afternoon" | "Evening", string>>;
  items: ItineraryItem[];
};

type TripPlan = {
  name: string;
  destination: string;
  startDate?: string;
  endDate?: string;
  durationDays: number;
  adults: number;
  children: number;
  budget?: { amount?: number; currency: string; level?: string };
  travelStyle?: string;
  interests?: string[];
  transportPreference?: string;
  accommodationPreference?: string;
  foodPreferences?: string[];
  days: TripDay[];
  recommendations: {
    hotels: Array<ItineraryItem & { pricePerNight?: number; rating?: number }>;
    transport: Array<ItineraryItem & { type?: string; route?: string; origin?: string; destination?: string }>;
    restaurants: Array<ItineraryItem & { cuisine?: string[]; priceLevel?: string }>;
    weather: { available: boolean; message: string };
    costSummary: {
      currency: string;
      listedActivityCosts: number;
      accommodation: number | null;
      transportation: number | null;
      food: number | null;
      bookingFees: number | null;
      total: number;
      perPerson: number;
      perDay: number;
      note: string;
    };
  };
  dataAvailability: string[];
  warnings: string[];
};

type SavedTrip = Omit<TripPlan, "days"> & {
  _id: string;
  notes?: string;
  itinerary?: TripDay[];
  days?: TripDay[];
  dataAvailability?: string[];
};

function emptyRecommendations(): TripPlan["recommendations"] {
  return {
    hotels: [],
    transport: [],
    restaurants: [],
    weather: { available: false, message: "A forecast is not available for these trip dates." },
    costSummary: {
      currency: "NPR",
      listedActivityCosts: 0,
      accommodation: null,
      transportation: null,
      food: null,
      bookingFees: null,
      total: 0,
      perPerson: 0,
      perDay: 0,
      note: "Known-price estimate only. Unpriced services are excluded.",
    },
  };
}

const TRAVEL_STYLES = ["Adventure", "Nature", "Culture", "Religious", "Relaxation", "Family", "Solo", "Luxury", "Budget", "Mixed"];
const INTERESTS = ["Trekking", "Hiking", "Sightseeing", "Food", "Shopping", "Wildlife", "Photography", "Adventure", "Historical places", "Religious places", "Local experiences"];
const TRANSPORTS = ["Bus", "Tourist bus", "Taxi", "Car", "Jeep", "Motorbike", "Domestic flight", "Mixed"];
const ACCOMMODATIONS = ["Hotel", "Resort", "Hostel", "Guesthouse", "Budget", "Premium"];
const FOOD_PREFERENCES = ["Nepali", "Indian", "Vegetarian", "Non-vegetarian", "Local food", "Fine dining", "Budget food"];

function parseNaturalLanguage(prompt: string) {
  const values: {
    destination?: string;
    durationDays?: number;
    adults?: number;
    budgetAmount?: number;
    interests?: string[];
  } = {};
  const destination = prompt.match(/\b(?:to|in|around)\s+(.+?)(?=\s+(?:for|under|below|with|on|interested|and)\b|[,.;!?]|$)/i);
  if (destination) values.destination = destination[1].trim().replace(/^(?:the\s+)/i, "");
  const duration = prompt.match(/\b(\d{1,2})\s*[- ]?\s*days?\b/i);
  if (duration) values.durationDays = Number(duration[1]);
  const adults = prompt.match(/\b(\d{1,2})\s*(?:people|travelers?|travellers?|persons?|adults?)\b/i);
  if (adults) values.adults = Number(adults[1]);
  const budget = prompt.match(/\b(?:under|below|budget(?:\s+of)?|npr)\s*(?:npr\s*)?([\d,]+)/i);
  if (budget) values.budgetAmount = Number(budget[1].replace(/,/g, ""));
  values.interests = INTERESTS.filter((interest) =>
    new RegExp(interest === "Adventure" ? "adventure|paragliding|rafting|bungee|zipline" : interest, "i").test(prompt)
  );
  return values;
}

function dateIsValid(value: string) {
  if (!value) return true;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

function formatDate(value?: string) {
  if (!value) return "";
  const date = new Date(`${value.slice(0, 10)}T00:00:00.000Z`);
  return Number.isFinite(date.getTime())
    ? date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })
    : "";
}

function withRouteDistances(items: ItineraryItem[]) {
  return items.map((item, index) => {
    const previous = items[index - 1];
    const previousLatitude = previous?.latitude;
    const previousLongitude = previous?.longitude;
    const latitude = item.latitude;
    const longitude = item.longitude;
    if (typeof previousLatitude !== "number" || !Number.isFinite(previousLatitude) ||
        typeof previousLongitude !== "number" || !Number.isFinite(previousLongitude) ||
        typeof latitude !== "number" || !Number.isFinite(latitude) ||
        typeof longitude !== "number" || !Number.isFinite(longitude)) {
      return { ...item, distanceFromPreviousKm: undefined };
    }
    const radians = (degrees: number) => degrees * Math.PI / 180;
    const latitudeDelta = radians(latitude - previousLatitude);
    const longitudeDelta = radians(longitude - previousLongitude);
    const latitude1 = radians(previousLatitude);
    const latitude2 = radians(latitude);
    const arc = Math.min(1, Math.max(0,
      Math.sin(latitudeDelta / 2) ** 2 +
      Math.cos(latitude1) * Math.cos(latitude2) * Math.sin(longitudeDelta / 2) ** 2
    ));
    const distanceFromPreviousKm = Math.round(6371 * 2 *
      Math.atan2(Math.sqrt(arc), Math.sqrt(1 - arc)) * 10) / 10;
    return { ...item, distanceFromPreviousKm };
  });
}

function ToggleGroup({
  label,
  options,
  selected,
  onToggle,
  multi = false,
}: {
  label: string;
  options: string[];
  selected: string | string[];
  onToggle: (option: string) => void;
  multi?: boolean;
}) {
  const active = Array.isArray(selected) ? selected : [selected];
  return (
    <View style={styles.fieldGroup}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.chips}>
        {options.map((option) => {
          const chosen = active.includes(option);
          return (
            <Pressable
              key={option}
              onPress={() => onToggle(option)}
              style={[styles.chip, chosen && styles.chipSelected]}
              accessibilityRole="button"
              accessibilityState={{ selected: chosen }}
            >
              <Text style={[styles.chipText, chosen && styles.chipTextSelected]}>{option}</Text>
            </Pressable>
          );
        })}
      </View>
      {!multi && !active.length ? <Text style={styles.hint}>Optional</Text> : null}
    </View>
  );
}

export default function PlanMyTripScreen({ navigation, route }: Props) {
  const { getAccessToken } = useAuth();
  const [prompt, setPrompt] = useState(route.params?.prompt ?? "");
  const [destination, setDestination] = useState("");
  const [durationDays, setDurationDays] = useState("3");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [adults, setAdults] = useState("");
  const [children, setChildren] = useState("");
  const [budgetAmount, setBudgetAmount] = useState("");
  const [budgetLevel, setBudgetLevel] = useState("");
  const [travelStyle, setTravelStyle] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [transportPreference, setTransportPreference] = useState("");
  const [accommodationPreference, setAccommodationPreference] = useState("");
  const [foodPreferences, setFoodPreferences] = useState<string[]>([]);
  const [plan, setPlan] = useState<TripPlan | null>(null);
  const [tripName, setTripName] = useState("");
  const [savedTripId, setSavedTripId] = useState("");
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [refreshingDay, setRefreshingDay] = useState<number | null>(null);
  const [loadingSavedTrip, setLoadingSavedTrip] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (route.params?.prompt !== undefined) {
      setPrompt(route.params.prompt);
    }
  }, [route.params?.prompt]);

  useEffect(() => {
    const tripId = route.params?.tripId;
    if (!tripId) return;
    const token = getAccessToken();
    if (!token) {
      setError("Sign in to edit a saved trip.");
      return;
    }
    const controller = new AbortController();
    setLoadingSavedTrip(true);
    setError("");
    backendRequest<SavedTrip>(`/trips/${encodeURIComponent(tripId)}`, {
      signal: controller.signal,
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((saved) => {
        const savedPlan: TripPlan = {
          ...saved,
          days: saved.itinerary ?? saved.days ?? [],
          recommendations: saved.recommendations ?? emptyRecommendations(),
          dataAvailability: saved.dataAvailability ?? [],
          warnings: saved.warnings ?? [],
        };
        setSavedTripId(saved._id);
        setPlan(savedPlan);
        setTripName(saved.name);
        setDestination(saved.destination);
        setDurationDays(String(saved.durationDays || savedPlan.days.length || 1));
        setStartDate(saved.startDate?.slice(0, 10) ?? "");
        setEndDate(saved.endDate?.slice(0, 10) ?? "");
        setAdults(String(saved.adults || 1));
        setChildren(String(saved.children || 0));
        setBudgetAmount(saved.budget?.amount === undefined ? "" : String(saved.budget.amount));
        setBudgetLevel(saved.budget?.level ?? "");
        setTravelStyle(saved.travelStyle ?? "");
        setInterests(saved.interests ?? []);
        setTransportPreference(saved.transportPreference ?? "");
        setAccommodationPreference(saved.accommodationPreference ?? "");
        setFoodPreferences(saved.foodPreferences ?? []);
      })
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load the saved trip.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingSavedTrip(false);
      });
    return () => controller.abort();
  }, [getAccessToken, route.params?.tripId]);

  const promptValues = useMemo(() => parseNaturalLanguage(prompt), [prompt]);

  const fillFromPrompt = () => {
    if (promptValues.destination) setDestination(promptValues.destination);
    if (promptValues.durationDays) setDurationDays(String(promptValues.durationDays));
    if (promptValues.adults) setAdults(String(promptValues.adults));
    if (promptValues.budgetAmount !== undefined) setBudgetAmount(String(promptValues.budgetAmount));
    if (promptValues.interests?.length) setInterests(promptValues.interests);
    setNotice("Trip details were extracted from your request. Review them before generating.");
    setError("");
  };

  const toggleMulti = (current: string[], option: string, setValue: (next: string[]) => void) => {
    setValue(current.includes(option)
      ? current.filter((value) => value !== option)
      : [...current, option]);
  };

  const generatePlan = async () => {
    const cleanDestination = destination.trim() || promptValues.destination || "";
    const dayCount = promptValues.durationDays ?? Number(durationDays);
    const adultCount = promptValues.adults ?? Number(adults);
    if (!Number.isInteger(adultCount) || adultCount < 1 || adultCount > 20) {
      setError("Traveler count must be from 1 to 20 adults.");
      return;
    }
    const childCount = children.trim() === "" ? 0 : Number(children);
    if (!Number.isInteger(childCount) || childCount < 0 || childCount > 20 || adultCount + childCount > 20) {
      setError("Child traveler count is invalid.");
      return;
    }
    const budget = budgetAmount.trim() ? Number(budgetAmount.replace(/,/g, "")) : promptValues.budgetAmount;
    const selectedInterests = interests.length ? interests : (promptValues.interests ?? []);
    if (!cleanDestination) {
      setError("Enter a Nepal destination, or add one to your natural-language request.");
      return;
    }
    if (!Number.isInteger(dayCount) || dayCount < 1 || dayCount > 14) {
      setError("Trip duration must be between 1 and 14 days.");
      return;
    }
    if (!dateIsValid(startDate) || !dateIsValid(endDate)) {
      setError("Enter valid travel dates in YYYY-MM-DD format.");
      return;
    }
    if (startDate && endDate && endDate < startDate) {
      setError("The end date must be on or after the start date.");
      return;
    }

    setGenerating(true);
    setError("");
    setNotice("");
    try {
      const result = await backendRequest<{ plan: TripPlan }>("/trips/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: prompt.trim(),
          destination: cleanDestination,
          durationDays: dayCount,
          startDate: startDate || undefined,
          endDate: endDate || undefined,
          adults: adultCount,
          children: childCount,
          budgetAmount: budget,
          budgetLevel: budgetLevel || undefined,
          travelStyle: travelStyle || undefined,
          interests: selectedInterests,
          transportPreference: transportPreference || undefined,
          accommodationPreference: accommodationPreference || undefined,
          foodPreferences,
        }),
      });
      setPlan(result.plan);
      setDestination(result.plan.destination);
      setDurationDays(String(result.plan.durationDays));
      setAdults(String(result.plan.adults));
      setChildren(String(result.plan.children));
      setBudgetAmount(result.plan.budget?.amount === undefined ? "" : String(result.plan.budget.amount));
      setTripName(result.plan.name);
      setNotice("Built from matching stored listings. The plan has not booked any service.");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not generate your itinerary.");
    } finally {
      setGenerating(false);
    }
  };

  const savePlan = async () => {
    if (!plan) return;
    const token = getAccessToken();
    if (!token) {
      setError("Sign in to save this itinerary to your account.");
      return;
    }
    setSaving(true);
    setError("");
    setNotice("");
    const payload = {
      name: tripName.trim() || plan.name,
      destination: plan.destination,
      startDate: plan.startDate,
      endDate: plan.endDate,
      durationDays: plan.durationDays,
      adults: plan.adults,
      children: plan.children,
      budget: plan.budget,
      travelStyle: plan.travelStyle,
      interests: plan.interests,
      transportPreference: plan.transportPreference,
      accommodationPreference: plan.accommodationPreference,
      foodPreferences: plan.foodPreferences,
      itinerary: plan.days,
      recommendations: plan.recommendations,
      dataAvailability: plan.dataAvailability,
      warnings: plan.warnings,
    };
    try {
      const saved = await backendRequest<SavedTrip>(
        savedTripId ? `/trips/${encodeURIComponent(savedTripId)}` : "/trips",
        {
          method: savedTripId ? "PUT" : "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify(savedTripId ? { ...payload, itinerary: plan.days, recommendations: plan.recommendations } : payload),
        }
      );
      setSavedTripId(saved._id);
      setTripName(saved.name);
      setNotice(`"${saved.name}" is saved to My Trips.`);
      // Mirror the complete trip into My Bookings as a trip-type record so
      // it appears there immediately with destination/dates/travellers/total.
      // A booking failure must never undo the saved trip.
      try {
        const total = Number(plan.recommendations?.costSummary?.total);
        await backendRequest("/bookings", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            itemType: "trip",
            tripId: saved._id,
            itemName: `Complete trip to ${saved.destination || plan.destination}`,
            location: saved.destination || plan.destination,
            checkIn: typeof saved.startDate === "string" ? saved.startDate.slice(0, 10) : plan.startDate,
            checkOut: typeof saved.endDate === "string" ? saved.endDate.slice(0, 10) : plan.endDate,
            adults: Number.isInteger(saved.adults) ? saved.adults : plan.adults,
            children: Number.isInteger(saved.children) ? saved.children : plan.children,
            amount: Number.isFinite(total) && total >= 0 ? Math.round(total) : 0,
          }),
        });
        setNotice(`"${saved.name}" is saved to My Trips and My Bookings — open My Bookings to pay.`);
      } catch (bookingError) {
        setNotice(`"${saved.name}" is saved to My Trips. Could not add it to My Bookings: ${bookingError instanceof Error ? bookingError.message : "please try again."}`);
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not save this trip.");
    } finally {
      setSaving(false);
    }
  };

  const updateDayItems = (dayNumber: number, items: ItineraryItem[]) => {
    setPlan((current) => {
      if (!current) return current;
      const days = current.days.map((day) => day.day === dayNumber ? { ...day, items } : day);
      const listedActivityCosts = days.flatMap((day) => day.items)
        .filter((item) => item.entityType === "activity" && Number.isFinite(item.estimatedCost))
        .reduce((total, item) => total + (item.estimatedCost ?? 0), 0);
      const accommodation = current.recommendations.costSummary.accommodation ?? 0;
      const total = listedActivityCosts + accommodation;
      const travelers = current.adults + current.children;
      return {
        ...current,
        days,
        recommendations: {
          ...current.recommendations,
          costSummary: {
            ...current.recommendations.costSummary,
            listedActivityCosts,
            total,
            perPerson: travelers > 0 ? total / travelers : total,
            perDay: current.durationDays > 0 ? total / current.durationDays : total,
          },
        },
      };
    });
  };

  const changeDay = async (day: TripDay, mode: "add" | "refresh") => {
    if (!plan || refreshingDay !== null) return;
    setRefreshingDay(day.day);
    setError("");
    setNotice("");
    try {
      const result = await backendRequest<{ day: TripDay }>("/trips/plan/day", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          destination: plan.destination,
          durationDays: 1,
          dayDate: day.date,
          adults: plan.adults,
          children: plan.children,
          budgetAmount: plan.budget?.amount,
          budgetLevel: plan.budget?.level,
          travelStyle: plan.travelStyle,
          interests: plan.interests,
          transportPreference: plan.transportPreference,
          accommodationPreference: plan.accommodationPreference,
          foodPreferences: plan.foodPreferences,
          excludeEntityIds: day.items.map((item) => item.entityId),
        }),
      });
      const existingItems = day.items;
      const freshItems = result.day.items.filter((item) =>
        !existingItems.some((existing) => existing.entityType === item.entityType && existing.entityId === item.entityId));
      if (mode === "add") {
        const additions = freshItems.slice(0, Math.max(0, 3 - existingItems.length));
        if (!additions.length) {
          setNotice("No additional listed stops are available for this day. Keep some time flexible.");
          return;
        }
        updateDayItems(day.day, withRouteDistances([...existingItems, ...additions].map((item, index) => ({
          ...item,
          suggestedTimeOfDay: ["Morning", "Afternoon", "Evening"][index],
        }))));
        setNotice("Added a stop from the current listings. Save changes to keep it.");
      } else if (!freshItems.length) {
        setNotice("There are no other matching listed stops for this day. Your current plan is unchanged.");
      } else {
        updateDayItems(day.day, freshItems.slice(0, 3));
        setNotice("Refreshed this day using other matching stored listings. Save changes to keep it.");
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update this day right now.");
    } finally {
      setRefreshingDay(null);
    }
  };

  const openMap = (item: ItineraryItem) => {
    navigation.navigate("Map", {
      query: [item.name, item.location].filter(Boolean).join(", "),
      latitude: item.latitude,
      longitude: item.longitude,
    });
  };

  const openHotelBooking = (hotel: ItineraryItem & { pricePerNight?: number }) => {
    if (!plan || !hotel.entityId || !hotel.pricePerNight || hotel.isDemoData !== false) return;
    navigation.navigate("Booking", {
      hotel: {
        id: hotel.entityId,
        name: hotel.name,
        location: hotel.location,
        pricePerNight: hotel.pricePerNight,
        image: hotel.image,
        images: hotel.images,
        imageSource: hotel.imageSource,
        imageSourcePage: hotel.imageSourcePage,
        imageLicense: hotel.imageLicense,
        imageCredit: hotel.imageCredit,
        imageDescription: hotel.imageDescription,
        imageRelevance: hotel.imageRelevance,
        isDemoData: false,
      },
      checkIn: plan.startDate,
      checkOut: plan.endDate,
    });
  };

  const isBookableId = (value?: string) => !!value && /^[0-9a-fA-F]{24}$/.test(value);

  /** Day-level Book Now for activities: opens the guided Complete Trip flow
   *  with this activity preselected, so the user continues through date /
   *  participants → price → demo payment → booking → My Bookings. */
  const openActivityBooking = (item: ItineraryItem) => {
    if (!plan || item.entityType !== "activity" || !isBookableId(item.entityId)) return;
    navigation.navigate("DestinationTrip", {
      destination: plan.destination,
      preselect: { itemType: "activity", itemId: item.entityId },
    });
  };

  const isLoading = generating || saving || loadingSavedTrip || refreshingDay !== null;

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <BackButton navigation={navigation} />
          <Text style={styles.headerTitle}>Plan My Trip</Text>
          <Pressable onPress={() => navigation.navigate("Bookings")} accessibilityRole="button" accessibilityLabel="My bookings">
            <Ionicons name="receipt-outline" size={22} color={colors.primary} />
          </Pressable>
        </View>

        <View style={styles.hero}>
          <RelevantImage entity={{ name: "Nepal", type: "country", location: "Nepal" }} style={styles.heroImage} />
          <View style={styles.heroOverlay}>
            <Text style={styles.heroTitle}>A Nepal trip that fits you</Text>
            <Text style={styles.heroSubtitle}>Itineraries are assembled from stored, verified listings—not generated business claims.</Text>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Start with a request</Text>
          <Text style={styles.hint}>Try: “Plan me a 5 day trip to Pokhara for 2 people under NPR 50,000 with adventure activities.”</Text>
          <TextInput
            value={prompt}
            onChangeText={setPrompt}
            placeholder="Describe the trip you have in mind"
            placeholderTextColor={colors.textMuted}
            multiline
            textAlignVertical="top"
            style={[styles.input, styles.promptInput]}
            accessibilityLabel="Trip request in natural language"
          />
          <Pressable style={styles.outlineButton} onPress={fillFromPrompt}>
            <Ionicons name="sparkles-outline" size={17} color={colors.primaryDark} />
            <Text style={styles.outlineButtonText}>Use details from request</Text>
          </Pressable>

          <Text style={styles.sectionTitle}>Trip details</Text>
          <Text style={styles.label}>Destination in Nepal</Text>
          <TextInput value={destination} onChangeText={setDestination} placeholder="e.g. Pokhara, Kathmandu, Chitwan" placeholderTextColor={colors.textMuted} style={styles.input} accessibilityLabel="Trip destination" returnKeyType="search" onSubmitEditing={() => void generatePlan()} />

          <View style={styles.row}>
            <View style={styles.halfField}>
              <Text style={styles.label}>Duration (days)</Text>
              <TextInput value={durationDays} onChangeText={setDurationDays} keyboardType="number-pad" placeholder="3" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="go" onSubmitEditing={() => void generatePlan()} />
            </View>
            <View style={styles.halfField}>
              <Text style={styles.label}>Adults</Text>
              <TextInput value={adults} onChangeText={(value) => setAdults(sanitizeQuantityText(value))} keyboardType="number-pad" maxLength={3} placeholder="2" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="go" onSubmitEditing={() => void generatePlan()} />
            </View>
            <View style={styles.halfField}>
              <Text style={styles.label}>Children</Text>
              <TextInput value={children} onChangeText={(value) => setChildren(sanitizeQuantityText(value))} keyboardType="number-pad" maxLength={3} placeholder="0" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="go" onSubmitEditing={() => void generatePlan()} />
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.halfField}>
              <BSADDatePicker
                label="Start date (optional)"
                value={startDate}
                onChange={setStartDate}
                minDate={todayAdISO()}
                placeholder="Select start date"
              />
            </View>
            <View style={styles.halfField}>
              <BSADDatePicker
                label="End date (optional)"
                value={endDate}
                onChange={setEndDate}
                minDate={startDate || todayAdISO()}
                placeholder="Select end date"
              />
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.halfField}>
              <Text style={styles.label}>Budget (NPR, optional)</Text>
              <TextInput value={budgetAmount} onChangeText={setBudgetAmount} keyboardType="number-pad" placeholder="e.g. 50000" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="go" onSubmitEditing={() => void generatePlan()} />
            </View>
            <View style={styles.halfField}>
              <Text style={styles.label}>Budget level</Text>
              <View style={styles.chips}>
                {["Budget", "Moderate", "Premium"].map((level) => (
                  <Pressable key={level} onPress={() => setBudgetLevel(budgetLevel === level ? "" : level)} style={[styles.chip, budgetLevel === level && styles.chipSelected]}>
                    <Text style={[styles.chipText, budgetLevel === level && styles.chipTextSelected]}>{level}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          </View>

          <ToggleGroup label="Travel style" options={TRAVEL_STYLES} selected={travelStyle} onToggle={(value) => setTravelStyle(travelStyle === value ? "" : value)} />
          <ToggleGroup label="Interests" options={INTERESTS} selected={interests} onToggle={(value) => toggleMulti(interests, value, setInterests)} multi />
          <ToggleGroup label="Transport preference" options={TRANSPORTS} selected={transportPreference} onToggle={(value) => setTransportPreference(transportPreference === value ? "" : value)} />
          <ToggleGroup label="Accommodation preference" options={ACCOMMODATIONS} selected={accommodationPreference} onToggle={(value) => setAccommodationPreference(accommodationPreference === value ? "" : value)} />
          <ToggleGroup label="Food preferences" options={FOOD_PREFERENCES} selected={foodPreferences} onToggle={(value) => toggleMulti(foodPreferences, value, setFoodPreferences)} multi />

          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          {notice ? <Text style={styles.noticeText}>{notice}</Text> : null}
          <Pressable style={[styles.primaryButton, isLoading && styles.disabled]} onPress={() => void generatePlan()} disabled={isLoading}>
            {generating ? <ActivityIndicator color="#FFFFFF" /> : <Ionicons name="map-outline" size={19} color="#FFFFFF" />}
            <Text style={styles.primaryButtonText}>{generating ? "Building itinerary…" : plan ? "Regenerate Trip" : "Generate My Trip"}</Text>
          </Pressable>
          {loadingSavedTrip ? <ActivityIndicator style={styles.loading} color={colors.primary} /> : null}
        </View>

        {plan ? (
          <View style={styles.results}>
            <View style={styles.resultHeading}>
              <View style={styles.resultHeadingText}>
                <Text style={styles.eyebrow}>YOUR ITINERARY</Text>
                <Text style={styles.resultTitle}>{plan.destination}</Text>
                <Text style={styles.hint}>{plan.durationDays} days · {plan.adults} adults{plan.children ? ` · ${plan.children} children` : ""}{plan.startDate ? ` · ${formatDate(plan.startDate)}` : ""}{plan.endDate && plan.endDate !== plan.startDate ? ` – ${formatDate(plan.endDate)}` : ""}</Text>
              </View>
              <Ionicons name="map" size={24} color={colors.primary} />
            </View>

            <Text style={styles.hint}>Named places below come from stored listings. Flexible time is planning guidance, not a confirmed activity or schedule.</Text>

            {plan.days.map((day) => (
              <View key={day.day} style={styles.dayCard}>
                <View style={styles.dayHeading}>
                  <View>
                    <Text style={styles.dayTitle}>Day {day.day}{day.focus ? ` — ${day.focus}` : ""}</Text>
                    {day.date ? <Text style={styles.dayDate}>{formatDate(day.date)}</Text> : null}
                  </View>
                  <Pressable
                    style={styles.dayAction}
                    onPress={() => void changeDay(day, "refresh")}
                    disabled={refreshingDay !== null}
                    accessibilityRole="button"
                    accessibilityLabel={`Refresh day ${day.day}`}
                  >
                    {refreshingDay === day.day
                      ? <ActivityIndicator size="small" color={colors.primary} />
                      : <Ionicons name="refresh-outline" size={16} color={colors.primaryDark} />}
                    <Text style={styles.dayActionText}>Refresh day</Text>
                  </Pressable>
                </View>
                {(["Morning", "Afternoon", "Evening"] as const)
                  .filter((period) => !day.items.some((item) => item.suggestedTimeOfDay === period))
                  .map((period) => (
                    <View key={period} style={styles.flexibleSlot}>
                      <Text style={styles.timeLabel}>{period}</Text>
                      <Text style={styles.metaText}>{day.guidance?.[period] || `Keep this time flexible while exploring ${plan.destination}.`}</Text>
                    </View>
                  ))}
                {day.items.map((item) => (
                  <View key={`${item.entityType}-${item.entityId}`} style={styles.itemCard}>
                    <RelevantImage
                      entity={{
                        id: item.entityId,
                        name: item.name,
                        type: item.entityType,
                        location: item.location,
                        image: item.image,
                        images: item.images,
                        imageSource: item.imageSource,
                        imageSourcePage: item.imageSourcePage,
                        imageLicense: item.imageLicense,
                        imageCredit: item.imageCredit,
                        imageDescription: item.imageDescription,
                        imageRelevance: item.imageRelevance,
                      }}
                      style={styles.itemImage}
                    />
                    <View style={styles.itemContent}>
                      <Text style={styles.timeLabel}>{item.suggestedTimeOfDay} · {item.entityType}</Text>
                      <Text style={styles.itemTitle}>{item.name}</Text>
                      <Text style={styles.itemLocation}>{item.location || "Location not listed"}</Text>
                      {item.description ? <Text style={styles.itemDescription}>{item.description}</Text> : null}
                      <View style={styles.itemMeta}>
                        {item.durationMinutes !== undefined ? <Text style={styles.metaText}>{item.durationMinutes} min listed</Text> : null}
                        {item.distanceFromPreviousKm !== undefined ? <Text style={styles.metaText}>{item.distanceFromPreviousKm} km straight-line from the previous listed stop</Text> : null}
                        {item.estimatedCost !== undefined ? <Text style={styles.metaText}>NPR {item.estimatedCost.toLocaleString()} listed; not a guaranteed price</Text> : null}
                        {!item.estimatedCost && item.entityType === "activity" ? <Text style={styles.metaText}>Activity price not listed</Text> : null}
                      </View>
                      <View style={styles.itemActions}>
                        <Pressable style={styles.mapButton} onPress={() => openMap(item)}>
                          <Ionicons name="navigate-outline" size={15} color={colors.primaryDark} />
                          <Text style={styles.mapButtonText}>Open in Maps</Text>
                        </Pressable>
                        {item.entityType === "activity" && isBookableId(item.entityId) ? (
                          <Pressable
                            style={styles.bookNowButton}
                            onPress={() => openActivityBooking(item)}
                            accessibilityRole="button"
                            accessibilityLabel={`Book ${item.name} now`}
                          >
                            <Ionicons name="ticket-outline" size={15} color="#FFFFFF" />
                            <Text style={styles.bookNowButtonText}>
                              Book Now{item.estimatedCost !== undefined ? ` · NPR ${item.estimatedCost.toLocaleString()}` : ""}
                            </Text>
                          </Pressable>
                        ) : null}
                        <Pressable
                          style={styles.mapButton}
                          onPress={() => {
                            updateDayItems(day.day, withRouteDistances(day.items.filter((current) =>
                              current.entityId !== item.entityId || current.entityType !== item.entityType)));
                            setNotice("Removed from the itinerary. Save changes to keep the update.");
                          }}
                          accessibilityRole="button"
                          accessibilityLabel={`Remove ${item.name} from day ${day.day}`}
                        >
                          <Ionicons name="close-circle-outline" size={15} color={colors.primaryDark} />
                          <Text style={styles.mapButtonText}>Remove</Text>
                        </Pressable>
                      </View>
                    </View>
                  </View>
                ))}
                {day.items.length < 3 ? (
                  <Pressable
                    style={styles.addStopButton}
                    onPress={() => void changeDay(day, "add")}
                    disabled={refreshingDay !== null}
                    accessibilityRole="button"
                  >
                    <Ionicons name="add-circle-outline" size={16} color={colors.primaryDark} />
                    <Text style={styles.mapButtonText}>Add a listed stop</Text>
                  </Pressable>
                ) : null}
              </View>
            ))}

            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>Accommodation recommendations</Text>
              <Text style={styles.hint}>Recommendations use stored listings; rooms are not reserved or confirmed.</Text>
              {plan.recommendations.hotels.length ? plan.recommendations.hotels.map((hotel) => (
                <View key={hotel.entityId} style={styles.recommendationCard}>
                  <RelevantImage
                    entity={{
                      id: hotel.entityId,
                      name: hotel.name,
                      type: "hotel",
                      location: hotel.location,
                      image: hotel.image,
                      images: hotel.images,
                      imageSource: hotel.imageSource,
                      imageSourcePage: hotel.imageSourcePage,
                      imageLicense: hotel.imageLicense,
                      imageCredit: hotel.imageCredit,
                      imageDescription: hotel.imageDescription,
                      imageRelevance: hotel.imageRelevance,
                    }}
                    style={styles.recommendationImage}
                  />
                  <View style={styles.recommendationInfo}>
                    <Text style={styles.itemTitle}>{hotel.name}</Text>
                    <Text style={styles.itemLocation}>{hotel.location || "Location not listed"}</Text>
                    {typeof hotel.rating === "number" ? (
                      <Text style={styles.metaText}>★ {hotel.rating}{typeof hotel.reviewCount === "number" ? ` (${hotel.reviewCount} reviews)` : ""}</Text>
                    ) : null}
                    {hotel.pricePerNight !== undefined ? <Text style={styles.metaText}>NPR {hotel.pricePerNight.toLocaleString()} / night listed; estimate only</Text> : <Text style={styles.metaText}>Nightly rate not listed</Text>}
                    {!!hotel.amenities?.length ? <Text style={styles.metaText}>Amenities: {hotel.amenities.slice(0, 5).join(" · ")}</Text> : null}
                    <Pressable style={styles.mapButton} onPress={() => navigation.push("HotelDetails", { hotelId: hotel.entityId })}>
                      <Text style={styles.mapButtonText}>View hotel details</Text>
                    </Pressable>
                    {hotel.isDemoData === false && hotel.pricePerNight ? (
                      <Pressable
                        style={styles.bookNowButton}
                        onPress={() => openHotelBooking(hotel)}
                        accessibilityRole="button"
                        accessibilityLabel={`Book ${hotel.name} now`}
                      >
                        <Ionicons name="bed-outline" size={15} color="#FFFFFF" />
                        <Text style={styles.bookNowButtonText}>Book Now · NPR {hotel.pricePerNight.toLocaleString()}/night</Text>
                      </Pressable>
                    ) : null}
                  </View>
                </View>
              )) : (
                <View>
                  <Text style={styles.emptyText}>No matching stay is listed for these dates.</Text>
                  <Pressable style={styles.mapButton} onPress={() => navigation.navigate("Hotels")}>
                    <Text style={styles.mapButtonText}>Browse hotels</Text>
                  </Pressable>
                </View>
              )}
            </View>

            {(plan.recommendations.restaurants ?? []).length ? (
              <View style={styles.sectionCard}>
                <Text style={styles.sectionTitle}>Food near your trip</Text>
                <Text style={styles.hint}>Restaurant suggestions use stored listings; opening hours and reservations are not confirmed.</Text>
                {(plan.recommendations.restaurants ?? []).map((restaurant) => (
                  <View key={restaurant.entityId} style={styles.transportRow}>
                    <RelevantImage
                      entity={{
                        id: restaurant.entityId,
                        name: restaurant.name,
                        type: "restaurant",
                        location: restaurant.location,
                        image: restaurant.image,
                        images: restaurant.images,
                        imageSource: restaurant.imageSource,
                        imageSourcePage: restaurant.imageSourcePage,
                        imageLicense: restaurant.imageLicense,
                        imageCredit: restaurant.imageCredit,
                        imageDescription: restaurant.imageDescription,
                        imageRelevance: restaurant.imageRelevance,
                      }}
                      style={styles.transportImage}
                    />
                    <View style={styles.transportInfo}>
                      <Text style={styles.itemTitle}>{restaurant.name}</Text>
                      <Text style={styles.itemLocation}>{restaurant.location || "Location not listed"}</Text>
                      {restaurant.cuisine?.length ? <Text style={styles.metaText}>{restaurant.cuisine.join(", ")}</Text> : null}
                      <Pressable style={styles.mapButton} onPress={() => openMap(restaurant)}>
                        <Text style={styles.mapButtonText}>Open in Maps</Text>
                      </Pressable>
                    </View>
                  </View>
                ))}
              </View>
            ) : null}

            {plan.recommendations.transport.length ? (
              <View style={styles.sectionCard}>
                <Text style={styles.sectionTitle}>Transport options</Text>
                <Text style={styles.hint}>Stored options only; schedules, seats, and live availability are not confirmed.</Text>
                {plan.recommendations.transport.map((vehicle) => (
                <View key={vehicle.entityId} style={styles.transportRow}>
                  <RelevantImage
                    entity={{
                      id: vehicle.entityId,
                      name: vehicle.name,
                      type: "transport",
                      location: vehicle.route ?? vehicle.location,
                      image: vehicle.image,
                      images: vehicle.images,
                      imageSource: vehicle.imageSource,
                      imageSourcePage: vehicle.imageSourcePage,
                      imageLicense: vehicle.imageLicense,
                      imageCredit: vehicle.imageCredit,
                      imageDescription: vehicle.imageDescription,
                      imageRelevance: vehicle.imageRelevance,
                    }}
                    style={styles.transportImage}
                  />
                  <View style={styles.transportInfo}>
                    <Text style={styles.itemTitle}>{vehicle.name}</Text>
                    <Text style={styles.itemLocation}>{vehicle.route || [vehicle.origin, vehicle.destination].filter(Boolean).join(" → ") || vehicle.location || "Route not listed"}</Text>
                    {vehicle.price !== undefined ? <Text style={styles.metaText}>NPR {vehicle.price.toLocaleString()} listed; route applicability is not confirmed</Text> : null}
                  </View>
                </View>
                ))}
              </View>
            ) : null}

            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>Estimated costs</Text>
              <Text style={styles.bodyText}>{plan.recommendations.costSummary.note}</Text>
              {plan.recommendations.costSummary.total > 0 ? (
                <View>
                  <Text style={styles.bodyText}>Known-price subtotal: NPR {Math.round(plan.recommendations.costSummary.total).toLocaleString()}</Text>
                  <Text style={styles.bodyText}>Even split per traveler: NPR {Math.round(plan.recommendations.costSummary.perPerson).toLocaleString()}</Text>
                  <Text style={styles.bodyText}>Known-price average per day: NPR {Math.round(plan.recommendations.costSummary.perDay).toLocaleString()}</Text>
                  {plan.recommendations.costSummary.accommodation !== null ? <Text style={styles.bodyText}>One-room stay estimate: NPR {plan.recommendations.costSummary.accommodation.toLocaleString()}</Text> : null}
                  {plan.recommendations.costSummary.listedActivityCosts > 0 ? <Text style={styles.bodyText}>Listed activity prices: NPR {plan.recommendations.costSummary.listedActivityCosts.toLocaleString()}</Text> : null}
                </View>
              ) : <Text style={styles.bodyText}>No numeric listing prices were available for this itinerary; ask providers for current rates.</Text>}
            </View>

            {(plan.dataAvailability ?? []).length ? (
              <View style={styles.availabilityNote}>
                <Text style={styles.hint}>Planning note: {plan.dataAvailability.join(" ")}</Text>
              </View>
            ) : null}

            <View style={styles.card}>
              <Text style={styles.sectionTitle}>{savedTripId ? "Edit saved trip" : "Save this trip"}</Text>
              <Text style={styles.hint}>Saving stores the itinerary with your account and adds the complete trip to My Bookings; it does not create individual service bookings.</Text>
              <Text style={styles.label}>Trip name</Text>
              <TextInput value={tripName} onChangeText={setTripName} placeholder="Give this trip a name" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="done" onSubmitEditing={() => { if (!saving && !loadingSavedTrip) void savePlan(); }} />
              <Pressable style={[styles.primaryButton, (saving || loadingSavedTrip) && styles.disabled]} onPress={() => void savePlan()} disabled={saving || loadingSavedTrip}>
                {saving ? <ActivityIndicator color="#FFFFFF" /> : <Ionicons name="bookmark-outline" size={18} color="#FFFFFF" />}
                <Text style={styles.primaryButtonText}>{saving ? "Saving…" : savedTripId ? "Save changes" : "Save Trip"}</Text>
              </Pressable>
              {!getAccessToken() ? (
                <Pressable style={styles.outlineButton} onPress={() => navigation.navigate("Login", { notice: "Sign in to save your trip itinerary." })}>
                  <Text style={styles.outlineButtonText}>Sign in to save</Text>
                </Pressable>
              ) : null}
              <Pressable
                style={styles.outlineButton}
                onPress={() => navigation.navigate("DestinationTrip", { destination: destination.trim() || undefined })}
                accessibilityRole="button"
                accessibilityLabel="Book this trip end to end"
              >
                <Ionicons name="airplane-outline" size={18} color={colors.primaryDark} />
                <Text style={styles.outlineButtonText}>Book this trip end-to-end</Text>
              </Pressable>
            </View>
          </View>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: 110 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md },
  headerTitle: { color: colors.text, fontSize: 20, fontWeight: "800" },
  hero: { height: 170, borderRadius: radius.lg, overflow: "hidden", backgroundColor: "#0F766E", marginBottom: spacing.md },
  heroImage: StyleSheet.absoluteFill,
  heroOverlay: { flex: 1, justifyContent: "flex-end", padding: spacing.lg, backgroundColor: "rgba(8,28,34,0.45)" },
  heroTitle: { color: "#FFFFFF", fontSize: 22, fontWeight: "900" },
  heroSubtitle: { color: "#FFFFFF", fontSize: 12, lineHeight: 17, marginTop: 4 },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, marginBottom: spacing.md },
  sectionCard: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, marginBottom: spacing.md },
  sectionTitle: { color: colors.text, fontSize: 16, fontWeight: "800", marginTop: spacing.sm },
  hint: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: 4 },
  label: { color: colors.text, fontSize: 12, fontWeight: "700", marginTop: spacing.md, marginBottom: 5 },
  input: { minHeight: 43, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border, paddingHorizontal: spacing.md, color: colors.text, backgroundColor: "#FFFFFF", fontSize: 13 },
  promptInput: { minHeight: 76, paddingTop: spacing.sm, marginTop: spacing.md },
  fieldGroup: { marginTop: spacing.md },
  row: { flexDirection: "row", gap: spacing.sm },
  halfField: { flex: 1, minWidth: 0 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 7 },
  chip: { borderRadius: 20, borderWidth: 1, borderColor: colors.border, backgroundColor: "#FFFFFF", paddingVertical: 7, paddingHorizontal: 10 },
  chipSelected: { backgroundColor: "#E4F3EF", borderColor: colors.primary },
  chipText: { color: colors.textMuted, fontSize: 11, fontWeight: "700" },
  chipTextSelected: { color: colors.primaryDark },
  outlineButton: { minHeight: 40, borderRadius: radius.md, borderWidth: 1, borderColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, marginTop: spacing.sm, paddingHorizontal: spacing.md },
  outlineButtonText: { color: colors.primaryDark, fontSize: 12, fontWeight: "800" },
  primaryButton: { minHeight: 47, borderRadius: radius.md, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, marginTop: spacing.md, paddingHorizontal: spacing.md },
  primaryButtonText: { color: "#FFFFFF", fontSize: 13, fontWeight: "800" },
  disabled: { opacity: 0.65 },
  errorText: { color: "#B42318", fontSize: 12, lineHeight: 17, marginTop: spacing.sm },
  noticeText: { color: colors.primaryDark, fontSize: 12, lineHeight: 17, marginTop: spacing.sm },
  loading: { marginTop: spacing.md },
  results: { marginTop: spacing.sm },
  resultHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginVertical: spacing.md },
  resultHeadingText: { flex: 1 },
  eyebrow: { color: colors.primaryDark, fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  resultTitle: { color: colors.text, fontSize: 24, fontWeight: "900", marginTop: 3 },
  disclaimer: { flexDirection: "row", alignItems: "flex-start", gap: spacing.sm, borderRadius: radius.md, backgroundColor: "#FFF7E5", padding: spacing.md, marginBottom: spacing.md },
  disclaimerText: { flex: 1, color: "#714D00", fontSize: 11, lineHeight: 16 },
  dayCard: { backgroundColor: "#F0F6F4", borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.md },
  dayHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.sm },
  dayTitle: { color: colors.text, fontSize: 17, fontWeight: "900" },
  dayDate: { color: colors.textMuted, fontSize: 11 },
  dayAction: { minHeight: 34, flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: spacing.sm },
  dayActionText: { color: colors.primaryDark, fontSize: 10, fontWeight: "800" },
  flexibleSlot: { borderLeftWidth: 2, borderLeftColor: colors.border, paddingLeft: spacing.sm, marginTop: spacing.xs },
  itemCard: { flexDirection: "row", backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, overflow: "hidden", marginTop: spacing.sm },
  itemImage: { width: 95, minHeight: 132 },
  itemContent: { flex: 1, minWidth: 0, padding: spacing.sm },
  timeLabel: { color: colors.primaryDark, fontSize: 9, fontWeight: "800", textTransform: "uppercase" },
  itemTitle: { color: colors.text, fontSize: 13, lineHeight: 17, fontWeight: "800", marginTop: 3 },
  itemLocation: { color: colors.textMuted, fontSize: 10, lineHeight: 14, marginTop: 3 },
  itemDescription: { color: colors.text, fontSize: 10, lineHeight: 15, marginTop: 5 },
  itemMeta: { gap: 3, marginTop: 5 },
  itemActions: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", columnGap: spacing.md, rowGap: 6 },
  metaText: { color: colors.textMuted, fontSize: 9, lineHeight: 13 },
  mapButton: { flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-start", marginTop: 6 },
  mapButtonText: { color: colors.primaryDark, fontSize: 10, fontWeight: "800" },
  bookNowButton: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, marginTop: 8, backgroundColor: colors.primary, borderRadius: radius.sm, paddingVertical: 9, paddingHorizontal: 10 },
  bookNowButtonText: { color: "#FFFFFF", fontSize: 11, fontWeight: "800" },
  addStopButton: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, marginTop: spacing.sm },
  recommendationCard: { flexDirection: "row", backgroundColor: "#FFFFFF", borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, overflow: "hidden", marginTop: spacing.sm },
  recommendationImage: { width: 105, minHeight: 105 },
  recommendationInfo: { flex: 1, padding: spacing.sm },
  emptyText: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: spacing.sm },
  transportRow: { flexDirection: "row", alignItems: "center", borderTopWidth: 1, borderTopColor: colors.border, paddingVertical: spacing.sm, marginTop: spacing.sm },
  transportImage: { width: 60, height: 55, borderRadius: radius.sm, overflow: "hidden" },
  transportInfo: { flex: 1, marginLeft: spacing.sm },
  bodyText: { color: colors.text, fontSize: 12, lineHeight: 18, marginTop: spacing.sm },
  availabilityNote: { paddingHorizontal: spacing.sm, paddingBottom: spacing.md },
  warningText: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: spacing.xs },
});
