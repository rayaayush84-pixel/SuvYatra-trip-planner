import React, { useState } from "react";
import { Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "Search">;
type SearchCategory = {
  label: string;
  module?: "activity" | "shopping" | "petrol" | "hospital" | "atm";
  route?: "Hotels" | "Restaurants" | "Transport";
  icon: keyof typeof Ionicons.glyphMap;
};

const CATEGORIES: SearchCategory[] = [
  { label: "Hotels", route: "Hotels", icon: "bed-outline" },
  { label: "Restaurants", route: "Restaurants", icon: "restaurant-outline" },
  { label: "Transportation", route: "Transport", icon: "bus-outline" },
  { label: "Activities", module: "activity", icon: "trail-sign-outline" },
  { label: "Shopping", module: "shopping", icon: "bag-outline" },
  { label: "Petrol Pumps & EV Charging", module: "petrol", icon: "car-outline" },
  { label: "Hospitals & Health Services", module: "hospital", icon: "medkit-outline" },
  { label: "ATMs & Banking", module: "atm", icon: "card-outline" },
];

export default function SearchScreen({ navigation }: Props) {
  const [query, setQuery] = useState("");
  const chooseCategory = (category: SearchCategory, search = query.trim()) => {
    if (category.route === "Hotels") navigation.push("Hotels", { location: search });
    else if (category.route === "Restaurants") navigation.push("Restaurants", { location: search });
    else if (category.route === "Transport") navigation.push("Transport", { location: search });
    else if (category.module) navigation.push("PlaceDirectory", { module: category.module, search });
  };
  const submit = () => {
    const value = query.trim().toLocaleLowerCase();
    const routeMatch = query.trim().match(/^(.+?)\s*(?:→|\bto\b)\s*(.+)$/i);
    if (routeMatch) {
      navigation.push("Transport", {
        origin: routeMatch[1].trim(),
        destination: routeMatch[2].trim(),
      });
      return;
    }
    if (/\b(atm|cash withdrawal|bank branch|currency exchange)\b/.test(value)) {
      chooseCategory(CATEGORIES[7], query.trim());
      return;
    }
    if (/\b(hospital|emergency|clinic|pharmacy|dental|eye care)\b/.test(value)) {
      chooseCategory(CATEGORIES[6], query.trim());
      return;
    }
    if (/\b(petrol|diesel|fuel|ev charging|charging station)\b/.test(value)) {
      chooseCategory(CATEGORIES[5], query.trim());
      return;
    }
    if (/\b(shopping|souvenir|handicraft|market|mall|trekking gear)\b/.test(value)) {
      chooseCategory(CATEGORIES[4], query.trim());
      return;
    }
    const selected = CATEGORIES.find((category) => value.includes(category.label.toLocaleLowerCase()));
    if (selected) {
      const search = query.trim().replace(new RegExp(selected.label, "i"), "").replace(/^\s*(in|near|for)\s+/i, "").trim();
      chooseCategory(selected, search);
      return;
    }
    if (value.includes("restaurant") || value.includes("food") || value.includes("cafe")) chooseCategory(CATEGORIES[1]);
    else if (/\b(bus|jeep|taxi|transport|route|bike rental|car rental)\b/.test(value)) chooseCategory(CATEGORIES[2]);
    else if (value) chooseCategory(CATEGORIES[3], query.trim());
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <BackButton navigation={navigation} iconSize={24} />
        <Text style={styles.title}>Discover SuvYatra</Text>
        <View style={styles.spacer} />
      </View>
      <View style={styles.searchBox}>
        <Ionicons name="search-outline" size={21} color={colors.primary} />
        <TextInput value={query} onChangeText={setQuery} onSubmitEditing={submit} placeholder="Search activities, food, routes, places…" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="search" />
        <Pressable onPress={submit} accessibilityRole="button" accessibilityLabel="Search"><Ionicons name="arrow-forward-circle" size={26} color={colors.primary} /></Pressable>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.subtitle}>Choose what you’re looking for. Search results come from SuvYatra’s verified database listings.</Text>
        {CATEGORIES.map((category) => (
          <Pressable key={category.label} onPress={() => chooseCategory(category)} style={styles.category}>
            <View style={styles.icon}><Ionicons name={category.icon} size={21} color={colors.primary} /></View>
            <Text style={styles.categoryText}>{category.label}</Text>
            <Ionicons name="chevron-forward" size={19} color={colors.textMuted} />
          </Pressable>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.lg, paddingTop: spacing.md },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.lg },
  title: { color: colors.text, fontSize: 20, fontWeight: "800" },
  spacer: { width: 24 },
  searchBox: { flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: colors.surface, borderRadius: radius.md, paddingHorizontal: spacing.md, marginBottom: spacing.md, borderWidth: 1, borderColor: colors.border, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.05, shadowRadius: 10, elevation: 1 },
  input: { flex: 1, color: colors.text, paddingVertical: 14, fontSize: 13 },
  content: { paddingBottom: 110 },
  subtitle: { color: colors.textMuted, fontSize: 13, lineHeight: 20, marginBottom: spacing.md },
  category: { flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, marginBottom: spacing.sm, gap: spacing.md, borderWidth: 1, borderColor: colors.border },
  icon: { width: 40, height: 40, borderRadius: 12, backgroundColor: "#E8F3F0", alignItems: "center", justifyContent: "center" },
  categoryText: { flex: 1, color: colors.text, fontSize: 14, fontWeight: "700" },
});
