import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";
import RelevantImage from "../components/RelevantImage";

type Props = NativeStackScreenProps<RootStackParamList, "Restaurants">;
type Restaurant = {
  _id: string;
  name: string;
  category?: string;
  location?: string;
  address?: string;
  city?: string;
  district?: string;
  province?: string;
  destination?: string;
  cuisine?: string[];
  foodTypes?: string[];
  mealTimes?: string[];
  facilities?: string[];
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  menuUrl?: string;
  priceRange?: string;
  rating?: number;
  reviewCount?: number;
  openingHours?: Record<string, string>;
  contact?: { phone?: string; website?: string };
  nearbyAttractions?: string[];
  latitude?: number;
  longitude?: number;
};
type RestaurantFilters = {
  cities: string[];
  districts: string[];
  provinces: string[];
  cuisines: string[];
  categories: string[];
  foodTypes: string[];
  mealTimes: string[];
  facilities: string[];
  priceRanges: string[];
};
type SavedItem = { _id: string; itemType: string; itemId?: string };

const EMPTY_FILTERS: RestaurantFilters = {
  cities: [],
  districts: [],
  provinces: [],
  cuisines: [],
  categories: [],
  foodTypes: [],
  mealTimes: [],
  facilities: [],
  priceRanges: [],
};
const RESTAURANT_CATEGORIES = [
  "Nepali Cuisine", "Indian", "Asian", "Italian / Continental", "Vegetarian", "Vegan",
  "BBQ / Grill", "Fast Food", "Cafés & Coffee", "Bakery & Desserts", "Fine Dining",
  "Local / Traditional Food", "Street Food",
];
const RESTAURANT_FACILITIES = [
  "Family-friendly", "Outdoor seating", "Rooftop", "Lake view", "Mountain view", "Delivery",
];

export default function RestaurantListScreen({ navigation, route }: Props) {
  const { getAccessToken, user } = useAuth();
  const [query, setQuery] = useState(route.params?.location ?? "");
  const [submittedQuery, setSubmittedQuery] = useState(route.params?.location?.trim() ?? "");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [selectedCuisine, setSelectedCuisine] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedFoodType, setSelectedFoodType] = useState("");
  const [selectedMealTime, setSelectedMealTime] = useState("");
  const [selectedFacility, setSelectedFacility] = useState("");
  const [selectedPriceRange, setSelectedPriceRange] = useState("");
  const [openNow, setOpenNow] = useState(false);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [savedItem, setSavedItem] = useState<SavedItem | null>(null);
  const [loading, setLoading] = useState(false);
  const [filtersLoading, setFiltersLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (route.params?.location !== undefined) {
      setQuery(route.params.location);
      setSubmittedQuery(route.params.location.trim());
    }
  }, [route.params?.location]);

  useEffect(() => {
    const timeout = setTimeout(() => setSubmittedQuery(query.trim()), 350);
    return () => clearTimeout(timeout);
  }, [query]);

  const searchParams = useMemo(() => {
    const params = new URLSearchParams();
    if (submittedQuery) params.set("search", submittedQuery);
    if (selectedCuisine) params.set("cuisine", selectedCuisine);
    if (selectedCity) params.set("city", selectedCity);
    if (selectedCategory) params.set("category", selectedCategory);
    if (selectedFoodType) params.set("foodType", selectedFoodType);
    if (selectedMealTime) params.set("mealTime", selectedMealTime);
    if (selectedFacility) params.set("facility", selectedFacility);
    if (selectedPriceRange) params.set("priceRange", selectedPriceRange);
    if (openNow) params.set("openNow", "true");
    return params.toString();
  }, [openNow, selectedCategory, selectedCity, selectedCuisine, selectedFacility, selectedFoodType, selectedMealTime, selectedPriceRange, submittedQuery]);

  useEffect(() => {
    const controller = new AbortController();
    setFiltersLoading(true);
    backendRequest<RestaurantFilters>("/restaurants/filters", { signal: controller.signal })
      .then(setFilters)
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not load restaurant filters.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setFiltersLoading(false);
      });
    return () => controller.abort();
  }, [reloadKey]);

  useEffect(() => {
    if (route.params?.restaurantId) {
      const controller = new AbortController();
      setLoading(true);
      setError("");
      backendRequest<Restaurant>(`/restaurants/${encodeURIComponent(route.params.restaurantId)}`, {
        signal: controller.signal,
      })
        .then(setRestaurant)
        .catch((requestError: unknown) => {
          if (!controller.signal.aborted) {
            setError(requestError instanceof Error ? requestError.message : "Could not load restaurant details.");
          }
        })
        .finally(() => {
          if (!controller.signal.aborted) setLoading(false);
        });
      return () => controller.abort();
    }
    const controller = new AbortController();
    setLoading(true);
    setError("");
    backendRequest<Restaurant[]>(`/restaurants?${searchParams}`, { signal: controller.signal })
      .then(setRestaurants)
      .catch((requestError: unknown) => {
        if (!controller.signal.aborted) {
          setError(requestError instanceof Error ? requestError.message : "Could not search restaurants.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [reloadKey, route.params?.restaurantId, searchParams]);

  useEffect(() => {
    const token = getAccessToken();
    const restaurantId = restaurant?._id;
    if (!token || !restaurantId) {
      setSavedItem(null);
      return;
    }
    const controller = new AbortController();
    backendRequest<SavedItem[]>("/saved-items", {
      signal: controller.signal,
      headers: { Authorization: `Bearer ${token}` },
    }).then((items) => {
      if (!controller.signal.aborted) {
        setSavedItem(items.find((item) => item.itemType === "restaurant" && item.itemId === restaurantId) ?? null);
      }
    }).catch((requestError: unknown) => {
      if (!controller.signal.aborted) {
        setError(requestError instanceof Error ? requestError.message : "Could not check Saved Places.");
      }
    });
    return () => controller.abort();
  }, [getAccessToken, restaurant?._id, reloadKey]);

  const openMaps = (place: Restaurant) => {
    const queryText = place.latitude !== undefined && place.longitude !== undefined
      ? `${place.latitude},${place.longitude}`
      : [place.name, place.address, place.location, place.city].filter(Boolean).join(", ");
    return Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(queryText)}`);
  };

  const toggleSaved = async (place: Restaurant) => {
    const token = getAccessToken();
    if (!token) {
      navigation.navigate("Login", { notice: "Sign in to save restaurants." });
      return;
    }
    setSaving(true);
    setError("");
    try {
      if (savedItem) {
        await backendRequest(`/saved-items/${savedItem._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedItem(null);
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            itemType: "restaurant",
            itemId: place._id,
            name: place.name,
            location: place.location ?? place.city,
            image: place.image,
            imageSource: place.imageSource,
            imageSourcePage: place.imageSourcePage,
            imageLicense: place.imageLicense,
            imageCredit: place.imageCredit,
            imageDescription: place.imageDescription,
            imageRelevance: place.imageRelevance,
          }),
        });
        setSavedItem(saved);
      }
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSaving(false);
    }
  };

  const addToTrip = (place: Restaurant) => {
    navigation.navigate("MainTabs", {
      screen: "Trips",
      params: {
        destination: {
          id: place._id,
          category: "restaurant",
          name: place.name,
          location: place.location ?? place.city ?? place.district,
          description: `Restaurant${place.cuisine?.length ? ` · ${place.cuisine.join(", ")}` : ""}`,
          image: place.image,
          latitude: place.latitude,
          longitude: place.longitude,
          tags: ["restaurant", ...(place.cuisine ?? [])],
        },
      },
    });
  };

  const clearFilters = () => {
    setQuery("");
    setSubmittedQuery("");
    setSelectedCuisine("");
    setSelectedCity("");
    setSelectedCategory("");
    setSelectedFoodType("");
    setSelectedMealTime("");
    setSelectedFacility("");
    setSelectedPriceRange("");
    setOpenNow(false);
  };

  const renderDetails = (place: Restaurant) => (
    <View style={styles.detailPanel}>
      {place.address ? <Text style={styles.bodyText}>{place.address}</Text> : null}
      {place.description ? <Text style={styles.bodyText}>{place.description}</Text> : null}
      {place.menuUrl ? (
        <Pressable onPress={() => void Linking.openURL(place.menuUrl!)}>
          <Text style={styles.linkText}>Open menu</Text>
        </Pressable>
      ) : null}
      {place.contact?.phone ? <Text style={styles.bodyText}>Phone: {place.contact.phone}</Text> : null}
      {place.contact?.website ? <Text style={styles.bodyText}>Website: {place.contact.website}</Text> : null}
      {place.nearbyAttractions?.length ? <Text style={styles.bodyText}>Nearby attractions: {place.nearbyAttractions.join(", ")}</Text> : null}
      {place.openingHours && Object.keys(place.openingHours).length
        ? Object.entries(place.openingHours).map(([day, hours]) => (
          <Text key={day} style={styles.bodyText}>{day}: {hours}</Text>
        ))
        : <Text style={styles.mutedText}>Opening hours unavailable.</Text>}
      <Text style={styles.caveat}>Availability shown in the trip planner is demo inventory, not live provider data.</Text>
      <Pressable
        style={styles.primaryButton}
        onPress={() => navigation.navigate("DestinationTrip", {
          destination: place.destination || place.city || "",
          preselect: { itemType: "restaurant", itemId: place._id },
        })}
        accessibilityRole="button"
        accessibilityLabel={`Reserve a table at ${place.name}`}
      >
        <Ionicons name="calendar-outline" size={18} color={colors.white} />
        <Text style={styles.primaryButtonText}>Reserve a table</Text>
      </Pressable>
      <View style={styles.actionRow}>
        {place.contact?.phone ? <ActionButton label="Call" icon="call-outline" onPress={() => void Linking.openURL(`tel:${place.contact?.phone}`)} /> : null}
        <ActionButton label="Maps" icon="map-outline" onPress={() => void openMaps(place)} />
        <ActionButton label="Save" icon={savedItem ? "heart" : "heart-outline"} onPress={() => void toggleSaved(place)} disabled={saving} />
        <ActionButton label="Add to Trip" icon="add-circle-outline" onPress={() => addToTrip(place)} />
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} />
        <Text style={styles.title}>{restaurant ? restaurant.name : "Restaurants"}</Text>
        <View style={styles.headerSpacer} />
      </View>
      {!restaurant ? (
        <View style={styles.controls}>
          <View style={styles.searchBox}>
            <Ionicons name="search-outline" size={19} color={colors.textMuted} />
            <TextInput value={query} onChangeText={setQuery} placeholder="Name, cuisine, city, or area" placeholderTextColor={colors.textMuted} style={styles.input} returnKeyType="search" onSubmitEditing={() => setSubmittedQuery(query.trim())} />
          </View>
          <FilterRow title="Cuisine" values={filters.cuisines} selected={selectedCuisine} onSelect={setSelectedCuisine} loading={filtersLoading} />
          <FilterRow title="City" values={filters.cities} selected={selectedCity} onSelect={setSelectedCity} loading={filtersLoading} />
          <FilterRow title="Category" values={[...new Set([...RESTAURANT_CATEGORIES, ...filters.categories])]} selected={selectedCategory} onSelect={setSelectedCategory} loading={filtersLoading} />
          <FilterRow title="Diet" values={["Vegetarian", "Vegan", ...filters.foodTypes.filter((value) => !["vegetarian", "vegan"].includes(value.toLowerCase()))]} selected={selectedFoodType} onSelect={setSelectedFoodType} loading={filtersLoading} />
          <FilterRow title="Meal" values={filters.mealTimes.length ? filters.mealTimes : ["Breakfast", "Lunch", "Dinner"]} selected={selectedMealTime} onSelect={setSelectedMealTime} loading={filtersLoading} />
          <FilterRow title="Facilities" values={[...new Set([...RESTAURANT_FACILITIES, ...filters.facilities])]} selected={selectedFacility} onSelect={setSelectedFacility} loading={filtersLoading} />
          <View style={styles.filterFooter}>
            <Text style={styles.mutedText}>Open-now uses stored Nepal-local opening hours only.</Text>
            <Pressable onPress={() => setOpenNow((value) => !value)} style={[styles.chip, openNow && styles.selectedChip]}><Text style={[styles.chipText, openNow && styles.selectedChipText]}>Open now</Text></Pressable>
          </View>
          <FilterRow title="Price" values={["Any", ...filters.priceRanges]} selected={selectedPriceRange} onSelect={(value) => setSelectedPriceRange(value === "Any" ? "" : value)} loading={filtersLoading} />
          <View style={styles.filterFooter}>
            <Text style={styles.mutedText}>Verified listings only</Text>
            <Pressable onPress={clearFilters} accessibilityRole="button"><Text style={styles.linkText}>Clear all filters</Text></Pressable>
          </View>
        </View>
      ) : null}
      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} /><Text style={styles.mutedText}>Loading verified restaurant data…</Text></View>
      ) : error ? (
        <View style={styles.center}><Text style={styles.errorText}>{error}</Text><Pressable onPress={() => setReloadKey((value) => value + 1)}><Text style={styles.linkText}>Try again</Text></Pressable></View>
      ) : restaurant ? (
        <ScrollView contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          <RelevantImage entity={{ name: restaurant.name, type: "restaurant", location: [restaurant.address, restaurant.location, restaurant.city].filter(Boolean).join(", "), image: restaurant.image, images: restaurant.images, imageSource: restaurant.imageSource, imageSourcePage: restaurant.imageSourcePage, imageLicense: restaurant.imageLicense, imageCredit: restaurant.imageCredit, imageDescription: restaurant.imageDescription, imageRelevance: restaurant.imageRelevance }} style={styles.detailImage} />
          <Text style={styles.name}>{restaurant.name}</Text>
          <Text style={styles.bodyText}>{[restaurant.cuisine?.join(", "), restaurant.category].filter(Boolean).join(" · ") || "Cuisine unavailable"}</Text>
          <Text style={styles.mutedText}>{[restaurant.address, restaurant.location, restaurant.city, restaurant.district, restaurant.province].filter(Boolean).join(", ") || "Location unavailable"}</Text>
          {restaurant.priceRange ? <Text style={styles.bodyText}>Price range: {restaurant.priceRange}</Text> : null}
          {restaurant.rating !== undefined ? <Text style={styles.bodyText}>Rating: {restaurant.rating}{restaurant.reviewCount !== undefined ? ` (${restaurant.reviewCount})` : ""}</Text> : null}
          {restaurant.description ? <Text style={styles.bodyText}>{restaurant.description}</Text> : null}
          {renderDetails(restaurant)}
        </ScrollView>
      ) : (
        <FlatList
          data={restaurants}
          keyExtractor={(item) => item._id}
          contentContainerStyle={restaurants.length ? styles.list : styles.emptyList}
          ListEmptyComponent={<View style={styles.center}><Ionicons name="restaurant-outline" size={30} color={colors.primary} /><Text style={styles.emptyTitle}>No verified restaurant listings</Text><Text style={styles.mutedText}>Search or clear filters. Listings appear here after verified data is added to SuvYatra.</Text></View>}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <RelevantImage entity={{ name: item.name, type: "restaurant", location: [item.address, item.location, item.city].filter(Boolean).join(", "), image: item.image, images: item.images, imageSource: item.imageSource, imageSourcePage: item.imageSourcePage, imageLicense: item.imageLicense, imageCredit: item.imageCredit, imageDescription: item.imageDescription, imageRelevance: item.imageRelevance }} style={styles.image} />
              <Pressable onPress={() => navigation.push("Restaurants", { restaurantId: item._id })} style={styles.cardText}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.bodyText}>{[item.cuisine?.join(", "), item.category].filter(Boolean).join(" · ") || "Cuisine unavailable"}</Text>
                <Text style={styles.mutedText}>{[item.address, item.location, item.city, item.district].filter(Boolean).join(", ") || "Location unavailable"}</Text>
                {item.priceRange ? <Text style={styles.bodyText}>{item.priceRange}</Text> : null}
                {item.rating !== undefined ? <Text style={styles.bodyText}>★ {item.rating}{item.reviewCount !== undefined ? ` (${item.reviewCount})` : ""}</Text> : null}
              </Pressable>
              <Pressable accessibilityRole="button" accessibilityLabel={`View ${item.name} details`} onPress={() => navigation.push("Restaurants", { restaurantId: item._id })}>
                <Ionicons name="chevron-forward" size={20} color={colors.primary} />
              </Pressable>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
}

function FilterRow({ title, values, selected, onSelect, loading }: {
  title: string;
  values: string[];
  selected: string;
  onSelect: (value: string) => void;
  loading: boolean;
}) {
  if (loading || !values.length) return null;
  return (
    <View style={styles.filterBlock}>
      <Text style={styles.filterTitle}>{title}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
        {values.map((value) => (
          <Pressable key={value} onPress={() => onSelect(selected === value ? "" : value)} style={[styles.chip, selected === value && styles.selectedChip]}>
            <Text style={[styles.chipText, selected === value && styles.selectedChipText]}>{value}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function ActionButton({ label, icon, onPress, disabled }: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  disabled?: boolean;
}) {
  return <Pressable disabled={disabled} onPress={onPress} style={styles.actionButton}><Ionicons name={icon} size={17} color={colors.primary} /><Text style={styles.actionText}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  title: { color: colors.text, fontSize: 19, fontWeight: "800", flex: 1, textAlign: "center" },
  headerSpacer: { width: 24 },
  controls: { paddingHorizontal: spacing.lg, paddingBottom: spacing.sm },
  searchBox: { flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, borderRadius: radius.md, paddingHorizontal: spacing.md, marginBottom: spacing.sm },
  input: { flex: 1, color: colors.text, paddingVertical: 12, marginLeft: 8 },
  filterBlock: { marginTop: spacing.xs },
  filterTitle: { color: colors.textMuted, fontSize: 12, fontWeight: "700", marginBottom: 5 },
  chips: { gap: 7, paddingBottom: 4 },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 6, backgroundColor: colors.surface },
  selectedChip: { backgroundColor: colors.primary, borderColor: colors.primary },
  chipText: { color: colors.text, fontSize: 12 },
  selectedChipText: { color: colors.white, fontWeight: "700" },
  filterFooter: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 6 },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 110 },
  emptyList: { flexGrow: 1, justifyContent: "center", padding: spacing.xl },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl, gap: spacing.sm },
  emptyTitle: { fontSize: 17, color: colors.text, fontWeight: "800", textAlign: "center" },
  mutedText: { color: colors.textMuted, fontSize: 12, lineHeight: 18, textAlign: "center" },
  errorText: { color: "#B42318", textAlign: "center" },
  linkText: { color: colors.primary, fontWeight: "700", paddingVertical: 5 },
  card: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md, gap: spacing.md },
  image: { width: 82, height: 82, borderRadius: radius.sm, backgroundColor: colors.border },
  detailImage: { width: "100%", height: 220, borderRadius: radius.md, marginBottom: spacing.md },
  cardText: { flex: 1, minWidth: 150, gap: 3 },
  name: { fontSize: 15, fontWeight: "800", color: colors.text },
  bodyText: { color: colors.text, fontSize: 12, lineHeight: 18 },
  detailPanel: { width: "100%", gap: 5, borderTopWidth: 1, borderColor: colors.border, paddingTop: spacing.sm },
  caveat: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: spacing.sm },
  primaryButton: { minHeight: 48, borderRadius: radius.md, backgroundColor: colors.primary, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm, marginTop: spacing.sm },
  primaryButtonText: { color: colors.white, fontSize: 14, fontWeight: "800" },
  actionRow: { flexDirection: "row", justifyContent: "space-between", marginTop: spacing.sm },
  actionButton: { flexDirection: "row", alignItems: "center", gap: 4, padding: 5 },
  actionText: { fontSize: 11, color: colors.primary, fontWeight: "700" },
});
