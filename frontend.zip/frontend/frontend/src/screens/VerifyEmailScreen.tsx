import React, { useState } from "react";
import {
  ActivityIndicator,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAuth } from "../auth/AuthContext";
import { radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "VerifyEmail">;

const AUTH_BG =
  require("../../../assets/WhatsApp Image 2026-09-10 at 11.13.41 PM (1).jpeg");

export default function VerifyEmailScreen({ navigation, route }: Props) {
  const { verifyRegisterOtp, resendRegisterOtp } = useAuth();
  const [email] = useState(route.params?.email ?? "");
  const [otp, setOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState(
    "A 6-digit verification code was sent to your Gmail. It expires in 10 minutes."
  );
  const [submitted, setSubmitted] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  React.useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [cooldown]);

  const otpError =
    submitted && !/^\d{6}$/.test(otp.trim())
      ? "Please enter the 6-digit code from your email."
      : "";

  const verify = async () => {
    setSubmitted(true);
    setError("");
    if (!/^\d{6}$/.test(otp.trim())) return;
    setBusy(true);
    try {
      const profile = await verifyRegisterOtp(email, otp.trim());
      navigation.reset({
        index: 0,
        routes: [{ name: profile?.role === "admin" ? "AdminDashboard" : "MainTabs" }],
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not verify the code.");
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    if (cooldown > 0) return;
    setError("");
    setBusy(true);
    try {
      await resendRegisterOtp(email);
      setCooldown(45);
      setNotice("A new code was sent to your Gmail. Check inbox and spam.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not resend the code.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.hero}>
          <ImageBackground source={AUTH_BG} style={styles.heroImage} resizeMode="cover">
            <View style={styles.heroOverlay} />
            <BackButton navigation={navigation} style={styles.backButton} iconColor="#FFFFFF" />
            <View style={styles.brandBlock}>
              <Text style={styles.brandText}>SuvYatra</Text>
              <Text style={styles.brandTagline}>Verify your Gmail</Text>
            </View>
          </ImageBackground>
        </View>

        <ScrollView
          style={styles.formScroll}
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.formPanel}>
            <Text style={styles.title}>Enter verification code</Text>
            <Text style={styles.subtitle}>
              Code sent to <Text style={styles.emailBold}>{email}</Text>
            </Text>

            <Text style={styles.fieldLabel}>6-digit code</Text>
            <View style={[styles.fieldBox, !!otpError && styles.fieldBoxError]}>
              <Ionicons name="key-outline" size={18} color="#64748B" />
              <TextInput
                value={otp}
                onChangeText={(v) => {
                  setOtp(v.replace(/\D/g, "").slice(0, 6));
                  setError("");
                }}
                placeholder="123456"
                placeholderTextColor="#9CA3AF"
                style={styles.fieldInput}
                keyboardType="number-pad"
                maxLength={6}
                autoFocus
                onSubmitEditing={() => void verify()}
              />
            </View>
            {!!otpError && <Text style={styles.fieldError}>{otpError}</Text>}

            <Pressable
              style={({ pressed }) => [
                styles.submitButton,
                busy && styles.submitButtonDisabled,
                pressed && !busy && styles.submitButtonPressed,
              ]}
              onPress={verify}
              disabled={busy}
              accessibilityRole="button"
            >
              {busy ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <Text style={styles.submitText}>Verify & Create Account</Text>
              )}
            </Pressable>

            <Pressable
              style={styles.resendRow}
              onPress={resend}
              disabled={busy || cooldown > 0}
              accessibilityRole="button"
            >
              <Text style={[styles.resendText, (busy || cooldown > 0) && styles.resendDisabled]}>
                {cooldown > 0 ? `Resend code in ${cooldown}s` : "Resend code"}
              </Text>
            </Pressable>

            {!!notice && (
              <View style={styles.notice} accessibilityRole="alert">
                <Text style={styles.noticeText}>{notice}</Text>
              </View>
            )}
            {!!error && (
              <View style={styles.authError} accessibilityRole="alert">
                <Text style={styles.authErrorText}>{error}</Text>
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFFFFF" },
  flex: { flex: 1 },
  hero: { height: 220, width: "100%" },
  heroImage: { flex: 1, justifyContent: "center" },
  heroOverlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: "rgba(10, 28, 49, 0.28)",
  },
  backButton: {
    position: "absolute",
    top: spacing.md,
    left: spacing.lg,
    zIndex: 2,
    width: 42,
    height: 42,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(15, 23, 42, 0.28)",
  },
  brandBlock: { alignItems: "center", paddingHorizontal: spacing.xl, paddingTop: spacing.lg },
  brandText: { color: "#FFFFFF", fontSize: 38, lineHeight: 44, fontWeight: "900" },
  brandTagline: { color: "#FFFFFF", fontSize: 15, fontWeight: "700", marginTop: spacing.xs },
  formScroll: { flex: 1, marginTop: -24, backgroundColor: "transparent" },
  content: { flexGrow: 1 },
  formPanel: {
    flexGrow: 1,
    width: "100%",
    maxWidth: 520,
    alignSelf: "center",
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: spacing.xl,
  },
  title: { fontSize: 22, lineHeight: 28, fontWeight: "800", color: "#102A43" },
  subtitle: { fontSize: 13, lineHeight: 19, color: "#64748B", marginTop: 4, marginBottom: spacing.lg },
  emailBold: { fontWeight: "800", color: "#102A43" },
  fieldLabel: { fontSize: 12, fontWeight: "700", color: "#52657A", marginBottom: 6 },
  fieldBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#D8E2EE",
    borderRadius: 12,
    paddingHorizontal: spacing.md,
    minHeight: 52,
    gap: spacing.sm,
  },
  fieldBoxError: { borderColor: "#EF4444" },
  fieldInput: { flex: 1, color: "#102A43", fontSize: 20, letterSpacing: 6, paddingVertical: spacing.sm },
  fieldError: { color: "#DC2626", fontSize: 12, marginTop: 4 },
  submitButton: {
    backgroundColor: "#2878E8",
    minHeight: 50,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginTop: spacing.lg,
  },
  submitButtonDisabled: { backgroundColor: "#AFCBF1" },
  submitButtonPressed: { opacity: 0.82 },
  submitText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" },
  resendRow: { alignSelf: "center", marginTop: spacing.md, paddingVertical: 6 },
  resendText: { color: "#2878E8", fontSize: 13, fontWeight: "800" },
  resendDisabled: { color: "#9CA3AF" },
  notice: {
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: "#A7F3D0",
    backgroundColor: "#ECFDF5",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginTop: spacing.md,
  },
  noticeText: { color: "#047857", fontSize: 13, lineHeight: 19, textAlign: "center" },
  authError: {
    borderWidth: 1,
    borderColor: "#FECACA",
    backgroundColor: "#FEF2F2",
    borderRadius: 12,
    padding: spacing.md,
    marginTop: spacing.md,
  },
  authErrorText: { color: "#B91C1C", fontSize: 13, lineHeight: 19 },
});
