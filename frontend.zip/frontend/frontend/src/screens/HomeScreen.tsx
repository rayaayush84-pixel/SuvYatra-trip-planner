import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  SafeAreaView,
  Image,
  Pressable,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Modal,
  KeyboardAvoidingView,
  Platform,
  useWindowDimensions,
} from "react-native";

import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { DestinationDetails, navigateToScreen, RootStackParamList } from "../../App";
import { colors, spacing, radius } from "../theme";
import RelevantImage from "../components/RelevantImage";
import SaveToast from "../components/SaveToast";
import { useAuth } from "../auth/AuthContext";
import { backendRequest } from "../services/backendApi";
import {
  Ionicons,
  MaterialCommunityIcons,
} from "@expo/vector-icons";

type NavigationProp =
  NativeStackNavigationProp<RootStackParamList>;

type SavedItem = { _id: string; itemType: string; itemId?: string; name: string };

// ======================================================
// CATEGORIES
// ======================================================

const categories = [
  {
    id: 1,
    name: "Hidden Gems",
    icon: "map-marker",
    color: "#5546D9",
  },
  {
    id: 2,
    name: "Hotels",
    icon: "office-building",
    color: "#3670C8",
  },
  {
    id: 4,
    name: "Transportation",
    icon: "car",
    color: "#5546D9",
  },
  {
    id: 5,
    name: "Activities",
    icon: "hiking",
    color: "#4B8B35",
  },
];

// ======================================================
// HOME SCREEN
// ======================================================

const HomeScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();

  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const isWeb = Platform.OS === "web";
  const { width: windowWidth, height: windowHeight } = useWindowDimensions();
  // Compact mobile-shaped popup on desktop/laptop; nearly full-screen
  // bottom sheet on narrow/mobile screens.
  const isCompactChat = isWeb && windowWidth >= 520;
  const chatWindowWidth = isCompactChat ? 400 : "100%";
  const chatWindowHeight = isCompactChat
    ? Math.min(700, Math.max(420, windowHeight - 40))
    : Math.round(windowHeight * 0.92);

  // Single submit path for the mini-chat: send button and Enter both use it.
  const submitHomeChat = () => {
    const prompt = chatInput.trim();
    if (!prompt) return;
    setIsChatOpen(false);
    setChatInput("");
    navigation.navigate("Chat", { prompt });
  };
  const [popularDestinations, setPopularDestinations] = useState<DestinationDetails[]>([]);
  const [destinationsLoading, setDestinationsLoading] = useState(true);
  const [destinationsError, setDestinationsError] = useState("");
  const { getAccessToken, user } = useAuth();
  const userId = user?._id ?? user?.id;
  const [savedMap, setSavedMap] = useState<Record<string, SavedItem>>({});
  const [savingId, setSavingId] = useState("");
  const [toast, setToast] = useState("");
  const [toastKey, setToastKey] = useState(0);
  const showToast = (message: string) => {
    setToast(message);
    setToastKey((key) => key + 1);
  };

  const savedKeyFor = (destination: DestinationDetails) =>
    destination.id != null ? String(destination.id) : `name:${destination.name.trim().toLocaleLowerCase()}`;

  useFocusEffect(useCallback(() => {
    let active = true;
    setDestinationsLoading(true);
    backendRequest<Array<{
      _id: string;
      name: string;
      province?: string;
      country?: string;
      description?: string;
      image?: string;
      images?: string[];
      imageSource?: string;
      imageSourcePage?: string;
      imageLicense?: string;
      imageCredit?: string;
      imageDescription?: string;
      imageRelevance?: "entity" | "category";
      highlights?: string[];
    }>>("/destinations?featured=popular").then((records) => {
      if (!active) return;
      setPopularDestinations(records.map((record) => ({
        id: record._id,
        name: record.name,
        location: [record.province, record.country].filter(Boolean).join(", ") || "Location not listed",
        rating: "",
        reviews: "",
        description: record.description || "Destination information is not available yet.",
        bestTime: "Not specified",
        price: "Not listed",
        image: record.image || "",
        images: record.images,
        imageSource: record.imageSource,
        imageSourcePage: record.imageSourcePage,
        imageLicense: record.imageLicense,
        imageCredit: record.imageCredit,
        imageDescription: record.imageDescription,
        imageRelevance: record.imageRelevance,
        hiddenGems: record.highlights || [],
        categories: ["Book Hotel", "Book Jeep", "Book Bike", "Book Bus", "Book Activities"],
      })));
      setDestinationsError("");
    }).catch((error: unknown) => {
      if (active) setDestinationsError(error instanceof Error ? error.message : "Could not load destinations.");
    }).finally(() => {
      if (active) setDestinationsLoading(false);
    });
    return () => { active = false; };
  }, []));

  useFocusEffect(useCallback(() => {
    const token = getAccessToken();
    if (!token || !userId) {
      if (!token) setSavedMap({});
      return;
    }
    const controller = new AbortController();
    backendRequest<SavedItem[]>(`/saved-items?userId=${encodeURIComponent(userId)}`, {
      signal: controller.signal,
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((items) => {
        if (!controller.signal.aborted) {
          const map: Record<string, SavedItem> = {};
          for (const item of items) {
            if (item.itemType !== "destination") continue;
            const key = item.itemId ?? `name:${item.name.trim().toLocaleLowerCase()}`;
            map[key] = item;
          }
          setSavedMap(map);
        }
      })
      .catch(() => {});
    return () => controller.abort();
  }, [getAccessToken, userId]));

  const toggleSavedDestination = async (destination: DestinationDetails) => {
    const token = getAccessToken();
    if (!token || !userId) {
      navigation.navigate("Login", { notice: "Sign in to save destinations to Saved Places." });
      return;
    }
    const key = savedKeyFor(destination);
    setSavingId(key);
    try {
      const existing = savedMap[key];
      if (existing) {
        await backendRequest(`/saved-items/${existing._id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${token}` },
        });
        setSavedMap((current) => {
          const next = { ...current };
          delete next[key];
          return next;
        });
        showToast("Removed from saved");
      } else {
        const saved = await backendRequest<SavedItem>("/saved-items", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            userId,
            itemType: "destination",
            itemId: destination.id,
            name: destination.name,
            location: destination.location,
            image: destination.image,
            imageSource: destination.imageSource,
            imageSourcePage: destination.imageSourcePage,
            imageLicense: destination.imageLicense,
            imageCredit: destination.imageCredit,
            imageDescription: destination.imageDescription,
            imageRelevance: destination.imageRelevance,
          }),
        });
        setSavedMap((current) => ({ ...current, [key]: saved }));
        showToast("Saved to your places");
      }
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Could not update Saved Places.");
    } finally {
      setSavingId("");
    }
  };

  const handleCategoryPress = (categoryName: string) => {
    const normalized = categoryName.trim();
    const screenMap: Record<string, { screen: Exclude<keyof RootStackParamList, "ResetPassword">; params?: Record<string, string> }> = {
      "Hidden Gems": { screen: "HiddenGems" },
      "hidden gems": { screen: "HiddenGems" },
      Hotels: { screen: "Hotels" },
      hotels: { screen: "Hotels" },
      Restaurants: { screen: "Restaurants" },
      restaurants: { screen: "Restaurants" },
      "Resturents": { screen: "Restaurants" },
      "resturents": { screen: "Restaurants" },
      Transportation: { screen: "Transport" },
      transportation: { screen: "Transport" },
      Activities: { screen: "PlaceDirectory", params: { module: "activity" } },
      activities: { screen: "PlaceDirectory", params: { module: "activity" } },
      Shopping: { screen: "PlaceDirectory", params: { module: "shopping" } },
      shopping: { screen: "PlaceDirectory", params: { module: "shopping" } },
      "Petrol Pump": { screen: "PlaceDirectory", params: { module: "petrol" } },
      "petrol pump": { screen: "PlaceDirectory", params: { module: "petrol" } },
      Hospital: { screen: "PlaceDirectory", params: { module: "hospital" } },
      hospital: { screen: "PlaceDirectory", params: { module: "hospital" } },
      ATM: { screen: "PlaceDirectory", params: { module: "atm" } },
      atm: { screen: "PlaceDirectory", params: { module: "atm" } },
      More: { screen: "Search" },
      more: { screen: "Search" },
    };

    const destination = screenMap[normalized] ?? screenMap[normalized.toLowerCase()];
    if (destination) {
      navigateToScreen(destination.screen, destination.params);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.brandLockup}>
            <View style={styles.brandMark}>
              <Ionicons name="compass-outline" size={21} color="#0F766E" />
            </View>
            <Text style={styles.brand}>
              Suv<Text style={styles.brandAccent}>Yatra</Text>
            </Text>
          </View>

          <TouchableOpacity style={styles.chatBubble} onPress={() => setIsChatOpen(true)}>
            <View style={styles.chatIconWrap}>
              <Ionicons name="chatbubble-ellipses-outline" size={20} color="#0F766E" />
            </View>
            <View style={styles.chatText}>
              <Text style={styles.chatTitle}>Chat with SuvYatra</Text>
              <Text style={styles.chatSubtitle}>Need help planning your trip?</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.heroIntro}>
          <View style={styles.eyebrowRow}>
            <View style={styles.eyebrowMark} />
            <Text style={styles.eyebrow}>YOUR NEXT JOURNEY STARTS HERE</Text>
          </View>
          <Text style={styles.pageTitle}>Find your next{"\n"}Nepal escape</Text>
          <Text style={styles.heroSupporting}>
            Places to go, stays to love, and journeys worth remembering.
          </Text>
        </View>

        <TouchableOpacity
          style={styles.guidedTripCard}
          onPress={() => navigation.navigate("DestinationTrip", {})}
          accessibilityRole="button"
          accessibilityLabel="Plan a complete trip"
          accessibilityHint="Opens the guided destination trip planner"
        >
          <View style={styles.guidedTripText}>
            <Text style={styles.guidedTripEyebrow}>GUIDED END-TO-END JOURNEY</Text>
            <Text style={styles.guidedTripTitle}>Plan a Complete Trip</Text>
            <Text style={styles.guidedTripSubtitle}>Pick any destination for transport, stay, activities, bookings & return — all in one flow.</Text>
          </View>
          <View style={styles.guidedTripArrow}>
            <Ionicons name="arrow-forward" size={19} color="#0F766E" />
          </View>
        </TouchableOpacity>

        <View style={styles.banner}>
          <Image
            source={require("../../../assets/1.jpeg")}
            style={StyleSheet.absoluteFill}
            resizeMode="cover"
            accessibilityLabel="Himalayan mountain valley in Nepal"
          />
          <View style={styles.bannerOverlay}>
            <Text style={styles.bannerTitle}>GO BEYOND THE USUAL</Text>
            <Text style={styles.bannerSubtitle}>Discover Nepal</Text>
            <Text style={styles.bannerTagline}>Find the places that stay with you.</Text>
            <TouchableOpacity
              style={styles.exploreButton}
              onPress={() => {
                const destination = popularDestinations[0];
                if (destination) navigation.push("Destination", { destination });
                else navigation.navigate("Search");
              }}
            >
              <Text style={styles.exploreButtonText}>Explore Now</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Categories</Text>
        </View>

        <View style={styles.categoriesGrid}>
          {categories.map((category) => (
            <TouchableOpacity key={category.id} style={styles.categoryItem} onPress={() => handleCategoryPress(category.name)}>
              <View style={[styles.categoryIcon, { backgroundColor: category.color + "18" }]}>
                <MaterialCommunityIcons name={category.icon as any} size={30} color={category.color} />
              </View>
              <Text style={styles.categoryName}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.destinationsHeader}>
          <Text style={styles.sectionTitle}>Popular Destinations</Text>
        </View>

        {destinationsLoading ? <ActivityIndicator color="#0F766E" /> : null}
        {destinationsError ? <Text style={styles.destinationNotice}>{destinationsError}</Text> : null}
        {!destinationsLoading && !destinationsError && popularDestinations.length === 0
          ? <Text style={styles.destinationNotice}>No destinations are listed yet.</Text>
          : null}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.destinationsScroll} contentContainerStyle={styles.destinationsContent}>
          {popularDestinations.map((destination) => {
            const key = savedKeyFor(destination);
            const listSaved = savedMap[key];
            return (
            <View key={destination.id} style={styles.destinationCardWrap}>
              <TouchableOpacity
                style={styles.destinationCard}
                onPress={() => navigation.push("Destination", { destination })}
              >
              <RelevantImage entity={{
                name: destination.name,
                type: "destination",
                location: destination.location,
                image: destination.image,
                images: destination.images,
                imageSource: destination.imageSource,
                imageSourcePage: destination.imageSourcePage,
                imageLicense: destination.imageLicense,
                imageCredit: destination.imageCredit,
                imageDescription: destination.imageDescription,
                imageRelevance: destination.imageRelevance,
              }} style={styles.destinationImage} />
              <View style={styles.destinationInfo}>
                <Text style={styles.destinationName}>{destination.name}</Text>
                <Text style={styles.destinationLocation} numberOfLines={1}>
                  {destination.location}
                </Text>
                {destination.rating ? <View style={styles.ratingContainer}>
                  <Ionicons name="star" size={16} color="#F59E0B" />
                  <Text style={styles.ratingText}>{destination.rating} ({destination.reviews})</Text>
                </View> : null}
              </View>
              </TouchableOpacity>
              <Pressable
                onPress={() => void toggleSavedDestination(destination)}
                disabled={savingId === key}
                style={styles.saveButton}
                accessibilityRole="button"
                accessibilityLabel={listSaved ? `Remove ${destination.name} from Saved` : `Save ${destination.name}`}
              >
                {savingId === key ? (
                  <ActivityIndicator size="small" color={colors.primary} />
                ) : (
                  <Ionicons
                    name={listSaved ? "heart" : "heart-outline"}
                    size={18}
                    color={listSaved ? "#D9435F" : "#0F766E"}
                  />
                )}
              </Pressable>
            </View>
            );
          })}
        </ScrollView>
      </ScrollView>
      <SaveToast message={toast} toastKey={toastKey} />

      <Modal visible={isChatOpen} transparent animationType="slide" onRequestClose={() => setIsChatOpen(false)}>
        <TouchableOpacity
          style={[styles.chatOverlay, isCompactChat && styles.chatOverlayDesktop]}
          activeOpacity={1}
          onPress={() => setIsChatOpen(false)}
        >
          <TouchableOpacity
            activeOpacity={1}
            style={[
              styles.chatPanel,
              isCompactChat && styles.chatPanelDesktop,
              { width: chatWindowWidth, height: chatWindowHeight },
            ]}
            onPress={() => {}}
          >
            <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.chatKeyboardView}>
              <View style={styles.chatHeader}>
                <Text style={styles.chatPanelTitle}>SuvYatra Assistant</Text>
                <TouchableOpacity onPress={() => setIsChatOpen(false)}>
                  <Ionicons name="close" size={24} color={colors.text} />
                </TouchableOpacity>
              </View>

              <ScrollView
                style={styles.chatMessages}
                contentContainerStyle={styles.chatMessagesContent}
                showsVerticalScrollIndicator
                keyboardShouldPersistTaps="handled"
              >
                <View style={styles.botBubble}>
                  <Text style={styles.botText}>Hi! I can help with trips, hotels, and destinations.</Text>
                </View>
              </ScrollView>

              <View style={styles.chatInputRow}>
                <TextInput
                  value={chatInput}
                  onChangeText={setChatInput}
                  placeholder="Type your message..."
                  placeholderTextColor={colors.textMuted}
                  style={styles.chatInput}
                  multiline
                  returnKeyType="send"
                  blurOnSubmit={false}
                  onSubmitEditing={submitHomeChat}
                  onKeyPress={
                    isWeb
                      ? (e: any) => {
                          const key = e?.key ?? e?.nativeEvent?.key;
                          if (key === "Enter" && !e?.shiftKey) {
                            e.preventDefault?.();
                            submitHomeChat();
                          }
                        }
                      : undefined
                  }
                />

                <TouchableOpacity
                  style={styles.sendButton}
                  accessibilityRole="button"
                  accessibilityLabel="Send message to SuvYatra Assistant"
                  onPress={submitHomeChat}
                >
                  <Ionicons name="arrow-forward" size={20} color={colors.white} />
                </TouchableOpacity>
              </View>
            </KeyboardAvoidingView>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: "100%",
    backgroundColor: "#F5F7FB",
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingBottom: 100,
    width: "100%",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: spacing.lg,
  },
  brandLockup: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  brandMark: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#DDF1EC",
    borderRadius: 18,
  },
  brand: {
    fontSize: 26,
    fontWeight: "900",
    color: "#102A43",
    letterSpacing: 0,
  },
  brandAccent: {
    color: "#0F766E",
  },
  chatBubble: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.92)",
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 10,
    shadowColor: "#14B8A6",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 3,
    borderWidth: 1,
    borderColor: "rgba(20,184,166,0.12)",
  },
  chatIconWrap: {
    width: 36,
    height: 36,
    backgroundColor: "#E6FFFB",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  chatText: {
    marginLeft: spacing.sm,
  },
  chatTitle: {
    fontSize: 11,
    fontWeight: "800",
    color: "#102A43",
  },
  chatSubtitle: {
    fontSize: 9,
    color: colors.textMuted,
  },
  pageTitle: {
    fontSize: 31,
    fontWeight: "900",
    color: "#102A43",
    marginTop: spacing.sm,
    lineHeight: 36,
    maxWidth: 340,
  },
  heroIntro: {
    backgroundColor: "#E8F3F0",
    marginHorizontal: -spacing.lg,
    marginTop: spacing.lg,
    marginBottom: spacing.lg,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: "#D5EAE5",
    borderBottomWidth: 1,
    borderBottomColor: "#D5EAE5",
  },
  eyebrowRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  eyebrowMark: {
    width: 18,
    height: 3,
    borderRadius: 2,
    backgroundColor: "#D07A4D",
  },
  eyebrow: {
    fontSize: 10,
    fontWeight: "800",
    color: "#0F766E",
    letterSpacing: 0,
  },
  heroSupporting: {
    color: "#5D7082",
    fontSize: 13,
    lineHeight: 19,
    marginTop: spacing.sm,
    maxWidth: 320,
  },
  guidedTripArrow: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 20,
    backgroundColor: "#FFFFFF",
  },
  guidedTripCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 16,
    padding: spacing.lg,
    marginBottom: spacing.xl,
    backgroundColor: "#0F766E",
    gap: spacing.md,
    shadowColor: "#0F766E",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.28,
    shadowRadius: 18,
    elevation: 5,
  },
  guidedTripText: { flex: 1, paddingRight: spacing.sm },
  guidedTripEyebrow: {
    color: "#D1FAE5",
    fontSize: 9,
    fontWeight: "800",
    letterSpacing: 0.8,
  },
  guidedTripTitle: {
    color: "#FFFFFF",
    fontSize: 21,
    fontWeight: "900",
    marginTop: spacing.xs,
  },
  guidedTripSubtitle: {
    color: "#E6FFFB",
    fontSize: 12,
    lineHeight: 17,
    marginTop: 3,
  },
  banner: {
    height: 230,
    borderRadius: 16,
    overflow: "hidden",
    marginBottom: spacing.xl,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 6,
  },
  bannerOverlay: {
    flex: 1,
    padding: spacing.xl,
    justifyContent: "center",
    backgroundColor: "rgba(8, 15, 28, 0.35)",
  },
  bannerTitle: {
    fontSize: 11,
    color: "#D1FAE5",
    marginBottom: spacing.xs,
    fontWeight: "800",
    letterSpacing: 0,
  },
  bannerSubtitle: {
    fontSize: 32,
    fontWeight: "900",
    color: colors.white,
  },
  bannerTagline: {
    fontSize: 14,
    color: colors.white,
    marginTop: 2,
    marginBottom: spacing.lg,
    fontWeight: "600",
  },
  exploreButton: {
    backgroundColor: "#14B8A6",
    borderRadius: 10,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    minHeight: 44,
    justifyContent: "center",
    alignSelf: "flex-start",
    shadowColor: "#14B8A6",
    shadowOpacity: 0.32,
    shadowRadius: 12,
    elevation: 4,
  },
  exploreButtonText: {
    color: colors.white,
    fontSize: 14,
    fontWeight: "800",
  },
  sectionHeader: {
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: 21,
    fontWeight: "800",
    color: "#102A43",
    letterSpacing: -0.3,
  },
  categoriesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: spacing.xl,
  },
  categoryItem: {
    width: "47%",
    alignItems: "center",
    marginBottom: spacing.lg,
  },
  categoryIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: spacing.sm,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 3,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.4)",
  },
  categoryName: {
    fontSize: 11,
    textAlign: "center",
    color: "#334155",
    fontWeight: "700",
    minHeight: 28,
  },
  destinationsHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: spacing.lg,
  },
  destinationsScroll: {
    marginHorizontal: 0,
  },
  destinationsContent: {
    paddingRight: spacing.md,
  },
  destinationCardWrap: {
    width: 232,
    marginRight: spacing.md,
  },
  destinationCard: {
    borderRadius: 14,
    overflow: "hidden",
    backgroundColor: "rgba(255,255,255,0.98)",
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.1,
    shadowRadius: 14,
    elevation: 4,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.16)",
  },
  saveButton: {
    position: "absolute",
    top: spacing.sm,
    right: spacing.sm,
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: "rgba(255,255,255,0.94)",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 3,
  },
  destinationImage: {
    width: "100%",
    height: 140,
  },
  destinationInfo: {
    padding: spacing.md,
  },
  destinationName: {
    fontSize: 16,
    fontWeight: "800",
    color: "#102A43",
  },
  destinationLocation: {
    fontSize: 11,
    color: "#64748B",
    marginTop: 3,
    marginBottom: spacing.sm,
  },
  destinationNotice: {
    color: "#64748B",
    fontSize: 13,
    paddingVertical: spacing.sm,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  ratingText: {
    fontSize: 12,
    color: "#475569",
    marginLeft: spacing.xs,
    fontWeight: "700",
  },
  chatOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(15,23,42,0.38)",
    zIndex: 50,
  },
  // Desktop/laptop: center the compact popup horizontally and vertically
  // (flexbox equivalent of position: fixed; left/top 50%; translate(-50%,
  // -50%)) with spacing so it never touches the screen edges.
  chatOverlayDesktop: {
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  chatPanel: {
    backgroundColor: colors.white,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xl,
    alignSelf: "stretch",
  },
  // Compact mobile-phone-shaped floating window (desktop/laptop only).
  chatPanelDesktop: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    alignSelf: "center",
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.22,
    shadowRadius: 28,
    elevation: 12,
  },
  chatKeyboardView: {
    width: "100%",
    flex: 1,
    flexDirection: "column",
  },
  chatHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: spacing.md,
  },
  chatPanelTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#0F172A",
  },
  chatMessages: {
    flex: 1,
    paddingVertical: spacing.sm,
    minHeight: 120,
  },
  chatMessagesContent: {
    flexGrow: 1,
    paddingBottom: spacing.sm,
  },
  botBubble: {
    alignSelf: "flex-start",
    backgroundColor: "#EEF2FF",
    borderRadius: 16,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    maxWidth: "80%",
  },
  botText: {
    fontSize: 14,
    color: "#1E293B",
    lineHeight: 20,
    fontWeight: "500",
  },
  chatInputRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: 16,
    backgroundColor: "#F8FAFC",
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  chatInput: {
    flex: 1,
    minHeight: 40,
    maxHeight: 120,
    color: colors.text,
    fontSize: 15,
    paddingVertical: 8,
    paddingHorizontal: spacing.sm,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#0F766E",
    justifyContent: "center",
    alignItems: "center",
    marginLeft: spacing.sm,
  },
});

export default HomeScreen;