import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { useAdminAuth } from "../auth/AdminAuthContext";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "AdminLogin">;

export default function AdminLoginScreen({ navigation }: Props) {
  const { admin, ready, login } = useAdminAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const passwordRef = useRef<TextInput>(null);

  useEffect(() => {
    if (ready && admin) navigation.reset({ index: 0, routes: [{ name: "AdminDashboard" }] });
  }, [admin, navigation, ready]);

  const submit = async () => {
    if (!email.trim() || !password) {
      setError("Enter your administrator email and password.");
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      await login(email, password);
      navigation.reset({ index: 0, routes: [{ name: "AdminDashboard" }] });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Admin login failed.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={styles.header}>
          <BackButton navigation={navigation} />
          <Text style={styles.eyebrow}>SUVYATRA ADMIN</Text>
          <View style={styles.spacer} />
        </View>
        <View style={styles.content}>
          <View style={styles.icon}>
            <Ionicons name="shield-checkmark-outline" size={30} color={colors.primaryDark} />
          </View>
          <Text style={styles.title}>Administrator sign in</Text>
          <Text style={styles.subtitle}>Sign in with your authorized administrator credentials.</Text>

          <Text style={styles.label}>Email</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Administrator email"
            placeholderTextColor={colors.textMuted}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            style={styles.input}
            accessibilityLabel="Administrator email"
            returnKeyType="next"
            onSubmitEditing={() => passwordRef.current?.focus()}
          />
          <Text style={styles.label}>Password</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Administrator password"
            placeholderTextColor={colors.textMuted}
            secureTextEntry
            autoCapitalize="none"
            autoComplete="current-password"
            style={styles.input}
            accessibilityLabel="Administrator password"
            ref={passwordRef}
            onSubmitEditing={() => void submit()}
            returnKeyType="go"
          />

          {error ? <Text style={styles.error} accessibilityRole="alert">{error}</Text> : null}
          <Pressable
            style={({ pressed }) => [styles.button, pressed && styles.pressed]}
            onPress={() => void submit()}
            disabled={submitting || !ready}
            accessibilityRole="button"
            accessibilityState={{ disabled: submitting || !ready }}
          >
            {submitting || !ready
              ? <ActivityIndicator color="#FFFFFF" />
              : <Text style={styles.buttonText}>Sign in to dashboard</Text>}
          </Pressable>
          <Pressable
            style={styles.forgotRow}
            onPress={() => navigation.navigate("ForgotPassword", { email: email.trim() || undefined, admin: true })}
            accessibilityRole="link"
          >
            <Text style={styles.forgotText}>Forgot password?</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: spacing.lg },
  eyebrow: { color: colors.primaryDark, fontSize: 12, fontWeight: "800", letterSpacing: 1 },
  spacer: { width: 24 },
  content: { width: "100%", maxWidth: 480, alignSelf: "center", padding: spacing.xl, marginTop: spacing.xl },
  icon: { width: 60, height: 60, borderRadius: radius.full, backgroundColor: "#E6FFFA", alignItems: "center", justifyContent: "center" },
  title: { color: colors.text, fontSize: 25, fontWeight: "800", marginTop: spacing.lg },
  subtitle: { color: colors.textMuted, fontSize: 14, lineHeight: 21, marginTop: spacing.sm, marginBottom: spacing.lg },
  label: { color: colors.text, fontSize: 13, fontWeight: "700", marginBottom: spacing.xs, marginTop: spacing.md },
  input: { minHeight: 48, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, backgroundColor: colors.white, paddingHorizontal: spacing.md, color: colors.text },
  error: { color: "#B91C1C", fontSize: 13, lineHeight: 19, marginTop: spacing.md },
  button: { minHeight: 50, borderRadius: radius.md, backgroundColor: colors.primaryDark, alignItems: "center", justifyContent: "center", marginTop: spacing.lg },
  pressed: { opacity: 0.82 },
  buttonText: { color: colors.white, fontSize: 15, fontWeight: "800" },
  forgotRow: { alignSelf: "center", marginTop: spacing.md },
  forgotText: { color: colors.primaryDark, fontSize: 13, fontWeight: "700" },
});
