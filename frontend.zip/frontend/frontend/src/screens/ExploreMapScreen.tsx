import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { DestinationDetails, HiddenGemDetails, RootStackParamList } from "../../App";
import MapEmbed from "../components/MapEmbed";
import RelevantImage from "../components/RelevantImage";
import { backendRequest } from "../services/backendApi";
import { colors, radius, spacing } from "../theme";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

type MapCategory = "destination" | "hidden-gem" | "hotel" | "activity";

type MapPlace = {
  key: string;
  category: MapCategory;
  name: string;
  location: string;
  latitude: number;
  longitude: number;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  ratingText?: string;
  priceText?: string;
  destination?: DestinationDetails;
  gem?: HiddenGemDetails;
  hotelId?: string;
  activityId?: string;
};

type DestinationRecord = {
  _id: string;
  name: string;
  slug?: string;
  province?: string;
  country?: string;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  highlights?: string[];
  tags?: string[];
  bestTimeToVisit?: string;
  approximateCost?: string;
  latitude?: number;
  longitude?: number;
};

type HotelRecord = {
  _id: string;
  name: string;
  location?: string;
  city?: string;
  district?: string;
  province?: string;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  pricePerNight?: number;
  rating?: number;
  latitude?: number;
  longitude?: number;
};

type ActivityRecord = {
  _id: string;
  name: string;
  city?: string;
  location?: string;
  address?: string;
  description?: string;
  image?: string;
  images?: string[];
  imageSource?: string;
  imageSourcePage?: string;
  imageLicense?: string;
  imageCredit?: string;
  imageDescription?: string;
  imageRelevance?: "entity" | "category";
  latitude?: number;
  longitude?: number;
};

const CATEGORIES: { label: string; value: MapCategory | "all"; icon: keyof typeof Ionicons.glyphMap }[] = [
  { label: "All", value: "all", icon: "apps-outline" },
  { label: "Destinations", value: "destination", icon: "map-outline" },
  { label: "Hidden Gems", value: "hidden-gem", icon: "sparkles-outline" },
  { label: "Hotels", value: "hotel", icon: "bed-outline" },
  { label: "Activities", value: "activity", icon: "trail-sign-outline" },
];

const CATEGORY_LABELS: Record<MapCategory, string> = {
  destination: "Destination",
  "hidden-gem": "Hidden Gem",
  hotel: "Hotel",
  activity: "Activity",
};

// GET /places returns a paginated envelope, not a bare array.
type PlacesSearchResponse = {
  items?: ActivityRecord[];
  page?: number;
  limit?: number;
  total?: number;
};

// Extracts the real record array from a /places response. Returns [] when the
// payload has no usable array (empty result, unexpected shape), so callers can
// always iterate safely while the existing empty-state UI explains the outcome.
function extractItems(response: PlacesSearchResponse | null | undefined): ActivityRecord[] {
  if (!response) return [];
  if (Array.isArray(response)) return response as ActivityRecord[];
  if (Array.isArray(response.items)) return response.items;
  return [];
}

function hasValidCoordinates(value: { latitude?: number; longitude?: number }): boolean {
  return (
    typeof value.latitude === "number" &&
    typeof value.longitude === "number" &&
    Number.isFinite(value.latitude) &&
    Number.isFinite(value.longitude) &&
    value.latitude >= -90 &&
    value.latitude <= 90 &&
    value.longitude >= -180 &&
    value.longitude <= 180
  );
}

// Published town-center coordinates for well-known Nepal destinations whose
// database records do not carry latitude/longitude yet. These are real,
// widely-published locations (not invented): a record's own database
// coordinates always take precedence, and an admin can override any of these
// by saving latitude/longitude on the record itself.
const KNOWN_DESTINATION_COORDINATES: Record<string, { latitude: number; longitude: number }> = {
  kathmandu: { latitude: 27.7172, longitude: 85.324 },
  pokhara: { latitude: 28.2096, longitude: 83.9856 },
  "chitwan-national-park": { latitude: 27.5744, longitude: 84.4937 },
  chitwan: { latitude: 27.5744, longitude: 84.4937 },
  lumbini: { latitude: 27.4833, longitude: 83.2833 },
  "everest-region": { latitude: 27.8069, longitude: 86.714 },
  everest: { latitude: 27.8069, longitude: 86.714 },
  mustang: { latitude: 28.7806, longitude: 83.7221 },
  jomsom: { latitude: 28.7806, longitude: 83.7221 },
  bandipur: { latitude: 27.9409, longitude: 84.4129 },
  ilam: { latitude: 26.9081, longitude: 87.9266 },
  nagarkot: { latitude: 27.7154, longitude: 85.5207 },
  bhaktapur: { latitude: 27.6717, longitude: 85.4285 },
  manang: { latitude: 28.6667, longitude: 84.0222 },
  janakpur: { latitude: 26.7271, longitude: 85.9407 },
};

function slugifyName(value: string | undefined): string {
  return (value ?? "")
    .trim()
    .toLocaleLowerCase()
    .replace(/[\s_]+/g, "-")
    .replace(/[^a-z0-9-]/g, "");
}

// Resolves map coordinates for a destination record: database coordinates
// first; the curated table above only as a fallback for well-known places.
// Returns null when neither source has valid coordinates, so the record is
// skipped instead of being pinned to a wrong/default location.
function resolveDestinationCoordinates(
  record: DestinationRecord
): { latitude: number; longitude: number } | null {
  if (hasValidCoordinates(record)) {
    return { latitude: record.latitude as number, longitude: record.longitude as number };
  }
  const known =
    KNOWN_DESTINATION_COORDINATES[slugifyName(record.slug)] ??
    KNOWN_DESTINATION_COORDINATES[slugifyName(record.name)];
  if (known) return known;
  return null;
}

function toDestinationDetails(record: DestinationRecord): DestinationDetails {
  return {
    id: record._id,
    name: record.name,
    location: [record.province, record.country].filter(Boolean).join(", ") || "Location not listed",
    rating: "",
    reviews: "",
    description: record.description || "Destination information is not available yet.",
    bestTime: record.bestTimeToVisit || "Not specified",
    price: record.approximateCost || "Not listed",
    image: record.image || "",
    images: record.images,
    imageSource: record.imageSource,
    imageSourcePage: record.imageSourcePage,
    imageLicense: record.imageLicense,
    imageCredit: record.imageCredit,
    imageDescription: record.imageDescription,
    imageRelevance: record.imageRelevance,
    hiddenGems: record.highlights || [],
    thingsToDo: record.highlights || [],
    categories: ["Book Hotel", "Book Jeep", "Book Bike", "Book Bus", "Book Activities"],
    latitude: record.latitude,
    longitude: record.longitude,
  };
}

function toHiddenGem(record: DestinationRecord): HiddenGemDetails {
  return {
    id: record._id,
    name: record.name,
    location: [record.province, record.country].filter(Boolean).join(", ") || undefined,
    province: record.province,
    description: record.description,
    whyHiddenGem: record.description,
    thingsToDo: record.highlights || [],
    tags: (record.tags || []).filter((tag) => tag.trim().toLocaleLowerCase() !== "hidden"),
    image: record.image,
    images: record.images,
    imageSource: record.imageSource,
    imageSourcePage: record.imageSourcePage,
    imageLicense: record.imageLicense,
    imageCredit: record.imageCredit,
    imageDescription: record.imageDescription,
    imageRelevance: record.imageRelevance,
  };
}

export default function ExploreMapScreen() {
  const navigation = useNavigation<NavigationProp>();
  const [places, setPlaces] = useState<MapPlace[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [activeCategory, setActiveCategory] = useState<MapCategory | "all">("all");
  const [selectedKey, setSelectedKey] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    Promise.all([
      backendRequest<DestinationRecord[]>("/destinations"),
      backendRequest<HotelRecord[]>("/hotels"),
      backendRequest<PlacesSearchResponse>("/places?module=activity"),
    ])
      .then(([destinationRecords, hotelRecords, activityResponse]) => {
        if (!active) return;
        const collected: MapPlace[] = [];
        const seen = new Set<string>();
        // GET /places returns a paginated envelope ({ items, page, limit, total }),
        // not a bare array — extract the real array and fall back to [] so a
        // shape change can never crash iteration below.
        const safeActivityRecords = extractItems(activityResponse);

        for (const record of destinationRecords) {
          const coordinates = resolveDestinationCoordinates(record);
          if (!coordinates) continue;
          const isHidden = (record.tags ?? []).some(
            (tag) => tag.trim().toLocaleLowerCase() === "hidden"
          );
          const key = `${isHidden ? "hidden-gem" : "destination"}:${record._id}`;
          if (seen.has(key)) continue;
          seen.add(key);
          if (isHidden) {
            collected.push({
              key,
              category: "hidden-gem",
              name: record.name,
              location: [record.province, record.country].filter(Boolean).join(", ") || "Location not listed",
              latitude: coordinates.latitude,
              longitude: coordinates.longitude,
              description: record.description,
              image: record.image,
              images: record.images,
              imageSource: record.imageSource,
              imageSourcePage: record.imageSourcePage,
              imageLicense: record.imageLicense,
              imageCredit: record.imageCredit,
              imageDescription: record.imageDescription,
              imageRelevance: record.imageRelevance,
              priceText: record.approximateCost,
              gem: toHiddenGem(record),
            });
          } else {
            collected.push({
              key,
              category: "destination",
              name: record.name,
              location: [record.province, record.country].filter(Boolean).join(", ") || "Location not listed",
              latitude: coordinates.latitude,
              longitude: coordinates.longitude,
              description: record.description,
              image: record.image,
              images: record.images,
              imageSource: record.imageSource,
              imageSourcePage: record.imageSourcePage,
              imageLicense: record.imageLicense,
              imageCredit: record.imageCredit,
              imageDescription: record.imageDescription,
              imageRelevance: record.imageRelevance,
              priceText: record.approximateCost,
              destination: toDestinationDetails(record),
            });
          }
        }

        for (const record of hotelRecords) {
          if (!hasValidCoordinates(record)) continue;
          const key = `hotel:${record._id}`;
          if (seen.has(key)) continue;
          seen.add(key);
          collected.push({
            key,
            category: "hotel",
            name: record.name,
            location:
              [record.location, record.city, record.district].filter(Boolean).join(", ") ||
              "Location not listed",
            latitude: record.latitude as number,
            longitude: record.longitude as number,
            description: record.description,
            image: record.image,
            images: record.images,
            imageSource: record.imageSource,
            imageSourcePage: record.imageSourcePage,
            imageLicense: record.imageLicense,
            imageCredit: record.imageCredit,
            imageDescription: record.imageDescription,
            imageRelevance: record.imageRelevance,
            ratingText:
              typeof record.rating === "number" ? `${record.rating.toFixed(1)} / 5` : undefined,
            priceText:
              typeof record.pricePerNight === "number"
                ? `NPR ${record.pricePerNight.toLocaleString("en-IN")} / night`
                : undefined,
            hotelId: record._id,
          });
        }

        for (const record of safeActivityRecords) {
          if (!hasValidCoordinates(record)) continue;
          const key = `activity:${record._id}`;
          if (seen.has(key)) continue;
          seen.add(key);
          collected.push({
            key,
            category: "activity",
            name: record.name,
            location:
              [record.address, record.location, record.city].filter(Boolean).join(", ") ||
              "Location not listed",
            latitude: record.latitude as number,
            longitude: record.longitude as number,
            description: record.description,
            image: record.image,
            images: record.images,
            imageSource: record.imageSource,
            imageSourcePage: record.imageSourcePage,
            imageLicense: record.imageLicense,
            imageCredit: record.imageCredit,
            imageDescription: record.imageDescription,
            imageRelevance: record.imageRelevance,
            activityId: record._id,
          });
        }

        setPlaces(collected);
      })
      .catch((requestError: unknown) => {
        if (active) {
          setError(requestError instanceof Error ? requestError.message : "Could not load map locations.");
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [reloadKey]);

  const visiblePlaces = useMemo(
    () => places.filter((place) => activeCategory === "all" || place.category === activeCategory),
    [activeCategory, places]
  );

  const selected = useMemo(
    () => visiblePlaces.find((place) => place.key === selectedKey) ?? null,
    [selectedKey, visiblePlaces]
  );

  const mapUrl = selected
    ? `https://www.google.com/maps?q=${selected.latitude},${selected.longitude}&z=13&output=embed`
    : "https://www.google.com/maps?q=Nepal&z=7&output=embed";

  const selectCategory = (value: MapCategory | "all") => {
    setActiveCategory(value);
    setSelectedKey("");
  };

  const openDetails = (place: MapPlace) => {
    if (place.category === "destination" && place.destination) {
      navigation.push("Destination", { destination: place.destination });
    } else if (place.category === "hidden-gem" && place.gem) {
      navigation.push("HiddenGemDetail", { gem: place.gem });
    } else if (place.category === "hotel" && place.hotelId) {
      navigation.push("HotelDetails", { hotelId: place.hotelId });
    } else if (place.category === "activity" && place.activityId) {
      navigation.push("PlaceDirectory", { module: "activity", placeId: place.activityId });
    }
  };

  const openInGoogleMaps = (place: MapPlace) =>
    void Linking.openURL(
      `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${place.latitude},${place.longitude}`)}`
    );

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <Text style={styles.title}>Map</Text>
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipsRow}
      >
        {CATEGORIES.map((category) => {
          const isActive = activeCategory === category.value;
          return (
            <Pressable
              key={category.value}
              onPress={() => selectCategory(category.value)}
              style={[styles.chip, isActive && styles.chipActive]}
              accessibilityRole="button"
              accessibilityState={{ selected: isActive }}
              accessibilityLabel={`Show ${category.label} on the map`}
            >
              <Ionicons
                name={category.icon}
                size={15}
                color={isActive ? colors.white : "#0F766E"}
              />
              <Text style={[styles.chipText, isActive && styles.chipTextActive]}>{category.label}</Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <View style={styles.mapContainer}>
        <MapEmbed key={mapUrl} uri={mapUrl} title={selected ? `Map of ${selected.name}` : "Map of Nepal"} />
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
      <Text style={styles.mapNote}>
        {selected
          ? `Showing ${selected.name} on Google Maps. Pinch or drag to zoom and pan.`
          : "Showing Nepal. Pick a place below to focus the map on it."}
      </Text>

      {loading ? (
        <View style={styles.centerRow}>
          <ActivityIndicator color="#0F766E" />
          <Text style={styles.mutedText}>Loading map locations…</Text>
        </View>
      ) : null}
      {error ? (
        <View style={styles.centerColumn}>
          <Text style={styles.errorText}>{error}</Text>
          <Pressable onPress={() => setReloadKey((value) => value + 1)} accessibilityRole="button">
            <Text style={styles.retryText}>Try again</Text>
          </Pressable>
        </View>
      ) : null}

      {!loading && !error ? (
        visiblePlaces.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="map-outline" size={30} color="#0F766E" />
            <Text style={styles.emptyTitle}>No mappable places yet</Text>
            <Text style={styles.emptyText}>
              {places.length === 0
                ? "None of the current records include valid coordinates, so there is nothing to show on the map."
                : "No places in this category include valid coordinates yet. Try another category."}
            </Text>
          </View>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.placesRow}
          >
            {visiblePlaces.map((place) => {
              const isSelected = place.key === selectedKey;
              return (
                <Pressable
                  key={place.key}
                  onPress={() => setSelectedKey(isSelected ? "" : place.key)}
                  style={[styles.placeCard, isSelected && styles.placeCardSelected]}
                  accessibilityRole="button"
                  accessibilityState={{ selected: isSelected }}
                  accessibilityLabel={`Focus ${place.name} on the map`}
                >
                  <RelevantImage
                    entity={{
                      name: place.name,
                      type: place.category === "hotel" ? "hotel" : "destination",
                      location: place.location,
                      image: place.image,
                      images: place.images,
                      imageSource: place.imageSource,
                      imageSourcePage: place.imageSourcePage,
                      imageLicense: place.imageLicense,
                      imageCredit: place.imageCredit,
                      imageDescription: place.imageDescription,
                      imageRelevance: place.imageRelevance,
                    }}
                    style={styles.placeImage}
                  />
                  <View style={styles.placeBody}>
                    <Text style={styles.placeCategory}>{CATEGORY_LABELS[place.category]}</Text>
                    <Text style={styles.placeName} numberOfLines={1}>
                      {place.name}
                    </Text>
                    <Text style={styles.placeLocation} numberOfLines={1}>
                      {place.location}
                    </Text>
                  </View>
                </Pressable>
              );
            })}
          </ScrollView>
        )
      ) : null}

      {selected ? (
        <View style={styles.popup}>
          <RelevantImage
            entity={{
              name: selected.name,
              type: selected.category === "hotel" ? "hotel" : "destination",
              location: selected.location,
              image: selected.image,
              images: selected.images,
              imageSource: selected.imageSource,
              imageSourcePage: selected.imageSourcePage,
              imageLicense: selected.imageLicense,
              imageCredit: selected.imageCredit,
              imageDescription: selected.imageDescription,
              imageRelevance: selected.imageRelevance,
            }}
            style={styles.popupImage}
          />
          <View style={styles.popupBody}>
            <Text style={styles.placeCategory}>{CATEGORY_LABELS[selected.category]}</Text>
            <Text style={styles.popupName}>{selected.name}</Text>
            <View style={styles.popupLocationRow}>
              <Ionicons name="location-outline" size={13} color={colors.textMuted} />
              <Text style={styles.popupLocation} numberOfLines={1}>
                {selected.location}
              </Text>
            </View>
            {selected.ratingText ? <Text style={styles.popupMeta}>★ {selected.ratingText}</Text> : null}
            {selected.priceText ? <Text style={styles.popupPrice}>{selected.priceText}</Text> : null}
            {selected.description ? (
              <Text style={styles.popupDescription} numberOfLines={2}>
                {selected.description}
              </Text>
            ) : null}
            <View style={styles.popupActions}>
              <Pressable
                style={styles.detailsButton}
                onPress={() => openDetails(selected)}
                accessibilityRole="button"
                accessibilityLabel={`View details for ${selected.name}`}
              >
                <Text style={styles.detailsButtonText}>View Details</Text>
              </Pressable>
              {selected.category === "destination" ? (
                <Pressable
                  style={styles.planButton}
                  onPress={() => navigation.push("DestinationTrip", { destination: selected.name })}
                  accessibilityRole="button"
                  accessibilityLabel={`Plan a trip to ${selected.name}`}
                >
                  <Text style={styles.planButtonText}>Plan a Trip</Text>
                </Pressable>
              ) : null}
              <Pressable
                style={styles.mapsButton}
                onPress={() => openInGoogleMaps(selected)}
                accessibilityRole="button"
                accessibilityLabel={`Open ${selected.name} in Google Maps`}
              >
                <Ionicons name="navigate-outline" size={15} color="#0F766E" />
                <Text style={styles.mapsButtonText}>Maps</Text>
              </Pressable>
            </View>
          </View>
        </View>
      ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: spacing.lg, paddingTop: spacing.md },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "center", marginBottom: spacing.sm },
  title: { color: colors.text, fontSize: 20, fontWeight: "800" },
  chipsRow: { gap: 7, paddingBottom: spacing.sm },
  chip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  chipActive: { backgroundColor: "#0F766E", borderColor: "#0F766E" },
  chipText: { color: colors.textMuted, fontSize: 11, fontWeight: "700" },
  chipTextActive: { color: colors.white },
  mapContainer: { height: 320, borderRadius: radius.lg, overflow: "hidden", borderWidth: 1, borderColor: colors.border, shadowColor: "#0F172A", shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.08, shadowRadius: 16, elevation: 3 },
  scrollContent: { paddingBottom: spacing.md },
  mapNote: { color: colors.textMuted, fontSize: 11, lineHeight: 16, marginTop: spacing.xs, marginBottom: spacing.sm },
  centerRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.md },
  centerColumn: { alignItems: "center", gap: spacing.sm, paddingVertical: spacing.md },
  mutedText: { color: colors.textMuted, fontSize: 12 },
  errorText: { color: "#B42318", fontSize: 12, textAlign: "center" },
  retryText: { color: "#0F766E", fontSize: 13, fontWeight: "800" },
  emptyState: {
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: spacing.xl,
    gap: spacing.sm,
  },
  emptyTitle: { color: colors.text, fontSize: 15, fontWeight: "800" },
  emptyText: { color: colors.textMuted, fontSize: 12, textAlign: "center", lineHeight: 18 },
  placesRow: { gap: spacing.sm, paddingBottom: spacing.sm },
  placeCard: {
    width: 176,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.border,
    shadowColor: "#0F172A",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  placeCardSelected: { borderColor: "#0F766E", borderWidth: 2 },
  placeImage: { width: "100%", height: 90 },
  placeBody: { padding: spacing.sm },
  placeCategory: { color: "#0F766E", fontSize: 9, fontWeight: "800", letterSpacing: 0.6 },
  placeName: { color: colors.text, fontSize: 13, fontWeight: "800", marginTop: 2 },
  placeLocation: { color: colors.textMuted, fontSize: 10, marginTop: 2 },
  popup: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 110,
  },
  popupImage: { width: "100%", height: 130 },
  popupBody: { padding: spacing.md },
  popupName: { color: colors.text, fontSize: 17, fontWeight: "800", marginTop: 2 },
  popupLocationRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 },
  popupLocation: { color: colors.textMuted, fontSize: 12, flex: 1 },
  popupMeta: { color: colors.text, fontSize: 11, fontWeight: "700", marginTop: 5 },
  popupPrice: { color: "#0F766E", fontSize: 12, fontWeight: "800", marginTop: 4 },
  popupDescription: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: 5 },
  popupActions: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.md },
  detailsButton: {
    flex: 1,
    minHeight: 46,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.sm,
    backgroundColor: "#0F766E",
    shadowColor: "#0F766E",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 2,
  },
  detailsButtonText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  planButton: {
    flex: 1,
    minHeight: 46,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: "#0F766E",
    backgroundColor: colors.surface,
  },
  planButtonText: { color: "#0F766E", fontSize: 12, fontWeight: "800" },
  mapsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
    paddingHorizontal: spacing.md,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: "#0F766E",
  },
  mapsButtonText: { color: "#0F766E", fontSize: 12, fontWeight: "800" },
});
