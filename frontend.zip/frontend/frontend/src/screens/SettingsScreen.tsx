import React, { useEffect, useState } from "react";
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { RootStackParamList } from "../../App";
import BackButton from "../components/BackButton";
import { clearRelevantImageCache } from "../imageResolver";
import { colors, radius, spacing } from "../theme";

type Props = NativeStackScreenProps<RootStackParamList, "Settings">;

type Settings = {
  pushNotifications: boolean;
  emailNotifications: boolean;
  smsNotifications: boolean;
  language: string;
  currency: string;
  compactView: boolean;
};

const DEFAULT_SETTINGS: Settings = {
  pushNotifications: true,
  emailNotifications: true,
  smsNotifications: false,
  language: "English",
  currency: "NPR (रू)",
  compactView: false,
};

const STORAGE_KEY = "suvyatra_settings_v1";

const LANGUAGE_OPTIONS = ["English", "नेपाली", "हिन्दी"];
const CURRENCY_OPTIONS = ["NPR (रू)", "USD ($)", "EUR (€)"];

function getStorage(): Storage | null {
  try {
    return typeof localStorage !== "undefined" ? localStorage : null;
  } catch {
    return null;
  }
}

const memoryStorage = new Map<string, string>();

function readSettings(): Settings {
  const store = getStorage();
  const raw = store ? store.getItem(STORAGE_KEY) : memoryStorage.get(STORAGE_KEY);
  if (!raw) {
    return { ...DEFAULT_SETTINGS };
  }
  try {
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<Settings>) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function writeSettings(settings: Settings) {
  const store = getStorage();
  const raw = JSON.stringify(settings);
  if (store) {
    try {
      store.setItem(STORAGE_KEY, raw);
    } catch {
      // storage unavailable
    }
  } else {
    memoryStorage.set(STORAGE_KEY, raw);
  }
}

export default function SettingsScreen({ navigation }: Props) {
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);

  useEffect(() => {
    setSettings(readSettings());
  }, []);

  const update = (patch: Partial<Settings>) => {
    setSettings((current) => {
      const next = { ...current, ...patch };
      writeSettings(next);
      return next;
    });
  };

  const cycle = (
    key: "language" | "currency",
    options: string[]
  ) => {
    const index = options.indexOf(settings[key]);
    const nextValue = options[(index + 1) % options.length];
    update({ [key]: nextValue });
  };

  const clearCache = () => {
    Alert.alert(
      "Clear image lookup cache",
      "This clears image lookup results held in memory. Images may be looked up again when needed.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Clear",
          style: "destructive",
          onPress: () => {
            clearRelevantImageCache();
            Alert.alert("Cache cleared", "Image lookup results were cleared.");
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      <View style={styles.header}>
        <BackButton navigation={navigation} style={styles.backButton} iconSize={24} />
        <Text style={styles.headerTitle}>Settings</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.sectionLabel}>Notifications</Text>
        <View style={styles.card}>
          <ToggleRow
            icon="notifications-outline"
            label="Push notifications"
            value={settings.pushNotifications}
            onChange={(value) => update({ pushNotifications: value })}
          />
          <ToggleRow
            icon="mail-outline"
            label="Email updates"
            value={settings.emailNotifications}
            onChange={(value) => update({ emailNotifications: value })}
          />
          <ToggleRow
            icon="chatbubble-ellipses-outline"
            label="SMS alerts"
            value={settings.smsNotifications}
            onChange={(value) => update({ smsNotifications: value })}
          />
        </View>

        <Text style={styles.sectionLabel}>Appearance</Text>
        <View style={styles.card}>
          <ToggleRow
            icon="contrast-outline"
            label="Compact view"
            value={settings.compactView}
            onChange={(value) => update({ compactView: value })}
          />
        </View>

        <Text style={styles.sectionLabel}>Preferences</Text>
        <View style={styles.card}>
          <ChoiceRow
            icon="language-outline"
            label="Language"
            value={settings.language}
            onPress={() => cycle("language", LANGUAGE_OPTIONS)}
          />
          <ChoiceRow
            icon="cash-outline"
            label="Currency"
            value={settings.currency}
            onPress={() => cycle("currency", CURRENCY_OPTIONS)}
          />
        </View>

        <Text style={styles.sectionLabel}>Data & Privacy</Text>
        <View style={styles.card}>
          <ActionRow
            icon="trash-outline"
            label="Clear image lookup cache"
            color="#EF4444"
            onPress={clearCache}
          />
        </View>

        <View style={styles.aboutCard}>
          <Text style={styles.aboutTitle}>SuvYatra</Text>
          <Text style={styles.aboutText}>Version 1.0.0 (Demo)</Text>
          <Text style={styles.aboutText}>Made with ♥ in Nepal</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function ToggleRow({
  icon,
  label,
  value,
  onChange,
}: {
  icon: string;
  label: string;
  value: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <View style={styles.row}>
      <View style={styles.rowLeft}>
        <View style={styles.rowIcon}>
          <Ionicons name={icon as any} size={19} color={colors.primaryDark} />
        </View>
        <Text style={styles.rowText}>{label}</Text>
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ false: "#D1D5DB", true: "#A3E4CE" }}
        thumbColor={value ? colors.primary : "#F4F4F5"}
        accessibilityRole="switch"
        accessibilityState={{ checked: value }}
        accessibilityLabel={label}
      />
    </View>
  );
}

function ChoiceRow({
  icon,
  label,
  value,
  onPress,
}: {
  icon: string;
  label: string;
  value: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        styles.row,
        pressed && styles.rowPressed,
      ]}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${label}, currently ${value}. Tap to change.`}
    >
      <View style={styles.rowLeft}>
        <View style={styles.rowIcon}>
          <Ionicons name={icon as any} size={19} color={colors.primaryDark} />
        </View>
        <Text style={styles.rowText}>{label}</Text>
      </View>
      <View style={styles.rowRight}>
        <Text style={styles.rowValue}>{value}</Text>
        <Ionicons name="chevron-forward" size={17} color="#A0A0A0" />
      </View>
    </Pressable>
  );
}

function ActionRow({
  icon,
  label,
  color,
  onPress,
}: {
  icon: string;
  label: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}
      onPress={onPress}
      accessibilityRole="button"
    >
      <View style={styles.rowLeft}>
        <View style={[styles.rowIcon, { backgroundColor: "#FEF2F2" }]}>
          <Ionicons name={icon as any} size={19} color={color} />
        </View>
        <Text style={[styles.rowText, { color }]}>{label}</Text>
      </View>
      <Ionicons name="chevron-forward" size={17} color="#A0A0A0" />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },

  backButton: {
    width: 40,
    height: 40,
    borderRadius: radius.full,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    textAlign: "center",
    flex: 1,
  },

  headerSpacer: {
    width: 40,
  },

  content: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxxl,
  },

  sectionLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: colors.textMuted,
    textTransform: "uppercase",
    letterSpacing: 0.4,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },

  card: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    overflow: "hidden",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 13,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },

  rowPressed: {
    backgroundColor: "#F2F5F4",
  },

  rowLeft: {
    flexDirection: "row",
    alignItems: "center",
  },

  rowIcon: {
    width: 34,
    height: 34,
    borderRadius: radius.sm,
    backgroundColor: "#EAF8F2",
    alignItems: "center",
    justifyContent: "center",
  },

  rowText: {
    fontSize: 15,
    color: colors.text,
    fontWeight: "500",
    marginLeft: spacing.md,
  },

  rowRight: {
    flexDirection: "row",
    alignItems: "center",
  },

  rowValue: {
    fontSize: 14,
    color: colors.textMuted,
    marginRight: 4,
  },

  aboutCard: {
    alignItems: "center",
    marginTop: spacing.xxl,
  },

  aboutTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
  },

  aboutText: {
    fontSize: 12.5,
    color: colors.textMuted,
    marginTop: 4,
  },
});