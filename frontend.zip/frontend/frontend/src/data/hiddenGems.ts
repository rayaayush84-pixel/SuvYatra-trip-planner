import { HiddenGemDetails } from "../../App";

export const DEFAULT_HIDDEN_GEMS: HiddenGemDetails[] = [
  {
    name: "Sarangkot",
    location: "Pokhara, Nepal",
    description:
      "A famous sunrise viewpoint with sweeping views of the Annapurna range and peaceful mountain air.",
    tags: ["Nature", "Peaceful"],
    image: "",
  },
  {
    name: "World Peace Pagoda",
    location: "Pokhara, Nepal",
    description:
      "A quiet hilltop pagoda surrounded by forests, known for meditation and panoramic valley views.",
    tags: ["Nature", "Peaceful"],
    image: "",
  },
  {
    name: "Begnas Lake",
    location: "Pokhara, Nepal",
    description:
      "A peaceful lake with boating, short treks, and a relaxed countryside feel away from busy tourist spots.",
    tags: ["Nature", "Hiking", "Peaceful"],
    whyHiddenGem:
      "The existing SuvYatra description says it is away from busy tourist spots.",
    image: "",
  },
];
