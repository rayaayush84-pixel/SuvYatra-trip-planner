/**
 * Complete Trip fallback strategy for SuvYatra.
 *
 * Used ONLY by the guided "Plan a Complete Trip" flow (DestinationTripScreen).
 * Priority order (universal fallback logic):
 *
 *   LEVEL 1: exact destination match
 *   LEVEL 2: same city / municipality match
 *   LEVEL 3: nearby / province match
 *   LEVEL 4: curated Nepal fallback dataset (destination-aware, real places only)
 *
 * Curated entries below are real, well-known Nepal travel entities or truthful
 * accommodation/service categories (e.g. teahouse lodges on trekking routes).
 * They are NEVER presented as bookable inventory: the UI marks them as
 * suggestions and only offers Map / Directions actions for them.
 */

export type DestinationScope = {
  /** Raw destination text entered/selected by the user. */
  primary: string;
  /** City term used for LEVEL 2 API searches. */
  city: string;
  /** Province term used for LEVEL 3 API searches ("" when unknown). */
  province: string;
  /** Key into CURATED_FALLBACK below. */
  key: string;
};

type AliasRule = {
  tokens: string[];
  city: string;
  province: string;
  key: string;
};

// Ordered: more-specific place names must come before generic ones
// (e.g. bhaktapur before kathmandu so "Bhaktapur Durbar Square" resolves right).
const ALIAS_RULES: AliasRule[] = [
  { tokens: ["bhaktapur", "nagarkot", "dhulikhel", "nyatapola", "pottery square", "changu"], city: "Bhaktapur", province: "Bagmati", key: "bhaktapur" },
  { tokens: ["lalitpur", "patan", "jhamsikhel", "pulchowk", "gwarko"], city: "Lalitpur", province: "Bagmati", key: "kathmandu" },
  { tokens: ["kathmandu", "thamel", "boudha", "boudhanath", "swayambhu", "pashupati", "durbar", "bhrikutimandap", "kirtipur", "pharping", "chobhar", "budhanilkantha", "narayanhiti", "hanuman dhoka", "asan", "indra chowk"], city: "Kathmandu", province: "Bagmati", key: "kathmandu" },
  { tokens: ["pokhara", "phewa", "fewa", "sarangkot", "davis", "devi's fall", "begnas", "rupa lake", "lakeside", "pagoda", "matepani", "damside", "baidam", "gupteshwor", "mahendra cave", "chamere"], city: "Pokhara", province: "Gandaki", key: "pokhara" },
  { tokens: ["bandipur", "siddha cave", "tanahun", "damauli"], city: "Bandipur", province: "Gandaki", key: "bandipur" },
  { tokens: ["manang", "tilicho", "thorong", "chame", "pisang", "annapurna circuit"], city: "Manang", province: "Gandaki", key: "manang" },
  { tokens: ["chitwan", "sauraha", "bharatpur", "rapti", "bishazari", "bis hazari", "devghat", "meghauli"], city: "Chitwan", province: "Bagmati", key: "chitwan" },
  { tokens: ["lumbini", "maya devi", "monastic zone", "kapilvastu", "tilaurakot", "sacred garden"], city: "Lumbini", province: "Lumbini", key: "lumbini" },
  { tokens: ["ilam", "kanyam", "antu", "fikkal", "tea garden"], city: "Ilam", province: "Koshi", key: "ilam" },
  { tokens: ["janakpur", "janaki", "mithila", "dhanush", "dhanush sagar"], city: "Janakpur", province: "Madhesh", key: "janakpur" },
  { tokens: ["everest", "khumbu", "namche", "lukla", "tengboche", "syangboche", "solukhumbu", "phakding", "lobuche", "gorakshep", "base camp"], city: "Solukhumbu", province: "Koshi", key: "everest" },
];

export function resolveDestination(raw: string): DestinationScope {
  const primary = (raw ?? "").trim();
  const lowered = primary.toLowerCase();
  for (const rule of ALIAS_RULES) {
    if (rule.tokens.some((token) => lowered.includes(token))) {
      return { primary, city: rule.city, province: rule.province, key: rule.key };
    }
  }
  return { primary, city: primary, province: "", key: "default" };
}

// ---------------------------------------------------------------------------
// Curated fallback shapes (structural subsets of the screen's record types).
// `cid` prefixes keep curated ids distinct from database ObjectIds so the UI
// can tell "suggestion, not bookable inventory" apart.
// ---------------------------------------------------------------------------

export type CuratedPlace = {
  _id: string;
  name: string;
  location?: string;
  description?: string;
  province?: string;
  highlights?: string[];
  whyVisit?: string;
  bestTimeToVisit?: string;
  isCurated?: boolean;
};

export type CuratedActivity = {
  _id: string;
  name: string;
  location?: string;
  province?: string;
  description?: string;
  meetingPoint?: string;
  isCurated?: boolean;
};

export type CuratedHotel = {
  _id: string;
  name: string;
  location?: string;
  description?: string;
};

export type CuratedService = {
  _id: string;
  name: string;
  category: string;
  location?: string;
  description?: string;
};

export type CuratedSet = {
  attractions: CuratedPlace[];
  activities: CuratedActivity[];
  gems: CuratedPlace[];
  hotels: CuratedHotel[];
  services: CuratedService[];
};

const NATIONWIDE_SERVICES: CuratedService[] = [
  {
    _id: "curated-service-police-100",
    name: "Nepal Police (Emergency 100)",
    category: "Emergency",
    location: "Nationwide",
    description: "National police emergency helpline. Dial 100 from any phone in Nepal.",
  },
  {
    _id: "curated-service-ambulance-102",
    name: "Ambulance Service (102)",
    category: "Emergency",
    location: "Nationwide",
    description: "National ambulance helpline. Dial 102 for medical emergencies.",
  },
];

export const CURATED_FALLBACK: Record<string, CuratedSet> = {
  kathmandu: {
    attractions: [
      { _id: "curated-attraction-ktm-boudhanath", name: "Boudhanath Stupa", location: "Boudha, Kathmandu", province: "Bagmati", description: "One of the largest stupas in Nepal and a UNESCO World Heritage Site, centre of Tibetan Buddhist culture in Kathmandu.", highlights: ["Stupa kora walk", "Monasteries", "Butter lamps"], isCurated: true },
      { _id: "curated-attraction-ktm-swayambhu", name: "Swayambhunath (Monkey Temple)", location: "Swayambhu, Kathmandu", province: "Bagmati", description: "Ancient hilltop stupa complex with panoramic views over Kathmandu Valley, sacred to Buddhists and Hindus.", highlights: ["Stupa", "Valley viewpoint", "Harati temple"], isCurated: true },
      { _id: "curated-attraction-ktm-pashupati", name: "Pashupatinath Temple", location: "Gaushala, Kathmandu", province: "Bagmati", description: "Nepal's most sacred Hindu temple on the Bagmati River, a UNESCO World Heritage Site.", highlights: ["Main temple", "Aarati ceremony", "Bagmati ghats"], isCurated: true },
      { _id: "curated-attraction-ktm-durbar", name: "Kathmandu Durbar Square", location: "Basantapur, Kathmandu", province: "Bagmati", description: "Historic royal square with palaces, courtyards and the living goddess Kumari's residence.", highlights: ["Hanuman Dhoka", "Kumari Ghar", "Taleju Temple"], isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-ktm-mountain-flight", name: "Mountain Flight over the Himalayas", location: "Tribhuvan International Airport, Kathmandu", description: "Scenic one-hour flight with views of Everest and the Himalayan range. Confirm schedule and weather with the airline.", meetingPoint: "Tribhuvan International Airport", isCurated: true },
      { _id: "curated-activity-ktm-chandragiri", name: "Chandragiri Cable Car Ride", location: "Thankot, Kathmandu", description: "Cable-car ride to Chandragiri Hill top for Himalayan panorama and Bhaleshwor Mahadev temple.", meetingPoint: "Chandragiri cable-car base station, Thankot", isCurated: true },
      { _id: "curated-activity-ktm-walk", name: "Thamel Heritage Walk", location: "Thamel, Kathmandu", description: "Guided walking exploration of Thamel's bazaars, shrines and courtyards. Arrange a local guide for the best experience.", meetingPoint: "Thamel, Kathmandu", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-ktm-kirtipur", name: "Kirtipur", location: "Kirtipur, Kathmandu Valley", province: "Bagmati", description: "Old Newar hill town with temples, traditional streets and valley views — far quieter than central Kathmandu.", whyVisit: "Authentic Newar town life without the Thamel crowds.", isCurated: true },
      { _id: "curated-gem-ktm-pharping", name: "Pharping", location: "Dakshinkali, Kathmandu Valley", province: "Bagmati", description: "Village known for the Asura Cave meditation site, monasteries and the Dakshinkali area.", whyVisit: "Spiritual sites and village walks off the main tourist circuit.", isCurated: true },
      { _id: "curated-gem-ktm-chobhar", name: "Chobhar Gorge", location: "Chobhar, Kathmandu", province: "Bagmati", description: "Narrow gorge where the Bagmati River exits the valley, with the Jal Binayak temple nearby.", whyVisit: "A short, scenic escape at the valley rim.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-ktm-yak-yeti", name: "Hotel Yak & Yeti", location: "Durbarmarg, Kathmandu", description: "Well-known heritage hotel on Durbarmarg. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-ktm-dwarikas", name: "Dwarika's Hotel", location: "Battisputali, Kathmandu", description: "Heritage-style hotel known for Newari architecture. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-ktm-guest-house", name: "Kathmandu Guest House", location: "Thamel, Kathmandu", description: "Long-running traveller favourite in Thamel. Availability not confirmed here — verify directly with the property." },
    ],
    services: [
      { _id: "curated-service-ktm-bir", name: "Bir Hospital", category: "Hospital", location: "Mahaboudha, Kathmandu", description: "Oldest government hospital in central Kathmandu. Verify hours and departments before visiting." },
      { _id: "curated-service-ktm-tourist-police", name: "Tourist Police Office", category: "Tourist help", location: "Bhrikutimandap, Kathmandu", description: "Tourist police assistance for visitors in Kathmandu. Verify current contact locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  bhaktapur: {
    attractions: [
      { _id: "curated-attraction-bkt-square", name: "Bhaktapur Durbar Square", location: "Bhaktapur", province: "Bagmati", description: "UNESCO-listed royal square famed for Nyatapola Temple, the 55-window palace and traditional Newar architecture.", highlights: ["Nyatapola Temple", "55-window palace", "Vatsala Temple"], isCurated: true },
      { _id: "curated-attraction-bkt-pottery", name: "Pottery Square", location: "Bhaktapur", province: "Bagmati", description: "Working pottery square where artisans shape and sun-dry clay pottery in the open.", isCurated: true },
      { _id: "curated-attraction-bkt-nagarkot", name: "Nagarkot Viewpoint", location: "Nagarkot, Bhaktapur", province: "Bagmati", description: "Hill-station viewpoint famous for sunrise and sunset Himalayan panoramas, including Everest on clear days.", bestTimeToVisit: "October to March for clearest views", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-bkt-pottery", name: "Pottery Making Session", location: "Pottery Square, Bhaktapur", description: "Hands-on pottery session with local artisans. Arrange on arrival; availability varies by day.", meetingPoint: "Pottery Square, Bhaktapur", isCurated: true },
      { _id: "curated-activity-bkt-nagarkot-hike", name: "Nagarkot Sunrise Walk", location: "Nagarkot", description: "Early-morning walk to the viewpoint tower for sunrise over the Himalaya. Check weather the evening before.", meetingPoint: "Nagarkot viewpoint", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-bkt-changu", name: "Changu Narayan", location: "Changunarayan, Bhaktapur", province: "Bagmati", description: "UNESCO-listed Vishnu temple on a hilltop with ancient inscriptions — much quieter than the main squares.", whyVisit: "Oldest temple in the valley in a peaceful hill setting.", isCurated: true },
      { _id: "curated-gem-bkt-dattatreya", name: "Dattatreya Square", location: "Bhaktapur", province: "Bagmati", description: "Lesser-visited historic square with the Dattatreya Temple and wood-carving museum.", whyVisit: "Heritage without the crowds of Durbar Square.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-bkt-peacock", name: "Peacock Guest House", location: "Dattatreya Square, Bhaktapur", description: "Heritage guest house on Dattatreya Square. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-bkt-club-himalaya", name: "Club Himalaya", location: "Nagarkot, Bhaktapur", description: "Well-known resort for Himalayan views at Nagarkot. Availability not confirmed here — verify directly with the property." },
    ],
    services: [
      { _id: "curated-service-bkt-hospital", name: "District Hospital, Bhaktapur", category: "Hospital", location: "Bhaktapur", description: "Government district hospital. Verify location and hours locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  pokhara: {
    attractions: [
      { _id: "curated-attraction-pkr-phewa", name: "Phewa Lake", location: "Lakeside, Pokhara", province: "Gandaki", description: "Pokhara's famous lake for boating with reflections of the Annapurna range and the Tal Barahi temple island.", highlights: ["Boating", "Tal Barahi Temple", "Lakeside walk"], isCurated: true },
      { _id: "curated-attraction-pkr-davis", name: "Davis Falls", location: "Pokhara", province: "Gandaki", description: "Powerful waterfall that disappears into an underground tunnel, best during and after monsoon.", isCurated: true },
      { _id: "curated-attraction-pkr-peace-pagoda", name: "World Peace Pagoda", location: "Anadu Hill, Pokhara", province: "Gandaki", description: "White hilltop pagoda with panoramic views over Phewa Lake and the Annapurnas.", isCurated: true },
      { _id: "curated-attraction-pkr-sarangkot", name: "Sarangkot", location: "Sarangkot, Pokhara", province: "Gandaki", description: "Classic sunrise viewpoint above Pokhara with sweeping Annapurna and Dhaulagiri views.", bestTimeToVisit: "October to April for clearest sunrises", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-pkr-paragliding", name: "Tandem Paragliding, Sarangkot", location: "Sarangkot, Pokhara", description: "Tandem paragliding flight from Sarangkot over Pokhara Valley. Fly only with a licensed operator and confirm weather.", meetingPoint: "Sarangkot launch site", isCurated: true },
      { _id: "curated-activity-pkr-boating", name: "Phewa Lake Boating", location: "Lakeside, Pokhara", description: "Row or paddle boat trip on Phewa Lake, including the Tal Barahi island temple. Hire boats at Lakeside.", meetingPoint: "Lakeside boat station", isCurated: true },
      { _id: "curated-activity-pkr-zipline", name: "Zipline, Sarangkot", location: "Sarangkot, Pokhara", description: "High-speed zipline descent near Sarangkot. Verify the operator and current safety information.", meetingPoint: "Sarangkot, Pokhara", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-pkr-begnas", name: "Begnas Lake", location: "Begnas, Pokhara", province: "Gandaki", description: "Peaceful lake east of Pokhara with boating and village walks, away from the Lakeside crowds.", whyVisit: "The quiet alternative to Phewa Lake.", isCurated: true },
      { _id: "curated-gem-pkr-rupa", name: "Rupa Lake", location: "Rupa, Pokhara", province: "Gandaki", description: "Small, calm lake near Begnas, popular with birdwatchers and those seeking solitude.", whyVisit: "One of the least-visited lakes around Pokhara.", isCurated: true },
      { _id: "curated-gem-pkr-matepani", name: "Matepani Gumba", location: "Matepani, Pokhara", province: "Gandaki", description: "Monastery on a hillock east of Mahendrapul with valley views and morning prayers.", whyVisit: "A quiet monastic stop most visitors miss.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-pkr-barahi", name: "Hotel Barahi", location: "Lakeside, Pokhara", description: "Well-known Lakeside hotel. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-pkr-fishtail", name: "Fish Tail Lodge", location: "Gaurighat, Pokhara", description: "Lakeside lodge across Phewa Lake, reached by raft. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-pkr-temple-tree", name: "Temple Tree Resort & Spa", location: "Lakeside, Pokhara", description: "Garden resort in Lakeside. Availability not confirmed here — verify directly with the property." },
    ],
    services: [
      { _id: "curated-service-pkr-manipal", name: "Manipal Teaching Hospital", category: "Hospital", location: "Phulbari, Pokhara", description: "Major teaching hospital in Pokhara. Verify departments and hours before visiting." },
      { _id: "curated-service-pkr-tourist-police", name: "Tourist Police Office", category: "Tourist help", location: "Damside, Pokhara", description: "Tourist police assistance for visitors in Pokhara. Verify current contact locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  chitwan: {
    attractions: [
      { _id: "curated-attraction-ctn-park", name: "Chitwan National Park", location: "Chitwan", province: "Bagmati", description: "UNESCO-listed lowland park famous for one-horned rhinoceros, gharials and jungle wildlife.", highlights: ["Rhino sightings", "Rapti River", "Jungle trails"], isCurated: true },
      { _id: "curated-attraction-ctn-rapti", name: "Rapti River", location: "Sauraha, Chitwan", province: "Bagmati", description: "River bordering the park, known for canoe rides and sunset views with elephants bathing.", isCurated: true },
      { _id: "curated-attraction-ctn-tharu", name: "Tharu Village, Sauraha", location: "Sauraha, Chitwan", province: "Bagmati", description: "Traditional Tharu settlement showcasing indigenous culture, mud houses and local life.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-ctn-safari", name: "Jungle Safari", location: "Chitwan National Park", description: "Guided jeep or walking safari in the park. Use an authorized operator and follow park rules.", meetingPoint: "Sauraha, Chitwan", isCurated: true },
      { _id: "curated-activity-ctn-canoe", name: "Canoe Ride on the Rapti", location: "Rapti River, Sauraha", description: "Traditional dugout-canoe ride for birdwatching and gharial spotting. Arrange through Sauraha operators.", meetingPoint: "Sauraha, Chitwan", isCurated: true },
      { _id: "curated-activity-ctn-tharu", name: "Tharu Cultural Program", location: "Sauraha, Chitwan", description: "Evening stick dance and cultural performance by the Tharu community in Sauraha.", meetingPoint: "Sauraha, Chitwan", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-ctn-bishazari", name: "Bishazari Tal (Bis Hazari Lake)", location: "Chitwan", province: "Bagmati", description: "Chain of oxbow lakes inside the park buffer zone, excellent for quiet birdwatching.", whyVisit: "A Ramsar wetland most park visitors never reach.", isCurated: true },
      { _id: "curated-gem-ctn-devghat", name: "Devghat", location: "Devghat, Chitwan", province: "Bagmati", description: "Sacred confluence town on the Narayani River with ashrams and riverside ghats.", whyVisit: "A peaceful pilgrimage town away from Sauraha's safari crowds.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-ctn-green-park", name: "Green Park Chitwan", location: "Sauraha, Chitwan", description: "Well-known resort in Sauraha near the park. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-ctn-tigerland", name: "Tigerland Safari Resort", location: "Meghauli, Chitwan", description: "Jungle resort on the Rapti River banks. Availability not confirmed here — verify directly with the property." },
    ],
    services: [
      { _id: "curated-service-ctn-hospital", name: "District Hospital, Bharatpur", category: "Hospital", location: "Bharatpur, Chitwan", description: "Government hospital in Bharatpur. Verify location and hours locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  lumbini: {
    attractions: [
      { _id: "curated-attraction-lmb-maya-devi", name: "Maya Devi Temple", location: "Lumbini", province: "Lumbini", description: "Temple marking the traditionally recognised birthplace of Gautama Buddha, within the Sacred Garden.", highlights: ["Marker stone", "Sacred Garden", "Puskarini pond"], isCurated: true },
      { _id: "curated-attraction-lmb-monastic", name: "Monastic Zone", location: "Lumbini", province: "Lumbini", description: "Zone of international monasteries built in the architectural styles of Buddhist nations worldwide.", isCurated: true },
      { _id: "curated-attraction-lmb-tilaurakot", name: "Tilaurakot", location: "Kapilvastu, Lumbini", province: "Lumbini", description: "Archaeological site identified with ancient Kapilvastu, the Shakya capital of Buddha's youth.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-lmb-cycling", name: "Lumbini Cycling Tour", location: "Lumbini", description: "Cycle between monasteries, the Sacred Garden and nearby villages. Hire bicycles near the main gate.", meetingPoint: "Lumbini main gate", isCurated: true },
      { _id: "curated-activity-lmb-meditation", name: "Meditation Session", location: "Lumbini", description: "Join a meditation or mindfulness session at one of the monasteries. Check schedules on arrival.", meetingPoint: "Monastic Zone, Lumbini", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-lmb-tilaurakot", name: "Tilaurakot Archaeological Site", location: "Kapilvastu", province: "Lumbini", description: "Quiet ruins of the Shakya palace city, a fraction of Lumbini's visitors make the trip.", whyVisit: "Deep history without the crowds.", isCurated: true },
      { _id: "curated-gem-lmb-kudan", name: "Kudan", location: "Kapilvastu", province: "Lumbini", description: "Site where Buddha met his father after enlightenment, with ancient stupas in a rural setting.", whyVisit: "An important Buddhist site most itineraries skip.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-lmb-hokke", name: "Lumbini Hokke Hotel", location: "Lumbini", description: "Well-known hotel near the Sacred Garden. Availability not confirmed here — verify directly with the property." },
    ],
    services: [
      { _id: "curated-service-lmb-hospital", name: "District Hospital, Bhairahawa", category: "Hospital", location: "Siddharthanagar (Bhairahawa)", description: "Nearest major government hospital to Lumbini. Verify location and hours locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  ilam: {
    attractions: [
      { _id: "curated-attraction-ilm-kanyam", name: "Kanyam Tea Garden", location: "Kanyam, Ilam", province: "Koshi", description: "Rolling tea estate with picnic spots and Himalayan views — eastern Nepal's most loved landscape.", highlights: ["Tea gardens", "Picnic spots", "Mountain views"], isCurated: true },
      { _id: "curated-attraction-ilm-antu", name: "Antu Danda", location: "Antu, Ilam", province: "Koshi", description: "Hilltop viewpoint famous for sunrise over the eastern Himalaya, including Kanchenjunga.", bestTimeToVisit: "October to December for clearest sunrises", isCurated: true },
      { _id: "curated-attraction-ilm-maipokhari", name: "Mai Pokhari", location: "Ilam", province: "Koshi", description: "Sacred Ramsar-listed lake surrounded by forest, important for both biodiversity and pilgrims.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-ilm-tea", name: "Tea Garden Walk & Tasting", location: "Kanyam, Ilam", description: "Walk the tea rows, visit a processing factory and taste fresh Ilam tea. Arrange with local estates.", meetingPoint: "Kanyam, Ilam", isCurated: true },
      { _id: "curated-activity-ilm-antu-sunrise", name: "Antu Danda Sunrise Trip", location: "Antu, Ilam", description: "Pre-dawn drive to Antu Danda for sunrise over Kanchenjunga and the eastern range.", meetingPoint: "Antu Danda", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-ilm-maipokhari", name: "Mai Pokhari", location: "Ilam", province: "Koshi", description: "Forest-ringed sacred lake that most Ilam visitors pass by on the way to Kanyam.", whyVisit: "Ramsar wetland in peaceful forest surroundings.", isCurated: true },
      { _id: "curated-gem-ilm-sandakpur", name: "Sandakpur (via Ilam)", location: "Ilam–Darjeeling border", province: "Koshi", description: "High ridge viewpoint on the Nepal–India border with four of the world's five highest peaks visible.", whyVisit: "A legendary viewpoint reached through Ilam's tea country.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-ilm-homestay", name: "Community Homestays (Kanyam / Ilam)", location: "Kanyam, Ilam", description: "Family-run community homestays are the standard stay around Kanyam. Availability not confirmed here — arrange locally in advance." },
    ],
    services: [
      { _id: "curated-service-ilm-hospital", name: "District Hospital, Ilam", category: "Hospital", location: "Ilam Bazaar, Ilam", description: "Government district hospital. Verify location and hours locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  bandipur: {
    attractions: [
      { _id: "curated-attraction-bdp-bazaar", name: "Bandipur Bazaar", location: "Bandipur, Tanahun", province: "Gandaki", description: "Preserved Newar trading town with 18th-century architecture and Himalayan backdrops.", highlights: ["Newar architecture", "Mountain views", "Tudikhel"], isCurated: true },
      { _id: "curated-attraction-bdp-siddha", name: "Siddha Cave", location: "Bandipur, Tanahun", province: "Gandaki", description: "One of Nepal's largest caves, reached by a hike down from Bandipur Bazaar.", isCurated: true },
      { _id: "curated-attraction-bdp-thanimai", name: "Thanimai Temple & Viewpoint", location: "Bandipur, Tanahun", province: "Gandaki", description: "Hilltop temple and viewpoint above the bazaar with Annapurna and Manaslu panoramas.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-bdp-cave", name: "Siddha Cave Exploration", location: "Bandipur", description: "Guided descent into Siddha Cave with a local guide. Carry a torch and wear sturdy shoes.", meetingPoint: "Bandipur Bazaar", isCurated: true },
      { _id: "curated-activity-bdp-hike", name: "Bandipur Ridge Hike", location: "Bandipur", description: "Walk the ridge trail past Thanimai temple for Himalayan views and village life.", meetingPoint: "Bandipur Bazaar", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-bdp-raniban", name: "Raniban Viewpoint", location: "Bandipur, Tanahun", province: "Gandaki", description: "Forested viewpoint below the bazaar that most day visitors never walk to.", whyVisit: "Forest trail with big Himalayan views.", isCurated: true },
      { _id: "curated-gem-bdp-ramkot", name: "Ramkot Village", location: "Near Bandipur, Tanahun", province: "Gandaki", description: "Traditional Magar village on the old trade route below Bandipur.", whyVisit: "Village life on a historic trading trail.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-bdp-old-inn", name: "Old Inn Bandipur", location: "Bandipur Bazaar, Tanahun", description: "Well-known Newari-style inn in the bazaar. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-bdp-mountain-resort", name: "Bandipur Mountain Resort", location: "Bandipur, Tanahun", description: "Hill resort above the town with Himalayan views. Availability not confirmed here — verify directly with the property." },
    ],
    services: [
      { _id: "curated-service-bdp-hospital", name: "District Hospital, Damauli", category: "Hospital", location: "Damauli, Tanahun", description: "Nearest district hospital to Bandipur. Verify location and hours locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  manang: {
    attractions: [
      { _id: "curated-attraction-mng-village", name: "Manang Village", location: "Manang", province: "Gandaki", description: "High Himalayan village on the Annapurna Circuit with stone houses, bakeries and mountain culture.", highlights: ["Gangapurna views", "Bakeries", "Acclimatisation walks"], isCurated: true },
      { _id: "curated-attraction-mng-tilicho-base", name: "Tilicho Base Camp Trail", location: "Manang", province: "Gandaki", description: "Trail toward Tilicho Lake, one of the world's highest lakes, via Khangsar village.", isCurated: true },
      { _id: "curated-attraction-mng-gangapurna-lake", name: "Gangapurna Lake", location: "Manang", province: "Gandaki", description: "Glacial lake an hour's walk from Manang village beneath Gangapurna's icefall.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-mng-acclimatisation", name: "Acclimatisation Hike", location: "Manang", description: "Guided acclimatisation day-hike to higher viewpoints. Essential before crossing Thorong La.", meetingPoint: "Manang village", isCurated: true },
      { _id: "curated-activity-mng-tilicho", name: "Tilicho Lake Trek", location: "Manang", province: "Gandaki", description: "Multi-day trek to Tilicho Lake (4,919 m). Requires permits, a guide and proper acclimatisation.", meetingPoint: "Manang village", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-mng-khangsar", name: "Khangsar Village", location: "Manang", province: "Gandaki", description: "Last village on the Tilicho trail, quieter and more traditional than Manang itself.", whyVisit: "The gateway to Tilicho that trekkers rush past.", isCurated: true },
      { _id: "curated-gem-mng-braga", name: "Braga Monastery", location: "Braga, Manang", province: "Gandaki", description: "500-year-old monastery above Braga village with ancient murals and mountain views.", whyVisit: "Centuries of history above the main trail.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-mng-teahouse", name: "Local Teahouse Lodges", location: "Manang, Annapurna Circuit", description: "Teahouse lodges are the standard stay on the circuit. Availability not confirmed here — arrange through your trekking operator." },
    ],
    services: [
      { _id: "curated-service-mng-aid-post", name: "Himalayan Rescue Aid Post", category: "Medical aid", location: "Manang", description: "Seasonal high-altitude aid post in Manang. Verify seasonal availability locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  everest: {
    attractions: [
      { _id: "curated-attraction-eve-namche", name: "Namche Bazaar", location: "Namche, Solukhumbu", province: "Koshi", description: "Famous Sherpa market town and acclimatisation hub on the Everest trail.", highlights: ["Sherpa museum", "Saturday market", "Everest views"], isCurated: true },
      { _id: "curated-attraction-eve-tengboche", name: "Tengboche Monastery", location: "Tengboche, Solukhumbu", province: "Koshi", description: "Largest monastery in Khumbu with morning prayers and a classic Everest–Ama Dablam backdrop.", isCurated: true },
      { _id: "curated-attraction-eve-sagarmatha", name: "Sagarmatha National Park", location: "Solukhumbu", province: "Koshi", description: "UNESCO-listed park protecting Everest's southern approaches, Sherpa villages and rare wildlife.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-eve-base-camp", name: "Everest Base Camp Trek", location: "Khumbu, Solukhumbu", description: "High-altitude trek to Everest Base Camp. Permits, acclimatisation and a licensed guide are essential.", meetingPoint: "Lukla, Solukhumbu", isCurated: true },
      { _id: "curated-activity-eve-kalapatthar", name: "Kala Patthar Sunrise Climb", location: "Gorakshep, Solukhumbu", description: "Pre-dawn climb to 5,545 m for the classic close-up Everest sunrise view.", meetingPoint: "Gorakshep", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-eve-khumjung", name: "Khumjung Village", location: "Khumjung, Solukhumbu", province: "Koshi", description: "Larger, quieter Sherpa village above Namche with the Hillary school and sacred sites.", whyVisit: "Authentic Sherpa village life above the trail crowds.", isCurated: true },
      { _id: "curated-gem-eve-thame", name: "Thame", location: "Thame, Solukhumbu", province: "Koshi", description: "Remote monastery village on the old salt-trade route west of Namche.", whyVisit: "A quiet detour most Everest trekkers miss.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-eve-everest-view", name: "Hotel Everest View", location: "Syangboche, Solukhumbu", description: "Famous viewpoint hotel above Namche. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-eve-teahouse", name: "Local Teahouse Lodges", location: "Namche / Khumbu trail", description: "Teahouse lodges are the standard stay on the Everest trail. Availability not confirmed here — arrange through your trekking operator." },
    ],
    services: [
      { _id: "curated-service-eve-lukla-hospital", name: "Pasang Lhamu Hospital, Lukla", category: "Hospital", location: "Lukla, Solukhumbu", description: "Hospital serving the lower Khumbu region. Verify services locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  janakpur: {
    attractions: [
      { _id: "curated-attraction-jnp-janaki", name: "Janaki Temple", location: "Janakpur", province: "Madhesh", description: "Magnificent Mughal-style temple dedicated to Goddess Sita at the heart of Mithila culture.", highlights: ["Temple architecture", "Vivah Mandap", "Festivals"], isCurated: true },
      { _id: "curated-attraction-jnp-dhanush", name: "Dhanush Sagar", location: "Janakpur", province: "Madhesh", description: "Sacred pond beside Janaki Temple, central to Chhath and local rituals.", isCurated: true },
      { _id: "curated-attraction-jnp-ram-mandir", name: "Ram Mandir", location: "Janakpur", province: "Madhesh", description: "Historic temple complex and one of the oldest pilgrimage stops in the city.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-jnp-mithila", name: "Mithila Art Experience", location: "Janakpur", description: "Visit Mithila art centres to see traditional Madhubani-style painting and meet local artists.", meetingPoint: "Janakpur", isCurated: true },
      { _id: "curated-activity-jnp-cycle", name: "Janakpur Heritage Cycle Tour", location: "Janakpur", description: "Cycle between temples, ponds and old bazaars with a local guide. Arrange cycles locally.", meetingPoint: "Janaki Temple area", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-jnp-dhanushadham", name: "Dhanushadham", location: "Dhanusha, Madhesh", province: "Madhesh", description: "Religious site with a fossil-like bow fragment linked to Ramayana legend, in peaceful rural surroundings.", whyVisit: "Legend and landscape away from the city.", isCurated: true },
      { _id: "curated-gem-jnp-kapileshwor", name: "Kapileshwor Sthan", location: "Janakpur", province: "Madhesh", description: "Ancient Shiva temple complex on the city's edge, quiet compared to the central temples.", whyVisit: "Old shrines in a calm setting.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-jnp-guest-house", name: "Guest Houses near Janaki Temple", location: "Janakpur", description: "Pilgrim guest houses and dharamshalas cluster around Janaki Temple. Availability not confirmed here — arrange locally in advance." },
    ],
    services: [
      { _id: "curated-service-jnp-hospital", name: "District Hospital, Janakpur", category: "Hospital", location: "Janakpur", description: "Government hospital in Janakpur. Verify location and hours locally." },
      ...NATIONWIDE_SERVICES,
    ],
  },
  default: {
    attractions: [
      { _id: "curated-attraction-np-phewa", name: "Phewa Lake", location: "Pokhara, Gandaki", province: "Gandaki", description: "Nepal's best-known lakeside destination for boating with Annapurna reflections.", isCurated: true },
      { _id: "curated-attraction-np-boudhanath", name: "Boudhanath Stupa", location: "Kathmandu, Bagmati", province: "Bagmati", description: "One of Nepal's most important Buddhist pilgrimage sites and a UNESCO World Heritage Site.", isCurated: true },
      { _id: "curated-attraction-np-chitwan", name: "Chitwan National Park", location: "Chitwan, Bagmati", province: "Bagmati", description: "UNESCO-listed park famous for one-horned rhinoceros and jungle wildlife.", isCurated: true },
    ],
    activities: [
      { _id: "curated-activity-np-phewa-boating", name: "Phewa Lake Boating", location: "Lakeside, Pokhara", description: "Row-boat trip on Phewa Lake. Hire boats at Lakeside, Pokhara.", meetingPoint: "Lakeside, Pokhara", isCurated: true },
      { _id: "curated-activity-np-heritage-walk", name: "Kathmandu Heritage Walk", location: "Kathmandu", description: "Walk the historic squares and bazaars of Kathmandu with a local guide.", meetingPoint: "Kathmandu Durbar Square", isCurated: true },
    ],
    gems: [
      { _id: "curated-gem-np-begnas", name: "Begnas Lake", location: "Pokhara, Gandaki", province: "Gandaki", description: "Peaceful lake east of Pokhara, away from the main tourist crowds.", whyVisit: "The quiet alternative to Phewa Lake.", isCurated: true },
      { _id: "curated-gem-np-kirtipur", name: "Kirtipur", location: "Kathmandu Valley, Bagmati", province: "Bagmati", description: "Old Newar hill town with temples and valley views.", whyVisit: "Authentic town life near Kathmandu.", isCurated: true },
    ],
    hotels: [
      { _id: "curated-hotel-np-yak-yeti", name: "Hotel Yak & Yeti", location: "Durbarmarg, Kathmandu", description: "Well-known heritage hotel in Kathmandu. Availability not confirmed here — verify directly with the property." },
      { _id: "curated-hotel-np-barahi", name: "Hotel Barahi", location: "Lakeside, Pokhara", description: "Well-known Lakeside hotel in Pokhara. Availability not confirmed here — verify directly with the property." },
    ],
    services: [...NATIONWIDE_SERVICES],
  },
};

export function curatedFor(key: string): CuratedSet {
  return CURATED_FALLBACK[key] ?? CURATED_FALLBACK.default;
}

/**
 * Pick lesser-known candidates from a destination search result: everything
 * except the exact destination match itself. Used for hidden gems so a famous
 * landmark is never labelled "hidden" just to fill the section.
 */
export function pickLesserKnown<T extends { name: string }>(records: T[], destination: string): T[] {
  const wanted = destination.trim().toLowerCase();
  return records.filter((record) => record.name.trim().toLowerCase() !== wanted);
}
