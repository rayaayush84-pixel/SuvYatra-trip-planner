import Constants from "expo-constants";
import { Platform } from "react-native";

export type ChatRole = "user" | "assistant";
export type HistoryItem = { role: ChatRole; content: string };
export type ChatSource = { source: string; snippet: string };

export type ReadyStatus = "checking" | "ready" | "empty" | "unreachable";

// User-facing fallback texts. The UI must never show raw backend details,
// HTTP status codes, ports, or provider names — those stay in logs.
export const CHAT_CONNECTIVITY_MESSAGE =
  "I'm having trouble reaching the travel assistant right now. Please check your connection and try again in a moment.";

export const CHAT_TEMPORARY_MESSAGE =
  "I'm having trouble accessing some travel information right now. Please try your question again in a moment.";

export const CHAT_AUTH_MESSAGE =
  "Please sign in again to continue chatting with the travel assistant.";

const NETWORK_ERROR_MESSAGE = CHAT_CONNECTIVITY_MESSAGE;

export class ChatApiError extends Error {
  status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.name = "ChatApiError";
    this.status = status;
  }
}

function getApiUrl(): string {
  const fromEnv = process.env.EXPO_PUBLIC_API_URL?.trim().replace(/\/+$/, "");

  const isWeb = Platform.OS === "web";
  if (isWeb && fromEnv) {
    return fromEnv;
  }

  const hostUri = Constants.expoConfig?.hostUri;
  if (hostUri) {
    const host = hostUri.split(":")[0];
    return `http://${host}:8000`;
  }

  return fromEnv || "http://localhost:8000";
}

export const API_URL = getApiUrl();

export async function checkReady(): Promise<ReadyStatus> {
  try {
    const res = await fetch(`${API_URL}/ready`);
    if (res.status === 503) {
      return "empty";
    }
    return res.ok ? "ready" : "unreachable";
  } catch {
    return "unreachable";
  }
}

/**
 * Map any HTTP failure to a clean user-facing message. Raw backend `detail`
 * text, status codes, and provider errors are deliberately discarded here —
 * the user only ever sees one of the friendly fallbacks above.
 */
function messageForStatus(status: number): string {
  if (status === 401 || status === 403) {
    return CHAT_AUTH_MESSAGE;
  }
  return CHAT_TEMPORARY_MESSAGE;
}

async function throwFromResponse(res: Response): Promise<never> {
  // Consume the body (so connections close cleanly) but never surface it.
  try {
    await res.json();
  } catch {
    // ignore parse errors
  }
  throw new ChatApiError(messageForStatus(res.status), res.status);
}

/** Convert any thrown error into the message the UI is allowed to display. */
export function userFacingChatError(error: unknown): string {
  if (error instanceof ChatApiError) {
    return error.message;
  }
  return CHAT_TEMPORARY_MESSAGE;
}

export type StreamOptions = {
  question: string;
  history: HistoryItem[];
  signal: AbortSignal;
  onToken: (token: string) => void;
  onDone: (sources: ChatSource[]) => void;
};

function supportsStreamingBody(): boolean {
  try {
    return (
      typeof (globalThis as any).ReadableStream === "function" &&
      typeof (globalThis as any).TextDecoder === "function"
    );
  } catch {
    return false;
  }
}

export async function streamChat(opts: StreamOptions): Promise<void> {
  const url = `${API_URL}/api/v1/chat/stream`;
  const body = JSON.stringify({
    question: opts.question,
    history: opts.history,
  });

  if (supportsStreamingBody()) {
    await streamWithFetch(url, body, opts);
  } else {
    await streamWithXhr(url, body, opts);
  }
}

function isStreamingBodySupported(res: Response): boolean {
  try {
    return (
      typeof res.body !== "undefined" &&
      typeof res.body?.getReader === "function"
    );
  } catch {
    return false;
  }
}

function handleBlock(block: string, opts: StreamOptions): void {
  const dataLine = block.split("\n").find((line) => line.startsWith("data:"));
  if (!dataLine) {
    return;
  }
  const payload = dataLine.slice(5).trim();
  if (!payload) {
    return;
  }

  let event: any;
  try {
    event = JSON.parse(payload);
  } catch {
    return;
  }
  if (!event || typeof event !== "object") {
    return;
  }

  if (typeof event.token === "string") {
    opts.onToken(event.token);
  } else if (event.done === true) {
    opts.onDone(Array.isArray(event.sources) ? event.sources : []);
  } else if (typeof event.error === "string") {
    // Never surface raw server SSE error text to the user.
    throw new ChatApiError(CHAT_TEMPORARY_MESSAGE);
  }
}

function processBuffer(
  buffer: string,
  opts: StreamOptions,
  handleEvent: (block: string) => void
): string {
  let index;
  while ((index = buffer.indexOf("\n\n")) !== -1) {
    const block = buffer.slice(0, index);
    buffer = buffer.slice(index + 2);
    handleEvent(block);
  }
  return buffer;
}

async function streamWithFetch(
  url: string,
  body: string,
  opts: StreamOptions
): Promise<void> {
  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
      signal: opts.signal,
    });
  } catch (err) {
    if (opts.signal.aborted) {
      return;
    }
    throw new ChatApiError(NETWORK_ERROR_MESSAGE);
  }

  if (!res.ok) {
    await throwFromResponse(res);
  }

  const reader = res.body?.getReader?.();
  if (!reader) {
    if (!isStreamingBodySupported(res)) {
      await streamWithXhr(url, body, opts);
      return;
    }
    throw new ChatApiError(NETWORK_ERROR_MESSAGE);
  }

  const decoder = new TextDecoder();
  let buffer = "";
  const handleEvent = (block: string) => handleBlock(block, opts);

  while (true) {
    const { done, value } = await reader.read();
    if (done) {
      break;
    }
    buffer += decoder.decode(value, { stream: true });
    buffer = processBuffer(buffer, opts, handleEvent);
  }
  buffer = processBuffer(buffer + "\n", opts, handleEvent);
}

async function streamWithXhr(
  url: string,
  body: string,
  opts: StreamOptions
): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    xhr.setRequestHeader("Content-Type", "application/json");

    let buffer = "";
    let lastIndex = 0;
    let sseError: string | null = null;
    const handleEvent = (block: string) => handleBlock(block, opts);

    const finish = (err?: Error) => {
      xhr.onprogress = null;
      xhr.onload = null;
      xhr.onerror = null;
      xhr.onabort = null;
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    };

    xhr.onprogress = () => {
      const text = xhr.responseText || "";
      buffer += text.slice(lastIndex);
      lastIndex = text.length;
      try {
        buffer = processBuffer(buffer, opts, handleEvent);
      } catch (err) {
        sseError = err instanceof Error ? err.message : "Unknown error";
        xhr.abort();
      }
    };

    xhr.onload = () => {
      if (sseError) {
        finish(new ChatApiError(sseError));
        return;
      }
      if (xhr.status === 0 || xhr.status >= 400) {
        finish(new ChatApiError(messageForStatus(xhr.status), xhr.status));
        return;
      }
      finish();
    };

    xhr.onerror = () => finish(new ChatApiError(NETWORK_ERROR_MESSAGE));

    xhr.onabort = () => {
      if (opts.signal.aborted) {
        finish();
      } else if (sseError) {
        finish(new ChatApiError(sseError));
      }
    };

    const handleAbort = () => xhr.abort();
    opts.signal.addEventListener("abort", handleAbort);
    xhr.send(body);
  });
}