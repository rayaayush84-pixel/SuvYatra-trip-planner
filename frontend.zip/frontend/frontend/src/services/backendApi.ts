import Constants from "expo-constants";
import { Platform } from "react-native";

const configuredBaseUrl = process.env.EXPO_PUBLIC_BACKEND_API_URL?.trim();
const localUrlPattern =
  /^https?:\/\/(?:localhost|127(?:\.\d{1,3}){3}|\[::1\])(?::\d+)?(?:\/|$)/i;

function getBackendBaseUrl(): string {
  if (Platform.OS !== "web" && Constants.expoConfig?.hostUri) {
    const configuredUrlIsLocal =
      !configuredBaseUrl || localUrlPattern.test(configuredBaseUrl);
    if (configuredUrlIsLocal) {
      const host = new URL(`http://${Constants.expoConfig.hostUri}`).hostname;
      return `http://${host}:5000/api`;
    }
  }

  return (
    configuredBaseUrl || "http://127.0.0.1:5000/api"
  ).replace(/\/+$/, "");
}

export const BACKEND_BASE_URL = getBackendBaseUrl();

export async function backendRequest<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);
  const abortFromCaller = () => controller.abort();
  options.signal?.addEventListener("abort", abortFromCaller, { once: true });
  try {
    const response = await fetch(`${BACKEND_BASE_URL}${normalizedPath}`, {
      ...options,
      signal: controller.signal,
    });

    if (!response.ok) {
      let message = `Request failed (${response.status}).`;
      try {
        const body: unknown = await response.json();
        if (
          typeof body === "object" &&
          body !== null &&
          "message" in body &&
          typeof body.message === "string"
        ) {
          message = body.message;
        }
      } catch {
        // Keep the HTTP status message when the server does not return JSON.
      }
      throw new Error(message);
    }

    return (await response.json()) as T;
  } catch (error) {
    if (!options.signal?.aborted && controller.signal.aborted) {
      throw new Error("The request timed out. Check your connection and try again.");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener("abort", abortFromCaller);
  }
}
