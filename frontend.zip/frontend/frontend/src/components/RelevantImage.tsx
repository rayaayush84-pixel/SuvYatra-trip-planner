import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Image,
  ImageStyle,
  Linking,
  StyleProp,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import {
  ImageEntity,
  RelevantImageReference,
  normalizeImageEntity,
  resolveRelevantImageCandidates,
} from "../imageResolver";
import { colors } from "../theme";

type Props = {
  entity: ImageEntity;
  style: StyleProp<ImageStyle>;
  resizeMode?: "cover" | "contain" | "stretch" | "center";
  accessibilityLabel?: string;
};

function fallbackIcon(type: string, name: string): keyof typeof Ionicons.glyphMap {
  const normalized = type.toLocaleLowerCase();
  const entityName = name.toLocaleLowerCase();
  if (normalized.includes("hotel")) return "bed-outline";
  if (normalized.includes("restaurant")) return "restaurant-outline";
  if (normalized.includes("hospital")) return "medkit-outline";
  if (normalized.includes("petrol")) return "car-outline";
  if (normalized.includes("atm")) return "card-outline";
  if (normalized.includes("transport")) {
    if (/bike|motorcycle|scooter/.test(entityName)) return "bicycle-outline";
    if (/jeep|car|taxi/.test(entityName)) return "car-outline";
    return "bus-outline";
  }
  if (normalized.includes("activity")) return "walk-outline";
  return "image-outline";
}

export default function RelevantImage({
  entity,
  style,
  resizeMode = "cover",
  accessibilityLabel,
}: Props) {
  // Normalize alternate image field names once, so every caller benefits.
  const normalized = normalizeImageEntity(entity);
  const entityKey = [
    normalized.name,
    normalized.type,
    normalized.location ?? "",
    normalized.image ?? "",
    (normalized.images ?? []).join(","),
  ].join("|");
  const requestVersion = useRef(0);
  const [candidates, setCandidates] = useState<RelevantImageReference[]>([]);
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const version = ++requestVersion.current;
    let active = true;
    setCandidates([]);
    setIndex(0);
    setLoading(true);

    resolveRelevantImageCandidates(normalized)
      .then((resolved) => {
        if (active && requestVersion.current === version) {
          setCandidates(resolved);
          // The ordered list always ends with a category fallback, so an
          // empty list only happens for entities with no name/type at all.
          setLoading(false);
        }
      })
      .catch((error: unknown) => {
        console.warn(`Image lookup failed for ${normalized.type} "${normalized.name}".`, error);
        if (active && requestVersion.current === version) setLoading(false);
      });

    return () => {
      active = false;
    };
    // Re-resolve when the entity (or any of its image fields) changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entityKey]);

  const image = candidates[index] ?? null;

  const handleImageError = () => {
    // Advance to the next candidate (stored → live → category fallback)
    // instead of leaving a broken image on screen.
    if (index + 1 < candidates.length) {
      setIndex(index + 1);
    } else {
      setIndex(candidates.length);
    }
  };

  if (!image) {
    return (
      <View style={[style, styles.fallback]} accessibilityLabel={accessibilityLabel ?? `${normalized.name} image`}>
        {loading ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : (
          <Ionicons name={fallbackIcon(normalized.type, normalized.name)} size={28} color="#0F766E" />
        )}
      </View>
    );
  }

  const label = accessibilityLabel ?? `${normalized.name} image`;
  return (
    <View style={[style, styles.frame]}>
      <Image
        source={{ uri: image.uri }}
        style={StyleSheet.absoluteFill}
        resizeMode={resizeMode}
        accessibilityLabel={`${label}; ${image.source}, ${image.license}${image.credit ? `, ${image.credit}` : ""}`}
        onLoad={() => setLoading(false)}
        onError={handleImageError}
      />
      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="small" color={colors.white} />
        </View>
      ) : null}
      <Text
        accessibilityLabel={`${image.credit || image.source}; ${image.license}`}
        accessibilityRole="link"
        numberOfLines={1}
        style={styles.attribution}
        onPress={() => {
          void Linking.openURL(image.sourcePage).catch((error: unknown) => {
            console.warn(`Could not open the image attribution page for ${normalized.name}.`, error);
          });
        }}
      >
        {`${image.relevance === "category" ? "Illustrative · " : ""}${image.credit || image.source} · ${image.license}`}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    overflow: "hidden",
    backgroundColor: "#DCE9E4",
  },
  fallback: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#DCE9E4",
  },
  loading: {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(15, 23, 42, 0.16)",
  },
  attribution: {
    position: "absolute",
    right: 4,
    bottom: 4,
    left: 4,
    paddingHorizontal: 4,
    paddingVertical: 2,
    overflow: "hidden",
    borderRadius: 4,
    color: "#FFFFFF",
    backgroundColor: "rgba(15, 23, 42, 0.68)",
    fontSize: 8,
  },
});
