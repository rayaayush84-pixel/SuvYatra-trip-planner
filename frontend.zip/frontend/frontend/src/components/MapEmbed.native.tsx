import React from "react";
import { StyleSheet } from "react-native";
import { WebView } from "react-native-webview";

export type MapEmbedProps = {
  uri: string;
  title?: string;
};

// Native (Android/iOS) implementation: the existing React Native-compatible
// map approach used across the app.
export default function MapEmbedNative({ uri }: MapEmbedProps) {
  return (
    <WebView
      source={{ uri }}
      style={styles.map}
      javaScriptEnabled
      domStorageEnabled
    />
  );
}

const styles = StyleSheet.create({
  map: { flex: 1 },
});
