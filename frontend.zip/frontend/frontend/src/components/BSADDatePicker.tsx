// Reusable AD (Gregorian) / BS (Bikram Sambat) calendar date picker.
// A calendar modal — never a plain text box. Emits one canonical AD ISO
// date (YYYY-MM-DD); BS is display + selection only, converted via the
// `nepali-date-converter` library (see utils/bsDate).
//
// Usage:
//   <BSADDatePicker label="Departure Date" value={startDate}
//     onChange={setStartDate} minDate={todayAdISO()} />
//   <BSADDatePicker label="Return Date" value={endDate}
//     onChange={setEndDate} minDate={startDate} minExclusive />

import React, { useEffect, useMemo, useState } from "react";
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useWindowDimensions,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing } from "../theme";
import {
  adMonthInfo,
  adToBs,
  bsMonthInfo,
  bsMonthNames,
  bsToAd,
  formatAdBsLines,
  formatDualDisplay,
  isStrictAdISO,
  todayAdISO,
} from "../utils/bsDate";

export type BSADDatePickerProps = {
  label: string;
  /** Canonical AD ISO (YYYY-MM-DD) or "". */
  value: string;
  onChange: (iso: string) => void;
  placeholder?: string;
  /** Earliest selectable date (inclusive unless minExclusive). */
  minDate?: string;
  /** Latest selectable date (inclusive). */
  maxDate?: string;
  /** minDate itself is not selectable (used for return-after-departure). */
  minExclusive?: boolean;
  /** Disable all past dates. Defaults to true for travel dates. */
  disablePast?: boolean;
  disabled?: boolean;
  error?: string;
};

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const AD_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function shiftMonth(year: number, month: number, delta: number): { year: number; month: number } {
  const total = (year * 12 + (month - 1) + delta) % 12;
  const norm = (total + 12) % 12;
  const yearDelta = Math.floor((year * 12 + (month - 1) + delta - norm) / 12);
  return { year: yearDelta, month: norm + 1 };
}

function isDisabledDate(iso: string, minDate?: string, maxDate?: string, minExclusive?: boolean, disablePast?: boolean): boolean {
  if (!isStrictAdISO(iso)) return true;
  if (disablePast !== false && iso < todayAdISO()) return true;
  if (minDate && isStrictAdISO(minDate)) {
    if (minExclusive ? iso <= minDate : iso < minDate) return true;
  }
  if (maxDate && isStrictAdISO(maxDate) && iso > maxDate) return true;
  return false;
}

export default function BSADDatePicker({
  label,
  value,
  onChange,
  placeholder = "Select date",
  minDate,
  maxDate,
  minExclusive = false,
  disablePast = true,
  disabled = false,
  error,
}: BSADDatePickerProps) {
  const { width } = useWindowDimensions();
  const [open, setOpen] = useState(false);
  const [calendar, setCalendar] = useState<"AD" | "BS">("AD");
  const [draft, setDraft] = useState(value && isStrictAdISO(value) ? value : "");
  const [adView, setAdView] = useState({ year: new Date().getFullYear(), month: new Date().getMonth() + 1 });
  const [bsView, setBsView] = useState({ year: 2083, month: 6 });

  const compact = width < 600;

  // Sync the visible month when the modal opens.
  useEffect(() => {
    if (!open) return;
    const base = value && isStrictAdISO(value) ? value : draft || todayAdISO();
    setDraft(value && isStrictAdISO(value) ? value : "");
    const [y, m] = base.split("-").map(Number);
    setAdView({ year: y, month: m });
    const bs = adToBs(base);
    if (bs) setBsView({ year: bs.year, month: bs.month });
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const adInfo = useMemo(() => adMonthInfo(adView.year, adView.month), [adView]);
  const bsInfo = useMemo(() => bsMonthInfo(bsView.year, bsView.month), [bsView]);
  const bsNames = useMemo(() => bsMonthNames(), []);

  const cells: (string | null)[] = useMemo(() => {
    if (calendar === "AD") {
      const out: (string | null)[] = Array(adInfo.firstWeekday).fill(null);
      for (let d = 1; d <= adInfo.daysInMonth; d++) {
        out.push(`${adView.year}-${String(adView.month).padStart(2, "0")}-${String(d).padStart(2, "0")}`);
      }
      return out;
    }
    const out: (string | null)[] = Array(bsInfo.firstWeekday).fill(null);
    for (let d = 1; d <= bsInfo.daysInMonth; d++) {
      out.push(bsToAd(bsView.year, bsView.month, d) ?? `bs:${d}`);
    }
    return out;
  }, [calendar, adInfo, bsInfo, adView, bsView]);

  const cellLabel = (iso: string | null, index: number): string => {
    if (!iso) return "";
    if (iso.startsWith("bs:")) return iso.slice(3);
    return String(Number(iso.slice(8, 10)));
  };

  const footer = draft && isStrictAdISO(draft) ? formatAdBsLines(draft) : null;

  const confirm = () => {
    if (draft && isStrictAdISO(draft) && !isDisabledDate(draft, minDate, maxDate, minExclusive, disablePast)) {
      onChange(draft);
      setOpen(false);
    }
  };

  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${label}: ${value ? formatDualDisplay(value) : placeholder}`}
        disabled={disabled}
        onPress={() => setOpen(true)}
        style={[styles.box, disabled && styles.boxDisabled, !!error && styles.boxError]}
      >
        <View style={styles.boxTextWrap}>
          <Text style={[styles.boxText, !value && styles.boxPlaceholder]} numberOfLines={1}>
            {value && isStrictAdISO(value) ? formatDualDisplay(value) : placeholder}
          </Text>
        </View>
        <Ionicons name="calendar-outline" size={20} color={colors.primary} />
      </Pressable>
      {!!error && <Text style={styles.error}>{error}</Text>}

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <View style={styles.backdrop}>
          <View style={[styles.modal, compact && styles.modalCompact]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{label}</Text>
              <Pressable onPress={() => setOpen(false)} accessibilityLabel="Close calendar">
                <Ionicons name="close" size={24} color={colors.text} />
              </Pressable>
            </View>

            <View style={styles.toggleRow}>
              {(["AD", "BS"] as const).map((mode) => (
                <Pressable
                  key={mode}
                  accessibilityRole="button"
                  accessibilityState={{ selected: calendar === mode }}
                  onPress={() => setCalendar(mode)}
                  style={[styles.toggle, calendar === mode && styles.toggleActive]}
                >
                  <Text style={[styles.toggleText, calendar === mode && styles.toggleTextActive]}>
                    {mode === "AD" ? "AD (English)" : "BS (Nepali)"}
                  </Text>
                </Pressable>
              ))}
            </View>

            <View style={styles.monthRow}>
              <Pressable
                accessibilityLabel="Previous month"
                style={styles.navBtn}
                onPress={() => {
                  if (calendar === "AD") setAdView((v) => shiftMonth(v.year, v.month, -1));
                  else setBsView((v) => shiftMonth(v.year, v.month, -1));
                }}
              >
                <Ionicons name="chevron-back" size={22} color={colors.text} />
              </Pressable>
              <Text style={styles.monthLabel}>
                {calendar === "AD"
                  ? `${AD_MONTHS[adView.month - 1]} ${adView.year}`
                  : `${bsNames[bsView.month - 1]} ${bsView.year}`}
              </Text>
              <Pressable
                accessibilityLabel="Next month"
                style={styles.navBtn}
                onPress={() => {
                  if (calendar === "AD") setAdView((v) => shiftMonth(v.year, v.month, 1));
                  else setBsView((v) => shiftMonth(v.year, v.month, 1));
                }}
              >
                <Ionicons name="chevron-forward" size={22} color={colors.text} />
              </Pressable>
            </View>

            <View style={styles.weekRow}>
              {WEEKDAYS.map((day) => (
                <Text key={day} style={styles.weekText}>{day}</Text>
              ))}
            </View>
            <ScrollView style={styles.gridScroll} contentContainerStyle={styles.grid}>
              {cells.map((iso, index) => {
                if (!iso) return <View key={`blank-${index}`} style={styles.day} />;
                const selectable = !iso.startsWith("bs:") && !isDisabledDate(iso, minDate, maxDate, minExclusive, disablePast);
                const selected = iso === draft;
                return (
                  <Pressable
                    key={`${iso}-${index}`}
                    disabled={!selectable}
                    onPress={() => setDraft(iso)}
                    accessibilityRole="button"
                    accessibilityState={{ selected, disabled: !selectable }}
                    style={[styles.day, selected && styles.daySelected, !selectable && styles.dayDisabled]}
                  >
                    <Text style={[styles.dayText, selected && styles.dayTextSelected, !selectable && styles.dayTextDisabled]}>
                      {cellLabel(iso, index)}
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>

            <View style={styles.footer}>
              {footer ? (
                <View>
                  <Text style={styles.footerLine}>{footer.ad}</Text>
                  <Text style={styles.footerLine}>{footer.bs}</Text>
                </View>
              ) : (
                <Text style={styles.footerHint}>Pick a date from the calendar.</Text>
              )}
            </View>

            <View style={styles.actions}>
              <Pressable style={styles.cancelBtn} onPress={() => setOpen(false)}>
                <Text style={styles.cancelText}>Cancel</Text>
              </Pressable>
              <Pressable
                style={[styles.selectBtn, (!draft || !isStrictAdISO(draft) || isDisabledDate(draft, minDate, maxDate, minExclusive, disablePast)) && styles.selectBtnDisabled]}
                onPress={confirm}
              >
                <Text style={styles.selectText}>Select Date</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  field: { marginBottom: spacing.md },
  label: { fontSize: 12, fontWeight: "700", color: "#52657A", marginBottom: 6 },
  box: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    minHeight: 48,
    gap: spacing.sm,
  },
  boxDisabled: { opacity: 0.6 },
  boxError: { borderColor: "#EF4444" },
  boxTextWrap: { flex: 1 },
  boxText: { color: colors.text, fontSize: 14 },
  boxPlaceholder: { color: "#9CA3AF" },
  error: { color: "#DC2626", fontSize: 12, marginTop: 4 },
  backdrop: { flex: 1, justifyContent: "center", alignItems: "center", padding: 18, backgroundColor: "rgba(15,23,42,0.45)" },
  modal: { width: "100%", maxWidth: 480, maxHeight: "92%", borderRadius: 18, backgroundColor: colors.surface, padding: 20 },
  modalCompact: { padding: 14 },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  modalTitle: { color: colors.text, fontSize: 17, fontWeight: "800" },
  toggleRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  toggle: { flex: 1, minHeight: 42, alignItems: "center", justifyContent: "center", borderRadius: 10, borderWidth: 1, borderColor: colors.border, backgroundColor: "#F8FAFC" },
  toggleActive: { backgroundColor: "#D1FAE5", borderColor: "#A7F3D0" },
  toggleText: { color: colors.textMuted, fontSize: 13, fontWeight: "700" },
  toggleTextActive: { color: "#047857" },
  monthRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  navBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center", borderRadius: 10, backgroundColor: "#F1F5F9" },
  monthLabel: { color: colors.text, fontSize: 16, fontWeight: "800" },
  weekRow: { flexDirection: "row", marginBottom: 4 },
  weekText: { flex: 1, textAlign: "center", color: colors.textMuted, fontSize: 11, fontWeight: "700", paddingVertical: 6 },
  gridScroll: { maxHeight: 330 },
  grid: { flexDirection: "row", flexWrap: "wrap" },
  day: { width: "14.28%", aspectRatio: 1, alignItems: "center", justifyContent: "center", borderRadius: 10 },
  daySelected: { backgroundColor: colors.primary },
  dayDisabled: { opacity: 0.3 },
  dayText: { color: colors.text, fontSize: 14 },
  dayTextSelected: { color: "#FFFFFF", fontWeight: "800" },
  dayTextDisabled: { color: colors.textMuted },
  footer: { borderTopWidth: 1, borderTopColor: colors.border, marginTop: 10, paddingTop: 10, minHeight: 48 },
  footerLine: { color: "#047857", fontSize: 13, fontWeight: "700" },
  footerHint: { color: colors.textMuted, fontSize: 12 },
  actions: { flexDirection: "row", justifyContent: "flex-end", gap: 10, marginTop: 12 },
  cancelBtn: { minHeight: 44, paddingHorizontal: 18, alignItems: "center", justifyContent: "center", borderRadius: 10, borderWidth: 1, borderColor: colors.border },
  cancelText: { color: colors.text, fontSize: 14, fontWeight: "700" },
  selectBtn: { minHeight: 44, paddingHorizontal: 22, alignItems: "center", justifyContent: "center", borderRadius: 10, backgroundColor: colors.primary },
  selectBtnDisabled: { opacity: 0.5 },
  selectText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
});
