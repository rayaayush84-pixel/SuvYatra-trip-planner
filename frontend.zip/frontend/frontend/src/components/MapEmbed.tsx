import React from "react";
import { Platform } from "react-native";
import type { MapEmbedProps } from "./MapEmbed.native";

// Platform entry point. Metro resolves the matching implementation:
// MapEmbed.web.tsx on web, MapEmbed.native.tsx on Android/iOS.
// The conditional require keeps react-native-webview out of the web bundle
// entirely, so the web Map never touches it.
const MapEmbed: React.FC<MapEmbedProps> =
  Platform.OS === "web" ? require("./MapEmbed.web").default : require("./MapEmbed.native").default;

export default MapEmbed;
export type { MapEmbedProps };
