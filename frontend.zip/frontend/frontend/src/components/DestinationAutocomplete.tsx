// Destination input for Complete Trip — a thin wrapper over the shared
// LocationAutocomplete, bound to the destination catalog endpoint.
// Same reusable location-search component/service as Origin.

import React from "react";
import LocationAutocomplete from "./LocationAutocomplete";

export type DestinationSummary = {
  _id: string;
  name: string;
  slug?: string;
  province?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
  description?: string;
};

type Props = {
  label?: string;
  placeholder?: string;
  /** Currently selected (validated) destination, if any. */
  selected: DestinationSummary | null;
  onSelect: (destination: DestinationSummary) => void;
  onClear: () => void;
  error?: string;
};

function asList(data: unknown): DestinationSummary[] {
  if (Array.isArray(data)) return data as DestinationSummary[];
  if (data && typeof data === "object") {
    const o = data as Record<string, unknown>;
    if (Array.isArray(o.items)) return o.items as DestinationSummary[];
    if (Array.isArray(o.data)) return o.data as DestinationSummary[];
  }
  return [];
}

export default function DestinationAutocomplete({
  label = "Destination",
  placeholder = "Type to search, e.g. Poka…",
  selected,
  onSelect,
  onClear,
  error,
}: Props) {
  return (
    <LocationAutocomplete
      label={label}
      placeholder={placeholder}
      endpoint="/destinations"
      queryParam="search"
      extract={asList}
      selected={selected}
      onSelect={(item) =>
        onSelect({
          _id: String(item._id ?? item.refId ?? ""),
          name: item.name,
          slug: typeof item.slug === "string" ? item.slug : undefined,
          province: typeof item.province === "string" ? item.province : undefined,
          country: typeof item.country === "string" ? item.country : undefined,
          latitude: typeof item.latitude === "number" ? item.latitude : undefined,
          longitude: typeof item.longitude === "number" ? item.longitude : undefined,
          description: typeof item.description === "string" ? item.description : undefined,
        })
      }
      onClear={onClear}
      error={error}
    />
  );
}
