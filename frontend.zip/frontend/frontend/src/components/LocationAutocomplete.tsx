// Reusable location search/autocomplete input shared by Destination AND
// Origin (same component, same service, same selection semantics).
// Typing alone NEVER validates — the user must pick a recognized record.
// Editing the text after a selection immediately invalidates it.

import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing } from "../theme";
import { BACKEND_BASE_URL } from "../services/backendApi";

export type LocationResult = {
  _id?: string;
  /** Stable record id proving a suggestion was selected. */
  refId?: string;
  name: string;
  formattedAddress?: string;
  kind?: string;
  slug?: string;
  city?: string;
  province?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
  description?: string;
  [key: string]: unknown;
};

type Props = {
  label?: string;
  placeholder?: string;
  /** Search endpoint, e.g. "/locations/search" or "/destinations". */
  endpoint: string;
  /** Query-string parameter name used by the endpoint. */
  queryParam?: string;
  /** Extract the suggestion list from the endpoint response. */
  extract?: (data: unknown) => LocationResult[];
  /** Currently selected (validated) location, if any. */
  selected: LocationResult | null;
  onSelect: (location: LocationResult) => void;
  onClear: () => void;
  error?: string;
};

function defaultExtract(data: unknown): LocationResult[] {
  if (data && typeof data === "object") {
    const o = data as Record<string, unknown>;
    if (Array.isArray(o.locations)) return o.locations as LocationResult[];
  }
  if (Array.isArray(data)) return data as LocationResult[];
  return [];
}

export default function LocationAutocomplete({
  label = "Location",
  placeholder = "Type to search…",
  endpoint,
  queryParam = "q",
  extract = defaultExtract,
  selected,
  onSelect,
  onClear,
  error,
}: Props) {
  const [text, setText] = useState(selected?.name ?? "");
  const [results, setResults] = useState<LocationResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [focused, setFocused] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [highlight, setHighlight] = useState(-1);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);
  const listHolderRef = useRef<any>(null);
  const lastChoice = useRef<{ key: string; at: number }>({ key: "", at: 0 });

  // Single selection path for press, touch, and keyboard. Press-in (pointer
  // down) and click can both fire for one user tap, so rapid duplicates for
  // the same record are ignored — exactly one selection is delivered.
  const choose = (item: LocationResult) => {
    const key = String(item.refId ?? item._id ?? item.name);
    const now = Date.now();
    if (lastChoice.current.key === key && now - lastChoice.current.at < 750) return;
    lastChoice.current = { key, at: now };
    onSelect(item);
    setText(item.name);
    setResults([]);
    setHighlight(-1);
  };

  // Blur hides the dropdown — EXCEPT when focus moves into the suggestion
  // list itself (clicking/tapping a suggestion button). Without this guard
  // the list unmounts mid-click and the selection is lost.
  const handleBlur = (e: any) => {
    try {
      const related = e?.nativeEvent?.relatedTarget as unknown as Node | null;
      const holder = listHolderRef.current as unknown as Node | null;
      if (related && holder && typeof holder.contains === "function" && holder.contains(related)) {
        return;
      }
    } catch {
      // Fall through to hiding the dropdown.
    }
    setFocused(false);
  };

  // Keep the input in sync when the parent sets a location externally
  // (e.g. popular list, preselect handoff). Deliberately one-way: when the
  // selection becomes null because the USER IS TYPING (onClear from
  // onChangeText/X is handled locally), the typed text must be preserved —
  // syncing "" here would erase each keystroke after a selection.
  useEffect(() => {
    if (selected) setText(selected.name);
  }, [selected?.refId, selected?._id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (debounce.current) clearTimeout(debounce.current);
    const query = text.trim();
    // Don't re-search the already-selected location.
    if (!query || (selected && query.toLowerCase() === selected.name.toLowerCase())) {
      setResults([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    debounce.current = setTimeout(() => {
      void (async () => {
        try {
          const response = await fetch(
            `${BACKEND_BASE_URL}${endpoint}?${queryParam}=${encodeURIComponent(query)}`
          );
          const data = await response.json().catch(() => []);
          if (!response.ok) throw new Error("Could not search locations.");
          setResults(extract(data).slice(0, 8));
          setHighlight(-1);
          setLoadError("");
        } catch (requestError) {
          setResults([]);
          setLoadError(requestError instanceof Error ? requestError.message : "Could not search locations.");
        } finally {
          setLoading(false);
        }
      })();
    }, 350);
    return () => {
      if (debounce.current) clearTimeout(debounce.current);
    };
  }, [text]); // eslint-disable-line react-hooks/exhaustive-deps

  const showList = focused && !selected && (results.length > 0 || loading);
  const selectedSubtitle =
    selected?.formattedAddress ||
    [selected?.province, selected?.country].filter(Boolean).join(", ");
  // Avoid "Kathmandu, Kathmandu, Bagmati, Nepal" when the address already
  // starts with the name.
  const selectedDisplay = !selected
    ? ""
    : selectedSubtitle && selectedSubtitle.toLowerCase().startsWith(selected.name.toLowerCase())
      ? selectedSubtitle
      : selectedSubtitle
        ? `${selected.name}, ${selectedSubtitle}`
        : selected.name;

  // Keyboard navigation: arrows move the highlight, Enter picks it, Escape
  // closes. Enter only selects when the dropdown is open with results —
  // otherwise it does nothing here, so surrounding form actions are safe.
  const handleKeyPress = (key: string) => {
    if (key === "ArrowDown" || key === "ArrowUp") {
      if (!results.length) return;
      setHighlight((current) => {
        const delta = key === "ArrowDown" ? 1 : -1;
        const next = current + delta;
        if (next < 0) return results.length - 1;
        if (next >= results.length) return 0;
        return next;
      });
    } else if (key === "Enter") {
      const pick = highlight >= 0 && highlight < results.length
        ? results[highlight]
        : results.length > 0 ? results[0] : null;
      if (showList && pick) choose(pick);
    } else if (key === "Escape") {
      setResults([]);
      setHighlight(-1);
    }
  };

  return (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.box, !!error && styles.boxError]}>
        <Ionicons name="location-outline" size={18} color={colors.textMuted} />
        <TextInput
          value={text}
          onChangeText={(value) => {
            setText(value);
            // Free typing invalidates any previous selection (clears the
            // stored place id / coordinates with it).
            if (selected) onClear();
          }}
          onFocus={() => setFocused(true)}
          onBlur={handleBlur}
          onKeyPress={({ nativeEvent }) => handleKeyPress(nativeEvent.key)}
          onSubmitEditing={() => {
            if (showList && results.length > 0) {
              choose(highlight >= 0 && highlight < results.length ? results[highlight] : results[0]);
            }
          }}
          placeholder={placeholder}
          placeholderTextColor="#9CA3AF"
          style={styles.input}
          autoCapitalize="words"
          autoCorrect={false}
          returnKeyType="search"
        />
        {loading ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : selected || text ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Clear ${label.toLowerCase()}`}
            onPress={() => {
              setText("");
              setResults([]);
              onClear();
            }}
          >
            <Ionicons name="close-circle" size={20} color={colors.textMuted} />
          </Pressable>
        ) : null}
      </View>
      {!!error && <Text style={styles.error}>{error}</Text>}
      {!!loadError && <Text style={styles.hint}>{loadError}</Text>}
      {selected ? (
        <Text style={styles.selected}>Selected: {selectedDisplay}</Text>
      ) : null}
      {showList ? (
        <View ref={listHolderRef} style={styles.list}>
          {results.map((item, index) => (
            <Pressable
              // One record can match as two different hubs (e.g. both ends of
              // one transport route), so the key must include the matched
              // name — the backend guarantees names are unique per result set.
              key={`${String(item.refId ?? item._id ?? "")}|${String(item.name ?? index)}`}
              accessibilityRole="button"
              accessibilityLabel={`Select ${item.name}`}
              accessibilityState={{ selected: index === highlight }}
              style={[styles.row, index === highlight && styles.rowHighlighted]}
              // Both handlers deliver to the same guarded choose():
              // onPressIn covers touch (responder grant on touchstart);
              // onPress covers mouse click (the blur guard above keeps the
              // row mounted until the click dispatches).
              onPressIn={() => choose(item)}
              onPress={() => choose(item)}
            >
              <Ionicons name="location" size={16} color={colors.primary} />
              <View style={styles.rowText}>
                <Text style={styles.rowTitle}>{item.name}</Text>
                <Text style={styles.rowSub}>
                  {item.formattedAddress ||
                    [item.province, item.country].filter(Boolean).join(", ") ||
                    "Nepal"}
                </Text>
              </View>
            </Pressable>
          ))}
          {!loading && results.length === 0 && text.trim() ? (
            <Text style={styles.noMatch}>
              No matching location — keep typing or pick from the list.
            </Text>
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  field: { marginBottom: spacing.md, zIndex: 5 },
  label: { fontSize: 12, fontWeight: "700", color: "#52657A", marginBottom: 6 },
  box: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    minHeight: 48,
    gap: spacing.sm,
  },
  boxError: { borderColor: "#EF4444" },
  input: { flex: 1, color: colors.text, fontSize: 14 },
  error: { color: "#DC2626", fontSize: 12, marginTop: 4 },
  hint: { color: colors.textMuted, fontSize: 11, marginTop: 4 },
  selected: { color: "#047857", fontSize: 12, fontWeight: "700", marginTop: 4 },
  list: {
    marginTop: 6,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    backgroundColor: colors.surface,
    overflow: "hidden",
    zIndex: 10,
    elevation: 4,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 12, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
  rowHighlighted: { backgroundColor: "#ECFDF5" },
  rowText: { flex: 1 },
  rowTitle: { color: colors.text, fontSize: 14, fontWeight: "700" },
  rowSub: { color: colors.textMuted, fontSize: 11 },
  noMatch: { color: colors.textMuted, fontSize: 12, padding: 12 },
});
