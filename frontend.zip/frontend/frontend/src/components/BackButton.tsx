import React, { useState } from "react";
import {
  Pressable,
  StyleProp,
  StyleSheet,
  ViewStyle,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

type NavigationLike = {
  canGoBack: () => boolean;
  goBack: () => void;
};

type Props = {
  navigation: NavigationLike;
  label?: string;
  iconColor?: string;
  iconSize?: number;
  style?: StyleProp<ViewStyle>;
  onFallback?: () => void;
};

export default function BackButton({
  navigation,
  label = "Go back",
  iconColor = "#0F172A",
  iconSize = 23,
  style,
  onFallback,
}: Props) {
  const [focused, setFocused] = useState(false);
  const canGoBack = navigation.canGoBack();

  if (!canGoBack && !onFallback) return null;

  return (
    <Pressable
      style={[styles.button, focused && styles.focused, style]}
      onPress={() => {
        if (navigation.canGoBack()) {
          navigation.goBack();
        } else {
          onFallback?.();
        }
      }}
      hitSlop={8}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityHint="Returns to the previous screen"
      focusable
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
    >
      <Ionicons name="arrow-back" size={iconSize} color={iconColor} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minWidth: 44,
    minHeight: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 22,
  },
  focused: {
    borderWidth: 2,
    borderColor: "#0F766E",
  },
});
