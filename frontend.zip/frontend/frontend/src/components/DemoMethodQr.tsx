import React from "react";
import { StyleSheet, Text, View } from "react-native";
import QRCode from "react-native-qrcode-svg";
import { colors, radius, spacing } from "../theme";
import { brandFor } from "../payments/methods";

export type DemoQrStatus = "pending" | "paid";

type Props = {
  method: string;
  amount: number;
  currency?: string;
  bookingCode: string;
  /** Label for the reference line: "Booking" (standalone) or "Trip" (complete-trip checkout). */
  codeLabel?: string;
  /** Structured JSON payload — the actual scannable content (dynamic per method + amount). */
  payload: string;
  status: DemoQrStatus;
};

/**
 * Method-branded demo QR card shared by every payment entry point.
 * Demo only: always labeled as such; never claims a real gateway transfer.
 */
export default function DemoMethodQr({ method, amount, currency = "NPR", bookingCode, codeLabel = "Booking", payload, status }: Props) {
  const brand = brandFor(method);
  return (
    <View style={[styles.box, { borderColor: brand.color, backgroundColor: brand.softBg }]}>
      <View style={styles.headerRow}>
        <View style={[styles.badge, { backgroundColor: brand.color }]}>
          <Text style={styles.badgeText}>{brand.label}</Text>
        </View>
        <Text style={styles.demoTag}>DEMO — NO REAL MONEY</Text>
      </View>
      <Text style={styles.amount}>
        {currency} {Number(amount).toLocaleString("en-IN")}
      </Text>
      <Text style={styles.booking}>{codeLabel}: {bookingCode}</Text>
      <Text style={styles.scanText}>{brand.scanText}</Text>
      <View style={styles.qrFrame}>
        <QRCode value={payload} size={200} />
      </View>
      <Text style={styles.status}>
        {status === "paid" ? "Payment Status: Successful ✓" : "Payment Status: Pending"}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  box: { borderWidth: 1.5, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm, alignItems: "center", gap: 6 },
  headerRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  badge: { borderRadius: radius.sm, paddingVertical: 4, paddingHorizontal: 12 },
  badgeText: { color: "#FFFFFF", fontSize: 14, fontWeight: "900" },
  demoTag: { color: "#B42318", fontSize: 10, fontWeight: "900" },
  amount: { color: colors.text, fontSize: 22, fontWeight: "900" },
  booking: { color: colors.textMuted, fontSize: 12, fontWeight: "700" },
  scanText: { color: colors.text, fontSize: 13, fontWeight: "700", textAlign: "center" },
  qrFrame: { backgroundColor: "#FFFFFF", borderRadius: radius.sm, padding: spacing.md, borderWidth: 1, borderColor: colors.border },
  status: { color: colors.textMuted, fontSize: 12, fontWeight: "800" },
});
