import React from "react";
import { StyleSheet } from "react-native";

export type MapEmbedProps = {
  uri: string;
  title?: string;
};

// Web implementation: a real interactive Google Map rendered in a plain
// iframe. react-native-webview is intentionally never imported here so the
// web bundle stays free of it.
export default function MapEmbedWeb({ uri, title = "Google Map" }: MapEmbedProps) {
  return React.createElement("iframe", {
    src: uri,
    title,
    loading: "lazy",
    allowFullScreen: true,
    style: StyleSheet.flatten({
      width: "100%",
      height: "100%",
      borderWidth: 0,
    }),
  });
}
