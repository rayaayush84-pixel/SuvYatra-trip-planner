import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing } from "../theme";
import type { DemoQrPayload } from "../payments/demoQr";

type ValidationResult =
  | { ok: true; payload: DemoQrPayload }
  | { ok: false; error: string };

type Props = {
  visible: boolean;
  /** Shown in the header so the user scans for the right booking. */
  bookingLabel: string;
  /** Strict validator bound to the booking being paid (parent-owned). */
  validate: (raw: string) => ValidationResult;
  /** Called exactly once per valid scan; parent confirms with the backend. */
  onSuccess: (payload: DemoQrPayload) => void;
  onClose: () => void;
};

const IS_WEB = Platform.OS === "web";

export default function DemoQrScanner({ visible, bookingLabel, validate, onSuccess, onClose }: Props) {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanError, setScanError] = useState("");
  const [manualEntry, setManualEntry] = useState("");
  const [manualMode, setManualMode] = useState(IS_WEB);
  const [checking, setChecking] = useState(false);
  const lockedRef = useRef(false);
  const onSuccessRef = useRef(onSuccess);
  onSuccessRef.current = onSuccess;

  useEffect(() => {
    if (visible) {
      lockedRef.current = false;
      setScanError("");
      setManualEntry("");
      setChecking(false);
      setManualMode(IS_WEB);
    }
  }, [visible]);

  const handleRawData = useCallback(
    (raw: string) => {
      if (lockedRef.current) return;
      const result = validate(raw);
      if (result.ok) {
        lockedRef.current = true;
        onSuccessRef.current(result.payload);
      } else {
        // Brief lock to avoid error spam from continuous scanning, then allow retry.
        lockedRef.current = true;
        setScanError(result.error);
        setTimeout(() => {
          lockedRef.current = false;
        }, 2000);
      }
    },
    [validate]
  );

  const submitManual = useCallback(() => {
    if (checking) return;
    setChecking(true);
    try {
      handleRawData(manualEntry);
    } finally {
      setChecking(false);
    }
  }, [checking, handleRawData, manualEntry]);

  const permissionGranted = permission?.granted === true;
  const showCamera = !IS_WEB && permissionGranted && !manualMode;

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Pressable onPress={onClose} accessibilityRole="button" accessibilityLabel="Cancel scanning" style={styles.headerBtn}>
            <Ionicons name="close" size={24} color={colors.text} />
          </Pressable>
          <View style={styles.headerText}>
            <Text style={styles.title}>Scan payment QR</Text>
            <Text style={styles.subtitle}>{bookingLabel}</Text>
          </View>
          <View style={styles.headerSpacer} />
        </View>

        <Text style={styles.instructions}>Point the camera at the demo QR code shown for this booking.</Text>

        {showCamera ? (
          <View style={styles.previewWrap}>
            <CameraView
              style={styles.preview}
              facing="back"
              barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
              onBarcodeScanned={(event) => handleRawData(event.data)}
            />
            <View style={styles.frame} pointerEvents="none" />
          </View>
        ) : (
          <View style={styles.fallbackBox}>
            {IS_WEB ? (
              <Text style={styles.muted}>Browser camera scanning is not supported here. Paste the exact QR payload text shown under the QR code instead — it is validated the same way.</Text>
            ) : !permission ? (
              <ActivityIndicator color={colors.primary} />
            ) : !permissionGranted ? (
              <View style={{ gap: spacing.sm }}>
                <Text style={styles.muted}>Camera access is needed to scan the demo QR code. You can grant access or enter the payload manually.</Text>
                <Pressable style={styles.primaryBtn} onPress={() => void requestPermission()}>
                  <Text style={styles.primaryBtnText}>Allow camera</Text>
                </Pressable>
              </View>
            ) : null}
          </View>
        )}

        {!!scanError && <Text style={styles.error}>{scanError}</Text>}

        {!manualMode && !IS_WEB ? (
          <Pressable style={styles.ghostBtn} onPress={() => setManualMode(true)}>
            <Text style={styles.ghostBtnText}>Enter QR payload manually instead</Text>
          </Pressable>
        ) : null}

        {manualMode ? (
          <View style={styles.manualBox}>
            <Text style={styles.label}>Demo QR payload (manual entry — validated identically)</Text>
            <TextInput
              value={manualEntry}
              onChangeText={setManualEntry}
              placeholder="Paste the QR payload text"
              placeholderTextColor={colors.textMuted}
              multiline
              autoCapitalize="none"
              autoCorrect={false}
              style={styles.input}
            />
            <Pressable style={styles.primaryBtn} onPress={submitManual} disabled={checking}>
              <Text style={styles.primaryBtnText}>{checking ? "Validating…" : "Validate QR payload"}</Text>
            </Pressable>
            {!IS_WEB && permissionGranted ? (
              <Pressable style={styles.ghostBtn} onPress={() => setManualMode(false)}>
                <Text style={styles.ghostBtnText}>Back to camera</Text>
              </Pressable>
            ) : null}
          </View>
        ) : null}

        <Pressable style={styles.cancelBtn} onPress={onClose}>
          <Text style={styles.cancelText}>Cancel</Text>
        </Pressable>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.lg, gap: spacing.md },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  headerBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerText: { flex: 1 },
  headerSpacer: { width: 40 },
  title: { color: colors.text, fontSize: 19, fontWeight: "900" },
  subtitle: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  instructions: { color: colors.text, fontSize: 13, lineHeight: 19 },
  previewWrap: { height: 320, borderRadius: radius.lg, overflow: "hidden", backgroundColor: "#0B1512", position: "relative" },
  preview: { flex: 1 },
  frame: { position: "absolute", left: "15%", right: "15%", top: "18%", bottom: "18%", borderWidth: 3, borderColor: "#14B8A6", borderRadius: radius.md },
  fallbackBox: { borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, padding: spacing.md },
  muted: { color: colors.textMuted, fontSize: 12, lineHeight: 18 },
  error: { color: "#B42318", fontSize: 13, lineHeight: 19, fontWeight: "700" },
  ghostBtn: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, minHeight: 42, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md },
  ghostBtnText: { color: colors.textMuted, fontSize: 12, fontWeight: "700" },
  manualBox: { gap: spacing.sm },
  label: { color: colors.textMuted, fontSize: 11, fontWeight: "700" },
  input: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, backgroundColor: colors.surface, minHeight: 88, paddingHorizontal: spacing.sm, paddingTop: spacing.sm, color: colors.text, fontSize: 12, textAlignVertical: "top" },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: radius.sm, minHeight: 44, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md },
  primaryBtnText: { color: colors.white, fontSize: 13, fontWeight: "800" },
  cancelBtn: { minHeight: 44, alignItems: "center", justifyContent: "center" },
  cancelText: { color: colors.text, fontSize: 13, fontWeight: "800" },
});
